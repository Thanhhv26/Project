-- Database: bi
-- DROP DATABASE bi;
CREATE DATABASE bi
  WITH OWNER = test01
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'ja_JP.UTF-8'
       LC_CTYPE = 'ja_JP.UTF-8'
       CONNECTION LIMIT = 20;
	   
GRANT ALL PRIVILEGES  ON database bi TO test01;