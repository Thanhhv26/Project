--drop table biorcl12cr2.test_1000000_record;
create table biorcl12cr2.test_1000000_record (
  varchar01 character varying(2000) not null
  , varchar02 character varying(2000)
  , varchar03 character varying(2000)
  , varchar04 character varying(2000)
  , varchar05 character varying(2000)
  , varchar06 character varying(2000)
  , varchar07 character varying(2000)
  , varchar08 character varying(2000)
  , varchar09 character varying(2000)
  , varchar10 character varying(2000)
  , primary key (varchar01)
);

BEGIN
  FOR i IN 1..1000000 LOOP
    INSERT INTO biorcl12cr2.test_1000000_record(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
  END LOOP;
END;

select count(*) from biorcl12cr2.test_1000000_record;