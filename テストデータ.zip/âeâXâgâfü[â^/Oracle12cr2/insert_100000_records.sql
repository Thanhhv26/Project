drop table biorcl12cr2.test_500000_record;
create table biorcl12cr2.test_500000_record (
  varchar01 character varying(2000) not null
  , varchar02 character varying(2000)
  , varchar03 character varying(2000)
  , varchar04 character varying(2000)
  , primary key (varchar01)
);

BEGIN
  FOR i IN 1..500000 LOOP
    INSERT INTO biorcl12cr2.test_500000_record(varchar01, varchar02, varchar03, varchar04) 
		VALUES (i, i, i, i);
  END LOOP;
END;

select count(*) from biorcl12cr2.test_500000_record;