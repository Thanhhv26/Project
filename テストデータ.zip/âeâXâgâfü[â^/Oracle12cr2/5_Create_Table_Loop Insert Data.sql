-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--1000000 RECORDS
drop table biorcl12cr2.Test1000000Record;
create table biorcl12cr2.Test1000000Record (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

BEGIN
  FOR i IN 1..1000000 LOOP
    INSERT INTO biorcl12cr2.Test1000000Record(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
  END LOOP;
END;

select count(*) from biorcl12cr2.Test1000000Record;
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--750000 RECORDS
drop table biorcl12cr2.Test750000Records;
create table biorcl12cr2.Test750000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

BEGIN
  FOR i IN 1..750000 LOOP
    INSERT INTO biorcl12cr2.Test750000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
  END LOOP;
END;

select count(*) from biorcl12cr2.Test750000Records;
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--500000 RECORDS
drop table biorcl12cr2.Test500000Records;
create table biorcl12cr2.Test500000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

BEGIN
  FOR i IN 1..500000 LOOP
    INSERT INTO biorcl12cr2.Test500000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
  END LOOP;
END;

select count(*) from biorcl12cr2.Test500000Records;
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--250000 RECORDS
drop table biorcl12cr2.Test250000Records;
create table biorcl12cr2.Test250000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

BEGIN
  FOR i IN 1..250000 LOOP
    INSERT INTO biorcl12cr2.Test250000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
  END LOOP;
END;

select count(*) from biorcl12cr2.Test250000Records;