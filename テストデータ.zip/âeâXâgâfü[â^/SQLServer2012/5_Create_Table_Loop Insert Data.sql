﻿--1000000 records
--create table
CREATE TABLE dbo.EXEX_BI_TABLE1000000
(
  varchar01 varchar(200) not null
  , varchar02 varchar(200)
  , varchar03 varchar(200)
  , varchar04 varchar(200)
  , varchar05 varchar(200)
  , varchar06 varchar(200)
  , varchar07 varchar(200)
  , varchar08 varchar(200)
  , varchar09 varchar(200)
  , varchar10 varchar(200)
  , primary key (varchar01)
);
--insert data
DECLARE @i int = 0
WHILE @i < 1000000
BEGIN
    SET @i = @i + 1
	INSERT INTO dbo.EXEX_BI_TABLE1000000(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
	VALUES (@i, @i, @i, @i, @i, @i, @i, @i, @i, @i);
END
--count data
select count(*) from [dbo].[EXEX_BI_TABLE1000000];


--------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------
--750000 records
--create table
CREATE TABLE dbo.EXEX_BI_TABLE750000
(
  varchar01 varchar(200) not null
  , varchar02 varchar(200)
  , varchar03 varchar(200)
  , varchar04 varchar(200)
  , varchar05 varchar(200)
  , varchar06 varchar(200)
  , varchar07 varchar(200)
  , varchar08 varchar(200)
  , varchar09 varchar(200)
  , varchar10 varchar(200)
  , primary key (varchar01)
);
--insert data
DECLARE @i int = 0
WHILE @i < 750000
BEGIN
    SET @i = @i + 1
	INSERT INTO dbo.EXEX_BI_TABLE750000(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
	VALUES (@i, @i, @i, @i, @i, @i, @i, @i, @i, @i);
END
--count data
select count(*) from [dbo].[EXEX_BI_TABLE750000];



--------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------
--500000 records
--create table
CREATE TABLE dbo.EXEX_BI_TABLE500000
(
  varchar01 varchar(200) not null
  , varchar02 varchar(200)
  , varchar03 varchar(200)
  , varchar04 varchar(200)
  , varchar05 varchar(200)
  , varchar06 varchar(200)
  , varchar07 varchar(200)
  , varchar08 varchar(200)
  , varchar09 varchar(200)
  , varchar10 varchar(200)
  , primary key (varchar01)
);
--insert data
DECLARE @i int = 0
WHILE @i < 500000
BEGIN
    SET @i = @i + 1
	INSERT INTO dbo.EXEX_BI_TABLE500000(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
	VALUES (@i, @i, @i, @i, @i, @i, @i, @i, @i, @i);
END
--count data
select count(*) from [dbo].[EXEX_BI_TABLE500000];



--------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------
--250000 records
--create table
CREATE TABLE dbo.EXEX_BI_TABLE250000
(
  varchar01 varchar(200) not null
  , varchar02 varchar(200)
  , varchar03 varchar(200)
  , varchar04 varchar(200)
  , varchar05 varchar(200)
  , varchar06 varchar(200)
  , varchar07 varchar(200)
  , varchar08 varchar(200)
  , varchar09 varchar(200)
  , varchar10 varchar(200)
  , primary key (varchar01)
);
--insert data
DECLARE @i int = 0
WHILE @i < 250000
BEGIN
    SET @i = @i + 1
	INSERT INTO dbo.EXEX_BI_TABLE250000(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
	VALUES (@i, @i, @i, @i, @i, @i, @i, @i, @i, @i);
END
--count data
select count(*) from [dbo].[EXEX_BI_TABLE250000];