--SQLServer: type auto increment
--1. bigint bigint
--2. decimal decimal
--3. int int
--4. numeric numeric
--5. smallint smallint
--6. tinyint tinyint


-- bigint
DROP TABLE IF EXISTS dbo.auto_increment_bigint;
CREATE TABLE dbo.auto_increment_bigint
(
	id bigint not null identity(1,1) primary key,
	name varchar(100) not null,
	address varchar(100) null
);
-- decimal
DROP TABLE IF EXISTS dbo.auto_increment_decimal;
CREATE TABLE dbo.auto_increment_decimal
(
	id decimal not null identity(1,1) primary key,
	name varchar(100) not null,
	address varchar(100) null
);
-- int
DROP TABLE IF EXISTS dbo.auto_increment_int;
CREATE TABLE dbo.auto_increment_int
(
	id int not null identity(1,1) primary key,
	name varchar(100) not null,
	address varchar(100) null
);
-- numeric
DROP TABLE IF EXISTS dbo.auto_increment_numeric;
CREATE TABLE dbo.auto_increment_numeric
(
	id numeric not null identity(1,1) primary key,
	name varchar(100) not null,
	address varchar(100) null
);
-- smallint
DROP TABLE IF EXISTS dbo.auto_increment_smallint;
CREATE TABLE dbo.auto_increment_smallint
(
	id smallint not null identity(1,1) primary key,
	name varchar(100) not null,
	address varchar(100) null
);
-- tinyint
DROP TABLE IF EXISTS dbo.auto_increment_tinyint;
CREATE TABLE dbo.auto_increment_tinyint
(
	id tinyint not null identity(1,1) primary key,
	name varchar(100) not null,
	address varchar(100) null
);