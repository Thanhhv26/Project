drop table public.thanh_test_300_column;

CREATE OR REPLACE FUNCTION public.create_thanh_test_300_column()
  RETURNS varchar AS
$BODY$
DECLARE 
	res varchar := 'create table thanh_test_300_column(';
BEGIN
  FOR i IN 1..299
	LOOP
		res := res || 'varchar' || i || ' character varying(2000),';
	END LOOP;
	res := res || 'varchar300 character varying(2000)';
	res := res || ')';
  RETURN res;
END;
$BODY$
LANGUAGE plpgsql VOLATILE COST 100;
ALTER FUNCTION public.create_thanh_test_300_column() OWNER TO postgres;

select public.create_thanh_test_300_column();

DO
$$BEGIN
EXECUTE (
   select public.create_thanh_test_300_column()
);
END$$;
