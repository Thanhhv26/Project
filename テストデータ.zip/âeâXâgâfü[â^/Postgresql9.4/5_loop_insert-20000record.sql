drop table public.thanh_test_20000_record;
create table public.thanh_test_20000_record (
  varchar01 character varying(2000) not null
  , varchar02 character varying(2000)
  , varchar03 character varying(2000)
  , varchar04 character varying(2000)
  , primary key (varchar01)
);

CREATE OR REPLACE FUNCTION public.create_thanh_test_20000_record()
  RETURNS void AS
$BODY$
DECLARE 
BEGIN
  FOR i IN 1..20000
	LOOP
		insert into thanh_test_20000_record(varchar01, varchar02, varchar03, varchar04)
		values(''||i, ''||i, ''||i, ''||i);
	END LOOP;
  RETURN;
END;
$BODY$
LANGUAGE plpgsql VOLATILE COST 100;
ALTER FUNCTION public.create_thanh_test_20000_record() OWNER TO postgres;

select public.create_thanh_test_20000_record();

select count(1) from thanh_test_20000_record;
