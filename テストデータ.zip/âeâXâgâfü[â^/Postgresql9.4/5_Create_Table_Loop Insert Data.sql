--1000000 Records
drop table public.Test1000000Records;
create table public.Test1000000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

CREATE OR REPLACE FUNCTION public.Test1000000Records()
  RETURNS void AS
$BODY$
DECLARE 
BEGIN
  FOR i IN 1..1000000
	LOOP
		insert into Test1000000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10)
		values(''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i);
	END LOOP;
  RETURN;
END;
$BODY$
LANGUAGE plpgsql VOLATILE COST 100;
ALTER FUNCTION public.Test1000000Records() OWNER TO postgres;

select public.Test1000000Records();

select count(1) from Test1000000Records;
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--750000 Records
drop table public.Test750000Records;
create table public.Test750000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

CREATE OR REPLACE FUNCTION public.Test750000Records()
  RETURNS void AS
$BODY$
DECLARE 
BEGIN
  FOR i IN 1..750000
	LOOP
		insert into Test750000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10)
		values(''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i);
	END LOOP;
  RETURN;
END;
$BODY$
LANGUAGE plpgsql VOLATILE COST 100;
ALTER FUNCTION public.Test750000Records() OWNER TO postgres;

select public.Test750000Records();

select count(1) from Test750000Records;
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--500000 Records
drop table public.Test500000Records;
create table public.Test500000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

CREATE OR REPLACE FUNCTION public.Test500000Records()
  RETURNS void AS
$BODY$
DECLARE 
BEGIN
  FOR i IN 1..500000
	LOOP
		insert into Test500000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10)
		values(''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i);
	END LOOP;
  RETURN;
END;
$BODY$
LANGUAGE plpgsql VOLATILE COST 100;
ALTER FUNCTION public.Test500000Records() OWNER TO postgres;

select public.Test500000Records();

select count(1) from Test500000Records;
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--250000 Records
drop table public.Test250000Records;
create table public.Test250000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

CREATE OR REPLACE FUNCTION public.Test250000Records()
  RETURNS void AS
$BODY$
DECLARE 
BEGIN
  FOR i IN 1..250000
	LOOP
		insert into Test250000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10)
		values(''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i, ''||i);
	END LOOP;
  RETURN;
END;
$BODY$
LANGUAGE plpgsql VOLATILE COST 100;
ALTER FUNCTION public.Test250000Records() OWNER TO postgres;

select public.Test250000Records();

select count(1) from Test250000Records;
