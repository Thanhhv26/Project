--01. smallint
--02. integer
--03. decimal
--04. numeric
--05. real
--06. double precision
--07. smallserial
--08. serial
--09. bigserial
--10. money

-- smallint
DROP TABLE IF EXISTS public.auto_increment_smallint;
create table public.auto_increment_smallint (
  id smallint default nextval('auto_increment_serial_id_seq'::regclass) not null
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);
-- integer
DROP TABLE IF EXISTS public.auto_increment_integer;
create table public.auto_increment_integer (
  id integer default nextval('auto_increment_serial_id_seq'::regclass) not null
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);
-- decimal
DROP TABLE IF EXISTS public.auto_increment_decimal;
create table public.auto_increment_decimal (
  id decimal default nextval('auto_increment_serial_id_seq'::regclass) not null
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);
-- numeric
DROP TABLE IF EXISTS public.auto_increment_numeric;
create table public.auto_increment_numeric (
  id numeric default nextval('auto_increment_serial_id_seq'::regclass) not null
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);
-- real
DROP TABLE IF EXISTS public.auto_increment_real;
create table public.auto_increment_real (
  id real default nextval('auto_increment_serial_id_seq'::regclass) not null
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);
-- double precision
DROP TABLE IF EXISTS public.auto_increment_double_precision;
create table public.auto_increment_double_precision (
  id double precision default nextval('auto_increment_serial_id_seq'::regclass) not null
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);
-- smallserial
DROP TABLE IF EXISTS public.auto_increment_smallserial;
create table public.auto_increment_smallserial (
  id smallserial
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);
-- bigserial
DROP TABLE IF EXISTS public.auto_increment_bigserial;
create table public.auto_increment_bigserial (
  id bigserial
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);
-- money
DROP TABLE IF EXISTS public.auto_increment_money;
create table public.auto_increment_money (
  id money  default nextval('auto_increment_serial_id_seq'::regclass) not null
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);
-- serial
--DROP TABLE IF EXISTS public.auto_increment_serial;
create table public.auto_increment_serial (
  id serial
  , name character varying(100) not null
  , address character varying(100)
  , primary key (id)
);