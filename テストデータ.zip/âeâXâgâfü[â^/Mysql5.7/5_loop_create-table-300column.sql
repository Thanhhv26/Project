DROP TABLE IF EXISTS TEST.thanh_test_300_column;
CREATE TABLE IF NOT EXISTS TEST.thanh_test_300_column(
	column1 VARCHAR(20)
);

DROP PROCEDURE IF EXISTS TEST.create_thanh_test_300_column;
DELIMITER //
CREATE PROCEDURE TEST.create_thanh_test_300_column()
BEGIN
	DECLARE i INT DEFAULT 2;
    WHILE i <= 300 DO
		SET @k = i;
		SET @TEMP = CONCAT('ALTER TABLE TEST.thanh_test_300_column ADD column3', @k, ' varchar(20);');
		PREPARE stmt FROM @TEMP;
		EXECUTE stmt;
		SET i = i + 1;
    END WHILE;
END;
//DELIMITER ;

CALL create_thanh_test_300_column();