-------------------------
CREATE USER 'DME'@'localhost' IDENTIFIED BY '123456x@X';
-------------------------
GRANT CREATE  ON TEST.* TO 'MDE'@'localhost' IDENTIFIED BY '123456X@x';
-------------------------
GRANT DROP  ON TEST.* TO 'MDE'@'localhost' IDENTIFIED BY '123456X@x';
-------------------------
GRANT DELETE  ON TEST.* TO 'MDE'@'localhost'IDENTIFIED BY '123456X@x';
-------------------------
GRANT INSERT  ON TEST.* TO 'MDE'@'localhost' IDENTIFIED BY '123456X@x';
-------------------------
GRANT UPDATE  ON TEST.* TO 'MDE'@'localhost' IDENTIFIED BY '123456X@x';