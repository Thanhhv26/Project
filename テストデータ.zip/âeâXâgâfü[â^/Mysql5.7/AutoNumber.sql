--自動連番で
--[SERIAL]
DROP TABLE IF EXISTS TEST.AutoNumber_SERIAL_自動連番で;
CREATE TABLE TEST.AutoNumber_SERIAL_自動連番で(
　　id SERIAL PRIMARY KEY,
　　name VARCHAR(50) NULL
);

--シーケンスキーで
--[INT, TINYINT, SMALLINT, MEDIUMINT, BIGINT, FLOAT, DOUBLE]
-- INT
DROP TABLE IF EXISTS TEST.AutoNumber_INT_シーケンスキーで;
CREATE TABLE TEST.AutoNumber_INT_シーケンスキーで (
  id INT PRIMARY KEY AUTO_INCREMENT, 
  name character varying(100) not null
);
-- TINYINT
DROP TABLE IF EXISTS TEST.AutoNumber_TINYINT_シーケンスキーで;
CREATE TABLE TEST.AutoNumber_TINYINT_シーケンスキーで (
  id TINYINT PRIMARY KEY AUTO_INCREMENT,
  name character varying(100) not null
);
-- SMALLINT
DROP TABLE IF EXISTS TEST.AutoNumber_SMALLINT_シーケンスキーで;
CREATE TABLE TEST.AutoNumber_SMALLINT_シーケンスキーで (
  id SMALLINT PRIMARY KEY AUTO_INCREMENT,
  name character varying(100) not null
);
-- MEDIUMINT
DROP TABLE IF EXISTS TEST.AutoNumber_MEDIUMINT_シーケンスキーで;
CREATE TABLE TEST.AutoNumber_MEDIUMINT_シーケンスキーで (
  id MEDIUMINT PRIMARY KEY AUTO_INCREMENT,
   name character varying(100) not null
);
-- BIGINT
DROP TABLE IF EXISTS TEST.AutoNumber_BIGINT_シーケンスキーで;
CREATE TABLE TEST.AutoNumber_BIGINT_シーケンスキーで (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  name character varying(100) not null
);
-- FLOAT
DROP TABLE IF EXISTS TEST.AutoNumber_FLOAT_シーケンスキーで;
CREATE TABLE TEST.AutoNumber_FLOAT_シーケンスキーで (
  id FLOAT PRIMARY KEY AUTO_INCREMENT,
  name character varying(100) not null
);
-- DOUBLE
DROP TABLE IF EXISTS TEST.AutoNumber_DOUBLE_シーケンスキーで;
CREATE TABLE TEST.AutoNumber_DOUBLE_シーケンスキーで (
  id DOUBLE PRIMARY KEY AUTO_INCREMENT,
  name character varying(100) not null
);
