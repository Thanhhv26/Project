drop table if exists TEST.Test_1000000_records;
create table if not exists TEST.Test_1000000_records (
  varchar01 character varying(2000) not null
  , varchar02 character varying(2000)
  , varchar03 character varying(2000)
  , varchar04 character varying(2000)
  , varchar05 character varying(2000)
  , varchar06 character varying(2000)
  , varchar07 character varying(2000)
  , varchar08 character varying(2000)
  , varchar09 character varying(2000)
  , varchar10 character varying(2000)
  , primary key (varchar01)
);

DROP PROCEDURE IF EXISTS TEST.Test_1000000_records;
DELIMITER //
CREATE PROCEDURE TEST.Test_1000000_records()
BEGIN
	DECLARE i INT DEFAULT 0;
    WHILE i < 1000000 DO
        INSERT INTO TEST.Test_1000000_records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
		SET i = i + 1;
    END WHILE;
END;
//DELIMITER ;

CALL TEST.Test_1000000_records();

