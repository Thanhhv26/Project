drop table public.thanh_test_300_column;

CREATE OR REPLACE FUNCTION public.insert_data_thanh_test_300_column()
  RETURNS varchar AS
$BODY$
DECLARE 
	result1 varchar := 'insert into thanh_test_300_column(';
	result2 varchar := '';
	resultFinal varchar := '';
BEGIN
	--
	FOR i IN 1..299 LOOP
		result1 := result1 || 'varchar' || i ||', ';
	END LOOP;
	result1 := result1 || 'varchar300';
	result1 := result1 || ') ';

	--	
	FOR j IN 1..10 LOOP
		result2 := 'values(';
		FOR i IN 1..299 LOOP
			result2 := result2 || j || ', ';
		END LOOP;
		result2 := result2 || j;
		result2 := result2 || '); ';
	resultFinal := 	resultFinal || result1 || result2;
	END LOOP;
  RETURN resultFinal;
END;
$BODY$
LANGUAGE plpgsql VOLATILE COST 100;
ALTER FUNCTION public.create_thanh_test_300_column() OWNER TO postgres;

select public.insert_data_thanh_test_300_column();

DO $$BEGIN EXECUTE ( select public.insert_data_thanh_test_300_column() ); END$$;
