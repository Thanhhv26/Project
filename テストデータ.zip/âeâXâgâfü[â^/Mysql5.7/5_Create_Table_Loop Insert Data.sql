﻿------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
--1000000 RECORDS
drop table if exists TEST.Test1000000Records;
create table if not exists TEST.Test1000000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

DROP PROCEDURE IF EXISTS TEST.Test1000000Records;
DELIMITER //
CREATE PROCEDURE TEST.Test1000000Records()
BEGIN
	DECLARE i INT DEFAULT 0;
    WHILE i < 1000000 DO
        INSERT INTO TEST.Test1000000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
		SET i = i + 1;
    END WHILE;
END;
//DELIMITER ;

CALL TEST.Test1000000Records();

SELECT COUNT(*) FROM TEST.Test1000000Records;
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
--750000 RECORDS
drop table if exists TEST.Test750000Records;
create table if not exists TEST.Test750000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

DROP PROCEDURE IF EXISTS TEST.Test750000Records;
DELIMITER //
CREATE PROCEDURE TEST.Test750000Records()
BEGIN
	DECLARE i INT DEFAULT 0;
    WHILE i < 750000 DO
        INSERT INTO TEST.Test750000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
		SET i = i + 1;
    END WHILE;
END;
//DELIMITER ;

CALL TEST.Test750000Records();

SELECT COUNT(*) FROM TEST.Test750000Records;
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
--500000 RECORDS
drop table if exists TEST.Test500000Records;
create table if not exists TEST.Test500000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

DROP PROCEDURE IF EXISTS TEST.Test500000Records;
DELIMITER //
CREATE PROCEDURE TEST.Test500000Records()
BEGIN
	DECLARE i INT DEFAULT 0;
    WHILE i < 500000 DO
        INSERT INTO TEST.Test500000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
		SET i = i + 1;
    END WHILE;
END;
//DELIMITER ;

CALL TEST.Test500000Records();

SELECT COUNT(*) FROM TEST.Test500000Records;
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
--250000 RECORDS
drop table if exists TEST.Test250000Records;
create table if not exists TEST.Test250000Records (
  varchar01 character varying(200) not null
  , varchar02 character varying(200)
  , varchar03 character varying(200)
  , varchar04 character varying(200)
  , varchar05 character varying(200)
  , varchar06 character varying(200)
  , varchar07 character varying(200)
  , varchar08 character varying(200)
  , varchar09 character varying(200)
  , varchar10 character varying(200)
  , primary key (varchar01)
);

DROP PROCEDURE IF EXISTS TEST.Test250000Records;
DELIMITER //
CREATE PROCEDURE TEST.Test250000Records()
BEGIN
	DECLARE i INT DEFAULT 0;
    WHILE i < 250000 DO
        INSERT INTO TEST.Test250000Records(varchar01, varchar02, varchar03, varchar04, varchar05, varchar06, varchar07, varchar08, varchar09, varchar10) 
		VALUES (i, i, i, i, i, i, i, i, i, i);
		SET i = i + 1;
    END WHILE;
END;
//DELIMITER ;

CALL TEST.Test250000Records();

SELECT COUNT(*) FROM TEST.Test250000Records;