-- Creates the login DME with password 'DME@sql2014'.
CREATE LOGIN DME 
    WITH PASSWORD = 'User@2014!';
USE test;
GO

-- Creates a database user for the login created above.
CREATE USER DME FOR LOGIN DME
WITH DEFAULT_SCHEMA = dbo;
EXEC SP_ADDROLEMEMBER 'DB_OWNER', 'DME';
GO

-- Granting INSERT permission on schema dbo to DME
GRANT INSERT ON SCHEMA :: dbo TO DME;

GRANT UPDATE ON SCHEMA :: dbo TO DME;

GRANT DELETE ON SCHEMA :: dbo TO DME;

GRANT ALTER ON SCHEMA :: dbo TO DME;

GRANT CONTROL ON SCHEMA :: dbo TO DME;

GRANT CREATE SEQUENCE ON SCHEMA :: dbo TO DME;

GRANT EXECUTE ON SCHEMA :: dbo TO DME WITH GRANT OPTION;

GRANT REFERENCES ON SCHEMA :: dbo TO DME;

GRANT CREATE SEQUENCE ON SCHEMA :: dbo TO DME;

-- Granting SELECT permission on schema dbo to database user DME
GRANT SELECT ON SCHEMA :: dbo TO DME WITH GRANT OPTION;

ALTER SERVER ROLE [bulkadmin] ADD MEMBER [DME]
GO
