/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0200SearchParam {
	/**
	 * 検索条件最大件数
	 *
	 * <p>
	 * 検索条件に指定できる条件の最大件数です。
	 * </p>
	 */
	public static int MAX_SEARCH_CONDITION_SIZE = 10;

	private String connectDefinisionId;
	private String tableId;
	private String tableLabel;
	private ColumnDisplayDefinitionDTO columnsDisplayDefinition;
	private SearchConditionItem[] searchConditionItems;
	private boolean orderDesc;
	private int resultRowCount;

	private int pageNumber;
	private int pageSize;
	
	private int offSet;
	private int limit;
	
	private UserInfo userInfo;
	
	private String action;
	
	/**
	 * true: select count data from conditions
	 * false: search data from conditions
	 */
	private boolean isCountData;
}
