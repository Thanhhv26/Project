/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import jp.co.systemexe.dbu.dbace.presentation.UploadFileType;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;

/**
 * データの一括インポートの設定情報を保持するDTO
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class FileImportInformationDTO {
	/**
	 * ファイルの種類
	 */
	private UploadFileType uploadFileType;

	/**
	 * ファイルエンコード(CSV、TSV)
	 */
	private String fileEncode;

	/**
	 * エラーを無視するか否か
	 */
	private boolean ignoreError;

	/**
	 * 同一レコードが存在した場合に、上書き更新するか否か
	 */
	private boolean superscribeUpdate;

	/**
	 * レコード更新用のリポジトリ情報
	 */
	private RecordEditorInformationDTO recordEditorInformationDTO;

	/**
	 * uploadFileType を戻します。
	 *
	 * @return UploadFileType
	 */
	public UploadFileType getUploadFileType() {
		return uploadFileType;
	}

	/**
	 * uploadFileType を設定します。
	 *
	 * @param UploadFileType uploadFileType
	 */
	public void setUploadFileType(UploadFileType uploadFileType) {
		this.uploadFileType = uploadFileType;
	}

	/**
	 * fileEncode を戻します。
	 *
	 * @return String
	 */
	public String getFileEncode() {
		return fileEncode;
	}

	/**
	 * fileEncode を設定します。
	 *
	 * @param String fileEncode
	 */
	public void setFileEncode(String fileEncode) {
		this.fileEncode = fileEncode;
	}

	/**
	 * ignoreError を戻します。
	 *
	 * @return boolean
	 */
	public boolean isIgnoreError() {
		return ignoreError;
	}

	/**
	 * ignoreError を設定します。
	 *
	 * @param boolean ignoreError
	 */
	public void setIgnoreError(boolean ignoreError) {
		this.ignoreError = ignoreError;
	}

	/**
	 * superscribeUpdate を戻します。
	 *
	 * @return boolean
	 */
	public boolean isSuperscribeUpdate() {
		return superscribeUpdate;
	}

	/**
	 * superscribeUpdate を設定します。
	 *
	 * @param boolean superscribeUpdate
	 */
	public void setSuperscribeUpdate(boolean superscribeUpdate) {
		this.superscribeUpdate = superscribeUpdate;
	}

	/**
	 * recordEditorInformationDTO を戻します。
	 *
	 * @return RecordEditorInformationDTO
	 */
	public RecordEditorInformationDTO getRecordEditorInformationDTO() {
		return recordEditorInformationDTO;
	}

	/**
	 * recordEditorInformationDTO を設定します。
	 *
	 * @param RecordEditorInformationDTO recordEditorInformationDTO
	 */
	public void setRecordEditorInformationDTO(
			RecordEditorInformationDTO recordEditorInformationDTO) {
		this.recordEditorInformationDTO = recordEditorInformationDTO;
	}
}
