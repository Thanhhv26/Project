/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.controller;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportResultDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.IdSelectTableLabeExtendConnectDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.TableNameListIsAcquiredFromRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.service.RecordService;
import jp.co.systemexe.dbu.dbace.library.service.certification.MyUserDetails;
import jp.co.systemexe.dbu.dbace.library.util.DownloadUtils;
import jp.co.systemexe.dbu.dbace.presentation.UploadFileType;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
import jp.co.systemexe.dbu.dbace.web.record.dto.DownloadFileInfo;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DataParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DataResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DeleteParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DeleteResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DownloadResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200LoadParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200LoadResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200SearchParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200SearchResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200UploadResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.SelectTargetedColumnSearchCondition;
import jp.co.systemexe.dbu.dbace.web.record.dto.UploadFileInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;
import jp.co.systemexe.dbu.dbace.web.user.dto.PageInfo;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
@RestController
@RequestMapping(value = "/data/record")
public class RecordController extends AbstractController {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@Autowired
	private RecordService recordService;

	/*@Autowired
	CreationService creationService;*/

	/**
	 * Index page
	 *
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index() throws Exception {
		return new ModelAndView(PageConst.SCREEN_RECORD_LIST);
	}

	/**
	 * get info page
	 *
	 * @return PageInfo
	 */
	@RequestMapping(value = "/getInfoPage", method = { RequestMethod.POST })
	public PageInfo getInfoPage() throws Exception {
		return new PageInfo();
	}

//	/**
//	 * Index page
//	 *
//	 * @return
//	 * @throws Exception
//	 */
//	@RequestMapping(value = "/alltables", method = { RequestMethod.GET, RequestMethod.POST })
//	public ModelAndView allTables(Model model) throws Exception {
//		return new ModelAndView(PageConst.SCREEN_RECORD_LIST_ALL_TABLE);
//	}

	/**
	 *
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	@RequestMapping(value = "/getAllTableList", method = RequestMethod.POST)
	public @ResponseBody List<IdSelectTableLabeExtendConnectDTO> getAllTableList()
			throws ApplicationDomainLogicException {
		MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();
		return recordService.getAllTableList(myUserDetails.getUserInfoDTO());
	}

	/**
	 *
	 * @param loadParam
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	@RequestMapping(value = "/load", method = RequestMethod.POST)
	public FRM0200LoadResultModel doLoadRecord(@RequestBody FRM0200LoadParam loadParam)
			throws ApplicationDomainLogicException {
		loadParam.setUserInfo(getUserInfo());
		return recordService.doLoadRecord(loadParam);
	}

	/**
	 *
	 * @param deleteParam
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = "application/json")
	public FRM0200DeleteResultModel doOnceDelete(@RequestBody FRM0200DeleteParam deleteParam)
			throws ApplicationDomainLogicException {
		deleteParam.setUserInfo(getUserInfo());
		return recordService.doOnceDelete(deleteParam);
	}

//	/**
//	 * プルダウンリストを作成して戻します。
//	 *
//	 * @param columnDatas
//	 * @return
//	 * @throws ApplicationDomainLogicException
//	 */
//	protected Map<String, SelectOneMenuItem[]> createSelectItems(final Map<String, String> columnDatas,
//			String selectedConnectDefinisionId, String tableId, RecordEditorInformationDTO recordEditorInformationDTO)
//			throws ApplicationDomainLogicException {
//		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
//		final UserInfo userInfo = getUserInfo();
//		final ColumnDisplayDefinitionDTO columnDef;
//		columnDef = logic.getColumnDisplayDefinition(selectedConnectDefinisionId, tableId, columnDatas,
//				recordEditorInformationDTO.getDbConnectInfomationDTO(), recordEditorInformationDTO.getTableDef(),
//				recordEditorInformationDTO.getTableForm(), userInfo.getName());
//
//		final Map<String, SelectOneMenuItem[]> ret = new HashMap<String, SelectOneMenuItem[]>();
//
//		for (final String columnName : columnDef.getItemDefinitions().keySet()) {
//			ret.put(columnName, columnDef.getItemDefinitions().get(columnName).getSelectableItems());
//		}
//
//		return ret;
//	}
//
//	/**
//	 * ラジオボタンを作成して戻します。
//	 *
//	 * @param columnDatas
//	 * @return
//	 * @throws ApplicationDomainLogicException
//	 */
//	protected Map<String, SelectOneMenuItem[]> createRadioItems(final Map<String, String> columnDatas,
//			String selectedConnectDefinisionId, String tableId, RecordEditorInformationDTO recordEditorInformationDTO)
//			throws ApplicationDomainLogicException {
//		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
//		final UserInfo userInfo = getUserInfo();
//		final ColumnDisplayDefinitionDTO columnDef;
//		columnDef = logic.getColumnDisplayDefinition(selectedConnectDefinisionId, tableId, columnDatas,
//				recordEditorInformationDTO.getDbConnectInfomationDTO(), recordEditorInformationDTO.getTableDef(),
//				recordEditorInformationDTO.getTableForm(), userInfo.getName());
//
//		final Map<String, SelectOneMenuItem[]> ret = new HashMap<String, SelectOneMenuItem[]>();
//
//		for (final String columnName : columnDef.getItemDefinitions().keySet()) {
//			ret.put(columnName, columnDef.getItemDefinitions().get(columnName).getSelectableItems());
//		}
//
//		return ret;
//	}

	// /**
	// *
	// * 更新可能な項目か否か。
	// * <p>
	// * リポジトリ情報の更新可能区分を判定し、該当カラムが編集可能かどうかを返します。<BR />
	// * なお、更新処理の場合、該当カラムがキー項目の場合は編集可能項目であっても、編集不可(false)を返します。
	// * </p>
	// *
	// * @param tableItemDTO
	// * @param updateDivision
	// * @return
	// */
	// private boolean canEditing(final TableItemDTO tableItemDTO, final
	// UpdateDivision updateDivision) {
	//
	// if (tableItemDTO.canEditing()) {
	// if (updateDivision == UpdateDivision.update &&
	// tableItemDTO.isUpdateKey()) {
	// return false;
	// } else {
	// return true;
	// }
	// } else {
	// return false;
	// }
	// }

	/**
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/validateDownload", method = RequestMethod.POST)
	public FRM0200DownloadResultModel validateDownload(@RequestBody DownloadFileInfo param) throws Exception {
		param.setUserInfo(getUserInfo());
		return recordService.validateDownload(param);
	}

	/**
	 * 「ファイルに出力する」ボタンのイベントハンドラ
	 * <p>
	 * 現在表示されている条件で、Excel出力を行います。
	 * </p>
	 *
	 * @throws ApplicationDomainLogicException
	 */
	@RequestMapping(value = "/download", method = RequestMethod.POST)
	public FRM0200DownloadResultModel doDownload(@Valid @ModelAttribute("data") DownloadFileInfo param,
			HttpServletResponse response, BindingResult result) throws ApplicationDomainLogicException {
		FRM0200DownloadResultModel model = new FRM0200DownloadResultModel();
		model.setFileName(param.getFileName());
		model.setFilePath(param.getFilePath());
		HttpStatus status = HttpStatus.NOT_FOUND;

		OutputStream os;
		try {

			status = DownloadUtils.downloadStatus(response, param.getFilePath(), param.getFileName());
			response.setContentType(MediaType.APPLICATION_JSON);
			response.setCharacterEncoding("utf-8");

			os = response.getOutputStream();
			String jsonString = this.objectToJson(model);
			os.write(jsonString.getBytes("utf-8"));
			response.setStatus(status.value());

			if (!StringUtils.isEmpty(model.getFilePath())) {
				File readFile = new File(model.getFilePath());
				readFile.delete();
			}

		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return model;
	}

	/**
	 * Validate upload file
	 *
	 * @param file
	 *            uploaded file
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/validateUploadFile", method = RequestMethod.POST)
	public FRM0200UploadResultModel validateUploadFile(@RequestBody UploadFileInfo uploadFileInfo) throws Exception {
		FRM0200UploadResultModel resultModel = new FRM0200UploadResultModel();
		final String fileName = uploadFileInfo.getName();
		if (uploadFileInfo == null || fileName == null) {
			resultModel.getMessageInfo().add(new MessageInfo("file", "MI-E-0500-0002", MessageType.ERROR,
					messageService, new String[] { messageService.getMessage("frm0200.form.record.upload.file") }));
			return resultModel;
		}
		final int extensionIndex = fileName.lastIndexOf(".");
		if (extensionIndex == -1 || (extensionIndex + 1) == fileName.length()) {
			// MI-E-0127=インポートファイルが不正です。({0})
			resultModel.getMessageInfo().add(
					new MessageInfo("", "MI-E-0127", MessageType.ERROR, messageService, new String[] { fileName }));
		}
		final UploadFileType fileType = UploadFileType
				.extensionOf(fileName.substring(extensionIndex + 1).toLowerCase());
		getLogger().debug("fileName.length():" + fileName.length());
		getLogger().debug("extension:" + fileName.substring(extensionIndex + 1));
		getLogger().debug("fileType:" + fileType);
		if (fileType == null) {
			resultModel.getMessageInfo().add(
					new MessageInfo("", "MI-E-0153", MessageType.ERROR, messageService));
			return resultModel;
		}
		if (uploadFileInfo.getSize() > getMaxUploadFileSize(fileType)) {
			// MI-E-0149=取込むデータ件数が多すぎます。データ件数を絞り込んでください。
			final String message = MessageUtils.getMessage("MI-E-0149");
			getLogger().error(message);
			resultModel.getMessageInfo().add(new MessageInfo("", "MI-E-0149", MessageType.ERROR, messageService));
		}
		if (resultModel.getMessageInfo().size() > 0) {
			return resultModel;
		}
		resultModel.getMessageInfo()
				.add(new MessageInfo("frm0200.form.record.upload.file", MessageType.SUCCESS, messageService));
		return resultModel;
	}

	/**
	 * アップロード可能なファイルの最大バイトを返します。
	 *
	 * @param fileType
	 * @return
	 */
	private long getMaxUploadFileSize(final UploadFileType fileType) {
		long ret = 0;
		if (fileType == UploadFileType.CSV) {
			ret = SystemProperties.getImportMaximumByteForCsv();
		} else if (fileType == UploadFileType.TSV) {
			ret = SystemProperties.getImportMaximumByteForTsv();
		} else if (fileType == UploadFileType.EXCEL || fileType == UploadFileType.NEWEXCEL) {
			ret = SystemProperties.getImportMaximumByteForExcel();
		}
		return ret * 1024L * 1024L;
	}

	/**
	 * Upload file
	 *
	 * @param file
	 *            uploaded file
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/importFile", method = RequestMethod.POST)
	// @MethodPermission(writable = true)
	public @ResponseBody FileImportResultDTO importFile(@RequestParam("connectDefinisionId") String connectDefinisionId,
			@RequestParam("tableId") String tableId, @RequestParam("file") MultipartFile file,
			@RequestParam("characterEncodingType") String characterEncodingType,
			@RequestParam("skipErrors") boolean skipErrors, @RequestParam("overwriteData") boolean overwriteData) throws Exception{
		String condition = "\"\"ファイルのエンコード \"\"= " + characterEncodingType + " and \"\"エラーが発生した場合に、エラーを無視して処理を続行する\"\"=" + skipErrors
				+" and \"\"データが存在する場合は、上書き更新する\"\"=" + overwriteData;
		final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		if (isMultiTable(connectDefinisionId, tableId)) {
			try {
				FileImportResultDTO fileImportResultDTO = recordService.importFileMultiTable(connectDefinisionId,
						tableId, multipartToFile(file), characterEncodingType, skipErrors, overwriteData,
						getUserInfo());

				OutputAuditLog.writeExcuteSearchLog(
	            		AuditEventKind.IMPORT,
	            		getUserInfo(),
	            		logic.getConnectionByID(connectDefinisionId).getLabel(),
	            		logic.getTableForm(connectDefinisionId, tableId).getLabel(),
	            		AuditStatus.success,
	            		condition,
	            		String.valueOf(fileImportResultDTO.getTotalCount()));

				return fileImportResultDTO;
			} catch (ApplicationDomainLogicException | IllegalStateException | IOException e) {
				getLogger().error(e.getMessage());
				FRM0200UploadResultModel resultModel = new FRM0200UploadResultModel();
				resultModel.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
				FileImportResultDTO fileImportResultDTO = new FileImportResultDTO();
				fileImportResultDTO.setResultModel(resultModel);

				try {
					OutputAuditLog.writeExcuteSearchLog(
							AuditEventKind.IMPORT,
							getUserInfo(),
							logic.getConnectionByID(connectDefinisionId).getLabel(),
		            		logic.getTableForm(connectDefinisionId, tableId).getLabel(),
							AuditStatus.failure,
							condition,
							String.valueOf(fileImportResultDTO.getTotalCount()));
				} catch (ApplicationDomainLogicException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				return fileImportResultDTO;
			}
		} else {
			try {
				FileImportResultDTO fileImportResultDTO = recordService.importFile(connectDefinisionId, tableId,
						multipartToFile(file), characterEncodingType, skipErrors, overwriteData, getUserInfo());

				OutputAuditLog.writeExcuteSearchLog(
	            		AuditEventKind.IMPORT,
	            		getUserInfo(),
	            		logic.getConnectionByID(connectDefinisionId).getLabel(),
	            		logic.getTableForm(connectDefinisionId, tableId).getLabel(),
	            		AuditStatus.success,
	            		condition,
	            		String.valueOf(fileImportResultDTO.getTotalCount()));

				return fileImportResultDTO;
			} catch (ApplicationDomainLogicException | IllegalStateException | IOException e) {
				getLogger().error(e.getMessage());
				FRM0200UploadResultModel resultModel = new FRM0200UploadResultModel();
				resultModel.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
				FileImportResultDTO fileImportResultDTO = new FileImportResultDTO();
				fileImportResultDTO.setResultModel(resultModel);

				try {
					OutputAuditLog.writeExcuteSearchLog(
							AuditEventKind.IMPORT,
							getUserInfo(),
							logic.getConnectionByID(connectDefinisionId).getLabel(),
		            		logic.getTableForm(connectDefinisionId, tableId).getLabel(),
							AuditStatus.failure,
							condition,
							String.valueOf(fileImportResultDTO.getTotalCount()));
				} catch (ApplicationDomainLogicException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				return fileImportResultDTO;
			}
		}
	}

	/**
	 * @param multipart
	 * @return
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	private String multipartToFile(MultipartFile multipart) throws IllegalStateException, IOException {
		File convFile = new File(multipart.getOriginalFilename());
		multipart.transferTo(convFile);
		return convFile.getPath();
	}

	// /**
	// * 表示用テーブル仮名プロパティ。
	// */
	// private String tableLabel;
	// /**
	// * tableLabel を戻します。
	// *
	// * @return String
	// */
	// public String getTableLabel() {
	// return tableLabel;
	// }
	//
	// /**
	// * tableLabel を設定します。
	// *
	// * @param String tableLabel
	// */
	// public void setTableLabel(String tableLabel) {
	// this.tableLabel = tableLabel;
	// }
	// /**
	// * テーブルリストプロパティ。
	// * <p>
	// * プルダウンリスト表示用のプロパティです。基底クラスに実装された tableId プロパティに、Teeda
	// * フレームワークにより自動的に選択テーブル名が設定され ます。
	// * </p>
	// */
	// private List<TableIdListItem> tableIdItems;
	// /**
	// * 対象テーブルデータ保持用プロパティ。
	// */
	// private String tableId;
	// /**
	// * tableId を戻します。
	// *
	// * @return String
	// */
	// public String getTableId() {
	// return tableId;
	// }
	//
	// /**
	// * tableId を設定します。
	// *
	// * @param String tableId
	// */
	// public void setTableId(String tableName) {
	// this.tableId = tableName;
	// }

	// /**
	// * レコード並び順昇順フラグ。
	// */
	// private boolean orderDesc;
	//
	// /**
	// * orderDesc を戻します。
	// *
	// * @return boolean
	// */
	// public boolean isOrderDesc() {
	// return orderDesc;
	// }
	//
	// /**
	// * orderDesc を設定します。
	// *
	// * @param boolean orderDesc
	// */
	// public void setOrderDesc(boolean orderAsc) {
	// this.orderDesc = orderAsc;
	// }

	// /**
	// * 完全一致、曖昧検索ボタン押下時の検索条件を保持するDTO。
	// * <p>
	// * 次へ、前へボタン押下時の検索条件となります。
	// * </p>
	// */
	// private RecordSearchConditionDTO beforeRecordSearchConditionItems;

	// /**
	// * 検索結果表示用リスト(明細)プロパティ
	// */
	// private SearchResultDescriptionItem[] searchResultDescriptionItems;

	// /**
	// * 検索条件表示用リストプロパティ
	// */
	// private SearchConditionItem[] searchConditionItems;

	// /**
	// * 検索結果表示用リスト(ヘッダ)プロパティ
	// */
	// private SearchResultHeaderItem[] searchResultHeaderItems;

	// /**
	// * 選択された接続定義ID
	// */
	// private String selectedConnectDefinisionId;
	//
	// /**
	// * selectedConnectDefinisionId を戻します。
	// *
	// * @return String
	// */
	// public String getSelectedConnectDefinisionId() {
	// return selectedConnectDefinisionId;
	// }
	//
	// /**
	// * selectedConnectDefinisionId を設定します。
	// *
	// * @param String selectedConnectDefinisionId
	// */
	// public void setSelectedConnectDefinisionId(String
	// selectedConnectDefinisionId) {
	// this.selectedConnectDefinisionId = selectedConnectDefinisionId;
	// }
	//
	// /**
	// * 現在の表示件数
	// */
	// private int nowViewableRecordCount;
	//
	// /**
	// * レコード最大表示数。
	// * <p>
	// * デフォルトはプロパティファイルから読み込む値です。
	// * </p>
	// */
	// private String maxViewableRecordCount =
	// String.valueOf(SystemProperties.getDisplayedNumberOfRecords());

	// /**
	// * レコード検索結果件数 プロパティ
	// * @throws ApplicationDomainLogicException
	// */
	// private int resultRowCount;

	// /**
	// * recordEditorInformationDTO を戻します。
	// *
	// * @return RecordEditorInformationDTO
	// */
	// public RecordEditorInformationDTO getRecordEditorInformationDTO() {
	// return recordEditorInformationDTO;
	// }
	//
	// /**
	// * recordEditorInformationDTO を設定します。
	// *
	// * @param RecordEditorInformationDTO recordEditorInformationDTO
	// */
	// public void setRecordEditorInformationDTO(
	// RecordEditorInformationDTO recordEditorInformationDTO) {
	// this.recordEditorInformationDTO = recordEditorInformationDTO;
	// }
	//
	// /**
	// * レコード更新用のリポジトリ情報
	// */
	// private RecordEditorInformationDTO recordEditorInformationDTO;

	@RequestMapping(value = "/getAllSelectObjectList", method = RequestMethod.POST)
	public List<SelectableItem> doSearchSelectObjectList(@RequestBody SelectTargetedColumnSearchCondition searchParam)
			throws ApplicationDomainLogicException {
		searchParam.setUserInfo(getUserInfo());
		return recordService.doSearchSelectObjectList(searchParam);
	}
//
//	/**
//	 * 現在表示している明細の出力件数(START)を返します。
//	 *
//	 * @return
//	 */
//	public int getPageStartViewableRecordCount(int resultRowCount, int nowViewableRecordCount, int maxItemCount) {
//		if (resultRowCount == 0) {
//			return 0;
//		} else if (nowViewableRecordCount <= maxItemCount) {
//			return 1;
//		} else if ((nowViewableRecordCount % maxItemCount) == 0) {
//			return nowViewableRecordCount - maxItemCount + 1;
//		} else {
//			return nowViewableRecordCount - (nowViewableRecordCount % maxItemCount) + 1;
//		}
//	}
//
//	/**
//	 * 現在表示している明細の出力件数(END)を返します。
//	 *
//	 * @return
//	 */
//	public int getPageEndViewableRecordCount(int resultRowCount, int nowViewableRecordCount) {
//		if (resultRowCount == 0) {
//			return 0;
//		} else {
//			return nowViewableRecordCount;
//		}
//	}

	/**
	 * Page クラスの初期化イベントハンドラ。
	 * <p>
	 * 項目定義情報オブジェクトを取得し、検索キーとして定義された項目リストを 作成し、プロパティに設定します。この情報を元に、検索値入力要素を HTML
	 * 内 に構築します。
	 * </p>
	 * <p>
	 * 検索要素構築後、データベースから初期表示レコードを取得し、表示します。 初期表示条件は、テーブル先頭から
	 * MAX_VIEWABLE_RECORD_COUNT で定義された 件数のレコードです。
	 * </p>
	 *
	 * @return null
	 * @throws ApplicationDomainLogicException
	 * @see jp.co.systemexe.bidwh3g.qdbutil.presentation.BaseTeedaPage#initialize()
	 */
	@RequestMapping(value = "/initSearch", method = RequestMethod.POST)
	public FRM0200SearchResultModel doInitSearch(@RequestBody FRM0200SearchParam searchParam)
			throws ApplicationDomainLogicException {
		searchParam.setUserInfo(getUserInfo());
		return recordService.doInitSearch(searchParam);
	}
	
	@RequestMapping(value = "/countRecord", method = RequestMethod.POST, produces = "application/json")
	public FRM0200SearchResultModel countRecord(@RequestBody FRM0200SearchParam searchParam)
			throws ApplicationDomainLogicException {
		searchParam.setUserInfo(getUserInfo());
		searchParam.setCountData(Boolean.TRUE);
		FRM0200SearchResultModel result = recordService.doSearchData(searchParam);
		return result;
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST, produces = "application/json")
	public FRM0200SearchResultModel doSearchData(@RequestBody FRM0200SearchParam searchParam)
			throws ApplicationDomainLogicException {
		searchParam.setUserInfo(getUserInfo());
		searchParam.setCountData(Boolean.FALSE);
		FRM0200SearchResultModel result = recordService.doSearchData(searchParam);
		return result;
	}

	// /**
	// * 画面要素上のテーブル名一覧プルダウンリスト再表示。
	// * <p>
	// * 指定された検索文字列からリポジトリ内のテーブル名を抽出し、画面要素上の プルダウンリストを再表示します。
	// * </p>
	// *
	// * @param condition
	// * テーブル名検索文字列
	// */
	// private List<TableIdListItem> getTables(final String connectDefinisionId,
	// final String tableId) {
	// ArrayList<TableIdListItem> tableIdItems = new
	// ArrayList<TableIdListItem>();
	// try {
	//
	// final TableNameListIsAcquiredFromRepositoryLogic logic = new
	// TableNameListIsAcquiredFromRepositoryLogic();
	// final List<IdSelectable> tableList;
	//
	// tableList = logic.getTableNameList(connectDefinisionId);
	// // tableList =
	// // logic.getTableNameList(getSelectedConnectDefinisionId());
	//
	// for (final Iterator<IdSelectable> ite = tableList.iterator();
	// ite.hasNext();) {
	// final IdSelectable table = ite.next();
	// final TableIdListItem item = new TableIdListItem();
	// item.setValue(table.getId());
	// item.setLabel(table.getLabel());
	// tableIdItems.add(item);
	// }
	// } catch (Exception e) {
	// throw new WebAppRuntimeException(e);
	// }
	//
	// return tableIdItems;
	// }

	/**
	 *
	 * @param connectDefinisionId
	 * @param tableFormId
	 * @return
	 */
	private boolean isMultiTable(final String connectDefinisionId, final String tableFormId) throws Exception{
		try {
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			return logic.isMultiTable(connectDefinisionId, tableFormId);
		} catch (Exception e) {
			throw new ApplicationDomainLogicException(e);
		}

	}

	// /**
	// * 項目定義情報 DTO を戻します。
	// * <p>
	// * リポジトリ及び DB メタデータで定義された各項目（カラム）の画面定義情報の
	// * 設定された DTO を取得し戻します。</p>
	// *
	// * @return ColumnDisplayDefinitionDTO
	// */
	// private final ColumnDisplayDefinitionDTO
	// getColumnDisplayDefinitionInitialize(FRM0200SearchResultModel model)
	// throws ApplicationDomainLogicException {
	// final RetrievalProcessingOfRecordFromDatabaseLogic logic
	// = new RetrievalProcessingOfRecordFromDatabaseLogic();
	//
	//// if (getPreviousViewId().indexOf("tableExplorer") != -1) {
	// final RecordEditorInformationDTO dto = logic.getRecordEditorInformation(
	// model.getConnectDefinisionId(), model.getTableId(),
	// getUserInfo().getId());
	// setRecordEditorInformationDTO(dto);
	//// }
	//
	// final ColumnDisplayDefinitionDTO ret = logic
	// .getColumnDisplayDefinition(model.getConnectDefinisionId(),
	// model.getTableId(),
	// getRecordEditorInformationDTO().getDbConnectInfomationDTO(),
	// getRecordEditorInformationDTO().getTableDef(),
	// getRecordEditorInformationDTO().getTableForm(),
	// getUserInfo().getId());
	// return ret;
	// }

	// /**
	// * 項目定義情報 DTO を戻します。
	// * <p>
	// * リポジトリ及び DB メタデータで定義された各項目（カラム）の画面定義情報の 設定された DTO を取得し戻します。
	// * </p>
	// *
	// * @return ColumnDisplayDefinitionDTO
	// */
	// private final ColumnDisplayDefinitionDTO getColumnsDisplay(final String
	// connectDefinisionId, final String tableId,
	// RecordEditorInformationDTO tableDefinitionDTO) throws
	// ApplicationDomainLogicException {
	// final RetrievalProcessingOfRecordFromDatabaseLogic logic = new
	// RetrievalProcessingOfRecordFromDatabaseLogic();
	//
	// final ColumnDisplayDefinitionDTO ret =
	// logic.getColumnDisplayDefinition(connectDefinisionId, tableId,
	// tableDefinitionDTO.getDbConnectInfomationDTO(),
	// tableDefinitionDTO.getTableDef(),
	// tableDefinitionDTO.getTableForm(), getUserInfo().getId());
	//
	// return ret;
	// }

	// /**
	// * リポジトリとデータベースのカラムが変更されているか否かを返します。
	// *
	// * @param dto
	// * @return 変更されている場合はtrue、変更されていない場合はfalse
	// * @throws ApplicationDomainLogicException
	// */
	// private boolean checkDifferenceOfColumnOnRepositoryAndDatabase(final
	// String connectDefinisionId,
	// final String tableId, final ColumnDisplayDefinitionDTO dto) throws
	// ApplicationDomainLogicException {
	// final CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic logic = new
	// CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic();
	// return logic.isDifference(connectDefinisionId, tableId, dto);
	// }

	// @Override
	// public UserInfo getUserInfo() {
	// MyUserDetails myUserDetails = (MyUserDetails)
	// SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	// UserInfo userInfo = new UserInfo();
	// userInfo.setId(myUserDetails.getUserid());
	// return userInfo;
	// }

	// ADD 初期化の問題を対応 2016/07/26 ↓

	// /**
	// * レコード一覧テーブルのヘッダ要素配列を生成して戻します。
	// * <p>
	// * テーブルのカラム名を表示するヘッダ要素の配列を生成して戻します。
	// * </p>
	// *
	// * <p>
	// * 一覧表示に表示する、更新処理の際のキー項目が設定されているカラムのみ 表示します。
	// * </p>
	// *
	// * @param dto
	// * @return
	// */
	// private SearchResultHeaderItem[] createHeaderItemArray(final
	// ColumnDisplayDefinitionDTO dto) {
	// final SortedMap<Integer, SearchResultHeaderItem> smap = new
	// TreeMap<Integer, SearchResultHeaderItem>();
	// final SortedMap<Integer, String> columns =
	// getColumnSortList(dto.getItemDefinitions());
	// for (final Integer index : columns.keySet()) {
	// final String column = columns.get(index);
	// final TableItemDTO def = dto.getItemDefinitions().get(column);
	// if (def != null && (def.canPreview() || def.isUpdateKey())) {
	// final SearchResultHeaderItem item = new SearchResultHeaderItem();
	// item.setColumnId(def.getItemId());
	// item.setColumnLabel(def.getItemLabel());
	// item.setJdbcMetaData(
	// dto.getDefinitionOfColumns().get(def.getItemId()).getJDBCMetaDataType().getDataType());
	//
	// if (dto.getDefinitionOfColumns().get(def.getItemId()).isPrimaryKey() ||
	// def.isUpdateKey()) {
	// item.setPrimaryKey(true);
	// } else {
	// item.setPrimaryKey(false);
	// }
	//
	// item.setCanPreview(def.canPreview());
	//
	// smap.put(index, item);
	// }
	// }
	// final SearchResultHeaderItem[] ret = new SearchResultHeaderItem[1];
	// ret[0] = new SearchResultHeaderItem();
	// ret[0].setSearchResultHeaderDetailItems(
	// smap.values().toArray(new SearchResultHeaderItem[smap.values().size()]));
	// return ret;
	// }

	// /**
	// * 画面表示用レコード明細の作成を行います。
	// * <p>
	// * 実際のレコードデータ、リポジトリ内の定義、DB スキーマ定義を元にレコード 明細（レコードの一覧表）を作成します。
	// * </p>
	// * <p>
	// * ヘッダの作成、データ表の作成を同時に行います。
	// * </p>
	// *
	// * @param records
	// * レコードデータ保持マップ
	// * @param displayDef
	// * 項目定義保持 DTO
	// */
	// private void createDisplayRecords(final SortedMap<Integer, Map<String,
	// String>> records,
	// final ColumnDisplayDefinitionDTO displayDef, FRM0200SearchResultModel
	// model,
	// RecordEditorInformationDTO tableDefinitionDTO) throws
	// ApplicationDomainLogicException {
	// // this.searchResultHeaderItems = createHeaderItemArray(displayDef);
	// if (model.getResultRowCount() >
	// SystemProperties.getSearchMaxRecordCount()) {
	// // MI-E-0125=該当データ件数が多すぎます。条件を絞り込み再度検索してください。
	// // addPageMessage(MessageUtils.getMessage("MI-E-0125"));
	// model.getMessageInfo().add(new MessageInfo("MI-E-0125",
	// MessageType.ERROR, messageService));
	// // this.searchResultDescriptionItems = new
	// // SearchResultDescriptionItem[0];
	// this.nowViewableRecordCount = 0;
	// model.setResultRowCount(0);
	// } else if (records == null || records.get(0) == null) {
	// // MI-E-0122=該当データが存在しません
	// // addPageMessage(MessageUtils.getMessage("MI-E-0122"));
	// model.getMessageInfo().add(new MessageInfo("MI-E-0122",
	// MessageType.ERROR, messageService));
	// // this.searchResultDescriptionItems = new
	// // SearchResultDescriptionItem[0];
	// this.nowViewableRecordCount = this.nowViewableRecordCount + 1;
	// } else {
	// // TODO:プルダウンデータ等をＩＤで出力する設定に戻す場合は、
	// // 以下のコメント化を解除し、for文をコメント化する。
	// // final SortedMap<Integer, Map<String, String>> columnDataLabel =
	// // records;
	// final SortedMap<Integer, Map<String, String>> columnDataLabel = new
	// TreeMap<Integer, Map<String, String>>();
	//
	// for (final Integer columnIndex : records.keySet()) {
	// final Map<String, String> map = records.get(columnIndex);
	// final RetrievalProcessingOfRecordFromDatabaseLogic logic = new
	// RetrievalProcessingOfRecordFromDatabaseLogic();
	// final ColumnDisplayDefinitionDTO defDb =
	// logic.getColumnDisplayDefinition(
	// model.getConnectDefinisionId(), model.getTableId(), map,
	// tableDefinitionDTO.getDbConnectInfomationDTO(),
	// tableDefinitionDTO.getTableDef(),
	// tableDefinitionDTO.getTableForm(), getUserInfo().getId());
	// final Map<String, String> columnLabel = new HashMap<String, String>();
	// for (final String columnName : map.keySet()) {
	// final TableItemDTO item = defDb.getItemDefinitions().get(columnName);
	// if (item.getHtmlElement() == DefinedHtmlElement.SELECT
	// || item.getHtmlElement() == DefinedHtmlElement.INPUT_RADIO) {
	// if (StringUtils.isEmpty(map.get(columnName))) {
	// columnLabel.put(columnName, "");
	// } else {
	// if (item.canDisplayNamePreview()) {
	// columnLabel.put(columnName,
	// getSelectItem(item.getSelectableItems(), map.get(columnName)));
	// } else {
	// columnLabel.put(columnName, map.get(columnName));
	// }
	// }
	// } else {
	// // MOD DBエースOracle日付対応 ↓
	// // columnLabel.put(
	// // columnName,
	// // map.get(columnName));
	// final DefinedHtmlElement element = item.getHtmlElement();
	// if (element == DefinedHtmlElement.INPUT_DATE || element ==
	// DefinedHtmlElement.INPUT_DATETIME
	// || element == DefinedHtmlElement.INPUT_TIMESTAMP) {
	// String valueDsp = DateUtils.formatDateToString(map.get(columnName),
	// element);
	// columnLabel.put(columnName, valueDsp);
	// } else {
	// columnLabel.put(columnName, map.get(columnName));
	// // MOD DBエースOracle日付対応 ↑
	// }
	// }
	// }
	// columnDataLabel.put(columnIndex, columnLabel);
	// }
	//
	// // this.searchResultDescriptionItems = createBodyItemArray(records,
	// // columnDataLabel, displayDef);
	// this.nowViewableRecordCount += records.size();
	// }
	// }

//	/**
//	 * リポジトリに登録されている表示順で整列されたカラムIDのマップを返します。
//	 *
//	 * @param map
//	 * @return
//	 */
//	protected SortedMap<Integer, String> getColumnSortList(final Map<String, TableItemDTO> map) {
//		final SortedMap<Integer, String> ret = new TreeMap<Integer, String>();
//		for (final String columnId : map.keySet()) {
//			final TableItemDTO item = map.get(columnId);
//			ret.put(item.getSortIndex(), columnId);
//		}
//		return ret;
//	}

	// /**
	// * レコード一覧テーブルのボディ要素配列を生成して戻します。
	// * <p>
	// * レコード一覧のボディ要素（配列で表現されたテーブル）を生成します。
	// * </p>
	// *
	// * @param records
	// * カラム実データ（ＤＢの値）
	// * @param columnDataLabel
	// * カラムの表示用データ（プルダウン等のラベル）
	// * @param displayDef
	// * @param allColumn
	// * 全てのカラムを表示するか否か
	// * @return
	// */
	// private SearchResultDescriptionItem[] createBodyItemArray(final
	// SortedMap<Integer, Map<String, String>> records,
	// final SortedMap<Integer, Map<String, String>> columnDataLabel,
	// final ColumnDisplayDefinitionDTO displayDef) {
	// final SearchResultDescriptionItem[] ret = new
	// SearchResultDescriptionItem[records.size()];
	// int i = 0;
	// for (final Integer recordNo : records.keySet()) {
	// final Map<String, String> record = records.get(recordNo);
	// if (record == null) {
	// break;
	// }
	// final SortedMap<Integer, SearchResultDescriptionItem> bodyItemMap =
	// createRecordItemMap(displayDef, record,
	// columnDataLabel.get(recordNo));
	//
	// ret[i] = new SearchResultDescriptionItem();
	// ret[i].setSearchResultDescriptionDetailItems(
	// bodyItemMap.values().toArray(new
	// SearchResultDescriptionItem[bodyItemMap.size()]));
	// i++;
	// }
	// return ret;
	// }

	// /**
	// * レコード一覧テーブルのボディ要素内のレコードマップを生成して戻します。
	// * <p>
	// * 実際のレコード表示用のレコードマップ（カラム毎のアイテムマップ）を生成 します。
	// * </p>
	// *
	// * @param displayDef
	// * @param record
	// * @param columnDataLabel
	// * @param allColumn
	// * 全てのカラムを表示するか否か
	// * @return
	// */
	// private SortedMap<Integer, SearchResultDescriptionItem>
	// createRecordItemMap(
	// final ColumnDisplayDefinitionDTO displayDef, final Map<String, String>
	// record,
	// final Map<String, String> columnDataLabel) {
	// final SortedMap<Integer, SearchResultDescriptionItem> ret = new
	// TreeMap<Integer, SearchResultDescriptionItem>();
	// final SortedMap<Integer, String> columns =
	// getColumnSortList(displayDef.getItemDefinitions());
	// for (final Iterator<Integer> ite = columns.keySet().iterator();
	// ite.hasNext();) {
	// final int index = ite.next();
	// final String column = columns.get(index);
	// final TableItemDTO tableItem =
	// displayDef.getItemDefinitions().get(column);
	// if (tableItem != null && (tableItem.canPreview() ||
	// tableItem.isUpdateKey())) {
	// final SearchResultDescriptionItem item = new
	// SearchResultDescriptionItem();
	// item.setColumnData(record.get(column));
	// item.setColumnDataLabel(columnDataLabel.get(column));
	// item.setCanPreview(tableItem.canPreview());
	// ret.put(index, item);
	// }
	// }
	// return ret;
	// }

	// /**
	// * 項目定義情報 DTO を戻します。
	// * <p>
	// * リポジトリ及び DB メタデータで定義された各項目（カラム）の画面定義情報の 設定された DTO を取得し戻します。
	// * </p>
	// *
	// * @return ColumnDisplayDefinitionDTO
	// */
	// private final ColumnDisplayDefinitionDTO
	// getColumnDisplayDefinition(FRM0200SearchParam searchParam,
	// RecordEditorInformationDTO tableDefinitionDTO)
	// throws ApplicationDomainLogicException {
	// final RetrievalProcessingOfRecordFromDatabaseLogic logic = new
	// RetrievalProcessingOfRecordFromDatabaseLogic();
	// final ColumnDisplayDefinitionDTO ret = logic
	// .getColumnDisplayDefinition(searchParam.getConnectDefinisionId(),
	// searchParam.getTableId(),
	// tableDefinitionDTO.getDbConnectInfomationDTO(),
	// tableDefinitionDTO.getTableDef(),
	// tableDefinitionDTO.getTableForm(),
	// getUserInfo().getId());
	// return ret;
	// }

	/**
	 * 「検索条件を保存」ボタンのイベントハンドラ。
	 * <p>
	 * 現在表示されている検索条件を外部XMLファイルに保存します。
	 * </p>
	 *
	 * @throws ApplicationDomainLogicException
	 */
	@RequestMapping(value = "/saveCondition", method = RequestMethod.POST, produces = "application/json")
	public FRM0200SearchResultModel doOutputSearchCondition(@RequestBody FRM0200SearchParam searchParam)
			throws ApplicationDomainLogicException {
		searchParam.setUserInfo(getUserInfo());
		return recordService.doOutputSearchCondition(searchParam);
	}

	// /**
	// * 「次」ボタンのイベントハンドラ。
	// * <p>
	// * レコードの検索を行い、取得したレコードを画面に表示します。
	// * 現在表示されている行の次の行(nowViewableRecordCount)から、
	// * +MAX_VIEWABLE_RECORD_COUNT までの行を表示します。
	// * </p>
	// * <p>
	// * 検索時の条件は初期表示、完全一致、曖昧検索時に保持しておいた、検索条件を使用します。
	// * </p>
	// *
	// * @return null
	// */
	// public String doNext() {
	// try {
	// final RecordSearchResultDTO dto = recordSearch(
	// nowViewableRecordCount, Integer.parseInt(maxViewableRecordCount),
	// this.beforeRecordSearchConditionItems);
	// this.resultRowCount = dto.getResultRowCount();
	// final ColumnDisplayDefinitionDTO def = getColumnDisplayDefinition();
	//
	// if (checkDifferenceOfColumnOnRepositoryAndDatabase(def)) {
	// // MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
	// addPageMessage(MessageUtils.getMessage("MI-E-0121"));
	// return null;
	// }
	//
	// createDisplayRecords(dto.getRecordSearchResult(), def);
	// return null;
	// } catch (final ApplicationDomainLogicException e) {
	// addPageMessage(e);
	// return null;
	// } catch (final Exception e) {
	// getLogger().fatal(e.getMessage(), e);
	// addPageMessage(e.getMessage());
	// return null;
	// }
	// }
	//
	// /**
	// * 「前」ボタンのイベントハンドラ。
	// * <p>
	// * レコードの検索を行い、取得したレコードを画面に表示します。
	// * 現在表示されている行の次の行(nowViewableRecordCount)から、
	// * -MAX_VIEWABLE_RECORD_COUNT までの行を表示します。
	// * </p>
	// * <p>
	// * 検索時の条件は初期表示、完全一致、曖昧検索時に保持しておいた、検索条件を使用します。
	// * </p>
	// *
	// * @return null
	// */
	// public String doPrevious() {
	// try {
	// final int previousIndex = nowViewableRecordCount
	// % (Integer.parseInt(maxViewableRecordCount)) == 0
	// ? Integer.parseInt(maxViewableRecordCount) * 2
	// : Integer.parseInt(maxViewableRecordCount)
	// + (nowViewableRecordCount % (Integer.parseInt(maxViewableRecordCount)));
	// this.nowViewableRecordCount = this.nowViewableRecordCount
	// - previousIndex;
	// final RecordSearchResultDTO dto = recordSearch(
	// nowViewableRecordCount, Integer.parseInt(maxViewableRecordCount),
	// this.beforeRecordSearchConditionItems);
	// this.resultRowCount = dto.getResultRowCount();
	// final ColumnDisplayDefinitionDTO def = getColumnDisplayDefinition();
	//
	// if (checkDifferenceOfColumnOnRepositoryAndDatabase(def)) {
	// // MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
	// addPageMessage(MessageUtils.getMessage("MI-E-0121"));
	// return null;
	// }
	//
	// createDisplayRecords(dto.getRecordSearchResult(), def);
	// return null;
	// } catch (final ApplicationDomainLogicException e) {
	// addPageMessage(e);
	// return null;
	// } catch (final Exception e) {
	// getLogger().fatal(e.getMessage(), e);
	// addPageMessage(e.getMessage());
	// return null;
	// }
	// }
	//
	// /**
	// * 「先頭」ボタンのイベントハンドラ。
	// * <p>
	// * レコードの検索を行い、取得したレコードを画面に表示します。
	// * 最初の行から、MAX_VIEWABLE_RECORD_COUNT までの行を表示します。
	// * </p>
	// * <p>
	// * 検索時の条件は初期表示、完全一致、曖昧検索時に保持しておいた、検索条件を使用します。
	// * </p>
	// *
	// * @return null
	// */
	// public String doFirst() {
	// try {
	// this.nowViewableRecordCount = 0;
	// final RecordSearchResultDTO dto = recordSearch(
	// this.nowViewableRecordCount, Integer.parseInt(maxViewableRecordCount),
	// this.beforeRecordSearchConditionItems);
	// this.resultRowCount = dto.getResultRowCount();
	// final ColumnDisplayDefinitionDTO def = getColumnDisplayDefinition();
	//
	// if (checkDifferenceOfColumnOnRepositoryAndDatabase(def)) {
	// // MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
	// addPageMessage(MessageUtils.getMessage("MI-E-0121"));
	// return null;
	// }
	//
	// createDisplayRecords(dto.getRecordSearchResult(), def);
	// return null;
	// } catch (final ApplicationDomainLogicException e) {
	// addPageMessage(e);
	// return null;
	// } catch (final Exception e) {
	// getLogger().fatal(e.getMessage(), e);
	// addPageMessage(e.getMessage());
	// return null;
	// }
	// }
	//
	// /**
	// * 「最終」ボタンのイベントハンドラ。
	// * <p>
	// * レコードの検索を行い、取得したレコードを画面に表示します。
	// * int(検索結果数 / MAX_VIEWABLE_RECORD_COUNT) * MAX_VIEWABLE_RECORD_COUNT から、
	// * MAX_VIEWABLE_RECORD_COUNT までの行を表示します。
	// * </p>
	// * <p>
	// * 検索時の条件は初期表示、完全一致、曖昧検索時に保持しておいた、検索条件を使用します。
	// * </p>
	// *
	// * @return null
	// */
	// public String doLast() {
	// try {
	// if ((this.resultRowCount % Integer.parseInt(maxViewableRecordCount)) ==
	// 0) {
	// final int pageIndex = (this.resultRowCount /
	// Integer.parseInt(maxViewableRecordCount));
	// if (pageIndex == 0) {
	// this.nowViewableRecordCount = 0;
	// } else {
	// this.nowViewableRecordCount = (pageIndex - 1)
	// * Integer.parseInt(maxViewableRecordCount);
	// }
	// } else {
	// this.nowViewableRecordCount = (this.resultRowCount /
	// Integer.parseInt(maxViewableRecordCount))
	// * Integer.parseInt(maxViewableRecordCount);
	// }
	//
	// final RecordSearchResultDTO dto = recordSearch(
	// this.nowViewableRecordCount, Integer.parseInt(maxViewableRecordCount),
	// this.beforeRecordSearchConditionItems);
	// this.resultRowCount = dto.getResultRowCount();
	// final ColumnDisplayDefinitionDTO def = getColumnDisplayDefinition();
	//
	// if (checkDifferenceOfColumnOnRepositoryAndDatabase(def)) {
	// // MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
	// addPageMessage(MessageUtils.getMessage("MI-E-0121"));
	// return null;
	// }
	//
	// createDisplayRecords(dto.getRecordSearchResult(), def);
	// return null;
	// } catch (final ApplicationDomainLogicException e) {
	// addPageMessage(e);
	// return null;
	// } catch (final Exception e) {
	// getLogger().fatal(e.getMessage(), e);
	// addPageMessage(e.getMessage());
	// return null;
	// }
	// }

	// /**
	// *
	// * @param tableId
	// * @param itemId
	// * @return
	// */
	// private String formatColumn(String tableId, String itemId, boolean
	// isMulti) {
	// TableIdDefinition tableIdDefinition = new TableIdDefinition(tableId);
	// if (isMulti) {
	// return String.format("\"%s\".\"%s\".\"%s\"",
	// tableIdDefinition.getSchem(), tableIdDefinition.getTable(),
	// itemId);
	// } else {
	// return String.format("\"%s\".\"%s\"", tableIdDefinition.getTable(),
	// itemId);
	// }
	// }

	/**
	 * @author LUONG THI THANH TRUC
	 * @version 6.0 Mar 15, 2017
	 */

	/**
	 * 「登録」ボタンのイベントハンドラ。
	 * <p>
	 * リポジトリとDBのカラム情報を比較し、DBが変更(ALTER等)されていた場合は、 エラーメッセージを表示します。
	 * </p>
	 * <p>
	 * 選択された行のプライマリキー情報、カラムデータをSessionに保存し、 対象レコード編集画面要素に新規登録モードで遷移します。
	 * </p>
	 *
	 * @return Class
	 */

	@RequestMapping(value = "/doInsert", method = RequestMethod.POST)
	public FRM0200DataResultModel doInsert(@RequestBody FRM0200DataParam model) throws ApplicationDomainLogicException {
		FRM0200DataResultModel resultModel = new FRM0200DataResultModel();
		resultModel.setConnectDefinisionId(model.getConnectDefinisionId());
		resultModel.setTableId(model.getTableId());
		model.setUserInfo(getUserInfo());
		resultModel = recordService.doInsertTable(model);
		return resultModel;
	}

	/*
	 * @RequestMapping(value = "/doUpdate", method = RequestMethod.POST) public
	 * FRM0200DataResultModel doUpdate(@RequestBody FRM0200DataParam model)
	 * throws ApplicationDomainLogicException { FRM0200DataResultModel
	 * resultModel = new FRM0200DataResultModel();
	 * resultModel.setConnectDefinisionId(model.getConnectDefinisionId());
	 * resultModel.setTableId(model.getTableId()); resultModel =
	 * recordService.doInsertTable(model); return resultModel; }
	 */

	/**
	 * 保存して、検索画面に戻るボタン押下のイベントハンドラ
	 *
	 * <p>
	 * 対象データを登録・更新し、編集対象レコード検索画面要素へ遷移します。
	 * </p>
	 *
	 * @return
	 */
	@RequestMapping(value = "/doOnceSaveData", method = RequestMethod.POST)
	public FRM0200DataResultModel doOnceSaveData(@RequestBody FRM0200DataParam model)
			throws ApplicationDomainLogicException {
		FRM0200DataResultModel resultModel = new FRM0200DataResultModel();
		model.setUserInfo(getUserInfo());
		resultModel = recordService.doOnceSaveDataTable(model);
		return resultModel;
	}

	/**
	 *
	 * @param deleteParam
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	@RequestMapping(value = "/onChangeSelectItem", method = RequestMethod.POST, produces = "application/json")
	public FRM0200DataResultModel onChangeSelectItem(@RequestBody FRM0200DataParam model)
			throws ApplicationDomainLogicException {
		FRM0200DataResultModel resultModel = new FRM0200DataResultModel();
		model.setUserInfo(getUserInfo());
		resultModel = recordService.getColumnSelectPulldownOnchange(model);
		return resultModel;
	}

}