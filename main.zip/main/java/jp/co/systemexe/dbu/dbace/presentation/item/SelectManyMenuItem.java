/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item;

/**
 * Teeda SelectManyMeny Item インターフェース。
 * <p>
 * Teeda HTML テンプレート内で select 要素、つまりプルダウンリストを使用する際に、
 * そのリスト内の値を定義するためのインターフェースです。option 要素の value
 * アトリビュートの保持値とテキスト要素の保持値の入出力インターフェースを定義
 * しています。</p>
 *
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public interface SelectManyMenuItem {

    /**
     * option 要素の value アトリビュートの保持値を戻します。
     * <p>
     * option 要素の value アトリビュートには、通常キー値或いはインデックス番号
     * を保持させます。</p>
     * 
     * @return String
     */
    public String getValue();

    /**
     * option 要素の value アトリビュートの保持値を設定します。
     * <p>
     * option 要素の value アトリビュートには、通常キー値或いはインデックス番号
     * を保持させます。</p>
     * 
     * @param value String
     */
    public void setValue(final String value);

    /**
     * ラベル表示されるテキスト要素の保持値を戻します。
     * 
     * @return String
     */
    public String getLabel();

    /**
     * ラベル表示されるテキスト要素の保持値を設定します。
     * 
     * @param label String
     */
    public void setLabel(final String label);

}
