/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.dto;

import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import lombok.Data;

@Data
public class SortColumnEditorDTO {

	private String connectDefinitionId;
	private TableFormDTO tableFormDTO;
}
