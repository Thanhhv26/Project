/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.io.Serializable;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;

/**
 * 編集対象レコード検索画面要素にて選択されたデータの
 * プライマリキー情報
 *
 * @author EXE 相田 一英
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class ColumnPrimaryKeyItem implements Serializable {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = -5363216662802628833L;

    /**
     * カラムデータ
     * Map&lt;columnId,columnData&gt;
     */
    private Map<String, String> columnData;

    /**
     * DB(XML)更新処理区分 enum。
     */
    private String updateDivision;

    /**
     * テーブルID
     */
    private String tableId;

    /**
     * 機能ID
     */
    private String functionId;

    /**
     * JDBCメタデータタイプ
     */
    private Map<String, JDBCMetaDataType> columnjdbcMetaDataType;

    /**
     * tableId を戻します。
     *
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * tableId を設定します。
     *
     * @param String tableId
     */
    public void setTableId(String tableId) {
        this.tableId = tableId;
    }

    /**
     * updateDivision を戻します。
     *
     * @return UpdateDivision
     */
    public String getUpdateDivision() {
        return updateDivision;
    }

    /**
     * updateDivision を設定します。
     *
     * @param UpdateDivision updateDivision
     */
    public void setUpdateDivision(String updateDivision) {
        this.updateDivision = updateDivision;
    }

    /**
     * 更新区分を設定します。
     * <p>
     * 入力値に制約をかけるための、同名 setter のオーバーロードです。</p>
     *
     * @param div
     */
    public void setUpdateDivision(final UpdateDivision div) {
        this.updateDivision = div.getKey();
    }

    /**
     * functionId を戻します。
     *
     * @return String
     */
    public String getFunctionId() {
        return functionId;
    }

    /**
     * functionId を設定します。
     *
     * @param String functionId
     */
    public void setFunctionId(String functionId) {
        this.functionId = functionId;
    }

    /**
     * columnData を戻します。
     *
     * @return Map<String,String>
     */
    public Map<String, String> getColumnData() {
        return columnData;
    }

    /**
     * columnData を設定します。
     *
     * @param Map<String,String> columnData
     */
    public void setColumnData(Map<String, String> columnData) {
        this.columnData = columnData;
    }

    /**
     * columnjdbcMetaDataType を戻します。
     *
     * @return Map<String,JDBCMetaDataType>
     */
    public Map<String, JDBCMetaDataType> getColumnjdbcMetaDataType() {
        return columnjdbcMetaDataType;
    }

    /**
     * columnjdbcMetaDataType を設定します。
     *
     * @param Map<String,JDBCMetaDataType> columnjdbcMetaDataType
     */
    public void setColumnjdbcMetaDataType(
            Map<String, JDBCMetaDataType> columnjdbcMetaDataType) {
        this.columnjdbcMetaDataType = columnjdbcMetaDataType;
    }

}
