/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;

import java.util.List;

import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author tu-lenh
 */

@Data
public class FRM0300ResultModel {
	//OK , NG
	private String status;
	private SynchrInfoDTO resultData;
	private List<MessageInfo> messageInfo;
//	private Map<String,String> resultMessage;
}
