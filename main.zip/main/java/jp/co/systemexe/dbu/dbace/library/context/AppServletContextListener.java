/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.context;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import jp.co.systemexe.dbu.dbace.domain.service.impl.InitializeServiceImpl;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
public class AppServletContextListener implements ServletContextListener {

	/**
	 * (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		new InitializeServiceImpl().initialize();
	}

	/**
	 * (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
	}
}
