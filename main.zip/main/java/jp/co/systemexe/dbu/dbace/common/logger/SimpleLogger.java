/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.logger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * SimpleLog 用のロガーオブジェクト。
 *
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public class SimpleLogger implements Logger {
    final Log log;

    /**
     * SimpleLogger の生成。
     * 
     * @param className 呼び出し元クラス名。
     */
    public SimpleLogger(final String className) {
        log = LogFactory.getLog(className);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object)
     */
    public void fatal(final Object obj) {
        log.fatal(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object, java.lang.Throwable)
     */
    public void fatal(Object obj, Throwable te) {
        log.fatal(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object)
     */
    public void error(final Object obj) {
        log.error(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object, java.lang.Throwable)
     */
    public void error(Object obj, Throwable te) {
        log.error(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object)
     */
    public void warn(final Object obj) {
        log.warn(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object, java.lang.Throwable)
     */
    public void warn(Object obj, Throwable te) {
        log.warn(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object)
     */
    public void info(final Object obj) {
        log.info(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object, java.lang.Throwable)
     */
    public void info(Object obj, Throwable te) {
        log.info(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object)
     */
    public void debug(final Object obj) {
        log.debug(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object, java.lang.Throwable)
     */
    public void debug(Object obj, Throwable te) {
        log.debug(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#isDebugEnabled()
     */
    public boolean isDebugEnabled() {
        return log.isDebugEnabled();
    }
}
