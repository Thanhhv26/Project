/*
 * @(#)MessageConst.java 1.0 May 29, 2015 Copyright 2015 by SystemEXE Inc. All
 * rights reserved.
 */
package jp.co.systemexe.dbu.dbace.web.common;

/**
 * Message constant class
 *
 * @author vdlson
 * @version 1.0 May 29, 2015
 */
public class MessageConst {

	/**
	 * ADD_SUCCESS_MSG
	 */
	public static final String COM_MSG_ID_INF_002 = "COM_MSG_ID_INF_002";

	/**
	 * WARNING_EXIST_MSG
	 */
	public static final String COM_MSG_ID_ERR_006 = "COM_MSG_ID_ERR_006";
	/**
	 * WARNING_DATA_INPUT
	 */
	public static final String COM_MSG_ID_ERR_002 = "COM_MSG_ID_ERR_002";
	/**
	 * UPDATE_SUCCESS_MSG
	 */
	public static final String COM_MSG_ID_INF_003 = "COM_MSG_ID_INF_003";
	/**
	 * DELETE_SUCCESS_MSG
	 */
	public static final String COM_MSG_ID_INF_001 = "COM_MSG_ID_INF_001";
	/**
	 * SERVER_PROCESS_ERROR
	 */
	public static final String COM_MSG_ID_ERR_001 = "COM_MSG_ID_ERR_001";

	/**
	 * /** Common Departmeant message
	 */
	public static final String FRM011E003 = "FRM011E003";
	public static final String FRM012W001 = "FRM012W001";
	public static final String FRM012E003 = "FRM012E003";
	public static final String FRM012W004 = "FRM012W004";
	public static final String FRM0102I001 = "FRM0102I001";
	public static final String FRM0120I001 = "FRM0120I001";
	public static final String MSG_ID_PAY = "MSG_ID_PAY";
	public static final String MSG_ID_CANCEL_CONFIRMED = "MSG_ID_CANCEL_CONFIRMED";
	public static final String MSG_ID_CANCEL_PAY = "MSG_ID_CANCEL_PAY";
	public static final String S0030E001 = "S0030E001";
	public static final String M007E001 = "M007E001";


	/**
	 * /** furlough list header report excel message
	 */
	public static final String FurloughAggreation = "S0010_TITLE";
	public static final String EmployeeCode = "employee.employeeCode";
	public static final String EmployeeName = "employee.employeeName";
	public static final String TotalNumber = "sumDay";
	public static final String SomeHolidays = "absenceDay";
	public static final String January = "january";
	public static final String February = "february";
	public static final String March = "march";
	public static final String April = "apri";
	public static final String May = "may";
	public static final String June = "june";
	public static final String July = "july";
	public static final String August = "august";
	public static final String September = "septembe";
	public static final String October = "october";
	public static final String November = "november";
	public static final String Dec = "december";
	public static final String LeaveDay = "numbelOfDay";

}
