package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 画面設定情報の保存ロジック。
 * <p>
 * テーブル個々に対応した画面設定（テーブルフォーム）情報を保存する処理です。</p>
 *
 * @author EXE 六本木 圭 
 * @version 0.0.0
 */

public class PreservationOfTableInfomationRepositoryLogic
        extends BaseApplicationDomainLogic {

    /**
     * テーブル個々に対応した画面設定をリポジトリに保存します。
     * <p></p>
     * 
     * @param dto TableFormDTO
     * @param String connectDefinitionId
     * @throws ApplicationDomainLogicException
     */
    public void save(final TableFormDTO dto, final String connectDefinitionId)
            throws ApplicationDomainLogicException {
        final TableFormDAO dao = createConnectDefinisionDAO();
        final TableFormDTO tableFormDto;
        try {
            tableFormDto = dao
                .getTableFormDTO(connectDefinitionId, dto.getTableFormId());
            if (tableFormDto == null) {
            	// MI-E-0033=テーブル情報が存在しません。
                throw new ApplicationDomainLogicException(
                		MessageUtils.getMessage("MI-E-0033"));
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        
        try {
        	tableFormDto.setTableFormLabel(dto.getTableFormLabel());
        	tableFormDto.setOrderDesc(dto.getOrderDesc());
        	tableFormDto.setSortConditionMap(dto.getSortConditionMap());
            dao.save(connectDefinitionId, tableFormDto);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * PreservationOfTableInfomationRepositoryLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public PreservationOfTableInfomationRepositoryLogic() {
        return;
    }

    /**
     * テーブル個々に対応した画面設定 DAO を生成して戻す。
     * 
     * @return ConnectDefinisionDAO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDAO createConnectDefinisionDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
