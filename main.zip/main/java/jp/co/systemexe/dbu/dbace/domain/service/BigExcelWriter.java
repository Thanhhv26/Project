/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service;

import java.io.File;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.google.common.collect.ImmutableList;

public interface BigExcelWriter {

	BigExcelWriter createWorkbook();

	BigExcelWriter addSheets(String[] sheetNames);

	BigExcelWriter writeWorkbookTemplate() throws IOException;

	SpreadsheetWriter createSpreadsheetWriter(String sheetName) throws IOException;

	SpreadsheetWriter createSpreadsheetWriter(XSSFSheet sheet) throws IOException;

	File completeWorkbook() throws IOException;

	void createTempFileExcelForCheckSize() throws IOException;

	Workbook getWorkbook();

	ImmutableList<XSSFSheet> getSheets();

	BigExcelWriter writeWorkbookTemplate(String sheetName) throws IOException;

	void deleteTempFiles() throws IOException;

}
