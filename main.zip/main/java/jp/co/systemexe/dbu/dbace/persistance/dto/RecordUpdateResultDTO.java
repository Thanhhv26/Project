/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * レコード登録、更新、削除結果 DTO。
 * <p>
 * データベースにレコードを登録、更新、削除した際の情報を保持する DTO です。</p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class RecordUpdateResultDTO implements Serializable  {
    /**
	 * <code>serialVersionUID</code> のコメント。
	 */
	private static final long serialVersionUID = 694084886217689076L;

	/**
     * 更新した、レコード件数 を保持します
     */
    private int resultRecordCount;
    
    /**
     * 実際に更新した際の、カラムとデータのマップを保持します。
     */
    private Map<String, String> dataMap = new HashMap<String, String>();
    
    /**
     * 更新した際のWHERE句(where句抜き)を保持します。
     */
    private String updateCondition;

	/**
	 * resultRecordCount を戻します。
	 * 
	 * @return int
	 */
	public int getResultRecordCount() {
		return resultRecordCount;
	}

	/**
	 * resultRecordCount を設定します。
	 *
	 * @param int resultRecordCount 
	 */
	public void setResultRecordCount(int resultRecordCount) {
		this.resultRecordCount = resultRecordCount;
	}

	/**
	 * dataMap を戻します。
	 * 
	 * @return Map<String,String>
	 */
	public Map<String, String> getDataMap() {
		return dataMap;
	}

	/**
	 * dataMap を設定します。
	 *
	 * @param Map<String,String> dataMap 
	 */
	public void setDataMap(Map<String, String> dataMap) {
		this.dataMap = dataMap;
	}

	/**
	 * updateCondition を戻します。
	 * 
	 * @return String
	 */
	public String getUpdateCondition() {
		return updateCondition;
	}

	/**
	 * updateCondition を設定します。
	 *
	 * @param String updateCondition 
	 */
	public void setUpdateCondition(String updateCondition) {
		this.updateCondition = updateCondition;
	}
}
