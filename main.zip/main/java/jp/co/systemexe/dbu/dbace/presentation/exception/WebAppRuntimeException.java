/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.exception;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import jp.co.systemexe.dbu.dbace.common.exception.SystemException;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * システム障害レベルの web 例外です。
 * <p>
 * プレゼンテーション層内で発生するシステム障害レベル例外です。原則、リリース
 * 段階で本例外がスローされる事はありません。テスト段階で本例外をキャッチした
 * 場合、その問題は直ちに解決されなければいけません。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class WebAppRuntimeException extends SystemException {
    final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private static final String FATAL = "致命的 : ";

    /**
     * <code>serialVersionUID</code>。
     */
    private static final long serialVersionUID = 3937823116382578724L;

    /**
     * WebAppRuntimeException の生成。
     * <p>コンストラクタ。</p>
     *
     * @param message
     * @param te
     */
    public WebAppRuntimeException(final String message, final Throwable te) {
        super(FATAL.concat(message), te);
        FacesContext.getCurrentInstance().addMessage(
            null,
            new FacesMessage("message.UidNotFound", message + " : "
                    + te.getLocalizedMessage()));
    }

    /**
     * WebAppRuntimeException の生成。
     * <p>コンストラクタ。</p>
     *
     * @param message
     */
    public WebAppRuntimeException(final String message) {
        super(FATAL.concat(message));
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage("message.UidNotFound", message));
    }

    /**
     * WebAppRuntimeException の生成。
     * <p>コンストラクタ。</p>
     *
     * @param te
     */
    public WebAppRuntimeException(final Throwable te) {
        super(te);
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage("message.UidNotFound", te.getLocalizedMessage()));
    }
}
