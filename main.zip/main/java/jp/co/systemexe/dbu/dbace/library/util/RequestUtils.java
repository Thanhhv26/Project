/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.util;

import java.io.Serializable;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
public final class RequestUtils implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/** logger */
    protected static Logger logger = LoggerFactory.getLogger(RequestUtils.class);

	// referer header key
	private static final String REQUEST_REFERER_HEADER_KEY = "Referer";

    /**
     * Get full context path (including host, port, protocol and context path)
     *
     * @param request the HTTP request to parse
     *
     * @return the full context path (including host, port, protocol and context path)
     */
    public static String getFullContextPath(HttpServletRequest request) {
    	String value = null;
    	if (request != null) {
    		String url = request.getRequestURL().toString();
    		String uri = request.getRequestURI();
    		String ctx = request.getContextPath();
    		value = url.substring(0, url.length() - uri.length()) + ctx;
    	}
    	return value;
    }
    /**
     * Get compress referer of the specified request (excluding context path)
     *
     * @param request the HTTP request to parse
     *
     * @return the compress referer of the specified request (excluding context path)
     */
    public static String getRefererURI(HttpServletRequest request) {
    	String value = getFullContextPath(request);
    	if (request != null && StringUtils.hasText(value)) {
    		String refReqURL = request.getHeader(REQUEST_REFERER_HEADER_KEY);
    		if (StringUtils.hasText(refReqURL) && refReqURL.indexOf("?") > 0) {
    			refReqURL.substring(0, refReqURL.indexOf("?") - 1);
    		}
    		if (StringUtils.hasText(refReqURL) && refReqURL.startsWith(value)) {
    			value = refReqURL.substring(value.length());
    		}
    		else {
    			value = refReqURL;
    		}
    	}
    	return value;
    }

    /**
     * Detect the specified request whether is ajax request
     *
     * @param request the request to detect
     *
     * @return true for ajax; else false
     */
    public static final boolean isAjaxRequest(HttpServletRequest request) {
    	return (request != null
    			&& Constants.AJAX_REQUEST_IDENTIFIER.equals(request.getHeader(Constants.AJAX_REQUEST_HEADER)));
    }
}
