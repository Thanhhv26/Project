package jp.co.systemexe.dbu.dbace.web.logout.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;

@RestController
@RequestMapping(value = "/web/logout")
public class LogoutController extends AbstractController {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

//	@Autowired
//	UserInfo userInfo;

	/**
	 * Logout
	 *
	 * @param error
	 * @param logout
	 * @param session
	 * @return
	 */
	@RequestMapping(method = { RequestMethod.GET })
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) {
	    Authentication auth = SecurityContextHolder.getContext().getAuthentication();

//		thanh begin
//		String userId = myUserDetails.getUserid();
//	    final String id = userId;
//	    final String clientIpAddress = myUserDetails.getClientIpAddress();
//	    final String serverName = myUserDetails.getServerName();
//	    UserInfo userInfoTemp = new UserInfo();
//	    userInfoTemp.setId(id);
//	    userInfoTemp.setClientIpAddress(clientIpAddress);
//	    userInfoTemp.setServerName(serverName);
//		thanh begin

	    if (auth != null){
	    	UserInfo userInfo = getUserInfo();
	    	try{
	    		OutputAuditLog.writeLoginLogoutLog(AuditEventKind.LOGOUT,userInfo,userInfo.getServerName(), AuditStatus.success);
	    		new SecurityContextLogoutHandler().logout(request, response, auth);
	    	}catch(Exception e){
	    		OutputAuditLog.writeLoginLogoutLog(AuditEventKind.LOGOUT,userInfo,userInfo.getServerName(),AuditStatus.failure);
	    	}
	    }
		return new ModelAndView(PageConst.SCREEN_LOGIN);
	}

}