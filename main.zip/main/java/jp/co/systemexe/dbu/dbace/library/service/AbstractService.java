/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.service;

import java.io.Serializable;

/**
 * Service Layer common abstract class
 * <p>
 * ServiceレイヤのServiceクラスはこの抽象クラスを継承してください。
 * </p>
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
public abstract class AbstractService implements Serializable {

	/** serial uid **/
	private static final long serialVersionUID = 1L;

	/** Logger. **/
	protected final jp.co.systemexe.dbu.dbace.common.logger.Logger logger = jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory.getLogger(this.getClass().getName());

	/**
	 * @see MessageService
	 */
//	@Autowired
//	protected MessageService messageService;

	/**
	 *
	 * @return
	 */
	public jp.co.systemexe.dbu.dbace.common.logger.Logger getLogger(){
		return logger;
	}

    /**
     * @return UserInfo
     */
//    public UserInfo getUserInfo(){
//    	MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//    	UserInfo userInfo = myUserDetails.getUserInfo();
//        return userInfo;
//    }
}
