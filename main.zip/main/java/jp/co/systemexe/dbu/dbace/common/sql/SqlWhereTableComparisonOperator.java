/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.sql;

import java.util.HashMap;
import java.util.Map;

/**
 * 比較演算子
 *
 * @author EXE 古賀 諭
 * @author EXE 島田 雄一郎
 */
public enum SqlWhereTableComparisonOperator {
    blank("",""),
    isNull("is null","IS NULL"),
    isNotNull("is not null","IS NOT NULL"),
    equal("=","= (等しい)"),
    notEqual("<>","<> (等しくない)"),
    greaterEqual(">=",">= (以上)"),
    lessEqual("<=","<= (以下)"),
    greaterThan(">","> (より大きい)"),
    lessThan("<","< (より小さい)"),
    likeContains("like","LIKE (含む)"),
    likeStartsWith("like","LIKE (始まる)"),
    likeEndsWith("like","LIKE (終わる)"),
    notLikeContains("not like","NOT LIKE (含まない)"),
    notLikeStartsWith("not like","NOT LIKE (始まらない)"),
    notLikeEndsWith("not like","NOT LIKE (終わらない)");

    private static Map<String, SqlWhereTableComparisonOperator> comparisonOperatorMap;
    private static Map<String, SqlWhereTableComparisonOperator> labelMap;
    private static Map<Integer, SqlWhereTableComparisonOperator> ordinalMap;

    static {
        comparisonOperatorMap = new HashMap<String, SqlWhereTableComparisonOperator>();
        labelMap = new HashMap<String, SqlWhereTableComparisonOperator>();
        ordinalMap = new HashMap<Integer, SqlWhereTableComparisonOperator>();

        for (final SqlWhereTableComparisonOperator comparisonOperator : SqlWhereTableComparisonOperator.values()) {
            comparisonOperatorMap.put(comparisonOperator.getComparisonOperator(), comparisonOperator);
            labelMap.put(comparisonOperator.getLabel(), comparisonOperator);
            ordinalMap.put(comparisonOperator.ordinal(), comparisonOperator);
        }
    }

    public static SqlWhereTableComparisonOperator comparisonOperatorOf(final String comparisonOperator) {
        return comparisonOperatorMap.get(comparisonOperator);
    }

    public static SqlWhereTableComparisonOperator labelOf(final String comparisonOperator) {
        return labelMap.get(comparisonOperator);
    }

    public static SqlWhereTableComparisonOperator ordinalOf(final Integer ordinal) {
        return ordinalMap.get(ordinal);
    }

    private String comparisonOperator;
    private String label;

    /**
     * @return comparisonOperator
     */
    public String getComparisonOperator() {
        return comparisonOperator;
    }

    /**
     * @return label
     */
    public String getLabel() {
        return label;
    }

    private SqlWhereTableComparisonOperator(final String comparisonOperator, final String label) {
        this.comparisonOperator = comparisonOperator;
        this.label = label;
    }
}
