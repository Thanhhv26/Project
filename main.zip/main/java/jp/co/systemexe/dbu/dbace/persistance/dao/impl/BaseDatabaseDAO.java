/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.jdbc.WebResultSetFacade;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.sql.SqlJoinTableLogicalOperator;
import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableComparisonOperator;
import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableLogicalOperator;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.persistance.dao.BaseConnectionManager;
import jp.co.systemexe.dbu.dbace.persistance.dao.BaseDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.ConnectionManagerFactory;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectSqlCondition;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SimpleSqlCondition;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.TableIdDefinition;
import jp.co.systemexe.dbu.dbace.persistance.dao.message.OracleMessageWrapper;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.web.common.AppConst;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.ColsDto.ColDto;

/**
 * データベース接続用の DAO 基底抽象クラスです。
 * <p>
 * 実際のデータベースメンテナンスに使用する DAO を実装するための基底抽象クラス
 * です。</p>
 *
 * @author  EXE 島田 雄一郎
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public abstract class BaseDatabaseDAO extends BaseDAO {

    /**
     * SQL の抽出文を作成する時に「'」で値を補完する属性リスト。
     */
    private static List<JDBCMetaDataType> classifiedAsCharacterList;
    static {
        classifiedAsCharacterList = new ArrayList<JDBCMetaDataType>();
        classifiedAsCharacterList.add(JDBCMetaDataType.CHAR);
        classifiedAsCharacterList.add(JDBCMetaDataType.NCHAR);
        classifiedAsCharacterList.add(JDBCMetaDataType.DATE);
        classifiedAsCharacterList.add(JDBCMetaDataType.TIME);
        classifiedAsCharacterList.add(JDBCMetaDataType.TIMESTAMP);
        classifiedAsCharacterList.add(JDBCMetaDataType.VARCHAR);
        classifiedAsCharacterList.add(JDBCMetaDataType.NVARCHAR);
        classifiedAsCharacterList.add(JDBCMetaDataType.LONGVARCHAR);
    }

    /**
     * DB 接続マネージャ。
     */
    private BaseConnectionManager connectionManager;

    public BaseConnectionManager getConnectionManager() {
		return connectionManager;
	}

	/**
     * PreparedStatement オブジェクト。
     */
    private PreparedStatement preparedStatement = null;

    /**
     * SELECT時に使用したWhere句を返します。
     */
    private String searchCondition;

    /**
     * データベースとの接続テストを実行します。
     * <p>
     * 正常に接続出来た場合はすぐにコネクションを切断しメソッドを終了します。
     * 接続に問題があった場合は例外をスローします。
     * </p>
     *
     * @param dto
     * @param connectionUserLabel
     * @throws DAOException
     */
    public void testConnect(final DbConnectInfomationDTO dto)
            throws DAOException {
        if (isConnected()) {
        	// MI-E-0007=既にデータベースへ接続されているため、テスト接続は行いません。
            final String message = MessageUtils.getMessage("MI-E-0007");
            getLogger().error(message);
            throw new DAOException(message);
        }
        try {
            connectionManager = ConnectionManagerFactory.createConnectionManager(
                dto.getDatabaseTypeConnectionDestination());
            connectionManager.getConnection(dto);
        } catch (final SQLException e) {
        	// MI-E-0032=データベースの接続に失敗しました。({0})
            final String message
            	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0032");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            connectionManager.close();
        }
    }

    /**
     * データベースとの接続を確立します。
     * <p>
     * 既に接続されている場合は例外をスローします。</p>
     *
     * @param dto DbConnectInfomationDTO
     * @exception DAOException
     */
    public void connect(final DbConnectInfomationDTO dto)
            throws DAOException {
        if (isConnected()) {
        	// MI-E-0009=既にデータベースへ接続されています。データベースとの接続を切断してください。
            final String message = MessageUtils.getMessage("MI-E-0009");
            getLogger().warn(message);
            throw new DAOException(message);
        }
        try {
            connectionManager = ConnectionManagerFactory.createConnectionManager(
                dto.getDatabaseTypeConnectionDestination());
            connectionManager.getConnection(dto);
        } catch (final SQLException e) {
        	// MI-E-0032=データベースの接続に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0032");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * データベースとの接続を閉じます。
     *
     * @throws DAOException
     */
    public void close() throws DAOException {
        if (isConnected()) {
            connectionManager.close();
        }
    }

    /**
     * データベースメタデータを戻します。
     * <p>
     * コネクションからデータベースメタデータを戻します。</p>
     *
     * @return DatabaseMetaData インターフェース
     * @throws SQLException
     */
    protected DatabaseMetaData getDatabaseMetaData() throws SQLException {
    	if (!isConnected()) {
    		throw new SQLException(MessageUtils.getMessage("MI-E-0144"));
    	}
        return connectionManager.getConnection().getMetaData();
    }

    /**
     * PreparedStatement を戻します。
     *
     * @return PreparedStatement
     */
    protected PreparedStatement getPreparedStatement() {
        return preparedStatement;
    }

    public void setPreparedStatement(PreparedStatement preparedStatement) {
		this.preparedStatement = preparedStatement;
	}

	/**
     * PreparedStatement を戻します。
     * <p>
     * クエリを設定した PreparedStatement を戻します。</p>
     * <p>
     * PreparedStatement のタイプはスクロール可、更新可能で統一です。
     * </p><p>
     * この条件は、クエリ実行後
     * </p>
     *
     * @param query SQL クエリ文字列
     * @return PreparedStatement
     * @throws DAOException
     */
    protected PreparedStatement getPreparedStatement(final String query)
            throws DAOException {
        try {
            this.preparedStatement = connectionManager.getConnection()
                .prepareStatement(query, ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
            return preparedStatement;
        } catch (final SQLException e) {
        	// MI-E-0021=データベースのカーソルの取得に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0021");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * PreparedStatement を戻します。
     * <p>
     * クエリを設定した PreparedStatement を戻します。</p>
     * <p>
     * PreparedStatement のタイプはスクロール不可、更新可能で統一です。
     * </p><p>
     * この条件は、クエリ実行後
     * </p>
     *
     * @param query SQL クエリ文字列
     * @return PreparedStatement
     * @throws DAOException
     */
    protected PreparedStatement getPreparedStatementForwardOnly(final String query)
            throws DAOException {
        try {
            this.preparedStatement = connectionManager.getConnection()
                .prepareStatement(query, ResultSet.TYPE_FORWARD_ONLY,
                    ResultSet.CONCUR_UPDATABLE);
            return preparedStatement;
        } catch (final SQLException e) {
        	// MI-E-0021=データベースのカーソルの取得に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0021");
            getLogger().error(message, e);
            throw new DAOException(e);
        }
    }

    /**
     * レコードを抽出した結果セットを戻します。
     * <p>
     * 複数カラムに対する一致条件のみのシンプルな条件で結果セットを取得し参照を
     * 戻します。</p>
     * <p>
     * 本メソッドを使用した場合は、クライアント側で結果セットの close 後、
     * getPreparedStatement の参照を経由し PreparedStatement も close しなければ
     * なりません。</p>
     *
     * @param condition
     * @param isForwardOnly
     * @return WebResultSetFacade 結果セットラッパー
     * @throws DAOException
     */
    protected WebResultSetFacade select(
    		final SelectSqlCondition condition,
    		final boolean isForwardOnly)
            throws DAOException {
    	final int offset = condition.getOffSet();
    	final int limit = condition.getLimit();
    	final String rownum_temp = "rownum_temp";
//        TableIdDefinition tableIdDefinition = new TableIdDefinition(condition.getTableId());
        String columns = createSelectClause(
        		condition.getType(), 
        		condition.getTableId(),
        		condition.getValuesMap(),
        		condition.getColumnsMap());
        if(condition.getLimit() != 0){
        	if(getConnectionManager() instanceof jp.co.systemexe.dbu.dbace.persistance.dao.db.OracleConnectionManager){//Oracle
            	columns += ", rownum " + rownum_temp;
            }
        }        

        String where = createWheresClause(
        		condition.getType(), 
        		condition.getTableId(),
        		condition.getColumnsMap(),
        		condition.getWheresMap());
        if(condition.getLimit() != 0){
        	if(getConnectionManager() instanceof jp.co.systemexe.dbu.dbace.persistance.dao.db.OracleConnectionManager){//Oracle
            	where += StringUtils.isBlank(where) ? " WHERE " : "";
            	where += String.format(" rownum <= %s ", (offset + limit));
            }
        }        
        
        String query = "select "
                + columns.toString()
                + " from "
                + createFromClause(condition)
                + " " + createJoinsClause(condition.getJoinsMap()) + " "
                + where;
                
        final String ordersClause = createOrdersClause(
                		condition.getType(),
                		condition.getTableId(),
                		condition.getColumnsMap(),
                		condition.getOrdersMap(),
                		condition.isOrderAsc());
        
        this.searchCondition = where.replace(" where ", "");
        if(condition.getLimit() != 0){
        	if(getConnectionManager() instanceof jp.co.systemexe.dbu.dbace.persistance.dao.db.SQLServerConnectionManager){//SQLServer
        		query += ordersClause;
            	query +=  String.format(" OFFSET %s ROWS FETCH NEXT %s ROWS ONLY ", offset, limit);
            } else if(getConnectionManager() instanceof jp.co.systemexe.dbu.dbace.persistance.dao.db.OracleConnectionManager){//Oracle
            	columns = columns.replace(", rownum " + rownum_temp, "");
            	query = String.format("SELECT %s FROM (SELECT * FROM (%s) WHERE %s > %s)", columns, query, rownum_temp, offset);
            	query += ordersClause;
//            	query +=  String.format(" OFFSET %s ROWS FETCH NEXT %s ROWS ONLY ", condition.getOffSet(), condition.getLimit());
            } else if(getConnectionManager() instanceof jp.co.systemexe.dbu.dbace.persistance.dao.db.PostgreSQLConnectionManager){//PostgreSQL
            	query += ordersClause;
            	query +=  String.format(" LIMIT %s OFFSET %s ", limit, offset);
            } else if(getConnectionManager() instanceof jp.co.systemexe.dbu.dbace.persistance.dao.db.MySQLConnectionManager){//MySQL
            	query += ordersClause;
            	query +=  String.format(" LIMIT %s OFFSET %s ", limit, offset);
            }
        }
        
        getLogger().debug("OFFSET:" + condition.getOffSet());
        getLogger().debug("LIMIT:" + condition.getLimit());
        
        query = query.replaceAll("\"", getConnectionManager().getQuoteId());
        getLogger().debug("select sql:" + query);

        try {
        	if (isForwardOnly) {
        		this.preparedStatement = getPreparedStatementForwardOnly(query);
        	} else {
        		this.preparedStatement = getPreparedStatement(query);
        	}
            return new WebResultSetFacade(this.preparedStatement.executeQuery());
        } catch (final SQLException e) {
            try {
                if (this.preparedStatement != null) {
                    this.preparedStatement.close();
                    this.preparedStatement = null;
                }
            } catch (final SQLException ex) {
                getLogger().warn(ex);
            }
        	// MI-E-0021=データベースのカーソルの取得に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0021");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

	/**
     *
     * @param tableId
     * @param itemId
     * @return
     */
    private String formatColumnMultiTable(String tableId, String itemId){
    	TableIdDefinition tableIdDefinition = new TableIdDefinition(tableId);
    	return String.format("\"%s\".\"%s\".\"%s\"",tableIdDefinition.getSchem(), tableIdDefinition.getTable(), itemId);
    }

    /**
     * Create columns
     * @param condition
     * @return
     */
	private String createSelectClause(final String type, final String mTableId,
			final Map<String, String> valuesMap,
			final Map<String, TableItemDTO> columnsMap) {
		if(!isMultiTable(type)){
			final StringBuffer columns = new StringBuffer();
			for (final Iterator<String> ite = valuesMap.keySet().iterator(); ite.hasNext();) {
				final String name = String.format("\"%s\"", ite.next());
				if (columns.length() <= 0) {
					columns.append(name);
				} else {
					columns.append(", ");
					columns.append(name);
				}
			}
			return columns.toString();
		}else{
			return createSelectClauseForMultiTable(mTableId, columnsMap);
		}
	}

	/**
	 * 「item->operationのselectがtrue」の場合、「item->cols->colのListNo」の順に[NULLを回避する関数]を使い「TableID.ItemID」をセットする
	 * <br/>
	 * <br/>
	 * 例：Oracleの場合で項目が3つある場合、NVL(TableID.ItemID,NVL(TableID.ItemID,NVL(TableID.ItemID,TableID.ItemID)))
	 * <br/>
	 * <br/>
	 * [NULLを回避する関数]Oracle：NVL　SQLServer：IsNULL　PostgreSQL：COALESCE　MySQL：IfNuLL
	 * @param columns
	 * @return
	 */
	protected abstract String ignoreNullColumns(final List<String> columns, final String columnType);

	/**
	 *	<p>	「item->operationのselectがfalse」の場合、「item->cols->colのListNoが1」の「TableID.ItemID」をセットする</p>
	 *	<p>	「item->operationのselectがtrue」の場合、「item->cols->colのListNo」の順に[NULLを回避する関数]を使い「TableID.ItemID」をセットする</p>
	 *	<p>	例：Oracleの場合で項目が3つある場合、NVL(TableID.ItemID,NVL(TableID.ItemID,NVL(TableID.ItemID,TableID.ItemID)))</p>
	 *	<p>	[NULLを回避する関数]Oracle：NVL　SQLServer：IsNULL　PostgreSQL：COALESCE　MySQL：IfNuLL</p>
	 * @param condition
	 * @return
	 */
	private String createSelectClauseForMultiTable(final String mTableId, final Map<String, TableItemDTO> columnsMap) {
		if (columnsMap == null || columnsMap.size() <= 0)
			return "";
		final StringBuffer columns = new StringBuffer();
		for (final Iterator<TableItemDTO> ite = columnsMap.values().iterator(); ite.hasNext();) {
			TableItemDTO tableItem = ite.next();
			if (tableItem.isRoot()) {
				// 「item->operationのselectがfalse」の場合、「item->cols->colのListNoが1」の「TableID.ItemID」をセットする
				if (tableItem.getOperations() != null && !tableItem.getOperations().isSelect()) {
					if (tableItem.getCols() != null && tableItem.getCols().size() > 0) {
						for (Iterator<String> iterator = tableItem.getCols().keySet().iterator(); iterator.hasNext();) {
							String listNo = (String) iterator.next();
							ColDto colDto = tableItem.getCols().get(listNo);
							String name = formatColumnMultiTable(colDto.getTableID(), colDto.getItemID());
							name += String.format(" AS \"%s\"", tableItem.getItemId());
							if (columns.length() <= 0) {
								columns.append(name);
							} else {
								columns.append(", ");
								columns.append(name);
							}
							break;
						}
					} else {
						final String name = formatColumnMultiTable(tableItem.getTableId(), tableItem.getItemId());
						if (columns.length() <= 0) {
							columns.append(name);
						} else {
							columns.append(", ");
							columns.append(name);
						}
					}
				}
				// 「item->operationのselectがtrue」の場合、「item->cols->colのListNo」の順に[NULLを回避する関数]を使い「TableID.ItemID」をセットする
				if (tableItem.getOperations() != null && tableItem.getOperations().isSelect()) {
					List<String> colList = new ArrayList<String>();
					if (tableItem.getCols() != null && tableItem.getCols().size() > 0) {
						for (Iterator<String> iterator = tableItem.getCols().keySet().iterator(); iterator.hasNext();) {
							String listNo = (String) iterator.next();
							ColDto colDto = tableItem.getCols().get(listNo);
							final String name = formatColumnMultiTable(colDto.getTableID(), colDto.getItemID());
							colList.add(name);
						}

						if (colList.size() > 0) {
							String name = ignoreNullColumns(colList, tableItem.getDataType());
							if (null != name && !"".equals(name)) {
								name += String.format(" AS \"%s\"", tableItem.getItemId());
								if (columns.length() <= 0) {
									columns.append(name);
								} else {
									columns.append(", ");
									columns.append(name);
								}
							}
						}
					} else {
						final String name = formatColumnMultiTable(mTableId, tableItem.getItemId());
						if (columns.length() <= 0) {
							columns.append(name);
						} else {
							columns.append(", ");
							columns.append(name);
						}
					}

				}
			}
		}
		return columns.toString();
	};

	/**
	 * @param mTableId
	 * @param tableItem
	 * @param item
	 * @return clause where of column
	 */
	public String createNVLOrIsNullInWhere(String mTableId,TableItemDTO tableItem,SelectConditionItem item){
		final StringBuffer columns = new StringBuffer();
		if (tableItem.getOperations() != null && tableItem.getOperations().isSelect()) {
			List<String> colList = new ArrayList<String>();
			if (tableItem.getCols() != null && tableItem.getCols().size() > 0) {
				for (Iterator<String> iterator = tableItem.getCols().keySet().iterator(); iterator.hasNext();) {
					String listNo = (String) iterator.next();
					ColDto colDto = tableItem.getCols().get(listNo);
					final String name = formatColumnMultiTable(colDto.getTableID(), colDto.getItemID());
					colList.add(name);
				}

				if (colList.size() > 0) {
					String name = ignoreNullColumns(colList, tableItem.getDataType());
					if (null != name && !"".equals(name)) {
						if (item.getComparisonOperator().equals(SqlWhereTableComparisonOperator.isNull)
		                        || item.getComparisonOperator().equals(SqlWhereTableComparisonOperator.isNotNull)) {
							name += item.getComparisonOperator().getComparisonOperator();
						} else {
//							String  wheresClause = createFuncCheckNullSelectWheresClause(item);
//							name += wheresClause;
							name += item.getComparisonOperator().getComparisonOperator() + "'" + getPatternMatchCondition(item.getComparisonOperator(), item.getValue()) + "'";
						}
						if (columns.length() <= 0) {
							columns.append(name);
						} else {
							columns.append(", ");
							columns.append(name);
						}
					}
				}
			} else {
				final String name = formatColumnMultiTable(mTableId, tableItem.getItemId());
				if (columns.length() <= 0) {
					columns.append(name);
				} else {
					columns.append(", ");
					columns.append(name);
				}
			}
		}
		return columns.toString();
	}

	/**
     * レコードを抽出した結果セットを戻します。
     * <p>
     * 複数カラムに対する一致条件のみのシンプルな条件で結果セットを取得し参照を
     * 戻します。</p>
     * <p>
     * 本メソッドを使用した場合は、クライアント側で結果セットの close 後、
     * getPreparedStatement の参照を経由し PreparedStatement も close しなければ
     * なりません。</p>
     *
     * @param condition
     * @return WebResultSetFacade 結果セットラッパー
     * @throws DAOException
     */
    protected WebResultSetFacade select(final SelectSqlCondition condition)
            throws DAOException {
    	return select(condition, false);
    }

    /**
     * レコード件数を抽出した結果セットを戻します。
     * <p>
     * 複数カラムに対する一致条件のみのシンプルな条件で結果セットを取得し参照を
     * 戻します。</p>
     * <p>
     * 本メソッドを使用した場合は、クライアント側で結果セットの close 後、
     * getPreparedStatement の参照を経由し PreparedStatement も close しなければ
     * なりません。</p>
     *
     * @param condition
     * @return WebResultSetFacade 結果セットラッパー
     * @throws DAOException
     */
    protected String rowCount(final SelectSqlCondition condition)
            throws DAOException {
        final String where = createWheresClause(condition.getType(), condition.getTableId(), condition.getColumnsMap(), condition.getWheresMap());
        final String query = "select "
                + "COUNT(*)"
                + " from "
                + createFromClause(condition)
                + " " + createJoinsClause(condition.getJoinsMap()) + " "
                + where;

        getLogger().debug(query);
        this.searchCondition = where.replace(" where ", "");

        return query;
    }

    private String createFromClause(final SelectSqlCondition condition) {
    	TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
    	if (isMultiTable(condition.getType())) {
    		String mTableId = getTableMasterId(condition.getJoinsMap());

    		if(condition.getJoinsMap() == null || condition.getJoinsMap().size() == 0){
    			mTableId = condition.getTablesMap().keySet().iterator().next();
    		}

    		tableiddefinition = new TableIdDefinition(mTableId);
    	}
    	return String.format("\"%s\".\"%s\"",tableiddefinition.getSchem(), tableiddefinition.getTable());
	}

    private String getTableMasterId(SortedMap<String, ApplicationRelationDTO> relationsMap){
    	if(relationsMap != null && relationsMap.size() > 0){
    		for (Iterator<ApplicationRelationDTO> iterator = relationsMap.values().iterator(); iterator.hasNext();) {
    			ApplicationRelationDTO relation = (ApplicationRelationDTO) iterator.next();
				for (Iterator<TableDTO> tableIterator = relation.getTables().iterator(); tableIterator.hasNext();) {
					TableDTO relationTable = (TableDTO) tableIterator.next();
					if(relationTable.getType().equals(AppConst.RELATION_TABLE_MASTER)){
						return relationTable.getTableid();
					}

				}
			}
    	}
    	return "";
    }

    /**
     * レコード件数を抽出した結果セットを戻します。
     * <p>
     * 複数カラムに対して全て Like による曖昧条件で結果セットを取得し参照を戻し
     * ます。</p>
     * <p>
     * 本メソッドを使用した場合は、クライアント側で結果セットの close 後、
     * getPreparedStatement の参照を経由し PreparedStatement も close しなければ
     * なりません。</p>
     *
     * @param condition
     * @return WebResultSetFacade 結果セットラッパー
     * @throws DAOException
     */
    protected String rowCountLike(final SelectSqlCondition condition)
            throws DAOException {
        TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
        final String where = createWheresClause(condition.getType(), condition.getTableId(), condition.getColumnsMap(), condition.getWheresMap());
        final String query = "select "
                + "COUNT(*)"
                + " from "
                + String.format("\"%s\".\"%s\"",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + where;

        getLogger().debug(query);
        this.searchCondition = where.replace(" where ", "");

        return query;
    }

    /**
     * レコードを更新します。
     * <p>
     * 複数カラムに対する一致条件のみのシンプルな条件で、対象レコードを更新
     * します。</p>
     *
     * @param condition 条件設定オブジェクト
     * @throws DAOException
     */
    protected void update(
    		final SimpleSqlCondition condition,
    		final String databaseId,
    		final UserInfo userInfo
    		)
            throws DAOException {
    	final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
        TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
        final StringBuffer columns = new StringBuffer();
        for (final String name : condition.getValuesMap().keySet()) {
        	String aliasName = "";
        	for(Map.Entry<String, String> aliasEntry:condition.getAliasNameMap().entrySet()){
        		if (aliasEntry.getValue().equals(name)){
        			aliasName = aliasEntry.getKey();
        		}
        	}
        	final Boolean isVirtualColumn = condition.getVirtualColumns().get(name);
        	if (isVirtualColumn != null
        			&& isVirtualColumn) {
        		continue;
        	}
        	String columnname = String.format("\"%s\" as \"%s\"", name, aliasName);
            if (columns.length() <= 0) {
                columns.append(columnname);
            } else {
                columns.append(", ");
                columns.append(columnname);
            }
        }
        final String where = createSimpleWheresString(condition);
        final String query = "select " + columns.toString() + " from "
        + String.format("\"%s\".\"%s\"",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + where;

        getLogger().debug(query);

        this.preparedStatement = getPreparedStatement(query);

        final WebResultSetFacade facade;
        try {
            facade = new WebResultSetFacade(this.preparedStatement
                .executeQuery());
        } catch (final SQLException e) {
        	// MI-E-0079=レコードの更新に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0079");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        boolean isSuccess = true;
        try {
            facade.first();
            facade.updateMap(condition);
            facade.updateRow();
            isSuccess = true;
        } catch (final SQLException e) {
            isSuccess = false;
        	getLogger().error(e.getErrorCode() + "," + e.getSQLState() + "," + e.getLocalizedMessage());
        	// MI-E-0079=レコードの更新に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0079");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } catch (final DAOException e) {
            isSuccess = false;
            throw e;
        } finally {
            try {
				OutputAuditLog.writeExcuteUpdateLog(
						AuditEventKind.UPDATE,
						userInfo,
						connectDefinitionListLogic.getConnectionByID(condition.getConnectDefinitionId()).getLabel(),
						connectDefinitionListLogic.getTableForm(condition.getConnectDefinitionId(), condition.getTableId()).getLabel(),
						isSuccess ? AuditStatus.success : AuditStatus.failure,
						condition.getValuesMap(),
						where.replace(" where ", ""),
						isSuccess ? "1" : "0");
			} catch (ApplicationDomainLogicException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

            facade.close();
        }
    }

    /**
     * レコードを削除します。
     * <p>
     * 複数カラムに対する一致条件のみのシンプルな条件で、対象レコードを削除
     * します。</p>
     *
     * @param condition 条件設定オブジェクト
     * @throws DAOException
     */
    protected int delete(
    		final SimpleSqlCondition condition,
    		final String databaseId,
    		final UserInfo userInfo
    		)
            throws DAOException {
        TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
    	final String where = createSimpleWheresString(condition);
        final String query = "delete from "
                + String.format("\"%s\".\"%s\"",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + where;

        getLogger().debug(query);
        int rowAffected = 0;
        boolean isSuccess = true;
        PreparedStatement statement = null;
        try {
        	statement = connectionManager
                .getConnection().prepareStatement(query);
            rowAffected = statement.executeUpdate();
            isSuccess = true;
        } catch (final SQLException e) {
            isSuccess = false;

        	// MI-E-0081=レコードの削除に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0081");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
        	final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
            try {
				OutputAuditLog.writeExcuteUpdateLog(
						AuditEventKind.DELETE,
						userInfo,
						connectDefinitionListLogic.getConnectionByID(condition.getConnectDefinitionId()).getLabel(),
						connectDefinitionListLogic.getTableForm(condition.getConnectDefinitionId(), condition.getTableId()).getLabel(),
						isSuccess ? AuditStatus.success : AuditStatus.failure,
						condition.getValuesMap(),
						where.replace(" where ", ""),
						isSuccess ? "1" : "0");
			} catch (ApplicationDomainLogicException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

            if (statement != null) {
            	try {
            		statement.close();
            	} catch (final SQLException e) {
            		getLogger().warn(e);
            	}
            }
        }
        return rowAffected;
    }

    /**
     * レコードを追加します。
     * <p>
     * テーブル名と値のコレクションを与えるとレコードの追加を行います。</p>
     *
     * @param condition 条件設定オブジェクト
     * @throws DAOException
     */
    protected void insert(
    		final SimpleSqlCondition condition,
    		final String databaseId,
    		final UserInfo userInfo
    		)
            throws DAOException {
        final StringBuffer columns = new StringBuffer();
        TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());

        for (final String name : condition.getValuesMap().keySet()) {
        	final Boolean isVirtualColumn = condition.getVirtualColumns().get(name);
        	if (isVirtualColumn != null
        			&& isVirtualColumn) {
        		continue;
        	}
        	String columnname = String.format("\"%s\"", name);
            if (columns.length() <= 0) {
                columns.append(columnname);
            } else {
                columns.append(", ");
                columns.append(columnname);
            }
        }
        final String query = "select " + columns.toString() + " from "
                + String.format("\"%s\".\"%s\"",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + createSimpleWheresString(condition);

        getLogger().debug(query);

        this.preparedStatement = getPreparedStatement(query);

        WebResultSetFacade facade = null;
        boolean isSuccess = true;
        try {
            facade = new WebResultSetFacade(this.preparedStatement
                .executeQuery());
            facade.moveToInsertRow();
            facade.insertMap(condition);
            facade.insertRow();
            isSuccess = true;
        } catch (final SQLException e) {
            isSuccess = false;

            // MI-E-0097=レコードの登録に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0097");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } catch (final DAOException e) {
            isSuccess = false;

            throw e;
        } finally {
        	final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
            try {
				OutputAuditLog.writeExcuteUpdateLog(
						AuditEventKind.INSERT,
						userInfo,
						connectDefinitionListLogic.getConnectionByID(condition.getConnectDefinitionId()).getLabel(),
						connectDefinitionListLogic.getTableForm(condition.getConnectDefinitionId(), condition.getTableId()).getLabel(),
						isSuccess ? AuditStatus.success : AuditStatus.failure,
						condition.getValuesMap(),
						"",
						isSuccess ? "1" : "0");
			} catch (ApplicationDomainLogicException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

        	if (facade != null) {
        		facade.close();
        	}
            try {
                if (this.preparedStatement != null) {
                    this.preparedStatement.close();
                    this.preparedStatement = null;
                }
            } catch (final SQLException ex) {
                getLogger().warn(ex);
            }
        }
    }

	/**
	 * 昇順指定の order 句を作成して戻す。
	 * <p>
	 * 先頭に ' order by ' も修飾して戻します。
	 * </p>
	 * <p>
	 * 条件指定が無い場合は空文字を戻します。
	 * </p>
	 *
	 * @param ordersMap
	 *            カラムソート順定義マップ
	 * @param asc
	 *            昇順フラグ（true : 昇順 / false : 降順）
	 * @return
	 */
	private String createOrdersClause(final String type, final String tableId,
			final Map<String, TableItemDTO> columnsMap, final SortedMap<Integer, String> ordersMap,
			final Boolean isOrderAsc) {
		if (!isMultiTable(type)) {
			return createOrdersClause(ordersMap, isOrderAsc);
		} else {
			return createOrdersClauseForMultiTable(tableId, columnsMap, ordersMap, isOrderAsc);
		}
	}

	protected String createOrdersClause(SortedMap<Integer, String> ordersMap, boolean asc) {
		if (ordersMap.size() <= 0) {
			return "";
		} else {
			final StringBuffer orders = new StringBuffer();
			for (final Iterator<String> ite = ordersMap.values().iterator(); ite.hasNext();) {
				final String name = String.format("\"%s\"", ite.next());

				if (orders.length() <= 0) {
					orders.append(name);
				} else {
					orders.append(",");
					orders.append(name);
				}
				orders.append((asc ? " asc" : " desc"));
			}
			return " order by " + orders.toString();
		}
	}

	/**
	 *
	 * @param tableId
	 * @param columnsMap
	 * @param ordersMap
	 * @param isOrderAsc
	 * @return
	 */
	private String createOrdersClauseForMultiTable(final String tableId, final Map<String, TableItemDTO> columnsMap,
			final SortedMap<Integer, String> ordersMap, final Boolean isOrderAsc) {
		if (ordersMap.size() <= 0)
			return "";
		final StringBuffer orders = new StringBuffer();
		for (final Iterator<String> ite = ordersMap.values().iterator(); ite.hasNext();) {
			String columnId = ite.next();
			if (columnsMap.containsKey(columnId) && columnsMap.get(columnId).getCols() != null
					&& columnsMap.get(columnId).getCols().size() > 0) {
				TableItemDTO tableItem = columnsMap.get(columnId);
				if (tableItem.getCols() != null && tableItem.getCols().size() > 0) {
					List<String> colList = new ArrayList<String>();
					for (Iterator<String> iterator = tableItem.getCols().keySet().iterator(); iterator.hasNext();) {
						String listNo = (String) iterator.next();
						ColDto colDto = tableItem.getCols().get(listNo);
						final String name = formatColumnMultiTable(colDto.getTableID(), colDto.getItemID());
						colList.add(name);
					}
					if (colList.size() > 0) {
						final String name = ignoreNullColumns(colList, tableItem.getDataType());
						if (orders.length() <= 0) {
							orders.append(name);
						} else {
							orders.append(", ");
							orders.append(name);
						}
						orders.append((isOrderAsc ? " asc" : " desc"));
					}
				}
			} else {
				final String name = formatColumnMultiTable(tableId, columnId);
				if (orders.length() <= 0) {
					orders.append(name);
				} else {
					orders.append(",");
					orders.append(name);
				}
				orders.append((isOrderAsc ? " asc" : " desc"));
			}
		}
		return " order by " + orders.toString();
	}

	/**
     * 項目名と値を単純に「=」で接続した Where 句文字列を作成して戻す。
     * <p>
     * 先頭に ' where ' も修飾して戻します。</p>
     * <p>
     * 条件指定が無い場合は空文字を戻します。</p>
     *
     * @param wheresMap
     * @return
     */
     protected String createSimpleWheresString(final SimpleSqlCondition condition) {
        final Map<String, String> wheresMap = condition.getWheresMap();
        if (wheresMap.size() <= 0) {
            return "";
        } else {
            final StringBuffer wheres = new StringBuffer();
            for (final Iterator<String> ite = wheresMap.keySet().iterator(); ite
                    .hasNext();) {
                final String name = ite.next();
                final String columnname = String.format("\"%s\"", name);
                final String singleQuart = additionSingleQuart(condition.getJdbcMetaDataMap().get(name));
                final String value = wheresMap.get(name);
                if (wheres.length() <= 0) {
                    if (value.equals("")) {
                        wheres.append("(");
                        if (singleQuart.endsWith("'")) {
                            wheres.append(columnname);
                            wheres.append(" = ");
                            wheres.append(singleQuart);
                            wheres.append(value.replace("'", "''"));
                            wheres.append(singleQuart);
                            wheres.append(" or ");
                        }
                        wheres.append(columnname);
                        wheres.append(" is null ");
                        wheres.append(")");
                    } else {
                        wheres.append(columnname);
                        wheres.append(" = ");
                        wheres.append(singleQuart);
                        wheres.append(value.replace("'", "''"));
                        wheres.append(singleQuart);
                    }
                } else {
                    wheres.append(" and ");
                    if (value.equals("")) {
                        wheres.append("(");
                        if (singleQuart.endsWith("'")) {
                            wheres.append(columnname);
                            wheres.append(" = ");
                            wheres.append(singleQuart);
                            wheres.append(value.replace("'", "''"));
                            wheres.append(singleQuart);
                            wheres.append(" or ");
                        }
                        wheres.append(columnname);
                        wheres.append(" is null ");
                        wheres.append(")");
                    } else {
                        wheres.append(columnname);
                        wheres.append(" = ");
                        wheres.append(singleQuart);
                        wheres.append(value.replace("'", "''"));
                        wheres.append(singleQuart);
                    }
                }
            }
            return " where ".concat(wheres.toString());
        }
    }

    /**
     * 項目名と値を単純に「=」で接続した Where 句文字列を作成して戻す。
     * <p>
     * 先頭に ' where ' も修飾して戻します。</p>
     * <p>
     * 条件指定が無い場合は空文字を戻します。</p>
     *
     * @param wheresMap
     * @return
     */
    protected abstract String createSelectWheresClause(
            final SortedMap<Integer, SelectConditionItem> wheresMap);

    protected abstract String createFuncCheckNullSelectWheresClause(SelectConditionItem item);

    /**
     *
     * <p>	「relations->relationのListNO」の順番に「id」を取得。「id」を条件に「connectDefinision->relation_info->relationのid」を見つける</p>
     * <p>	該当するリレーション情報からFROMを生成する 構文例：　(マスタ 結合方法 ディテール ON 結合条件)　　　※リレーション1つずつを「()」で括る</p>
     * <p>	「table.type」が「master」の「table.tableid」をセット</p>
     * <p>  「table.type」が「detail」の「table.tableid」をセット</p>
     * <p>  「relation.type」をセット</p>
     * <p>	「itemsのitem」の数だけ作成する。複数ある場合は「AND」で繋げる</p>
     * <p>	左辺：【「table.type」が「master」の「table.tableid」】.【「item.master」】</p>
     * <p>	右辺：【「table.type」が「detail」の「table.tableid」】.【「item.master」】</p>
     *
     * @param relationsMap
     * @return
     */
    private String createJoinsClause(final SortedMap<String, ApplicationRelationDTO> relationsMap){
    	String join = " ";
    	if(relationsMap == null || relationsMap.size() == 0) return join;
    	String rootTableId = null;
    	List<String> tablesJoinedList = new ArrayList<String>();

		for (Iterator<ApplicationRelationDTO> iterator = relationsMap.values().iterator(); iterator.hasNext();) {
			ApplicationRelationDTO relation = (ApplicationRelationDTO) iterator.next();
			getLogger().info(relation.getRelationLabel());
			String type = relation.getRelationType().toLowerCase().replaceAll(" ", "");
			String mMasterId = "";
			String mDetailId = "";
			for (Iterator<TableDTO> tableIterator = relation.getTables().iterator(); tableIterator.hasNext();) {
				TableDTO relationTable = (TableDTO) tableIterator.next();
				TableIdDefinition tableIdDefinition = new TableIdDefinition(relationTable.getTableid());
				String tableId = String.format("\"%s\".\"%s\"", tableIdDefinition.getSchem(),
						tableIdDefinition.getTable());
				if (relationTable.getType().equals(AppConst.RELATION_TABLE_MASTER)) {
					mMasterId = tableId;
				} else {
					mDetailId = tableId;
				}
			}

			// Set first mMasterId of table in relations is FROM
			if(rootTableId == null){
				rootTableId = mMasterId;
				tablesJoinedList.add(rootTableId);
			}

			if(rootTableId != mMasterId){
				if(!tablesJoinedList.contains(mMasterId)){
					join += " " + SqlJoinTableLogicalOperator.valueOf(type).getLogicalOperator() + " " + mMasterId;
					tablesJoinedList.add(mMasterId);
				}
			}
			if(rootTableId != mDetailId){
				if(!tablesJoinedList.contains(mDetailId)){
					join += " " + SqlJoinTableLogicalOperator.valueOf(type).getLogicalOperator() + " " + mDetailId;
					tablesJoinedList.add(mDetailId);
				}
			}

			join += " " + SqlJoinTableLogicalOperator.on.getLogicalOperator() + " ";
			String cond = " ";
			for (Iterator<ItemDTO> itemIterator = relation.getItems().iterator(); itemIterator.hasNext();) {
				ItemDTO relationItem = (ItemDTO) itemIterator.next();
				join += cond;
				join += mDetailId + "." + String.format("\"%s\"", relationItem.getDetail()) + " = " + mMasterId
						+ "." + String.format("\"%s\"", relationItem.getMaster());
				cond = " " + SqlWhereTableLogicalOperator.and.getLogicalOperator() + " ";
			}
		}
    	join = join.replace("  ", " ");
    	return join;
    };

//    private List<ApplicationRelationDTO> getRelationsByTableId(String relationId, String tableId,
//    		SortedMap<String, ApplicationRelationDTO> relationsMap, boolean isTableMaster){
//    	List<ApplicationRelationDTO> listRelateDTO = new ArrayList<ApplicationRelationDTO>();
//    	if(relationsMap == null || relationsMap.size() == 0) return listRelateDTO;
//
//    	for (Iterator<ApplicationRelationDTO> iterator = relationsMap.values().iterator(); iterator.hasNext();) {
//			ApplicationRelationDTO relation = (ApplicationRelationDTO) iterator.next();
//			for (Iterator<TableDTO> tableIterator = relation.getTables().iterator(); tableIterator.hasNext();) {
//				TableDTO relationTable = (TableDTO) tableIterator.next();
//				TableIdDefinition tableIdDefinition = new TableIdDefinition(relationTable.getTableid());
//				String tbl = String.format("\"%s\".\"%s\"", tableIdDefinition.getSchem(),
//						tableIdDefinition.getTable());
//				if(relationId != relation.getRelationId() && tableId.equals(tbl)){
//					listRelateDTO.add(relation);
//				}
//			}
//    	}
//    	return listRelateDTO;
//    }


    /**
     *
     * @param type
     * @param mTableId: table master ID
     * @param columnsMap
     * @param wheresMap
     * @return
     */
    private String createWheresClause(String type, String mTableId, Map<String, TableItemDTO> columnsMap,
			SortedMap<Integer, SelectConditionItem> wheresMap) {
    	if (!isMultiTable(type)) {
    		return createSelectWheresClause(wheresMap);
    	}else{
    		return createWheresClauseForMultiTable(mTableId, columnsMap, wheresMap);
    	}
	}

    /**
     *
     * @param type
     * @return
     */
    protected boolean isMultiTable(final String type){
    	if (type == null || type.equals("")) {
    		return false;
    	}
    	return true;
    }

    /**
//  *
//  */
	public TableDefinitionDTO getTableDefinition(TableFormDTO tableFormDTO) throws DAOException {
		final DatabaseMetaData meta;
		try {
			meta = getDatabaseMetaData();
		} catch (final SQLException e) {
			// MI-E-0031=データベースのメタデータ取得に失敗しました。
			final String message = MessageUtils.getMessage("MI-E-0031");
			getLogger().error(message, e);
			throw new DAOException(message, e);
		}

		int index = 0;
		if (isMultiTable(tableFormDTO.getType())) {
			final TableDefinitionDTO multiTableDefinitionDTO = new TableDefinitionDTO(tableFormDTO.getTableFormId());
			for (Iterator<TableItemDTO> iterator = tableFormDTO.getTableItemMap().values().iterator(); iterator.hasNext();) {
				TableItemDTO tableItemDTO = (TableItemDTO) iterator.next();
				TableIdDefinition id = new TableIdDefinition(tableItemDTO.getTableId());
				// In case tableItemDTO has childs col
				if(tableItemDTO.isRoot()){
					JDBCMetaDataType metaDataType = null;
					String columnTypeName = null;
					for (Iterator<ColDto> iterator2 = tableItemDTO.getCols().values().iterator(); iterator2.hasNext();) {
						ColDto colDto = (ColDto) iterator2.next();
						final TableIdDefinition tableIdDefinition = new TableIdDefinition(colDto.getTableID());

						try {
				            checkTableName(tableIdDefinition, meta);
				        } catch (SQLException e) {
				            throw new DAOException(e.getMessage());
				        }

						String name = getColumnName(tableIdDefinition, meta, colDto.getItemID());

						if (name != null) {
							String colName = formatColumnMultiTable(colDto.getTableID(), name);
							final DefinitionOfColumn columnDef = new DefinitionOfColumn(name);
				            columnDef.setTableId(colDto.getTableID());

				            setPrimaryKeys(meta, tableIdDefinition, columnDef);
							setFkKeys(meta, tableIdDefinition, columnDef);
							setUniqueColumn(meta, tableIdDefinition, columnDef);
							setColumnTypeNames(meta, tableIdDefinition, columnDef);
							setResultSetMetaData(tableIdDefinition, columnDef);
							setRemarks(meta, tableIdDefinition, columnDef);

							multiTableDefinitionDTO.getDefinitionOfColumnMap().put(colName, columnDef);
							if(metaDataType == null){
								metaDataType = columnDef.getJDBCMetaDataType();// Get first col jdbc data type
							}
							if(columnTypeName == null){
								columnTypeName = columnDef.getColumnTypeName();
							}
						}
					}
//					multiTableDefinitionDTO.getColumnNames().put(index, tableItemDTO.getItemId());
//					index++;
					//id = new TableIdDefinition(tableItemDTO.getCols().values().iterator().next().getTableID());
					final DefinitionOfColumn columnDef = new DefinitionOfColumn(tableItemDTO.getItemId());
					columnDef.setTableId(tableItemDTO.getTableId());
					columnDef.setJDBCMetaDataType(metaDataType);
//					columnDef.setPrimaryKey(tableItemDTO.getPrimaryKey());
//					columnDef.setUnique(tableItemDTO.getUnique());
//					columnDef.setForeignKey(tableItemDTO.getForeignKey());
//
					columnDef.setColumnTypeName(columnTypeName);
//					setResultSetMetaData(id, columnDef);
//					columnDef.setNotNull(false);
//					multiTableDefinitionDTO.getColumnNames().put(index, tableItemDTO.getItemId());
					multiTableDefinitionDTO.getDefinitionOfColumnMap().put(tableItemDTO.getItemId(), columnDef);
					index++;
				}else{
					//final TableIdDefinition id = new TableIdDefinition(tableItemDTO.getTableId());
					try {
			            checkTableName(id, meta);
			        } catch (SQLException e) {
			            throw new DAOException(e.getMessage());
			        }

					String name = getColumnName(id, meta, tableItemDTO.getItemId());
					if (name != null) {
						String colName = formatColumnMultiTable(tableItemDTO.getTableId(), name);
						final DefinitionOfColumn columnDef = new DefinitionOfColumn(name);
			            columnDef.setTableId(tableItemDTO.getTableId());

			            setPrimaryKeys(meta, id, columnDef);
						setFkKeys(meta, id, columnDef);
						setUniqueColumn(meta, id, columnDef);
						setColumnTypeNames(meta, id, columnDef);
						setResultSetMetaData(id, columnDef);
						setRemarks(meta, id, columnDef);

			            multiTableDefinitionDTO.getColumnNames().put(index, colName);
						multiTableDefinitionDTO.getDefinitionOfColumnMap().put(colName, columnDef);
						index++;
					}
				}

			}


			multiTableDefinitionDTO.setView(false);
			multiTableDefinitionDTO.outputDebugLog();
			return multiTableDefinitionDTO;
		} else {
			return getTableDefinition(tableFormDTO.getTableFormId());
		}
	}

    protected TableDefinitionDTO getTableDefinition(String tableFormId) throws DAOException {
		return null;
	}

	/**
     * カラム名の一覧を取得して Map に設定して戻します。
     *
     * @param id
     * @return
     * @throws DAOException
     */
    protected String getColumnName(
    		final TableIdDefinition id,
            final DatabaseMetaData meta,
            final String columnName)
            throws DAOException {
    	String name = null;
        try {
            final ResultSet rs = meta.getColumns(null, id.getSchem(), id
                .getTable(), columnName);
            while (rs.next()) {
                name = rs.getString("COLUMN_NAME");
            }
            rs.close();
        } catch (final SQLException e) {
        	// MI-E-0025=カラム名の一覧取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0025");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        return name;
    }

    protected void setPrimaryKeys(
            final DatabaseMetaData meta, final TableIdDefinition id,
            final DefinitionOfColumn colDef) throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getPrimaryKeys(null, id.getSchem(), id.getTable());
            while (rs.next()) {
                if(colDef != null && colDef.getColumnId().equals(rs.getString("COLUMN_NAME"))){
                	colDef.setPrimaryKey(true);
                	colDef.setUnique(true);
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0010=主キー（Primary Key)の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0010");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    protected void setFkKeys(final DatabaseMetaData meta,
            final TableIdDefinition id, final DefinitionOfColumn colDef)
            throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getImportedKeys(null, id.getSchem(), id.getTable());
            while (rs.next()) {
            	if(colDef != null && colDef.getColumnId().equals(rs.getString("FKCOLUMN_NAME"))){
            		colDef.setForeignKey(true);
            	}
            }
        } catch (final SQLException e) {
        	// MI-E-0006=外部キー(Foreign Key)の取得に失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0006");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    protected void setUniqueColumn(
            final DatabaseMetaData meta, final TableIdDefinition id,
            final DefinitionOfColumn colDef) throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getIndexInfo(null, id.getSchem(), id.getTable(), true,
                true);
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                if (colDef != null && name != null && name.equals("") == false) {
                    colDef.setUnique(true);
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0018=ユニークキー（Unique Key)の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0018");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    protected void setColumnTypeNames(
            final DatabaseMetaData meta,
            final TableIdDefinition id,
            final DefinitionOfColumn colDef)
            throws DAOException {
        try {
            final ResultSet rs = meta.getColumns(null, id.getSchem(), id.getTable(), "%");
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                final String type = rs.getString("TYPE_NAME");
                if(colDef != null && colDef.getColumnId().equals(name)){
	                if(colDef != null){
	                	colDef.setColumnTypeName(type);
	                }
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0123=カラムのデータ型の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0123");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    protected void setResultSetMetaData(
            final TableIdDefinition id, DefinitionOfColumn def)
            throws DAOException {
        final StringBuffer columnSql = new StringBuffer();
        columnSql.append(def.getColumnId());

        final String sql = "select " + columnSql.toString() + " from "
                + id.getTableId() + " where 1=2";
        final PreparedStatement statement = getPreparedStatement(sql);
        final ResultSet rs;
        try {
            rs = statement.executeQuery();
        } catch (final SQLException e) {
        	// MI-E-0071=結果セットの取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0071");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }

        try {
            final ResultSetMetaData meta = rs.getMetaData();
            for (int i = 1; i <= meta.getColumnCount(); i++) {
                final String name = meta.getColumnName(i);

                if(def != null && def.getColumnId().equals(name)){
	                def.getDefinitionOfNumericalValue().setPrecision(
	                    meta.getPrecision(i));
	                def.getDefinitionOfNumericalValue().setScale(meta.getScale(i));
	                def.setAutoIncrement(meta.isAutoIncrement(i));
	                def.setColumnDisplayMaxSize(meta.getColumnDisplaySize(i));
	                getJDBCMetaDataType(meta, i, def);
	                if (meta.isNullable(i) == ResultSetMetaData.columnNullable) {
	                    def.setNotNull(false);
	                } else {
	                    def.setNotNull(true);
	                }
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0024=カラム情報の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0024");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                statement.close();
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    /**
     * 別のカラム型情報を取得します。
     * カラム型情報を戻します。
     * @param meta
     * @param i
     * @param def
     * @throws SQLException
     */
    protected void getJDBCMetaDataType(final ResultSetMetaData meta, int i,
			final DefinitionOfColumn def) throws SQLException {
		if(def.getColumnTypeName().equals("time")){
	    	def.setJDBCMetaDataType(JDBCMetaDataType.TIME);
	    }else if(def.getColumnTypeName().equals("datetime2")) {
	    	def.setJDBCMetaDataType(JDBCMetaDataType.TIMESTAMP);
	    }else if(def.getColumnTypeName().equals("date")){
	    	def.setJDBCMetaDataType(JDBCMetaDataType.DATE);
	    }else if (def.getColumnTypeName().equals("datetimeoffset")){
	    	def.setJDBCMetaDataType(JDBCMetaDataType.OTHER);
		} else {
	    	def.setJDBCMetaDataType(JDBCMetaDataType.dataTypeOf(meta
	                .getColumnType(i)));
		}
	}

    protected void setRemarks(
            final DatabaseMetaData meta,
            final TableIdDefinition id,
            DefinitionOfColumn colDef)
            throws DAOException {
        try {
            final ResultSet rs = meta.getColumns(null, id.getSchem(), id.getTable(), colDef.getColumnId());
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                if(colDef != null && colDef.getColumnId().equals(name)){
                	colDef.setRemarks(rs.getString("REMARKS"));
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0022=カラムのコメント(REMARKS)取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0022");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }



    /**
     *	<p> ①画面の対象項目に該当する「itemのid」を確認し「iteem->operationのselect」の値を取得</p>
	 *  <p> select=falseの場合、「item->cols->colのListNoが1」の「TableID.ItemID」を左辺の値にセットする。	</p>
	 * 	<p> select=trueの場合、「item->cols->colのListNo」の順にWHERE句を作成。左辺の値に「TableID.ItemID」をセットする。それぞれの条件は「or」で繋げる。</p>
	 * 	<p> ②比較演算子や検索条件を利用し、右辺をセット。　画面の1条件ごとに「()」で括る</p>
	 * 	<p> ③複数検索条件がある場合は、画面の論理演算子を利用してセット。	</p>
     * @param columnsMap
     * @param wheresMap
     * @return
     */
    private String createWheresClauseForMultiTable(String mTableId, Map<String, TableItemDTO> columnsMap,
			SortedMap<Integer, SelectConditionItem> wheresMap) {
    	if (wheresMap.size() <= 0) {
            return "";
        } else {
            final StringBuffer wheres = new StringBuffer();
            for (final Integer index : wheresMap.keySet()) {
                final SelectConditionItem item = wheresMap.get(index);
                if(columnsMap.containsKey(item.getColumnId())){
                	SortedMap<Integer, SelectConditionItem> subWheresMap = new TreeMap<Integer, SelectConditionItem>();
                	TableItemDTO tableItem = columnsMap.get(item.getColumnId());
                	if(tableItem.getCols() != null && tableItem.getCols().size() > 0){
                		SqlWhereTableLogicalOperator subLogicalOperator = SqlWhereTableLogicalOperator.blank;
                		for (Iterator<String> iterator = tableItem.getCols().keySet().iterator(); iterator.hasNext();) {
	    					String listNo = (String) iterator.next();
	    					ColDto colDto = tableItem.getCols().get(listNo);
	    					SelectConditionItem itemCond = new SelectConditionItem();
	    					itemCond.setColumnId(colDto.getItemID());
	    					itemCond.setTableId(colDto.getTableID());
	    					itemCond.setColumnTypeName(item.getColumnTypeName());
	    					itemCond.setComparisonOperator(item.getComparisonOperator());
	    					itemCond.setJDBCMetaDataType(item.getJDBCMetaDataType());
	    					itemCond.setLogicalOperator(subLogicalOperator);
	    					itemCond.setValue(item.getValue());
	    					subWheresMap.put(new Integer(listNo), itemCond);
	//            			「item->operationのselectがfalse」の場合、「item->cols->colのListNoが1」の「TableID.ItemID」をセットする
	//    					 Only get first item
	            			if(tableItem.getOperations() != null && !tableItem.getOperations().isSelect()){
	            				break;
	            			}else{
	            				if(iterator.hasNext()){
	            					if(SqlWhereTableComparisonOperator.isNull.equals(item.getComparisonOperator())
	            							|| SqlWhereTableComparisonOperator.isNotNull.equals(item.getComparisonOperator())){
	            						itemCond.setLogicalOperator(SqlWhereTableLogicalOperator.and);
	            					}else{
	            						itemCond.setLogicalOperator(SqlWhereTableLogicalOperator.or);
	            					}

	            				}else{
	            					itemCond.setLogicalOperator(subLogicalOperator);
	            				}


	            			}
	//            			「item->operationのselectがtrue」の場合、「item->cols->colのListNo」の順に[NULLを回避する関数]を使い「TableID.ItemID」をセットする
	    				}
                		if (tableItem.getOperations()!=null && tableItem.getOperations().isSelect() && subWheresMap.size() > 0) {
                			String subWheres = createNVLOrIsNullInWhere(mTableId,tableItem,item);
							if (subWheres.replaceAll(" ", "").toLowerCase().startsWith("where")) {
								subWheres = subWheres.replaceFirst("where", "");
							}
							wheres.append(" (");
							wheres.append(subWheres);
							wheres.append(") ");
							wheres.append(item.getLogicalOperator().getLogicalOperator());
						} else if (subWheresMap.size() > 0) {
							String subWheres = createSelectWheresClause(subWheresMap);
							if (subWheres.replaceAll(" ", "").toLowerCase().startsWith("where")) {
								subWheres = subWheres.replaceFirst("where", "");
							}
							wheres.append(" (");
							wheres.append(subWheres);
							wheres.append(") ");
							wheres.append(item.getLogicalOperator().getLogicalOperator());
						}
                	}else{
                		item.setTableId(mTableId);
    					subWheresMap.put(new Integer(0), item);
    					String subWheres = createSelectWheresClause(subWheresMap);
    					if(subWheres.replaceAll(" ", "").toLowerCase().startsWith("where")){
        					subWheres = subWheres.replaceFirst("where", "");
        				}
    					wheres.append(subWheres);
                	}
                }

            }
            if(wheres.toString().equals("")){
            	return " ";
            }

            return " where ".concat(wheres.toString());
        }
	}

    /**
     *
     * @param dto
     * @param form
     * @return
     */
    protected SelectSqlCondition createSelectSqlCondition(
            final RecordSearchConditionDTO dto, 
            final TableFormDTO form) {
        final SelectSqlCondition ret = new SelectSqlCondition();
        ret.setTableId(dto.getTableId());
        ret.setType(form.getType());
        for (final Iterator<String> ite = form.getTableItemMap().keySet()
            .iterator(); ite.hasNext();) {
            ret.addValues(ite.next(), null);
        }

        for (final Integer index : dto.getConditions().keySet()) {
            final SelectConditionItem buff = dto.getConditions().get(index);
            ret.addWheres(index, buff);
        }

        for (final Iterator<Integer> ite = form.getSortConditionMap().keySet()
            .iterator(); ite.hasNext();) {
            final int index = ite.next();
            ret.addOrders(index, form.getSortConditionMap().get(index));
        }

		for (final Iterator<String> ite = form.getRelationMap().keySet().iterator(); ite.hasNext();) {
			final String id = ite.next();
			ret.addRelation(id, form.getRelationMap().get(id));
		}

		for (final Iterator<String> ite = form.getTableItemMap().keySet().iterator(); ite.hasNext();) {
			final String id = ite.next();
			ret.addColumn(id, form.getTableItemMap().get(id));
		}

		ret.setTablesMap(form.getTableMap());
        ret.setOrderAsc(form.getOrderDesc() ? false : true);
        ret.setOffSet(dto.getOffSet());
        ret.setLimit(dto.getLimit());
        return ret;
    }

    /**
     *
     * @param dto
     * @return
     */
    protected SelectSqlCondition createSelectSqlCondition(
            final RecordSearchConditionDTO dto) {
        final SelectSqlCondition ret = new SelectSqlCondition();
        ret.setTableId(dto.getTableId());

        for (final Integer index : dto.getConditions().keySet()) {
            final SelectConditionItem buff = dto.getConditions().get(index);
            ret.addWheres(index, buff);
        }


        return ret;
    }

	/**
     * 指定された演算子がパターンマッチング(LIKE または NOT LIKE)であるか検証します。
     * @param sqlWhereTableComparisonOperator
     * @return 指定された演算子がパターンマッチング(LIKE または NOT LIKE)である場合に、trueを返す。それ以外の場合は、falseを返す。
     */
    public boolean isPatternMatchComparisonOperator(SqlWhereTableComparisonOperator sqlWhereTableComparisonOperator) {
        if (SqlWhereTableComparisonOperator.likeContains.equals(sqlWhereTableComparisonOperator)
            || SqlWhereTableComparisonOperator.likeStartsWith.equals(sqlWhereTableComparisonOperator)
            || SqlWhereTableComparisonOperator.likeEndsWith.equals(sqlWhereTableComparisonOperator)
            || SqlWhereTableComparisonOperator.notLikeContains.equals(sqlWhereTableComparisonOperator)
            || SqlWhereTableComparisonOperator.notLikeStartsWith.equals(sqlWhereTableComparisonOperator)
            || SqlWhereTableComparisonOperator.notLikeEndsWith.equals(sqlWhereTableComparisonOperator)) {
            return true;
        }
        return false;
    }

    /**
     * データベース接続済みか否かを戻す。
     *
     * @return
     */
    private boolean isConnected() {
        if (connectionManager == null || connectionManager.getConnection() == null) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * SQLの条件に'（シングルクォート）を設定するか否か
     * <p>
     * 数値型の場合は『'』をそれ以外は『』を返します。
     * </p>
     */
    protected String additionSingleQuart(JDBCMetaDataType type) {
        for (JDBCMetaDataType classifiedAsCharacter : classifiedAsCharacterList) {
            if (classifiedAsCharacter == type) {
                return "'";
            }
        }
        return "";
    }

    /**
     * 指定されたconditionに、ワイルドカードの役割を担うメタ文字%を付加して返します。
     * @param sqlWhereTableComparisonOperator 比較演算子。
     * @param condition 条件。
     * @return ワイルドカードの役割を担うメタ文字%を付加した条件。
     */
    public String getPatternMatchCondition(SqlWhereTableComparisonOperator sqlWhereTableComparisonOperator, String condition) {
        StringBuffer buffer = new StringBuffer(128);
        if (SqlWhereTableComparisonOperator.likeContains.equals(sqlWhereTableComparisonOperator)
            || SqlWhereTableComparisonOperator.notLikeContains.equals(sqlWhereTableComparisonOperator)) {
            buffer.append("%");
            buffer.append(condition);
            buffer.append("%");
        } else if (SqlWhereTableComparisonOperator.likeStartsWith.equals(sqlWhereTableComparisonOperator)
            || SqlWhereTableComparisonOperator.notLikeStartsWith.equals(sqlWhereTableComparisonOperator)) {
            buffer.append(condition);
            buffer.append("%");
        } else if (SqlWhereTableComparisonOperator.likeEndsWith.equals(sqlWhereTableComparisonOperator)
            || SqlWhereTableComparisonOperator.notLikeEndsWith.equals(sqlWhereTableComparisonOperator)) {
            buffer.append("%");
            buffer.append(condition);
        } else {
            buffer.append(condition);
        }
        return buffer.toString();
    }

    /**
     * JDBCメタデータタイプが数値型か否かを返します。
     *
     * @param jdbc
     * @return
     */
    protected boolean isJDBCMetaDataTypeToNumber(final JDBCMetaDataType jdbc) {
        if (jdbc == JDBCMetaDataType.TINYINT
                || jdbc == JDBCMetaDataType.SMALLINT
                || jdbc == JDBCMetaDataType.INTEGER
                || jdbc == JDBCMetaDataType.BIGINT
                || jdbc == JDBCMetaDataType.FLOAT
                || jdbc == JDBCMetaDataType.REAL
                || jdbc == JDBCMetaDataType.DOUBLE
                || jdbc == JDBCMetaDataType.NUMERIC
                || jdbc == JDBCMetaDataType.DECIMAL) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * JDBCメタデータタイプが日付型か否かを返します。
     *
     * @param jdbc
     * @return
     */
    protected boolean isJDBCMetaDataTypeToDate(final JDBCMetaDataType jdbc) {
        if (jdbc == JDBCMetaDataType.DATE
                || jdbc == JDBCMetaDataType.TIME
                || jdbc == JDBCMetaDataType.TIMESTAMP) {
            return true;
        } else {
            return false;
        }
    }
    /**
     * BaseDatabaseDAO の生成。
     * <p>コンストラクタ。</p>
     */
    public BaseDatabaseDAO() {
        return;
    }

	/**
	 * searchCondition を戻します。
	 *
	 * @return String
	 */
	public String getSearchCondition() {
		return searchCondition;
	}

	public void setSearchCondition(String searchCondition) {
		this.searchCondition = searchCondition;
	}

	/**
	 * Get connection
	 *
	 * @return
	 * @throws DAOException
	 */
	public Connection getConnection() throws DAOException {
		return this.connectionManager.getConnection();

	}

	/**
	 * Create connection with transaction
	 *
	 * @param dto
	 * @throws DAOException
	 */
	public void connectWithTransaction(final DbConnectInfomationDTO dto) throws DAOException {
        if (isConnected()) {
        	// MI-E-0009=既にデータベースへ接続されています。データベースとの接続を切断してください。
            final String message = MessageUtils.getMessage("MI-E-0009");
            getLogger().warn(message);
            throw new DAOException(message);
        }
        try {
            connectionManager = ConnectionManagerFactory.createConnectionManager(
                dto.getDatabaseTypeConnectionDestination());
            this.connectionManager.connectWithTransaction(dto);
        } catch (final SQLException e) {
        	// MI-E-0032=データベースの接続に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0032");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
	}

	/**
	 * Commit transaction
	 *
	 * @throws DAOException
	 */
	public void commit() throws DAOException {
		try {
			this.connectionManager.commit();
		} catch (SQLException e) {
			throw new DAOException(e);
		}
	}

	/**
	 * Rollback transaction
	 *
	 * @throws DAOException
	 */
	public void rollback() throws DAOException {
		try {
			this.connectionManager.rollback();
		} catch (SQLException e) {
			throw new DAOException(e);
		}
	}

	/**
	 * バグ #15387 - データ操作画面の「操作対象」一覧で表示エラーメッセージ ■データ操作_エラーメッセージ表示の修正
	 * ・現状：「DBオブジェクト削除済」のオプジェクトを「データ操作画面」 の「操作対象」一覧に選択、「選択」ボタンを押下すると下記のエラーメッセージ
	 * を表示することを修正 「エラーメッセージ」 データベースに操作対象のオブジェクトが存在しません
	 * ※「エラーメッセジ」を表示の場所は添付ファイルにて確認してください。
	 */
    public String checkTableName(TableIdDefinition id, DatabaseMetaData meta) throws SQLException {
        try {
            ResultSet rs = meta.getTables(null, id.getSchem(), id
                .getTable(), null);
            String name = null;
            while (rs.next()) {
            	name = rs.getString("TABLE_NAME");
            }
            rs.close();

            if(StringUtils.isEmpty(name)){
            	// MI-E-5009=データベースに操作対象のオブジェクトが存在しません
                String message = MessageUtils.getMessage("MI-E-5009");
                getLogger().error(message);
                throw new SQLException(message);
            }
        } catch (SQLException e) {
        	throw e;
        }
    	return null;
    }
    
    /**
     * @param columnTypeName
     * 「<dataType>」タグに「decimal() identity」が記載されています。.
     * 「<dataType>」タグは、型の名称なので自動採番型でも「decimal」にしてほしいです。
     * また、仮にリポジトリを手動で「decimal」にしてもデータ操作画面で、定義が違うと
     * エラーになってしまっています。     * 
     * @return
     */
    public String customIdentityColumnTypeName(String columnTypeName){
    	String temp = "";
    	if(columnTypeName != null && columnTypeName.length() > 0){
    		for(int i = 0; i < columnTypeName.toCharArray().length; i++){
        		if(columnTypeName.toCharArray()[i] != '(' 
        				&& columnTypeName.toCharArray()[i] != ')'){
        			temp += columnTypeName.toCharArray()[i];
        		}
        	} 
    	}    	               	
    	temp = temp.toLowerCase().replaceAll("identity", "").trim();
    	columnTypeName = temp.toUpperCase().replaceAll("UNSIGNED", "").trim();
    	return columnTypeName;
    }
}
