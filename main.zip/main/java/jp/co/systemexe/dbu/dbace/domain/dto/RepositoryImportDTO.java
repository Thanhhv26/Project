/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

/**
 * リポジトリのインポート処理用パラメータ DTO。
 * <p>
 * リポジトリ間での情報エクスポート＆インポート用のパラメータ転送用 VO です。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class RepositoryImportDTO {

    /**
     * エクスポート元接続定義 ID。
     */
    private String exportConnectDefinition;

    /**
     * インポート元接続定義 ID。
     */
    private String importConnectDefinition;

    /**
     * users 要素をインポートするか否か。
     */
    private boolean usersElement;

    /**
     * tableForms 要素をインポートするか否か。
     */
    private boolean tableFormsElement;

    /**
     * exportConnectDefinition を戻します。
     * 
     * @return String
     */
    public String getExportConnectDefinition() {
        return exportConnectDefinition;
    }

    /**
     * exportConnectDefinition を設定します。
     *
     * @param String exportConnectDefinition 
     */
    public void setExportConnectDefinition(String exportConnectDefinition) {
        this.exportConnectDefinition = exportConnectDefinition;
    }

    /**
     * importConnectDefinition を戻します。
     * 
     * @return String
     */
    public String getImportConnectDefinition() {
        return importConnectDefinition;
    }

    /**
     * importConnectDefinition を設定します。
     *
     * @param String importConnectDefinition 
     */
    public void setImportConnectDefinition(String inportConnectDefinition) {
        this.importConnectDefinition = inportConnectDefinition;
    }

    /**
     * tableFormsElement を戻します。
     * 
     * @return boolean
     */
    public boolean isTableFormsElement() {
        return tableFormsElement;
    }

    /**
     * tableFormsElement を設定します。
     *
     * @param boolean tableFormsElement 
     */
    public void setTableFormsElement(boolean tableFormsElement) {
        this.tableFormsElement = tableFormsElement;
    }

    /**
     * usersElement を戻します。
     * 
     * @return boolean
     */
    public boolean isUsersElement() {
        return usersElement;
    }

    /**
     * usersElement を設定します。
     *
     * @param boolean usersElement 
     */
    public void setUsersElement(boolean usersElement) {
        this.usersElement = usersElement;
    }

    /**
     * RepositoryImportDTO の生成。
     * <p>コンストラクタ。</p>
     */
    public RepositoryImportDTO() {
        return;
    }
}
