/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.relation.dto;

import java.io.Serializable;

import lombok.Data;

/**
 * @author  tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	//connection id
    private String connectid;
	private String Id;
	private String relationName;
	private String objectId1;
	private String objectName1;
	private String joinName;
	private String objectId2;
	private String objectName2;
	private String databaseTypeConnectionDestination;
}
