/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.exception;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
public interface IUtilException {

}
