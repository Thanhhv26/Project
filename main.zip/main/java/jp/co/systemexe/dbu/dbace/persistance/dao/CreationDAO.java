/**
 * Copyright(C) 2017 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.List;

import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.ConnectDefinision;

public interface CreationDAO {

	/**
	 * get all info connection in xml
	 * @return
	 * @throws ApplicationDomainLogicException
	 * @throws DAOException
	 */
	List<ConnectDefinision> getAllConnection() throws ApplicationDomainLogicException;
	
	/**
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	boolean checkFormatFileRepositoryXml() throws ApplicationDomainLogicException;
}