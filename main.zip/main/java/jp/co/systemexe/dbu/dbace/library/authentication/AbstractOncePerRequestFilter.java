/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.authentication;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;

/**
 * Abstract filter once per request
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
@Component
public abstract class AbstractOncePerRequestFilter extends OncePerRequestFilter {

	/**
     * SLF4J
     */
    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * @see MessageService
     */
    @Autowired
    protected MessageService messageService;

    /*
     * (Non-Javadoc)
     * @see org.springframework.web.filter.OncePerRequestFilter#doFilterInternal(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, javax.servlet.FilterChain)
     */
    @Override
	protected final void doFilterInternal(HttpServletRequest request, HttpServletResponse response, javax.servlet.FilterChain filterChain)
			throws ServletException, IOException {
    	// do filter before
    	logger.debug(">>> Do filter chain [" + request.getRequestURI() + "] - [" + this.getClass().getName() + "]....");
    	if (!this.doBeforeFilter(request, response)) {
	    	// filter chain do filtering
	    	filterChain.doFilter(request, response);
	    	// do after filtering
	    	this.doAfterFilter(request, response);
    	}
    };

    /**
     * TODO Override for filtering before {@link FilterChain} do filtering
     *
     * @param request the current request
     * @param response the current response
     *
     * @return true for not doing filter chain; else doing it
     */
    protected abstract boolean doBeforeFilter(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException;
    /**
     * TODO Override for filtering after {@link FilterChain} do filtering
     *
     * @param request the current request
     * @param response the current response
     */
    protected void doAfterFilter(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	// TODO Override for filtering after {@link FilterChain} do filtering
    }
}
