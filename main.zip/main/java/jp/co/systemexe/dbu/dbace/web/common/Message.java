package jp.co.systemexe.dbu.dbace.web.common;

import lombok.Data;

@Data
public class Message {

	private int code;
	private String title;
	private String detail;

	public Message(int code, String title, String detail) {
		this.setCode(code);
		this.setTitle(title);
		this.setDetail(detail);
	}
	public Message(int code, String detail) {
		this(code, null, detail);
	}
	public Message() {
	}
}
