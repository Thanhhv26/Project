/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseDbAccessApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.DbConnectInfomationDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchResultDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.common.AppConst;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;

/**
 * データベースからのレコードの検索・取得ロジック。
 * <p>
 * データベースからレコードを検索し、取得したレコードを戻します。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @author EXE 相田 一英
 * @version 0.0.0
 */
public class RetrievalProcessingOfRecordFromDatabaseLogic extends BaseDbAccessApplicationDomainLogic {

	/**
	 * 画面表示用のプルダウンリスト用のリストを取得します。
	 *
	 * @param connectDefinitionId
	 * @param tableId
	 * @param columnId
	 * @param map
	 * @param connectionUserLabel
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public Map<String, SelectableItem[]> setSelectableMap(final String columnLabel, final Map<String, String> dataMap,
			final DbConnectInfomationDTO dbConnectInfomationDTO, final TableFormDTO tableForm,
			final String connectionUserLabel) throws ApplicationDomainLogicException {

		final DatabaseTableDAO dao = createDatabaseTableDAO(
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
		try {
			dao.connect(dbConnectInfomationDTO);
		} catch (final DAOException e) {
			try {
				dao.close();
			} catch (final DAOException ex) {
				getLogger().warn(ex);
			}
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}

		final Map<String, SelectableItem[]> ret = new HashMap<String, SelectableItem[]>();

		for (final Iterator<TableItemDTO> ite = tableForm.getTableItemMap().values().iterator(); ite.hasNext();) {
			final TableItemDTO dto = ite.next();
			if (DefinedHtmlElement.INPUT_RADIO == dto.getHtmlElement()
					|| DefinedHtmlElement.SELECT == dto.getHtmlElement()) {
				if (dto.getSqlString() != null && dto.getSqlString().equals("") == false) {
					String query = dto.getSqlString();
					if (query.indexOf("'@".concat(columnLabel).concat("'")) != -1) {
						if (dataMap != null && dataMap.size() >= 0) {
							for (final Iterator<String> wIte = dataMap.keySet().iterator(); wIte.hasNext();) {
								final String key = wIte.next();
								final String value = dataMap.get(key) == null ? "" : dataMap.get(key);
								query = query.replaceAll("'@".concat(key).concat("'"), "'".concat(value).concat("'"));
							}
						}
						final SelectableItem[] selectItems;
						try {
							selectItems = dao.getSelectableMap(query);
						} catch (final DAOException e) {
							try {
								dao.close();
							} catch (final DAOException ex) {
								getLogger().warn(ex);
							}
							// MI-E-0043=プルダウンリストの取得に失敗しました。
							final String message = MessageUtils.getMessage("MI-E-0043");
							getLogger().fatal(message, e);
							throw new ApplicationDomainLogicException(message, e);
						}
						ret.put(dto.getItemId(), selectItems);
					}
				}
			}
		}
		try {
			dao.close();
		} catch (final DAOException e) {
			getLogger().warn(e);
		}

		return ret;
	}

	/**
	 * プルダウン用アイテムから、keyと一致する表示名を返します。
	 *
	 * @param items
	 * @param value
	 * @return
	 */
	public String getSelectItem(final SelectableItem[] items, String key, boolean canDisplayNamePreview) {
		if (items == null || items.length == 0) {
			return "";
		}

		for (SelectableItem item : items) {
			if (item.getLabel() == null)
				item.setLabel("");
			if (canDisplayNamePreview) {
				if (item != null && key != null
						&& item.getValue().trim().toLowerCase().equals(key.toLowerCase())) {
					return item.getLabel();
				}
			}
		}
		if (!canDisplayNamePreview) {
			return key;
		}

		return "";
	}

	/**
	 * 画面表示用のプルダウンリスト用のリストを取得します。
	 *
	 * @param connectDefinitionId
	 * @param tableId
	 * @param columnId
	 * @param map
	 * @param connectionUserLabel
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public SelectOneMenuItem[] getSelectableMap(final String columnId, final Map<String, String> dataMap,
			final DbConnectInfomationDTO dbConnectInfomationDTO, final TableItemDTO tableItem)
			throws ApplicationDomainLogicException {

		final DatabaseTableDAO dao = createDatabaseTableDAO(
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
		try {
			dao.connect(dbConnectInfomationDTO);
		} catch (final DAOException e) {
			try {
				dao.close();
			} catch (final DAOException ex) {
				getLogger().warn(ex);
			}
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}

		SelectOneMenuItem[] ret = null;

		if (DefinedHtmlElement.INPUT_RADIO == tableItem.getHtmlElement()
				|| DefinedHtmlElement.SELECT == tableItem.getHtmlElement()) {
			if (tableItem.getSqlString() != null && tableItem.getSqlString().equals("") == false) {
				String query = tableItem.getSqlString();

				if (dataMap != null && dataMap.size() >= 0) {
					for (final Iterator<String> wIte = dataMap.keySet().iterator(); wIte.hasNext();) {
						final String key = wIte.next();
						final String value = dataMap.get(key) == null ? "" : dataMap.get(key);
						query = query.replaceAll("'@".concat(key).concat("'"), "'".concat(value).concat("'"));
					}
					try {
						ret = dao.getSelectableMap(query);
					} catch (final DAOException e) {
						try {
							dao.close();
						} catch (final DAOException ex) {
							getLogger().warn(ex);
						}
						// MI-E-0043=プルダウンリストの取得に失敗しました。
						final String message = MessageUtils.getMessage("MI-E-0043");
						getLogger().fatal(message, e);
						throw new ApplicationDomainLogicException(message, e);
					}
				}
			}
			else
			{
				return tableItem.getSelectableItems();
			}
		}
		try {
			dao.close();
		} catch (final DAOException e) {
			getLogger().warn(e);
		}

		return ret;
	}

	/**
	 * テーブルのデータベース内定義情報を取得します。
	 *
	 * @param connectDefinitionId
	 * @param tableId
	 * @param connectionUserLabel
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public TableDefinitionDTO getTableDefinitionDTO(final String connectDefinitionId, final String tableId,
			final String connectionUserLabel) throws ApplicationDomainLogicException {
		final DbConnectInfomationDTO dbConnectInfomationDTO = getDbConnectInfomation(connectDefinitionId);
		return getTableDefinitionDTO(connectDefinitionId, dbConnectInfomationDTO.getDatabaseTypeConnectionDestination(),
				tableId, connectionUserLabel);
	}

	/**
	 * テーブルのデータベース内定義情報を取得します。
	 *
	 * @param connectDefinitionLabel
	 * @param tableId
	 * @param connectionUserLabel
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public TableDefinitionDTO getTableDefinitionDTOByConnectLabel(final String connectDefinitionId,
			final String tableId, final String connectionUserLabel) throws ApplicationDomainLogicException {
		final DbConnectInfomationDTO dbConnectInfomationDTO = getDbConnectInfomationByLabel(connectDefinitionId);
		return getTableDefinitionDTOLabel(connectDefinitionId,
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination(), tableId, connectionUserLabel);
	}

	/**
	 * 項目定義情報 DTO を戻します。
	 * <p>
	 * 指定されたテーブルの各項目の、リポジトリ内の定義情報及びデータベース内の 最新の定義情報を取得し、DTO にまとめて戻します。<br />
	 * プレゼンテーション層側ではこの情報を元に画面要素を構築します。
	 * </p>
	 * <p>
	 * 画面入力値を元にプルダウンリスト用のリストデータを再取得するため入力値 マップを受け取る、同名メソッドのオーバーロードです。
	 * </p>
	 *
	 * @param connectDefinitionId
	 *            接続定義 ID
	 * @param tableId
	 *            テーブル ID（＝スキーマ名.テーブル名）
	 * @param map
	 *            画面での一時入力値マップ（カラム名, 値）
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public ColumnDisplayDefinitionDTO getColumnDisplayDefinition(final String connectDefinitionId, final String tableId,
			final Map<String, String> map, final DbConnectInfomationDTO dbConnectInfomationDTO,
			final TableDefinitionDTO tableDef, final TableFormDTO tableForm, final String connectionUserLabel)
			throws ApplicationDomainLogicException {
		final ColumnDisplayDefinitionDTO ret = new ColumnDisplayDefinitionDTO();
		if (tableForm == null) {
			// MI-E-0033=テーブル情報が存在しません。
			throw new ApplicationDomainLogicException(MessageUtils.getMessage("MI-E-0033"));
		}
		setSelectableMap(connectDefinitionId, dbConnectInfomationDTO, tableForm, map, connectionUserLabel);
		ret.getItemDefinitions().putAll(tableForm.getTableItemMap());
		ret.getColumnNames().putAll(tableDef.getColumnNames());
		ret.getDefinitionOfColumns().putAll(tableDef.getDefinitionOfColumnMap());
		ret.setView(tableDef.isView());
		ret.setOrderDesc(tableForm.getOrderDesc());
		return ret;
	}

	/**
	 * 項目定義情報 DTO を戻します。
	 * <p>
	 * リポジトリ及び DB メタデータで定義された各項目（カラム）の画面定義情報の 設定された DTO を取得し戻します。
	 * </p>
	 *
	 * @return ColumnDisplayDefinitionDTO
	 */
	public ColumnDisplayDefinitionDTO getColumnsDisplay(final String connectDefinisionId, final String tableId,
			RecordEditorInformationDTO recordEditorInformationDTO, String userId)
			throws ApplicationDomainLogicException {
		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		// MyUserDetails myUserDetails = (MyUserDetails)
		// SecurityContextHolder.getContext().getAuthentication()
		// .getPrincipal();
		final ColumnDisplayDefinitionDTO ret = logic.getColumnDisplayDefinition(connectDefinisionId, tableId,
				recordEditorInformationDTO.getDbConnectInfomationDTO(), recordEditorInformationDTO.getTableDef(),
				recordEditorInformationDTO.getTableForm(), userId);
		return ret;
	}

	/**
	 * 項目定義情報 DTO を戻します。
	 * <p>
	 * 指定されたテーブルの各項目の、リポジトリ内の定義情報及びデータベース内の 最新の定義情報を取得し、DTO にまとめて戻します。<br />
	 * プレゼンテーション層側ではこの情報を元に画面要素を構築します。
	 * </p>
	 *
	 * @param connectDefinitionId
	 *            接続定義 ID
	 * @param tableId
	 *            テーブル ID（＝スキーマ名.テーブル名）
	 * @param tableDef
	 *            テーブルのデータベース内定義情報
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public ColumnDisplayDefinitionDTO getColumnDisplayDefinition(final String connectDefinitionId, final String tableId,
			final TableDefinitionDTO tableDef, final String connectionUserLabel)
			throws ApplicationDomainLogicException {
		final DbConnectInfomationDTO dbConnectInfomationDTO = getDbConnectInfomation(connectDefinitionId);

		final TableFormDTO tableForm = getTableFormDTO(connectDefinitionId, tableId);
		return getColumnDisplayDefinition(connectDefinitionId, tableId, null, dbConnectInfomationDTO, tableDef,
				tableForm, connectionUserLabel);
	}

	/**
	 * 項目定義情報 DTO を戻します。
	 * <p>
	 * 指定されたテーブルの各項目の、リポジトリ内の定義情報及びデータベース内の 最新の定義情報を取得し、DTO にまとめて戻します。<br />
	 * プレゼンテーション層側ではこの情報を元に画面要素を構築します。
	 * </p>
	 *
	 * @param connectDefinitionId
	 *            接続定義 ID
	 * @param tableId
	 *            テーブル ID（＝スキーマ名.テーブル名）
	 * @param tableDef
	 *            テーブルのデータベース内定義情報
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public ColumnDisplayDefinitionDTO getColumnDisplayDefinitionByConnectName(final String connectDefinitionId,
			final String tableId, final TableDefinitionDTO tableDef, final String connectionUserLabel)
			throws ApplicationDomainLogicException {
		final DbConnectInfomationDTO dbConnectInfomationDTO = getDbConnectInfomationByLabel(connectDefinitionId);

		final TableFormDTO tableForm = getTableFormDTOByConnectName(connectDefinitionId, tableId);
		return getColumnDisplayDefinition(connectDefinitionId, tableId, null, dbConnectInfomationDTO, tableDef,
				tableForm, connectionUserLabel);
	}

	/**
	 * 項目定義情報 DTO を戻します。
	 * <p>
	 * 指定されたテーブルの各項目の、リポジトリ内の定義情報及びデータベース内の 最新の定義情報を取得し、DTO にまとめて戻します。<br />
	 * プレゼンテーション層側ではこの情報を元に画面要素を構築します。
	 * </p>
	 *
	 * @param connectDefinitionId
	 *            接続定義 ID
	 * @param tableId
	 *            テーブル ID（＝スキーマ名.テーブル名）
	 * @param tableDef
	 *            テーブルのデータベース内定義情報
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public ColumnDisplayDefinitionDTO getColumnDisplayDefinition(final String connectDefinitionId, final String tableId,
			final DbConnectInfomationDTO dbConnectInfomationDTO, final TableDefinitionDTO tableDef,
			final String connectionUserLabel) throws ApplicationDomainLogicException {
		final TableFormDTO tableForm = getTableFormDTO(connectDefinitionId, tableId);
		return getColumnDisplayDefinition(connectDefinitionId, tableId, null, dbConnectInfomationDTO, tableDef,
				tableForm, connectionUserLabel);
	}

	/**
	 * 項目定義情報 DTO を戻します。
	 * <p>
	 * 指定されたテーブルの各項目の、リポジトリ内の定義情報及びデータベース内の 最新の定義情報を取得し、DTO にまとめて戻します。<br />
	 * プレゼンテーション層側ではこの情報を元に画面要素を構築します。
	 * </p>
	 *
	 * @param connectDefinitionId
	 *            接続定義 ID
	 * @param tableId
	 *            テーブル ID（＝スキーマ名.テーブル名）
	 * @param tableDef
	 *            テーブルのデータベース内定義情報
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public ColumnDisplayDefinitionDTO getColumnDisplayDefinition(final String connectDefinitionId, final String tableId,
			final DbConnectInfomationDTO dbConnectInfomationDTO, final TableDefinitionDTO tableDef,
			final TableFormDTO tableForm, final String connectionUserLabel) throws ApplicationDomainLogicException {
		return getColumnDisplayDefinition(connectDefinitionId, tableId, null, dbConnectInfomationDTO, tableDef,
				tableForm, connectionUserLabel);
	}

	/**
	 * プルダウンリスト表示用の最新のデータセットを設定する。
	 * <p>
	 * 抽出条件パラメータ指定マップが指定された場合は、プルダウンリスト抽出用の SQL 文のパラメータ置換を実行します。
	 * </p>
	 * <p>
	 * 抽出条件パラメータ指定マップが全く存在しない場合は、各項目定義の SQL 設定
	 * を調べ、定義されていた場合は選択候補マップを初期化し空要素を登録します。
	 * </p>
	 * <p>
	 * なお、SQL 文中のパラメータは "@" +（カラム名）という書式で記述されるもの とします。
	 * </p>
	 *
	 * @param connectDefinitionId
	 * @param form
	 * @param dataMap
	 *            抽出条件パラメータ指定マップ
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @throws ApplicationDomainLogicException
	 */
	private void setSelectableMap(final String connectDefinitionId, final DbConnectInfomationDTO dbConnectInfomationDTO,
			final TableFormDTO form, final Map<String, String> dataMap, final String connectionUserLabel)
			throws ApplicationDomainLogicException {
		if (dataMap == null || dataMap.size() <= 0) {
			for (final Iterator<TableItemDTO> ite = form.getTableItemMap().values().iterator(); ite.hasNext();) {
				final TableItemDTO dto = ite.next();
				if (DefinedHtmlElement.INPUT_RADIO == dto.getHtmlElement()
						|| DefinedHtmlElement.SELECT == dto.getHtmlElement()) {
					if (dto.getSqlString() != null && dto.getSqlString().equals("") == false) {
						final SelectableItem[] item = new SelectableItem[1];
						item[0] = new SelectableItem();
						item[0].setLabel("");
						item[0].setValue("");
						dto.setSelectableItems(item);
					}
				}
			}
		} else {
			final DatabaseTableDAO dao = createDatabaseTableDAO(
					dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
			try {
				dao.connect(dbConnectInfomationDTO);
			} catch (final DAOException e) {
				try {
					dao.close();
				} catch (final DAOException ex) {
					getLogger().warn(ex);
				}
				throw new ApplicationDomainLogicException(e.getMessage(), e);
			}
			for (final Iterator<TableItemDTO> ite = form.getTableItemMap().values().iterator(); ite.hasNext();) {
				final TableItemDTO dto = ite.next();
				if (DefinedHtmlElement.INPUT_RADIO == dto.getHtmlElement()
						|| DefinedHtmlElement.SELECT == dto.getHtmlElement()) {
					if (dto.getSqlString() != null && dto.getSqlString().equals("") == false) {
						String query = dto.getSqlString();
						boolean isErrorSqlString = false;
						if (dataMap != null && dataMap.size() >= 0) {
							for (final Iterator<String> wIte = dataMap.keySet().iterator(); wIte.hasNext();) {
								final String key = wIte.next();
								final String value = dataMap.get(key) == null ? "" : dataMap.get(key);

								final String replaceTarget = "'@".concat(key).concat("'");
								final String replaceString = "'".concat(value).concat("'");
								isErrorSqlString = isErrorSqlString
										| (query.contains(replaceTarget) && (null == value || 0 == value.length()));
								query = query.replaceAll(replaceTarget, replaceString);
							}
						}
						final SelectableItem[] selectItems;
						try {
							if (isErrorSqlString) {
								selectItems = new ArrayList<SelectableItem>().toArray(new SelectableItem[0]);
							} else {
								selectItems = dao.getSelectableMap(query);
							}
						} catch (final DAOException e) {
							try {
								dao.close();
							} catch (final DAOException ex) {
								getLogger().warn(ex);
							}
							// MI-E-0043=プルダウンリストの取得に失敗しました。
							final String message = MessageUtils.getMessage("MI-E-0043");
							getLogger().fatal(message, e);
							throw new ApplicationDomainLogicException(message, e);
						}
						dto.setSelectableItems(selectItems);
					}
				}
			}
			getLogger().info("setSelectableMap4");
			try {
				dao.close();
			} catch (final DAOException e) {
				getLogger().warn(e);
			}
		}
	}

	/**
	 * 検索条件に応じたレコード一覧を取得し戻す。
	 * <p>
	 * 検索条件に応じたレコードデータ一覧を戻します。レコードはリポジトリに定義 された並び順で SortedMap に保持されます。
	 * </p>
	 *
	 * @param dto
	 *            RecordSearchConditionDTO
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @return RecordSearchResultDTO レコード検索結果 DTO
	 * @throws ApplicationDomainLogicException
	 */
	public RecordSearchResultDTO getOneRecord(final RecordSearchConditionDTO dto,
			final DbConnectInfomationDTO dbConnectInfomationDTO, final TableDefinitionDTO tableDef,
			final TableFormDTO tableForm, final UserInfo userInfo, final String action)
			throws ApplicationDomainLogicException {
		RecordSearchResultDTO ret = null;
		final DatabaseTableDAO dao = createDatabaseTableDAO(
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
		final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
		try {
			dao.connect(dbConnectInfomationDTO);
			ret = dao.doSelect(dto, tableForm, tableDef);
			ret.setResultRowCount(1);

			if (action.equals(AppConst.ACTION_VIEW) || action.equals(AppConst.ACTION_SEARCH)) {
				OutputAuditLog.writeExcuteSearchLog(
						action.equals(AppConst.ACTION_VIEW) ? AuditEventKind.REFERENCE : AuditEventKind.SEARCH,
						userInfo, connectDefinitionListLogic.getConnectionByID(dto.getConnectDefinitionId()).getLabel(),
						connectDefinitionListLogic.getTableForm(dto.getConnectDefinitionId(), dto.getTableId())
								.getLabel(),
						AuditStatus.success, ret.getSearchCondition(), action.equals(AppConst.ACTION_VIEW)
								? String.valueOf(1) : String.valueOf(ret.getResultRowCount()));
			}

			return ret;
		} catch (final DAOException e) {
			if (action.equals(AppConst.ACTION_VIEW) || action.equals(AppConst.ACTION_SEARCH)) {
				OutputAuditLog
						.writeExcuteSearchLog(
								action.equals(AppConst.ACTION_VIEW) ? AuditEventKind.REFERENCE : AuditEventKind.SEARCH,
								userInfo,
								connectDefinitionListLogic.getConnectionByID(dto.getConnectDefinitionId()).getLabel(),
								connectDefinitionListLogic.getTableForm(dto.getConnectDefinitionId(), dto.getTableId())
										.getLabel(),
								AuditStatus.failure, ret == null ? "" : ret.getSearchCondition(), "0");
			}
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} finally {
			try {
				dao.close();
			} catch (final DAOException e) {
				getLogger().warn(e);
			}
		}
	}

	/**
	 * 検索条件に応じたレコード一覧を取得し戻す。
	 * <p>
	 * 検索条件に応じたレコードデータ一覧を戻します。レコードはリポジトリに定義 された並び順で SortedMap に保持されます。
	 * </p>
	 *
	 * @param dto
	 *            RecordSearchConditionDTO
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @return RecordSearchResultDTO レコード検索結果 DTO
	 * @throws ApplicationDomainLogicException
	 */
	public RecordSearchResultDTO getRecords(
			final RecordSearchConditionDTO dto,
			final DbConnectInfomationDTO dbConnectInfomationDTO, 
			final TableDefinitionDTO tableDef,
			final TableFormDTO tableForm, 
			final String action,
			final UserInfo userInfo) throws ApplicationDomainLogicException {
		RecordSearchResultDTO ret = null;
		final DatabaseTableDAO dao = createDatabaseTableDAO(dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
		final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
		try {
			dao.connect(dbConnectInfomationDTO);
			final int rowCount = dao.getRowCount(dto, tableForm);

			if (rowCount > SystemProperties.getSearchMaxRecordCount()) {
				ret = new RecordSearchResultDTO();
				ret.setResultRowCount(rowCount);
				throw new ApplicationDomainLogicException(MessageUtils.getMessage("MI-E-0125"));
			} else {
				ret = dao.doSelect(dto, tableForm, tableDef);
				ret.setResultRowCount(rowCount);
			}

			if (action.equals(AppConst.ACTION_VIEW) || action.equals(AppConst.ACTION_SEARCH)) {
				OutputAuditLog.writeExcuteSearchLog(
						action.equals(AppConst.ACTION_VIEW) ? AuditEventKind.REFERENCE : AuditEventKind.SEARCH,
						userInfo, connectDefinitionListLogic.getConnectionByID(dto.getConnectDefinitionId()).getLabel(),
						connectDefinitionListLogic.getTableForm(dto.getConnectDefinitionId(), dto.getTableId())
								.getLabel(),
						AuditStatus.success, ret.getSearchCondition(),
						action.equals(AppConst.ACTION_VIEW) ? String.valueOf(1) : String.valueOf(rowCount));
			}
			return ret;
		} catch (final DAOException e) {
			if (action.equals(AppConst.ACTION_VIEW) || action.equals(AppConst.ACTION_SEARCH)) {
				OutputAuditLog
						.writeExcuteSearchLog(
								action.equals(AppConst.ACTION_VIEW) ? AuditEventKind.REFERENCE : AuditEventKind.SEARCH,
								userInfo,
								connectDefinitionListLogic.getConnectionByID(dto.getConnectDefinitionId()).getLabel(),
								connectDefinitionListLogic.getTableForm(dto.getConnectDefinitionId(), dto.getTableId())
										.getLabel(),
								AuditStatus.failure, ret == null ? "" : ret.getSearchCondition(), "0");
			}
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} finally {
			try {
				dao.close();
			} catch (final DAOException e) {
				getLogger().warn(e);
			}
		}
	}

	/**
	 * @param dto
	 * @param dbConnectInfomationDTO
	 * @param tableDef
	 * @param tableForm
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public int getCountRecords(final RecordSearchConditionDTO dto, final DbConnectInfomationDTO dbConnectInfomationDTO,
			final TableDto tableDto) throws ApplicationDomainLogicException {
		final DatabaseTableDAO dao = createDatabaseTableDAO(
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
		try {
			dao.connect(dbConnectInfomationDTO);
			final int rowCount = dao.getRowCountTab(dto, tableDto);
			return rowCount;
		} catch (final DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} finally {
			try {
				dao.close();
			} catch (final DAOException e) {
				getLogger().warn(e);
			}
		}
	}

	/**
	 * @param dto
	 * @param dbConnectInfomationDTO
	 * @param tableDef
	 * @param tableForm
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public int getCountRecord(final RecordSearchConditionDTO dto, final DbConnectInfomationDTO dbConnectInfomationDTO,
			final TableFormDTO tableDto) throws ApplicationDomainLogicException {
		final DatabaseTableDAO dao = createDatabaseTableDAO(
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
		try {
			dao.connect(dbConnectInfomationDTO);
			final int rowCount = dao.getRowCount(dto, tableDto);
			return rowCount;
		} catch (final DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} finally {
			try {
				dao.close();
			} catch (final DAOException e) {
				getLogger().warn(e);
			}
		}
	}

	/**
	 * @param dto
	 * @param dbConnectInfomationDTO
	 * @param tableDef
	 * @param tableForm
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public int getCountRecords(final RecordSearchConditionDTO dto, final DbConnectInfomationDTO dbConnectInfomationDTO)
			throws ApplicationDomainLogicException {
		final DatabaseTableDAO dao = createDatabaseTableDAO(
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
		try {
			dao.connect(dbConnectInfomationDTO);
			final int rowCount = dao.getRowCount(dto);
			return rowCount;
		} catch (final DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} finally {
			try {
				dao.close();
			} catch (final DAOException e) {
				getLogger().warn(e);
			}
		}
	}

	/**
	 * レコード更新用のリポジトリ情報を返します。
	 *
	 * @param connectDefinitionId
	 * @param tableId
	 * @param connectionUserLabel
	 * @return RecordEditorInformationDTO
	 */
	public Map<String, RecordEditorInformationDTO> getRecordEditorInformationMap(final String connectDefinitionId,
			final List<String> tableIdList, final String connectionUserLabel) throws ApplicationDomainLogicException {
		final Map<String, RecordEditorInformationDTO> ret = new HashMap<String, RecordEditorInformationDTO>();

		final DbConnectInfomationDTO dbConnectInfomationDTO = getDbConnectInfomation(connectDefinitionId);
		final Map<String, TableDefinitionDTO> tableDefinitionDTOMap = getTableDefinitionDTOMap(connectDefinitionId,
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination(), tableIdList, connectionUserLabel);
		final Map<String, TableFormDTO> tableFormDTOMap = getTableFormDTOMap(connectDefinitionId, tableIdList);

		for (final String tableId : tableIdList) {
			final RecordEditorInformationDTO dto = new RecordEditorInformationDTO();
			dto.setDbConnectInfomationDTO(dbConnectInfomationDTO);
			dto.setTableDef(tableDefinitionDTOMap.get(tableId));
			dto.setTableForm(tableFormDTOMap.get(tableId));
			ret.put(tableId, dto);
		}

		return ret;
	}

	/**
	 * レコード更新用のリポジトリ情報を返します。
	 *
	 * @param connectDefinitionId
	 * @param tableId
	 * @param connectionUserLabel
	 * @return RecordEditorInformationDTO
	 */
	public RecordEditorInformationDTO getRecordEditorInformation(final String connectDefinitionId, final String tableId,
			final String connectionUserLabel) throws ApplicationDomainLogicException {
		final RecordEditorInformationDTO ret = new RecordEditorInformationDTO();

		final DbConnectInfomationDTO dbConnectInfomationDTO = getDbConnectInfomation(connectDefinitionId);
		final TableDefinitionDTO tableDefinitionDTO = getTableDefinitionDTO(connectDefinitionId,
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination(), tableId, connectionUserLabel);
		final TableFormDTO tableFormDTO = getTableFormDTO(connectDefinitionId, tableId);

		ret.setDbConnectInfomationDTO(dbConnectInfomationDTO);
		ret.setTableDef(tableDefinitionDTO);
		ret.setTableForm(tableFormDTO);

		return ret;
	}

	/**
	 * レコード更新用のリポジトリ情報を返します。
	 *
	 * @param connectDefinitionId
	 * @param tableId
	 * @param connectionUserLabel
	 * @return RecordEditorInformationDTO
	 */
	public RecordEditorInformationDTO getRecordEditorInformationMuiltiTable(final String connectDefinitionId,
			final String tableId, final String connectionUserLabel) throws ApplicationDomainLogicException {
		final RecordEditorInformationDTO ret = new RecordEditorInformationDTO();

		final DbConnectInfomationDTO dbConnectInfomationDTO = getDbConnectInfomation(connectDefinitionId);
		final TableFormDTO tableFormDTO = getTableFormDTO(connectDefinitionId, tableId);

		ret.setDbConnectInfomationDTO(dbConnectInfomationDTO);
		ret.setTableForm(tableFormDTO);

		return ret;
	}

	/**
	 * レコード更新用のリポジトリ情報を返します。
	 *
	 * @param connectDefinitionId
	 * @param tableId
	 * @param connectionUserLabel
	 * @return RecordEditorInformationDTO
	 */
	public RecordEditorInformationDTO getRecordEditorInformation(final String connectDefinitionId,
			TableFormDTO multiTableFormDTO, final String connectionUserLabel) throws ApplicationDomainLogicException {
		final RecordEditorInformationDTO ret = new RecordEditorInformationDTO();

		final DbConnectInfomationDTO dbConnectInfomationDTO = getDbConnectInfomation(connectDefinitionId);

		final TableDefinitionDTO tableDefinitionDTO = getTableDefinitionDTO(connectDefinitionId, multiTableFormDTO,
				dbConnectInfomationDTO.getDatabaseTypeConnectionDestination(), connectionUserLabel);

		ret.setDbConnectInfomationDTO(dbConnectInfomationDTO);
		ret.setTableDef(tableDefinitionDTO);
		ret.setTableForm(multiTableFormDTO);

		return ret;
	}

	/**
	 * RetrievalProcessingOfRecordFromDatabaseLogic の生成。
	 * <p>
	 * コンストラクタ。
	 * </p>
	 */
	public RetrievalProcessingOfRecordFromDatabaseLogic() {
		return;
	}

	public DbConnectInfomationDTO getDbConnectInfomation(final String connectDefinitionId)
			throws ApplicationDomainLogicException {
		final DbConnectInfomationDAO dao = createDbConnectInfomationDAO();
		try {
			return dao.getDbConnectInfomationDTO(connectDefinitionId);
		} catch (final DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}
	}
}
