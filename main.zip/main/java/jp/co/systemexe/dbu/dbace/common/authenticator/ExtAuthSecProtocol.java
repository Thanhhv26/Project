/**
 * Copyright(C) 2016 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.authenticator;

/**
 * 外部認証接続情報 列挙体。
 *
 * @author Nguyen Dong Truc
 * @version 5.0.0
 */
public enum ExtAuthSecProtocol {
	/**
	 * NONE
	 */
	NONE("NONE"),
	/**
	 * SIMPLE
	 */
	SIMPLE("simple"),
	/**
	 * DIGEST-MD5 CRAM-MD5
	 */
	DIGEST_MD5("DIGEST-MD5 CRAM-MD5"),
	/**
	 * EXTERNAL
	 */
	EXTERNAL("EXTERNAL");

	private String value;

	public String getValue() {
		return value;
	}

	private ExtAuthSecProtocol(final String value) {
		this.value = value;
	}
}
