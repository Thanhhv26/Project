/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.domain.service.ConnectionService;
import jp.co.systemexe.dbu.dbace.library.service.AbstractService;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.web.connect.dto.ConnectDto;
import jp.co.systemexe.dbu.dbace.web.connect.json.FRM0500SearchParam;
import jp.co.systemexe.dbu.dbace.web.connect.model.FRM0500ResultModel;

@Service
public class ConnectionServiceImpl extends AbstractService implements ConnectionService {

	private static final long serialVersionUID = 1L;

	/*@Autowired
	CreationService creationService;*/

	@Override
	public FRM0500ResultModel search(FRM0500SearchParam searchParam) throws ApplicationRuntimeException {
		FRM0500ResultModel searchResultModel = new FRM0500ResultModel();

		final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		final Map<String, ConnectDto> connectDefinisionMap;
		try {
			connectDefinisionMap = logic.getConnectDefinisionMap();
		} catch (final ApplicationDomainLogicException e) {
			logger.error(e.getMessage(), e);
			return null;
		}

		for (final String id : connectDefinisionMap.keySet()) {
			final ConnectDto connectDefinition = connectDefinisionMap.get(id);

			if(searchParam != null){
				if(StringUtils.isEmpty(searchParam.getConnectDefinitionName()) && StringUtils.isEmpty(searchParam.getTemplateDatabaseUrl())){
					searchResultModel.getResultData().add(connectDefinition);
				}else if (!StringUtils.isEmpty(searchParam.getConnectDefinitionName())
						&& connectDefinition.getConnectDefinitionName().toLowerCase().contains(searchParam.getConnectDefinitionName().toLowerCase())) {
					searchResultModel.getResultData().add(connectDefinition);
				}else if (!StringUtils.isEmpty(searchParam.getTemplateDatabaseUrl())
						&& connectDefinition.getTemplateDatabaseUrl().toLowerCase().contains(searchParam.getTemplateDatabaseUrl().toLowerCase())) {
					searchResultModel.getResultData().add(connectDefinition);
				}
			}
		}

		//sort by RelationName
		  Collections.sort(searchResultModel.getResultData(), new Comparator<ConnectDto>() {
		    @Override public int compare(final ConnectDto o1, final ConnectDto o2) {
		      return o1.getConnectDefinitionName().compareTo(o2.getConnectDefinitionName());
		    }
		  });

		if (searchResultModel.getResultData().size() == 0) {
			// baseUserEditingPage.addPageMessage(MessageUtils.getMessage("MI-E-0053"));
			return searchResultModel;
		}

		return searchResultModel;
	}

	@Override
	public Boolean deleteConnect(ConnectDto connectDto) throws ApplicationRuntimeException {
		boolean flag = false;
		try {
			final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
			flag = logic.delete(connectDto);
		} catch (ApplicationDomainLogicException e) {
			flag = false;
		} catch (DAOException e) {
			flag = false;
		}

		OutputAuditLog.writeConnectedDefinitionLog(
				AuditEventKind.DELETE,
				connectDto.getUserInfo(),
				connectDto.getConnectDefinition(),
				flag ? AuditStatus.success : AuditStatus.failure,
				"1");

		return flag;
	}

	@Override
	public int insertConnect(ConnectDto newConnectDto) throws ApplicationRuntimeException {
		int flag = 0;
		try {
			final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
			flag = logic.insert(newConnectDto);
		} catch (ApplicationDomainLogicException e) {
			flag = 0;
		} catch (DAOException e) {
			flag = 0;
		}

		OutputAuditLog.writeConnectedDefinitionLog(
				AuditEventKind.INSERT,
				newConnectDto.getUserInfo(),
				newConnectDto.getConnectDefinition(),
				flag == 1 ? AuditStatus.success : AuditStatus.failure,
				"1");

		return flag;
	}

	@Override
	public int updateConnect(ConnectDto connectDto) throws ApplicationRuntimeException {
		int flag = 0;
		try {
			final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
			flag = logic.update(connectDto);
		} catch (ApplicationDomainLogicException e) {
			flag = 0;
		} catch (DAOException e) {
			flag = 0;
		}

		OutputAuditLog.writeConnectedDefinitionLog(
				AuditEventKind.UPDATE,
				connectDto.getUserInfo(),
				connectDto.getConnectDefinition(),
				flag == 1 ? AuditStatus.success : AuditStatus.failure,
				"1");

		return flag;
	}

	@Override
	public void testConnect(ConnectDto connectDto) throws ApplicationRuntimeException {
		try {
			final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
			logic.testConnect(connectDto);
		} catch (ApplicationDomainLogicException e) {
			e.printStackTrace();
			throw new ApplicationRuntimeException(e);
		} catch (DAOException e) {
			throw new ApplicationRuntimeException(e);
		}
	}

}
