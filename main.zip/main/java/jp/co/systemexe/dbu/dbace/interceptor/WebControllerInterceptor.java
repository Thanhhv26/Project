/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.interceptor;

import java.util.List;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.library.util.BeanUtils;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;

/**
 * ControllerInterceptorのクラス。
 *
 * @author systemexe
 * @version 1.0 Nov 29, 2016
 *
 */
@Aspect
@Component
@SuppressWarnings("unchecked")
public class WebControllerInterceptor extends WebInterceptor {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.intercepter.MethodInterceptor#checkInvoke(java.lang.Class, java.lang.String, java.lang.Object[])
	 */
	@Override
	protected boolean checkInvoke(Class<?> targetClass, String method, Object[] medArgs) {
//		// clear cache every action
//		UserProfile userprofile = AuthenticationUtils.getCurrentProfile();
//		// TODO Waiting to get authentication from spring socket
//		// If current request is from socket, current authentication will be invalid
//		if (userprofile == null && !ArrayUtils.isEmpty(medArgs)) {
//			for(Object medArg : medArgs) {
//				userprofile = AuthenticationUtils.getProfile(medArg);
//				if (userprofile != null) break;
//			}
//		}
//		// check normal user permission (has permission on modules)
//		boolean allowed = (userprofile != null);
//		if (allowed && !userprofile.isSysadmin()) {
//			allowed = this.hasUserPermission(userprofile.getUsername(), targetClass, method);
//		}
//		// check root user permission (modules has been existed and enabled)
//		else if (allowed) {
//			allowed = this.hasRootPermission(targetClass, method);
//		}
//		return allowed;
		return true;
	}

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.intercepter.MethodInterceptor#afterInvoke(java.lang.Class, java.lang.String, java.lang.Object[], java.lang.Object)
	 */
	@Override
	protected void afterInvoke(Class<?> targetClass, String method, Object[] medArgs, Object value) {
		// if result is a model and view; then applying common attribute if necessary
		// at this moment, it means current user had the accessable permission with this module
		if (BeanUtils.isInstanceOf(value, ModelAndView.class)) {
			// parse class module information
//			List<String> modList = new ArrayList<String>();
//			MethodPermission clzzPerm = BeanUtils.getClassAnnotation(targetClass, MethodPermission.class);
//			String[] modules = (clzzPerm != null && !ArrayUtils.isEmpty(clzzPerm.value()) ? clzzPerm.value() : new String[] {});
//			if (!ArrayUtils.isEmpty(modules)) modList.addAll(Arrays.asList(modules));
//			// parse method modules information
//			List<? extends Annotation> medperms = BeanUtils.getMethodAnnotations(
//					targetClass, method, MethodPermission.class);
//			if (BeanUtils.isCollectionOf(medperms, MethodPermission.class)) {
//				List<MethodPermission> perms = (List<MethodPermission>) medperms;
//				for(MethodPermission perm : perms) {
//					String[] medModules = (!ArrayUtils.isEmpty(perm.value()) ? perm.value() : new String[] {});
//					if (!ArrayUtils.isEmpty(medModules)) modList.addAll(Arrays.asList(medModules));
//				}
//			}
//
//			// parse writable permissions for normal user, exclude system administrator
//			UserProfile userprofile = AuthenticationUtils.getCurrentProfile();
			List<String> readModList = null;
			List<String> writeModList = null;
//			List<String> cssModList = moduleService.getModuleCss(modList);
//			String moduleCss = (!CollectionUtils.isEmpty(cssModList) ? cssModList.get(0) : null);
//			if (!userprofile.isSysadmin()) {
//				readModList = moduleService.checkReadable(userprofile.getUsername(), modList);
//				writeModList = moduleService.checkWritable(userprofile.getUsername(), modList);
//			}
//			else {
//				readModList = modList;
//				writeModList = modList;
//			}

			// applies modules that user has writable permission
			ModelAndView mav = (ModelAndView) value;
			mav.addObject("readableRoles", readModList);
			mav.addObject("writableRoles", writeModList);
//			mav.addObject("moduleClass", moduleCss);
			mav.addObject("moduleClass", null);
		}
		else {
			logger.debug("Class: [" + targetClass.getName()
					+ "] - Method: [" + method
					+ "] - Value: [" + (value == null ? "NULL" : value.getClass().getName()) + "]");
		}
	}

	/**
	 * Check permission of root user
	 *
	 * @param targetClass the target controller class
	 * @param method the request handler method
	 *
	 * @return true for allowing; otherwise false
	 */
	private boolean hasRootPermission(Class<?> targetClass, String method) {
//		// check permission base on target class
//		MethodPermission clzzPerm = BeanUtils.getClassAnnotation(targetClass, MethodPermission.class);
//		String[] modules = (clzzPerm != null && !ArrayUtils.isEmpty(clzzPerm.value()) ? clzzPerm.value() : new String[] {});
//
//		// check permission base on invoking method
//		List<? extends Annotation> medperms = BeanUtils.getMethodAnnotations(targetClass, method, MethodPermission.class);
//		// if found permission annotation
//		// then checking it from database permission
//		if (BeanUtils.isCollectionOf(medperms, MethodPermission.class)) {
//			List<MethodPermission> perms = (List<MethodPermission>) medperms;
//			for(MethodPermission perm : perms) {
//				if (!ArrayUtils.isEmpty(perm.value())) {
//					modules = ArrayUtils.addAll(modules, perm.value());
//				}
//			}
//		}
//
//		// check module whether has been enabled all or not any module neet to check
//		return (ArrayUtils.isEmpty(modules) || moduleService.isEnabled(modules));
		return true;
	}
	/**
	 * Check permission of normal user
	 *
	 * @param userName the user code
	 * @param targetClass the target controller class
	 * @param method the request handler method
	 *
	 * @return true for allowing; otherwise false
	 */
	private boolean hasUserPermission(String userName, Class<?> targetClass, String method) {
//		// parse info to check
//		boolean allowed = false;
//		boolean reqRead = true;
//		boolean reqWrite = false;
//		List<String> modules = new LinkedList<String>();
//
//		// parse target class permission info
//		MethodPermission medPerm = BeanUtils.getClassAnnotation(targetClass, MethodPermission.class);
//		if (medPerm != null) {
//			reqRead = medPerm.required();
//			reqWrite = medPerm.writable();
//			if (!ArrayUtils.isEmpty(medPerm.value())) modules.addAll(Arrays.asList(medPerm.value()));
//		}
//		else logger.debug(">>> Not found permission on [" + targetClass.getName() + "] controller");
//
//		// parse method permission info
//		medPerm = BeanUtils.getMethodAnnotation(targetClass, method, MethodPermission.class);
//		if (medPerm != null) {
//			reqRead = (!reqRead ? medPerm.required() : reqRead);
//			reqWrite = (!reqWrite ? medPerm.writable() : reqWrite);
//			if (!ArrayUtils.isEmpty(medPerm.value())) modules.addAll(Arrays.asList(medPerm.value()));
//		}
//		else logger.debug(">>> Not found permission on method [" + method + "] of [" + targetClass.getName() + "] controller");
//
//		// only accept when defined module and not requiring permission
//		allowed = (!reqRead && !reqWrite && !CollectionUtils.isEmpty(modules));
//		// if allowing; then checking modules whether existed and enabled
//		String[] arrModules = (CollectionUtils.isEmpty(modules)
//				? new String[] {} : modules.toArray(new String[modules.size()]));
//		if (allowed) {
//			allowed = moduleService.isEnabled(arrModules);
//			if (!allowed) {
//				logger.warn(
//						"ACCESS DENIED - One of [" + StringUtils.arrayToDelimitedString(arrModules, "|") + "] modules "
//						+ "maybe disabled or not existed from database!!!");
//			}
//		}
//		// else requiring permission from database
//		else {
//			allowed = moduleService.hasPermission(userName, arrModules, reqWrite);
//			if (!allowed) {
//				logger.warn(
//						"ACCESS DENIED - [" + userName + "] hasnt enough [" + (reqWrite ? "Writable" : "Readable") + "] "
//						+ "permission on [" + StringUtils.arrayToDelimitedString(arrModules, "|") + "] modules!!!");
//			}
//		}
//
//		return allowed;
		return true;
	}

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.intercepter.MethodInterceptor#supportFor()
	 */
	@Override
	protected Class<?> supportFor() {
		return AbstractController.class;
	}
}
