/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto.authority;

import java.io.Serializable;
import java.util.List;

/**
 * 接続定義毎のアプリケーション操作権限を保持するDTO。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class ConnectDefinisionAuthority implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 接続定義ID
	 */
	private String connectDefinisionId;
	
	/**
	 * アプリケーション操作権限
	 */
	private List<GeneralUserOperationAuthority> operationAuthority;

	/**
	 * connectDefinisionId を戻します。
	 * 
	 * @return String
	 */
	public String getConnectDefinisionId() {
		return connectDefinisionId;
	}

	/**
	 * connectDefinisionId を設定します。
	 *
	 * @param String connectDefinisionId 
	 */
	public void setConnectDefinisionId(String connectDefinisionId) {
		this.connectDefinisionId = connectDefinisionId;
	}

	/**
	 * operationAuthority を戻します。
	 * 
	 * @return List<GeneralUserOperationAuthority>
	 */
	public List<GeneralUserOperationAuthority> getOperationAuthority() {
		return operationAuthority;
	}

	/**
	 * operationAuthority を設定します。
	 *
	 * @param List<GeneralUserOperationAuthority> operationAuthority 
	 */
	public void setOperationAuthority(
			List<GeneralUserOperationAuthority> operationAuthority) {
		this.operationAuthority = operationAuthority;
	}
}
