/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationScreenDTO {
	private String tableFormId;
	private String itemId;
	//DELETE_COLUMN_USE_RELATION_SCREEN;
	//DELETE_COLUMN_USE_ITEM_COLS;
	//COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM;
	//COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM;
	//COLUMN_DELETE_PK_USE_TABLES_TABLE_ITEM;
	private String columnChangeUseCase;
	private RelationAndScreenInfoDTO relationAndScreenInfoDTO;
}