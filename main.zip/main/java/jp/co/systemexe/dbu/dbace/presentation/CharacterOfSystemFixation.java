/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

/**
 * システム内固定のキャラクタ定義 enum。
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public enum CharacterOfSystemFixation {
    /**
     * システム内で静的に定義されている事を示す符号。
     * <p>
     * リポジトリ XML 内で予約されたコード等。</p>
     */
    SYSTEM("system");

    private final String code;

    /**
     * code を戻します。
     * 
     * @return String
     */
    public String getCode() {
        return code;
    }

    private CharacterOfSystemFixation(final String code) {
        this.code = code;
    }
}
