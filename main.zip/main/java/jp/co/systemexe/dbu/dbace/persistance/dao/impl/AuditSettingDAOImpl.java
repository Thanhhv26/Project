/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.audit.AuditCategories;
import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.persistance.dao.AuditSettingDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.auditsetting.AuditSetting;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.auditsetting.Categories.Category;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.auditsetting.File;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

/**
 * 監査ログ設定情報XML DAO。
 * <p>
 * 監査ログ設定情報XML にアクセスする DAO の実装クラスになります。</p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class AuditSettingDAOImpl extends BaseAuditSettingXmlDAO
        implements AuditSettingDAO {

    /**
     * 監査ログ設定情報を読み込みます。
     */
    public AuditSettingDTO getAuditSettingDTO() {
        final AuditSetting auditSetting = getAuditSetting();
        final AuditSettingDTO ret = new AuditSettingDTO();
        final File file = auditSetting.getFile();

        int count = 0;
        for (Category category : auditSetting.getCategories().getCategory()) {
            ret.getCategoryMap().put(count, category.getId());
            count++;
        }

        ret.setFileSize(file.getSize());
        ret.setFileUnit(file.getUnit());
        ret.setFileRotation(file.getRotation());
        ret.setFilePath(file.getPath());

        return ret;
    }

    /**
     * 監査ログ設定情報を保存します。
     *
     * @param dto
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.AuditSettingDAO#save(java.lang.String, jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO)
     */
    public void save(
            final AuditSettingDTO beforeDto,
            final AuditSettingDTO dto,
            final UserInfo userInfo
            ) throws DAOException {
        final AuditSetting auditSetting = getAuditSetting();
        final List<Category> categoryList = auditSetting.getCategories().getCategory();
        categoryList.clear();
        final Map<Integer, String> categoryMap = dto.getCategoryMap();
        for (Integer index : categoryMap.keySet()) {
            final String id = categoryMap.get(index);
            final Category category = getObjectFactory().createCategoriesCategory();
            category.setId(id);
            categoryList.add(category);
        }

        final File file = auditSetting.getFile();
        file.setSize(dto.getFileSize());
        file.setUnit(dto.getFileUnit());
        file.setRotation(dto.getFileRotation());
        file.setPath(dto.getFilePath());

        boolean isSuccess = true;
        try {
            update();
            isSuccess = true;
        } catch (final DAOException e) {
            isSuccess = false;
            throw e;
        } finally {
            outputAuditLog(beforeDto, dto, userInfo, isSuccess);
        }
    }

    /**
     * 監査ログ設定の変更ログを取得します。
     *
     * @param beforeDto
     * @param dto
     * @param userInfo
     */
    private void outputAuditLog(
            final AuditSettingDTO beforeDto,
            final AuditSettingDTO dto,
            final UserInfo userInfo,
            final boolean isSuccess) {
        final Map<AuditCategories, AuditEventKind> map
            = new HashMap<AuditCategories, AuditEventKind>();
        // 監査カテゴリのチェックが変更されたか否か（監査開始、終了）
        for (AuditCategories category : AuditCategories.values()) {
            // 更新前になし、更新後にありの場合、監査開始
            if (!beforeDto.getCategoryMap().containsValue(category.name())
                    && dto.getCategoryMap().containsValue(category.name())) {
                map.put(category, AuditEventKind.START);
            } else if (beforeDto.getCategoryMap().containsValue(category.name())
                    && !dto.getCategoryMap().containsValue(category.name())) {
                // 更新前にあり、更新後になしの場合、監査停止
                map.put(category, AuditEventKind.STOP);
            }
        }

        boolean isUpdate = false;
        if (!beforeDto.getFilePath().equals(dto.getFilePath())
                || beforeDto.getFileRotation() != dto.getFileRotation()
                || beforeDto.getFileSize() != dto.getFileSize()
                || !beforeDto.getFileUnit().equals(dto.getFileUnit())) {
            isUpdate = true;
        }

        if (map.size() != 0) {
            for (AuditCategories category : map.keySet()) {
                OutputAuditLog.writeAuditSettingLog(
                		map.get(category),
                		userInfo,
                		category,
                		isSuccess ? AuditStatus.success : AuditStatus.failure);
            }
        }

        if (isUpdate) {
            OutputAuditLog.writeAuditSettingOtherLog(
            		AuditEventKind.UPDATE,
            		userInfo,
            		isSuccess ? AuditStatus.success : AuditStatus.failure);
        }
    }

    /**
     * ApplicationUserDAOImpl の生成。
     * <p>
     * コンストラクタ。</p>
     *
     * @throws DAOException
     */
    public AuditSettingDAOImpl() throws DAOException {
        super();
    }
}
