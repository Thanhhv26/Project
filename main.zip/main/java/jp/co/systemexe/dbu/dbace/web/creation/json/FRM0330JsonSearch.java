package jp.co.systemexe.dbu.dbace.web.creation.json;

import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import lombok.Data;

@Data
public class FRM0330JsonSearch {
	UserAuthority userAuthority;
	String tableMultiName;
}
