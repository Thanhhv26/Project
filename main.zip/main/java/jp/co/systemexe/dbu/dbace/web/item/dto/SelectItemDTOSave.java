/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.dto;

import java.util.List;

import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import lombok.Data;

@Data
public class SelectItemDTOSave {
	/**
	 * 選択された接続定義ID
	 */
	String connectDefinitionId;
	/**
	 * テーブルプルダウンリストより選択された、テーブル ID プロパティーを保持し ます。
	 */
	String tableId;
	/**
	 * テーブル Label 「仮名」プロパティを保持します。
	 */
	String tableLabel;
	/**
	 * カラムリストより選択された、カラムの ID プロパティーを保持します。
	 */
	String itemId;
	/**
	 * カラム Label 「仮名」プロパティを保持します。
	 */
	String columnLabel;
	/**
	 * HTML 要素リストより選択された HTML ID プロパティーを保持します。
	 */
	String htmlElement;
	/**
	 * 既定値プロパティを保持します。
	 */
	String defaultValue;
	/**
	 * 画面表示用項目説明文プロパティを保持します。
	 */
	String explanation;
	/**
	 * 一覧表示設定ラジオボタンのラジオボタンリストプロパティより選択された 一覧 表示設定 プロパティー ID を保持します。
	 */
	String canPreview;
	/**
	 * 登録・編集時表示設定ラジオボタンのラジオボタンリストプロパティより選択された 設定 プロパティー ID を保持します。
	 */
	String canDisplayRecordEdit;
	/**
	 * 一覧表示設定ラジオボタンのラジオボタンリストプロパティより選択された 一覧 表示設定 プロパティー ID を保持します。
	 */
	String canDisplayNamePreview;
	/**
	 * 更新可能設定ラジオボタンのラジオボタンリストより選択された 更新可能設定 プロパティー ID を保持します。
	 */
	String canEditing;
	/**
	 * 更新処理のキー設定ラジオボタンのラジオボタンリストより選択された 更新処理 のキー設定 プロパティー ID を保持します。
	 */
	String isUpdateKey;
	/**
	 * 検索キー設定ラジオボタンのラジオボタンリストより選択された 検索キー設定 プロパティー ID を保持します。
	 */
	String isSelectKey;
	/**
	 * アプリケーション独自定義制約リストプロパティを保持します。
	 * <p>
	 * チェックボックス HTML 生成用。本アプリケーションにて定義されている独自定 義制約を保持します。
	 * </p>
	 */
	List<restrictionsDTO> restrictionsItems;
	/**
	 * HTML 要素に対応する、プルダウン等のリスト用のデータプロパティを保持します。
	 */
	List<SelectableItem> selectableListItems;
	/**
	 * SQL文のプロパティを保持します。
	 */
	String sqlString;
	String sqlParameters;
}
