/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.relation.dto;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationCreateColumnNameDefDTO {
	//column name A reference column name B
	String columnName;
	String columnNameLabel;
	//column name B
	String columnNameR;
	String columnNameRLabel;
}
