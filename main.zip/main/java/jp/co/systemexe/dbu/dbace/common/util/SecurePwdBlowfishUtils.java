/**
 * Copyright(C) 2016 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.util;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * <p>
 * securing password with blowfish。 encrypt , decrypt password
 * </p>
 *
 * @author EXE レン
 * @version 0.0.0
 */
public class SecurePwdBlowfishUtils {

	/**
	 * ロガーへの参照を保持します。
	 */
	private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	/**
	 * 文字列の暗号化。
	 * 
	 * @param strEncrypt
	 *            鍵文字列
	 * @param text
	 *            暗号化対象文字列
	 * @return 暗号化文字列
	 */
	public String encrypt(String strEncrypt, String openSesame) {
		try {
			String ret = BlowfishUtils.encrypt2b64(openSesame, strEncrypt);
			return ret;
		} catch (final Exception e) {
			final String message = "ライセンスキーの暗号化に失敗しました。";
			logger.fatal(message, e);
			return null;
		}
	}

	/**
	 * 文字列の複合化
	 * 
	 * @param strDecrypt
	 *            鍵文字列
	 * @param encrypted
	 *            復号化対象文字列
	 * @return 復号後文字列
	 */
	public String decrypt(String strDecrypt, String openSesame) {
		try {
			String ret = BlowfishUtils.decrypt4b64(openSesame, strDecrypt);
			return ret;
		} catch (final Exception e) {
			final String message = "ライセンスキーの複合化に失敗しました。";
			logger.fatal(message, e);
			return null;
		}
	}
}
