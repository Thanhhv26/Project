/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.io.Serializable;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import lombok.Getter;
import lombok.Setter;

/**
 * レコード検索条件 DTO。
 * <p>
 * データベース内のレコード検索を行う際の検索条件を保持する DTO です。</p>
 *
 * @author  EXE 相田 一英
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class RecordSearchConditionDTO implements Serializable {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 6462874681302316605L;

    /**
     * 接続定義 ID。
     */
    private String connectDefinitionId;

    /**
     * テーブル ID。
     */
    private String tableId;

    private String tableLabel;

    /**
     * 検索条件マップ。
     * <p>Map&l;カラム名, 条件&gt;</p>
     */
    private SortedMap<Integer, SelectConditionItem> conditions = new TreeMap<Integer, SelectConditionItem>();

    public void setConditions(SortedMap<Integer, SelectConditionItem> conditions) {
		this.conditions = conditions;
	}

	/**
     * 検索種別。
     */
    private TypeOfRetrieval typeOfRetrieval;

    /**
     * 表示開始インデックス。
     * <p>表示を開始する先頭インデックス。</p>
     */
    private int topIndex;

    /**
     * 表示レコード数。
     * <p>
     * 実際に取得するレコード数。ビジネスロジックは表示開始インデックスから
     * この件数分のレコードを戻して来ます。</p>
     */
    private int recordCount;

    /**
     * 並び順の昇順フラグ。
     * <p>true : 昇順（デフォルト） / false : 降順</p>
     */
    private boolean orderAsc = true;

    /**
     * DB 接続情報
     */
    private DbConnectInfomationDTO dbConnectInfomationDTO;

    /**
     * テーブルのデータベース内定義情報
     */
    private  TableDefinitionDTO tableDef;

    /**
     * テーブルフォーム
     */
    private TableFormDTO tableForm;
    
    /**
     * 
     */
    @Getter
    @Setter
    private int offSet;
    
	/**
	 * 
	 */
    @Getter
    @Setter
	private int limit;

    /**
     * 並び順の昇順フラグを戻します。
     * <p>true : 昇順（デフォルト） / false : 降順</p>
     *
     * @return boolean
     */
    public boolean isOrderAsc() {
        return orderAsc;
    }

    /**
     * 並び順の昇順フラグを設定します。
     * <p>true : 昇順（デフォルト） / false : 降順</p>
     *
     * @param boolean orderAsc
     */
    public void setOrderAsc(boolean orderAsc) {
        this.orderAsc = orderAsc;
    }

    /**
     * 検索種別を戻します。
     *
     * @return TypeOfRetrieval
     */
    public TypeOfRetrieval getTypeOfRetrieval() {
        return typeOfRetrieval;
    }

    /**
     * 検索種別を設定します。
     *
     * @param TypeOfRetrieval typeOfRetrieval
     */
    public void setTypeOfRetrieval(final TypeOfRetrieval typeOfRetrieval) {
        this.typeOfRetrieval = typeOfRetrieval;
    }

    /**
     * 表示レコード数を戻します。
     * <p>
     * 実際に取得するレコード数。ビジネスロジックは表示開始インデックスから
     * この件数分のレコードを戻して来ます。</p>
     *
     * @return int
     */
    public int getRecordCount() {
        return recordCount;
    }

    /**
     * 表示レコード数を設定します。
     * <p>
     * 実際に取得するレコード数。ビジネスロジックは表示開始インデックスから
     * この件数分のレコードを戻して来ます。</p>
     *
     * @param int recordCount
     */
    public void setRecordCount(int recordCount) {
        this.recordCount = recordCount;
    }

    /**
     * 表示開始インデックスを戻します。
     * <p>
     * 表示を開始する先頭インデックス。</p>
     *
     * @return int
     */
    public int getTopIndex() {
        return topIndex;
    }

    /**
     * 表示開始インデックスを設定します。
     * <p>
     * 表示を開始する先頭インデックス。</p>
     *
     * @param int topIndex
     */
    public void setTopIndex(int topIndex) {
        this.topIndex = topIndex;
    }

    /**
     * connectDefinitionId を戻します。
     *
     * @return String
     */
    public String getConnectDefinitionId() {
        return connectDefinitionId;
    }

    /**
     * connectDefinitionId を設定します。
     *
     * @param String connectDefinitionId
     */
    public void setConnectDefinitionId(String connectDefinitionId) {
        this.connectDefinitionId = connectDefinitionId;
    }

    /**
     * tableId を戻します。
     *
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * tableId を設定します。
     *
     * @param String tableId
     */
    public void setTableId(String tableId) {
        this.tableId = tableId;
    }

    /**
     * 検索条件マップを戻します。
     *
     * @return Map&lt;カラム名, 検索条件アイテム&gt;
     */
    public SortedMap<Integer, SelectConditionItem> getConditions() {
        return conditions;
    }

    /**
     * RecordSearchConditionDTO の生成。
     * <p>コンストラクタ。</p>
     */
    public RecordSearchConditionDTO() {
        return;
    }

	/**
	 * dbConnectInfomationDTO を戻します。
	 *
	 * @return DbConnectInfomationDTO
	 */
	public DbConnectInfomationDTO getDbConnectInfomationDTO() {
		return dbConnectInfomationDTO;
	}

	/**
	 * dbConnectInfomationDTO を設定します。
	 *
	 * @param DbConnectInfomationDTO dbConnectInfomationDTO
	 */
	public void setDbConnectInfomationDTO(
			DbConnectInfomationDTO dbConnectInfomationDTO) {
		this.dbConnectInfomationDTO = dbConnectInfomationDTO;
	}

	/**
	 * tableDef を戻します。
	 *
	 * @return TableDefinitionDTO
	 */
	public TableDefinitionDTO getTableDef() {
		return tableDef;
	}

	/**
	 * tableDef を設定します。
	 *
	 * @param TableDefinitionDTO tableDef
	 */
	public void setTableDef(TableDefinitionDTO tableDef) {
		this.tableDef = tableDef;
	}

	/**
	 * tableForm を戻します。
	 *
	 * @return TableFormDTO
	 */
	public TableFormDTO getTableForm() {
		return tableForm;
	}

	/**
	 * tableForm を設定します。
	 *
	 * @param TableFormDTO tableForm
	 */
	public void setTableForm(TableFormDTO tableForm) {
		this.tableForm = tableForm;
	}

	public String getTableLabel() {
		return tableLabel;
	}

	public void setTableLabel(String tableLabel) {
		this.tableLabel = tableLabel;
	}
}
