/**
 * Copyright(C) 2012 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.nio.channels.FileChannel;

import org.apache.log4j.Layout;
import org.apache.log4j.RollingFileAppender;
import org.apache.log4j.helpers.CountingQuietWriter;
import org.apache.log4j.helpers.LogLog;
import org.apache.log4j.spi.LoggingEvent;

/**
 * ファイルサイズでローテーションするAppenderクラス。<br>
 * ロックされているファイルをリネームする際に、エラーが発生した場合は、ファイルをコピーする。
 *
 * @author  EXE 古賀 諭
 * @version 0.0.0
 */
public class AppRollingFileAppender extends RollingFileAppender {

    private long nextRollover = 0;

    /**
     * Constructor。
     */
    public AppRollingFileAppender() {
        super();
    }

    /**
     * Constructor。
     * @param layout
     * @param filename
     * @throws IOException
     */
    public AppRollingFileAppender(Layout layout,
                    String filename) throws IOException {
        super(layout, filename);
    }

    /**
     * Constructor。
     * @param layout
     * @param filename
     * @param append
     * @throws IOException
     */
    public AppRollingFileAppender(Layout layout,
                    String filename, boolean append) throws IOException {
        super(layout, filename, append);
    }


    /* (非 Javadoc)
     * @see org.apache.log4j.RollingFileAppender#rollOver()
     */
    public void rollOver() {
        File target;
        File file;

        if (qw != null) {
            long size = ((CountingQuietWriter) qw).getCount();
            LogLog.debug("rolling over count=" + size);
            //   if operation fails, do not roll again until
            //      maxFileSize more bytes are written
            nextRollover = size + maxFileSize;
        }
        LogLog.debug("maxBackupIndex="+maxBackupIndex);

        boolean renameSucceeded = true;
        // If maxBackups <= 0, then there is no file renaming to be done.
        if(maxBackupIndex > 0) {
            // Delete the oldest file, to keep Windows happy.
            file = new File(fileName + '.' + maxBackupIndex);
            if (file.exists())
                renameSucceeded = file.delete();

            // Map {(maxBackupIndex - 1), ..., 2, 1} to {maxBackupIndex, ..., 3, 2}
            for (int i = maxBackupIndex - 1; i >= 1 && renameSucceeded; i--) {
                file = new File(fileName + "." + i);
                if (file.exists()) {
                    target = new File(fileName + '.' + (i + 1));
                    LogLog.debug("Renaming file " + file + " to " + target);
                    renameSucceeded = file.renameTo(target);
                }
            }

            if(renameSucceeded) {
                // Rename fileName to fileName.1
                target = new File(fileName + "." + 1);

                this.closeFile(); // keep windows happy.

                file = new File(fileName);
                LogLog.debug("Renaming file " + file + " to " + target);
                renameSucceeded = file.renameTo(target);

                //カレントログファイルのリネームに失敗している場合は、コピーする。
                if (!renameSucceeded) {
                    try {
                        LogLog.warn("Renaming file " + fileName + " to " + fileName + "." + 1 + "is error.");
                        copyFile(fileName, fileName + "." + 1);
                        //コピーが成功した場合に、リネームが成功した扱いとする。
                        renameSucceeded = true;
                    } catch (IOException e1) {
                        LogLog.error("Copying file " + fileName + " to " + fileName + "." + 1 + "is error.");
                        renameSucceeded = false;
                    }
                }

                //
                //   if file rename failed, reopen file with append = true
                //
                if (!renameSucceeded) {

                    try {
                        this.setFile(fileName, true, bufferedIO, bufferSize);
                    }
                    catch(IOException e) {
                        if (e instanceof InterruptedIOException) {
                            Thread.currentThread().interrupt();
                        }
                        LogLog.error("setFile("+fileName+", true) call failed.", e);
                    }
                }
            }
        }

        //
        //   if all renames were successful, then
        //
        if (renameSucceeded) {
            try {
                // This will also close the file. This is OK since multiple
                // close operations are safe.
                this.setFile(fileName, false, bufferedIO, bufferSize);
                nextRollover = 0;
            }
            catch(IOException e) {
                if (e instanceof InterruptedIOException) {
                    Thread.currentThread().interrupt();
                }
                LogLog.error("setFile("+fileName+", false) call failed.", e);
            }
        }
    }


    /* (非 Javadoc)
     * @see org.apache.log4j.RollingFileAppender#subAppend(org.apache.log4j.spi.LoggingEvent)
     */
    protected void subAppend(LoggingEvent event) {
        super.subAppend(event);
        if(fileName != null && qw != null) {
            long size = ((CountingQuietWriter) qw).getCount();
            if (size >= maxFileSize && size >= nextRollover) {
                rollOver();
            }
        }
    }

    /**
     * ファイルをコピーする。
     * @param srcFile コピー元。
     * @param destFile コピー先。
     * @throws IOException I/O例外が発生した場合。
     */
    public void copyFile(String srcFile, String destFile) throws IOException {
        FileChannel srcChannel = null;
        FileChannel destChannel = null;
        try {
            srcChannel = new FileInputStream(srcFile).getChannel();
            destChannel = new FileOutputStream(destFile).getChannel();
            srcChannel.transferTo(0, srcChannel.size(), destChannel);
        } catch (Exception e) {
            LogLog.error("Copying file " + srcFile + " to " + destFile + "is error." + e.toString());
            throw new IOException(e.toString(), e);
        } finally {
            srcChannel.close();
            destChannel.close();
        }
    }
}
