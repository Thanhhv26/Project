/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;

import java.util.List;

import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author tu-lenh
 */

@Data
public class DeleteResultModel {
	//OK , NG
	private String status;
	private DeleteInfoDTO resultData;
	private List<MessageInfo> messageInfo;
}
