/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import lombok.Data;

/**
 *
 * @author bao-anh
 * @version 6.0 Feb 17, 2017
 *
 */
@Data
public class DownloadFileInfo {

	private String connectDefinisionId;
	private String tableId;
	private String fileType;
	private Boolean isExportAll;
	private Boolean checkSearchBeforeDownload;

	private ColumnDisplayDefinitionDTO columnsDisplayDefinition;
	private SearchConditionItem[] searchConditionItems;
	private String jsonSearchConditionItems;
	private UserInfo userInfo;

	private String filePath;
	private String fileName;
}
