package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import java.io.Serializable;

/**
 * カラム条件定義情報一覧のリスト表示用アイテム。
 * <p>
 * </p>
 * @author  EXE 六本木 圭
 * @version 0.0.0
 */

public class ColumnConditionItem implements Serializable {
    
    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 4232404427857554514L;
    /**
     * <code>serialVersionUID</code> のコメント。
     */

    /**
     * 一覧表示設定名称。
     * <p>ユーザーが定義する一覧表示設定に付けた表示用名称です。</p>
     */
    private String outputLabel;
    /**
     * 一覧表示設定 ID。
     * <p>システム内部で扱われる ID です。</p>
     */
    private String outputValue;
    /**
     * outputLabel を戻します。
     * 
     * @return String
     */
    public String getOutputLabel() {
        return outputLabel;
    }
    /**
     * outputLabel を設定します。
     *
     * @param String outputLabel 
     */
    public void setOutputLabel(String outputLabel) {
        this.outputLabel = outputLabel;
    }
    /**
     * outputValue を戻します。
     * 
     * @return String
     */
    public String getOutputValue() {
        return outputValue;
    }
    /**
     * outputValue を設定します。
     *
     * @param String outputValue 
     */
    public void setOutputValue(String outputValue) {
        this.outputValue = outputValue;
    }

 
}
