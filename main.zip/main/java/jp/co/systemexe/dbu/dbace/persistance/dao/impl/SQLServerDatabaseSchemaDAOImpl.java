/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.TableIdDefinition;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * データベースのスキーマ情報 DAO。
 * <p>
 * データベースのテーブル名一覧やテーブルスキーマ情報へのアクセスを行う DAO です。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class SQLServerDatabaseSchemaDAOImpl extends BaseDatabaseDAO
        implements DatabaseSchemaDAO {

    /**
     * テーブルの定義情報を取得します。
     * <p>
     * テーブルのカラム詳細情報 DTO を取得して戻します。</p>
     *
     * @param tableId テーブル ID（スキーマ名.テーブル名）
     * @return TableDefinitionDTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO#getTableDefinition(java.lang.String)
     */
    public TableDefinitionDTO getTableDefinition(final String tableId)
            throws DAOException {
        final DatabaseMetaData meta;
        try {
            meta = getDatabaseMetaData();
        } catch (final SQLException e) {
        	// MI-E-0031=データベースのメタデータ取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0031");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        final TableIdDefinition id = new TableIdDefinition(tableId);
        try {
            checkTableName(id, meta);
        } catch (SQLException e) {
            throw new DAOException(e.getMessage());
        }

        final SortedMap<Integer, String> columns = getColumnNames(id, meta);
        final TableDefinitionDTO ret = createDefaultTableDefinitionDTO(id, columns);
        ret.setView(isView(meta, id));
        setPrimaryKeysToTableDefinitionDTO(meta, id, ret);
        setFkKeysToTableDefinitionDTO(meta, id, ret);
        setUniqueColumnToTableDefinitionDTO(meta, id, ret);
        ret.getColumnNames().putAll(columns);
        setColumnTypeNames(meta, id, ret);
        setResultSetMetaDataToTableDefinitionDTO(id, ret);
        setRemarks(meta, id, ret);

        ret.outputDebugLog();
        return ret;
    }

//    /**
//     *
//     */
//	@Override
//	public TableDefinitionDTO getTableDefinition(TableFormDTO tableFormDTO) throws DAOException {
//		final DatabaseMetaData meta;
//		try {
//			meta = getDatabaseMetaData();
//		} catch (final SQLException e) {
//			// MI-E-0031=データベースのメタデータ取得に失敗しました。
//			final String message = MessageUtils.getMessage("MI-E-0031");
//			getLogger().error(message, e);
//			throw new DAOException(message, e);
//		}
//
//		int index = 0;
//		if (isMultiTable(tableFormDTO.getType())) {
//			final TableDefinitionDTO multiTableDefinitionDTO = new TableDefinitionDTO(tableFormDTO.getTableFormId());
//			for (Iterator<TableItemDTO> iterator = tableFormDTO.getTableItemMap().values().iterator(); iterator.hasNext();) {
//				TableItemDTO tableItemDTO = (TableItemDTO) iterator.next();
//				// In case tableItemDTO has childs col
//				if(tableItemDTO.isRoot()){
//					final DefinitionOfColumn columnDef = new DefinitionOfColumn(tableItemDTO.getItemId());
//					columnDef.setTableId(tableItemDTO.getTableId());
//
//					columnDef.setPrimaryKey(tableItemDTO.getPrimaryKey());
//					columnDef.setUnique(tableItemDTO.getUnique());
//					columnDef.setForeignKey(tableItemDTO.getForeignKey());
//
//					columnDef.setColumnTypeName(tableItemDTO.getDataType());
//					columnDef.setNotNull(false);
//					//columnDef.setColumnDisplayMaxSize(Integer.valueOf(tableItemDTO.getDataLength()));
//
//					multiTableDefinitionDTO.getColumnNames().put(index, tableItemDTO.getItemId());
//					multiTableDefinitionDTO.getDefinitionOfColumnMap().put(tableItemDTO.getItemId(), columnDef);
//					index++;
//				}else{
//					final TableIdDefinition id = new TableIdDefinition(tableItemDTO.getTableId());
//					String name = getColumnName(id, meta, tableItemDTO.getItemId());
//					if (name != null) {
//						String colName = formatColumnMultiTable(tableItemDTO.getTableId(), name);
//						final DefinitionOfColumn columnDef = new DefinitionOfColumn(name);
//			            columnDef.setTableId(tableItemDTO.getTableId());
//
//			            setPrimaryKeys(meta, id, columnDef);
//						setFkKeys(meta, id, columnDef);
//						setUniqueColumn(meta, id, columnDef);
//						setColumnTypeNames(meta, id, columnDef);
//						setResultSetMetaData(id, columnDef);
//						setRemarks(meta, id, columnDef);
//
//			            multiTableDefinitionDTO.getColumnNames().put(index, colName);
//						multiTableDefinitionDTO.getDefinitionOfColumnMap().put(colName, columnDef);
//						index++;
//					}
//				}
//
//			}
//
//
//			multiTableDefinitionDTO.setView(false);
//			multiTableDefinitionDTO.outputDebugLog();
//			return multiTableDefinitionDTO;
//		} else {
//			return getTableDefinition(tableFormDTO.getTableFormId());
//		}
//	}



	/**
     * 結果セットメタデータからカラムの精度等の情報を DTO に設定。
     * <p></p>
     *
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setResultSetMetaDataToTableDefinitionDTO(
            final TableIdDefinition id, final TableDefinitionDTO dto)
            throws DAOException {
        final StringBuffer columnSql = new StringBuffer();
        for (final Iterator<Integer> ite = dto.getColumnNames().keySet()
            .iterator(); ite.hasNext();) {
            final int index = ite.next();
            columnSql.append(dto.getColumnNames().get(index));
            columnSql.append(",");
        }
        columnSql.deleteCharAt(columnSql.length() - 1);
        final String sql = "select " + columnSql.toString() + " from "
                + id.getTableId() + " where 1=2";
        final PreparedStatement statement = getPreparedStatement(sql);
        final ResultSet rs;
        try {
            rs = statement.executeQuery();
        } catch (final SQLException e) {
        	// MI-E-0071=結果セットの取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0071");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }

        try {
            final ResultSetMetaData meta = rs.getMetaData();
            for (int i = 1; i <= meta.getColumnCount(); i++) {
                final String name = meta.getColumnName(i);
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                    .get(name);
                if(def != null){
	                def.getDefinitionOfNumericalValue().setPrecision(
	                    meta.getPrecision(i));
	                def.getDefinitionOfNumericalValue().setScale(meta.getScale(i));
	                def.setAutoIncrement(meta.isAutoIncrement(i));
	                def.setColumnDisplayMaxSize(meta.getColumnDisplaySize(i));
	                getJDBCMetaDataType(meta, i, def);
	                if (meta.isNullable(i) == ResultSetMetaData.columnNullable) {
	                    def.setNotNull(false);
	                } else {
	                    def.setNotNull(true);
	                }
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0024=カラム情報の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0024");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                statement.close();
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

//    protected void setResultSetMetaData(
//            final TableIdDefinition id, DefinitionOfColumn def)
//            throws DAOException {
//        final StringBuffer columnSql = new StringBuffer();
//        columnSql.append(def.getColumnId());
//
//        final String sql = "select " + columnSql.toString() + " from "
//                + id.getTableId() + " where 1=2";
//        final PreparedStatement statement = getPreparedStatement(sql);
//        final ResultSet rs;
//        try {
//            rs = statement.executeQuery();
//        } catch (final SQLException e) {
//        	// MI-E-0071=結果セットの取得に失敗しました。
//            final String message = MessageUtils.getMessage("MI-E-0071");
//            getLogger().error(message, e);
//            throw new DAOException(message, e);
//        }
//
//        try {
//            final ResultSetMetaData meta = rs.getMetaData();
//            for (int i = 1; i <= meta.getColumnCount(); i++) {
//                final String name = meta.getColumnName(i);
//
//                if(def != null && def.getColumnId().equals(name)){
//	                def.getDefinitionOfNumericalValue().setPrecision(
//	                    meta.getPrecision(i));
//	                def.getDefinitionOfNumericalValue().setScale(meta.getScale(i));
//	                def.setAutoIncrement(meta.isAutoIncrement(i));
//	                def.setColumnDisplayMaxSize(meta.getColumnDisplaySize(i));
//	                getJDBCMetaDataType(meta, i, def);
//	                if (meta.isNullable(i) == ResultSetMetaData.columnNullable) {
//	                    def.setNotNull(false);
//	                } else {
//	                    def.setNotNull(true);
//	                }
//                }
//            }
//        } catch (final SQLException e) {
//        	// MI-E-0024=カラム情報の取得に失敗しました。
//            final String message = MessageUtils.getMessage("MI-E-0024");
//            getLogger().error(message, e);
//            throw new DAOException(message, e);
//        } finally {
//            try {
//                statement.close();
//                rs.close();
//            } catch (Exception e) {
//                getLogger().warn(e);
//            }
//        }
//    }

    /**
     * 別のカラム型情報を取得します。
     * カラム型情報を戻します。
     * @param meta
     * @param i
     * @param def
     * @throws SQLException
     */
    protected void getJDBCMetaDataType(final ResultSetMetaData meta, int i,
			final DefinitionOfColumn def) throws SQLException {
		if(def.getColumnTypeName().equals("time")){
	    	def.setJDBCMetaDataType(JDBCMetaDataType.TIME);
	    }else if(def.getColumnTypeName().equals("datetime2")) {
	    	def.setJDBCMetaDataType(JDBCMetaDataType.TIMESTAMP);
	    }else if(def.getColumnTypeName().equals("date")){
	    	def.setJDBCMetaDataType(JDBCMetaDataType.DATE);
	    }else if (def.getColumnTypeName().equals("datetimeoffset")){
	    	def.setJDBCMetaDataType(JDBCMetaDataType.OTHER);
		} else {
	    	def.setJDBCMetaDataType(JDBCMetaDataType.dataTypeOf(meta
	                .getColumnType(i)));
		}
	}

    /**
     * DB メタデータからユニーク制約の情報を読み込み DTO に設定する。
     * <p>
     * ユニークインデックスが定義されている場合は、そのカラムが主キーであると
     * 副次的に判定します。<br />
     * プライマリキー制約によって主キーを定義している場合は、この制約が存在
     * しない場合が（多々）あります。
     * </p>
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setUniqueColumnToTableDefinitionDTO(
            final DatabaseMetaData meta, final TableIdDefinition id,
            final TableDefinitionDTO dto) throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getIndexInfo(null, id.getSchem(), id.getTable(), true,
                true);
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                if (name != null && name.equals("") == false) {
                    final DefinitionOfColumn def = dto
                        .getDefinitionOfColumnMap().get(name);
                    def.setUnique(true);
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0018=ユニークキー（Unique Key)の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0018");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

//    protected void setUniqueColumn(
//            final DatabaseMetaData meta, final TableIdDefinition id,
//            final DefinitionOfColumn colDef) throws DAOException {
//        ResultSet rs = null;
//        try {
//            rs = meta.getIndexInfo(null, id.getSchem(), id.getTable(), true,
//                true);
//            while (rs.next()) {
//                final String name = rs.getString("COLUMN_NAME");
//                if (colDef != null && name != null && name.equals("") == false) {
//                    colDef.setUnique(true);
//                }
//            }
//        } catch (final SQLException e) {
//        	// MI-E-0018=ユニークキー（Unique Key)の取得に失敗しました。
//            final String message = MessageUtils.getMessage("MI-E-0018");
//            getLogger().error(message, e);
//            throw new DAOException(message, e);
//        } finally {
//            try {
//                rs.close();
//            } catch (Exception e) {
//                getLogger().warn(e);
//            }
//        }
//    }

    /**
     * DB メタデータから外部キーの情報を読み込み DTO に設定する。
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setFkKeysToTableDefinitionDTO(final DatabaseMetaData meta,
            final TableIdDefinition id, final TableDefinitionDTO dto)
            throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getImportedKeys(null, id.getSchem(), id.getTable());
            while (rs.next()) {
            	final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                        .get(rs.getString("FKCOLUMN_NAME"));
            	if(def != null){
            		def.setForeignKey(true);
            	}
            }
        } catch (final SQLException e) {
        	// MI-E-0006=外部キー(Foreign Key)の取得に失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0006");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

//    protected void setFkKeys(final DatabaseMetaData meta,
//            final TableIdDefinition id, final DefinitionOfColumn colDef)
//            throws DAOException {
//        ResultSet rs = null;
//        try {
//            rs = meta.getImportedKeys(null, id.getSchem(), id.getTable());
//            while (rs.next()) {
//            	if(colDef != null && colDef.getColumnId().equals(rs.getString("FKCOLUMN_NAME"))){
//            		colDef.setForeignKey(true);
//            	}
//            }
//        } catch (final SQLException e) {
//        	// MI-E-0006=外部キー(Foreign Key)の取得に失敗しました。
//        	final String message = MessageUtils.getMessage("MI-E-0006");
//            getLogger().error(message, e);
//            throw new DAOException(message, e);
//        } finally {
//            try {
//                rs.close();
//            } catch (Exception e) {
//                getLogger().warn(e);
//            }
//        }
//    }

    /**
     * DB メタデータからプライマリキーの情報を読み込み DTO に設定する。
     * <p>
     * プライマリキーで主キーが定義されている場合は、同時にユニークフラグも ON
     * しておきます。</p>
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setPrimaryKeysToTableDefinitionDTO(
            final DatabaseMetaData meta, final TableIdDefinition id,
            final TableDefinitionDTO dto) throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getPrimaryKeys(null, id.getSchem(), id.getTable());
            while (rs.next()) {
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                    .get(rs.getString("COLUMN_NAME"));
                if(def != null){
                	def.setPrimaryKey(true);
                	def.setUnique(true);
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0010=データベースに操作対象のオブジェクトが存在しません
            final String message = MessageUtils.getMessage("MI-E-0010");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

//    protected void setPrimaryKeys(
//            final DatabaseMetaData meta, final TableIdDefinition id,
//            final DefinitionOfColumn colDef) throws DAOException {
//        ResultSet rs = null;
//        try {
//            rs = meta.getPrimaryKeys(null, id.getSchem(), id.getTable());
//            while (rs.next()) {
//                if(colDef != null && colDef.getColumnId().equals(rs.getString("COLUMN_NAME"))){
//                	colDef.setPrimaryKey(true);
//                	colDef.setUnique(true);
//                }
//            }
//        } catch (final SQLException e) {
//        	// MI-E-0010=主キー（Primary Key)の取得に失敗しました。
//            final String message = MessageUtils.getMessage("MI-E-0010");
//            getLogger().error(message, e);
//            throw new DAOException(message, e);
//        } finally {
//            try {
//                rs.close();
//            } catch (Exception e) {
//                getLogger().warn(e);
//            }
//        }
//    }

    /**
     * カラム名の一覧を取得して Map に設定して戻します。
     *
     * @param id
     * @return
     * @throws DAOException
     */
    private SortedMap<Integer, String> getColumnNames(
    		final TableIdDefinition id,
            final DatabaseMetaData meta)
            throws DAOException {
        final SortedMap<Integer, String> ret = new TreeMap<Integer, String>();
        try {
            final ResultSet rs = meta.getColumns(null, id.getSchem(), id
                .getTable(), null);
            int index = 1;
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                ret.put(index, name);
                index++;
            }
            rs.close();
        } catch (final SQLException e) {
        	// MI-E-0025=カラム名の一覧取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0025");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }

    /**
     * カラム名の一覧を取得して Map に設定して戻します。
     *
     * @param id
     * @return
     * @throws DAOException
     */
//    protected String getColumnName(
//    		final TableIdDefinition id,
//            final DatabaseMetaData meta,
//            final String columnName)
//            throws DAOException {
//    	String name = null;
//        try {
//            final ResultSet rs = meta.getColumns(null, id.getSchem(), id
//                .getTable(), columnName);
//            while (rs.next()) {
//                name = rs.getString("COLUMN_NAME");
//            }
//            rs.close();
//        } catch (final SQLException e) {
//        	// MI-E-0025=カラム名の一覧取得に失敗しました。
//            final String message = MessageUtils.getMessage("MI-E-0025");
//            getLogger().error(message, e);
//            throw new DAOException(message, e);
//        }
//        return name;
//    }

    /**
     * カラム名一覧からテーブル定義 DTO を生成して戻します。
     *
     * @param idDef
     * @param columnNames
     * @return
     */
    private TableDefinitionDTO createDefaultTableDefinitionDTO(
            final TableIdDefinition idDef,
            final Map<Integer, String> columnNames) {
        final TableDefinitionDTO ret = new TableDefinitionDTO(idDef.getTable());
        for (final Iterator<String> ite = columnNames.values().iterator(); ite
            .hasNext();) {
            final String name = ite.next();
            final DefinitionOfColumn columnDef = new DefinitionOfColumn(name);
            columnDef.setTableId(idDef.getTableId());
            ret.getDefinitionOfColumnMap().put(name, columnDef);
        }
        return ret;
    }

    /**
     * テーブル名の一覧を取得して戻す。
     * <p>
     * 現在接続を確立しているデータベース内の、アクセス可能なテーブル名の一覧を
     * 取得して戻します。
     * </p><p>
     * テーブル名の前方はスキーマ名で修飾されています。
     * <code>(スキーマ名).(テーブル名)</code>
     * </p>
     *
     * @return List&lt;(スキーマ名).(テーブル名)&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO#getTableNameList()
     */
    public List<String> getTableNameList(String condition) throws DAOException {
        final List<String> ret = new ArrayList<String>();
        if (StringUtils.isNotEmpty(condition)) {
        	condition = condition.toLowerCase();
        }
        try {
            final DatabaseMetaData meta = getDatabaseMetaData();
            final String[] tps = {"TABLE", "VIEW"};
            final ResultSet rs = meta.getTables(null, "%", "%", tps);
            while (rs.next()) {
                final String schem = rs.getString("TABLE_SCHEM");
                final String table = rs.getString("TABLE_NAME");
                if (schem == null || schem.equals("")) {
                	if (StringUtils.isNotEmpty(condition)) {
                      if (table.matches(".*\\Q" + condition + "\\E.*")) {
                    	  ret.add(table);
                      }
                	} else {
                		ret.add(table);
                	}
                } else {
                	String schemTable = schem.concat(".").concat(table);
                	String schemTableTemp = schemTable;
                	schemTableTemp = schemTableTemp.toLowerCase();
                	if (StringUtils.isNotEmpty(condition)) {
                		if (schemTableTemp.matches(".*\\Q" + condition + "\\E.*")) {
                      	  ret.add(schemTable);
                        }
                	} else {
                		ret.add(schemTable);
                	}
                }
            }
            rs.close();
            return ret;
        } catch (final SQLException e) {
        	// MI-E-0035=テーブル名の一覧取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0035");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * データベース固有のデータ型を返します。
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setColumnTypeNames(
            final DatabaseMetaData meta,
            final TableIdDefinition id,
            final TableDefinitionDTO dto)
            throws DAOException {
        try {
            final ResultSet rs = meta.getColumns(null, id.getSchem(), id.getTable(), "%");
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                final String type = rs.getString("TYPE_NAME");
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap().get(name);
                if(def != null){
                	//「decimal() identity」 => 「decimal」
                	final String custom = customIdentityColumnTypeName(type);
                	def.setColumnTypeName(custom);
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0123=カラムのデータ型の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0123");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

//    protected void setColumnTypeNames(
//            final DatabaseMetaData meta,
//            final TableIdDefinition id,
//            final DefinitionOfColumn colDef)
//            throws DAOException {
//        try {
//            final ResultSet rs = meta.getColumns(null, id.getSchem(), id.getTable(), "%");
//            while (rs.next()) {
//                final String name = rs.getString("COLUMN_NAME");
//                final String type = rs.getString("TYPE_NAME");
//                if(colDef != null && colDef.getColumnId().equals(name)){
//	                if(colDef != null){
//	                	colDef.setColumnTypeName(type);
//	                }
//                }
//            }
//        } catch (final SQLException e) {
//        	// MI-E-0123=カラムのデータ型の取得に失敗しました。
//            final String message = MessageUtils.getMessage("MI-E-0123");
//            getLogger().error(message, e);
//            throw new DAOException(message, e);
//        }
//    }


    /**
     * カラムのコメント(REMARKS)を設定します。
     * <p>SQL ServerはJDBC経由でコメントが取得できない。<br />
     * また、コメントが格納されているデータ型がsql_variant型（JDBC未対応）のため、
     * SQLでも取得不可能なため、nullを返します。
     * </p>
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setRemarks(
            final DatabaseMetaData meta,
            final TableIdDefinition id,
            final TableDefinitionDTO dto)
            throws DAOException {
        try {
            final ResultSet rs = meta.getColumns(null, id.getSchem(), id.getTable(), "%");
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                    .get(name);
                if(def != null){
                	def.setRemarks(rs.getString("REMARKS"));
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0022=カラムのコメント(REMARKS)取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0022");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

//    protected void setRemarks(
//            final DatabaseMetaData meta,
//            final TableIdDefinition id,
//            DefinitionOfColumn colDef)
//            throws DAOException {
//        try {
//            final ResultSet rs = meta.getColumns(null, id.getSchem(), id.getTable(), colDef.getColumnId());
//            while (rs.next()) {
//                final String name = rs.getString("COLUMN_NAME");
//                if(colDef != null && colDef.getColumnId().equals(name)){
//                	colDef.setRemarks(rs.getString("REMARKS"));
//                }
//            }
//        } catch (final SQLException e) {
//        	// MI-E-0022=カラムのコメント(REMARKS)取得に失敗しました。
//            final String message = MessageUtils.getMessage("MI-E-0022");
//            getLogger().error(message, e);
//            throw new DAOException(message, e);
//        }
//    }

    /**
     * Viewか否か
     *
     * @param meta
     * @param id
     * @param dto
     * @return
     * @throws DAOException
     */
    private boolean isView(
            final DatabaseMetaData meta,
            final TableIdDefinition id)
            throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getTables(null, id.getSchem(), id.getTable(), new String[]{"VIEW"});
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (final SQLException e) {
        	// MI-E-0019=VIEW情報の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0019");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseDatabaseDAO#createSelectWheresString(java.util.SortedMap)
     */
    @Override
    protected String createSelectWheresClause(SortedMap<Integer, SelectConditionItem> wheresMap) {
        // TODO 自動生成されたメソッド・スタブ
        return null;
    }

    /**
     * DatabaseSchemaDAOImpl の生成。
     * <p>コンストラクタ。</p>
     */
    public SQLServerDatabaseSchemaDAOImpl() {
        return;
    }

    @Override
	protected String ignoreNullColumns(final List<String> columns, final String columnType) {
//    	final StringBuffer columnsBuff = new StringBuffer();
//		final StringBuffer bracketsBuff = new StringBuffer();
//		String dbFunc = "ISNULL";
//		//case 1 column : ISNULL(col1,null)
//		if (colList.size() == 1) {
//			columnsBuff.append(dbFunc);
//			columnsBuff.append("(");
//			columnsBuff.append(colList.get(0));
//			columnsBuff.append(", ");
//			columnsBuff.append("null");
//			bracketsBuff.append(")");
//			columnsBuff.append(bracketsBuff);
//			return columnsBuff.toString();
//		}
//		//case >= 2 column
//		int index = 0;
//		for (String name : colList) {
//			if (columnsBuff.length() > 0) {
//				columnsBuff.append(", ");
//			}
//			if(index >= colList.size() - 1){
//				columnsBuff.append(name);
//				break;
//			} else {
//				columnsBuff.append(dbFunc);
//				columnsBuff.append("(");
//				columnsBuff.append(name);
//			}
//			bracketsBuff.append(")");
//			index++;
//		}
//		columnsBuff.append(bracketsBuff);
//		return columnsBuff.toString();
    	return null;
	}

	@Override
	protected String createFuncCheckNullSelectWheresClause(SelectConditionItem item) {
		// TODO Auto-generated method stub
		return null;
	}
}
