/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import jp.co.systemexe.dbu.dbace.presentation.AdLdapServerType;
import jp.co.systemexe.dbu.dbace.presentation.LdapUserServerIdentify;

/**
 * データベース接続定義情報 DTO。
 * <p>
 * データベースに対する接続定義情報を保持する DTO です。<br />
 * 概ねデータベースへの接続文字列を定義する情報を保持します。</p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class ExternalAuthCooperationDefinitionDTO {

    /**
     * サーバー種類
     */
    private AdLdapServerType adLdapServerType;
    /**
     * サーバー種類
     */
    private LdapUserServerIdentify ldapUserServerIdentify;

}
