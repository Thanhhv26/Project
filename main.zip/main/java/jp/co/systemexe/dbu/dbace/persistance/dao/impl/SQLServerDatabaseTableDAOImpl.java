/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.jdbc.WebResultSetFacade;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectSqlCondition;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SimpleSqlCondition;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSaveConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchResultDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TypeOfRetrieval;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;

/**
 * データベースのテーブルデータ DAO。
 * <p>
 * 実際にデータベース内のテーブルデータにアクセスする DAO です。</p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class SQLServerDatabaseTableDAOImpl extends SQLServerDatabaseTableDAO
        implements DatabaseTableDAO {

    /**
     * id と label ペアの選択候補マップを戻します。
     * <p>
     * SQL 文を直接指定してレコードを取得し、結果をコレクションに設定して戻し
     * ます。<br />
     * 得られた結果セットのカラム数が２よりも少ない場合は例外をスローします。
     * </p><p>
     * なお、本メソッドはプルダウンリストへの表示データの取得を意図したメソッド
     * なので、戻すレコード件数は 1,000 件上限に制限されています。
     * </p>
     *
     * @param sql SQL 文
     * @return SelectOneMenuItem[]
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO#doSelect(java.lang.String)
     */
    public SelectableItem[] getSelectableMap(final String query)
            throws DAOException {

        getLogger().debug(query);

        final long start = System.currentTimeMillis();
        final PreparedStatement statement = getPreparedStatement(query);
        final ResultSet resultSet;
        try {
            resultSet = statement.executeQuery();
        } catch (final SQLException e) {
            try {
                statement.close();
            } catch (Exception ex) {
                getLogger().warn(e);
            }
        	// MI-E-0021=データベースのカーソルの取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0021");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        final ResultSetMetaData meta;
        try {
            meta = resultSet.getMetaData();
            if (meta.getColumnCount() < 2) {
                try {
                    resultSet.close();
                } catch (Exception e) {
                    getLogger().warn(e.toString());
                }
                try {
                    statement.close();
                } catch (Exception e) {
                    getLogger().warn(e.toString());
                }

                // MI-E-0023=カラム数が足りません。カラム数は2つ必要です。
                final String message = MessageUtils.getMessage("MI-E-0023");
                getLogger().error(message);
                throw new DAOException(message);
            }
        } catch (final SQLException e) {
            try {
                resultSet.close();
            } catch (Exception ex) {
                getLogger().warn(e.toString());
            }
            try {
                statement.close();
            } catch (Exception ex) {
                getLogger().warn(e.toString());
            }
        	// MI-E-0031=データベースのメタデータ取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0031");
            getLogger().error(message, e);
            throw new DAOException(e);
        }

        final List<SelectOneMenuItem> ret = new ArrayList<SelectOneMenuItem>();
        try {
            int counter = 0;
            resultSet.setFetchSize(SystemProperties.getPrefetchSize());
            while (resultSet.next()) {
                final SelectOneMenuItem item = new SelectableItem();
                final String key = resultSet.getString(1);
                item.setValue(key == null ? "" : key);
                item.setLabel(resultSet.getString(2));
                ret.add(item);
                counter++;
                if (counter >= SystemProperties.getPulldownMaxCount()) {
                    break;
                }
            }
            getLogger().debug("selectableMap loop:" + (System.currentTimeMillis() - start));
        } catch (final SQLException e) {
        	// MI-E-0057=レコードの検索処理に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0057");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                resultSet.close();
            } catch (Exception e) {
                getLogger().warn(e.toString());
            }
            try {
                statement.close();
            } catch (Exception e) {
                getLogger().warn(e.toString());
            }
        }
        return ret.toArray(new SelectableItem[0]);
    }

    /**
     * delete を発行しレコードを削除します。
     *
     * @param dto レコード削除条件 DTO
     * @param table テーブル DB 内定義 DTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO#doDelete(jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO)
     */
    public int doDelete(
    		final RecordSearchConditionDTO dto,
            final TableDefinitionDTO table,
    		final String databaseId,
    		final UserInfo userInfo
    		)
    		throws DAOException {
        final SimpleSqlCondition condition = new SimpleSqlCondition();
        condition.setTableId(dto.getTableId());

        for (Iterator<SelectConditionItem> iterator = dto.getConditions().values().iterator(); iterator.hasNext();) {
			SelectConditionItem selectConditionItem = (SelectConditionItem) iterator.next();
			condition.addWheres(selectConditionItem.getColumnId(), selectConditionItem.getValue());
            condition.addJdbcMetaData(selectConditionItem.getColumnId(), table.getDefinitionOfColumnMap().get(selectConditionItem.getColumnId()).getJDBCMetaDataType());
		}
        condition.setConnectDefinitionId(dto.getConnectDefinitionId());
        return delete(condition, databaseId, userInfo);
    }

    /**
     * insert を発行しレコードを追加します。
     *
     * @param records レコード保持マップ
     * @param dto 保存条件 DTO
     * @param table テーブル DB 内定義 DTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO#doInsert(java.util.Map, jp.co.systemexe.dbu.dbace.persistance.dto.RecordSaveConditionDTO)
     */
    public void doInsert(final Map<String, String> records,
            final RecordSaveConditionDTO dto,
            final TableDefinitionDTO table,
            final Map<String, TableItemDTO> tableItemMap,
    		final String databaseId,
    		final UserInfo userInfo
    		)
            throws DAOException {
        final SimpleSqlCondition condition = new SimpleSqlCondition();
        condition.setTableId(dto.getTableId());
        for (final Iterator<String> ite = records.keySet().iterator(); ite
            .hasNext();) {
            final String name = ite.next();
            condition.addValues(name, records.get(name));
            condition.addJdbcMetaData(name, table.getDefinitionOfColumnMap().get(name).getJDBCMetaDataType());
            condition.addHtmlElement(name, tableItemMap.get(name).getHtmlElement());
        }
        condition.setConnectDefinitionId(dto.getConnectDefinitionId());
        insert(condition, databaseId, userInfo);
    }

    /**
     * select を発行し結果レコードをコレクションに設定して戻します。
     * <p>
     * 条件指定に従い、一致検索或いは曖昧検索を行い、取得したレコードを
     * コレクションに設定して戻します。
     * </p><p>
     * 検索されたレコードの内、戻す範囲の先頭と、一度に戻すレコード数も指定
     * 出来ます。<br />
     * 指定された先頭位置にレコードが発見できない場合は空のコレクションを戻し
     * ます。<br />
     * 指定された先頭位置から、指定されたレコード数が存在しない場合は、存在した
     * 分だけを戻します。また、レコード数が 0 以下で指定されていた場合は、検索
     * されたレコードを指定された先頭位置から全て戻します。
     * </p><p>
     * なお、結果セットの先頭レコードへの移動のため absolute メソッドを使用して
     * いますが、このメソッドは結果セットを生成するステートメントがスクロール
     * 可能（TYPE_SCROLL_INSENSITIVE）の場合しか使用できません。
     * </p>
     *
     * @param dto レコード検索条件 DTO
     * @param form テーブルフォーム DTO
     * @param table テーブル DB 内定義 DTO
     * @return RecordSearchResultDTO レコード検索結果 DTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO#doSelect(jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO)
     */
    public RecordSearchResultDTO doSelect(
            final RecordSearchConditionDTO dto,
            final TableFormDTO form,
            final TableDefinitionDTO table) throws DAOException {
        final SelectSqlCondition condition = createSelectSqlCondition(dto, form);
        final WebResultSetFacade facade;
        if (dto.getTypeOfRetrieval() == TypeOfRetrieval.STRICTNESS) {
            facade = select(condition);
        } else if (dto.getTypeOfRetrieval() == TypeOfRetrieval.UNRESTRICTED) {
            condition.getWheresMap().clear();
            facade = select(condition);
        } else {
            try {
                getPreparedStatement().close();
            } catch (Exception ex) {
            }
            final String message = "TypeOfRetrieval enum is illegal state.";
            getLogger().fatal(message);
            throw new DAOException(message);
        }
        final SortedMap<Integer, Map<String, String>> recordSearchResult = new TreeMap<Integer, Map<String, String>>();
        final RecordSearchResultDTO ret = new RecordSearchResultDTO();
        try {
            facade.setFetchSize(SystemProperties.getDownloadFetchSize());
            if (facade.absolute(dto.getTopIndex() + 1)) {
                int i = 0;
                do {
                    if (dto.getRecordCount() >= 0 && i >= dto.getRecordCount()) {
                        break;
                    }
                    recordSearchResult.put(i, facade.getMap(form.getTableItemMap(), table));
                    i++;
                } while (facade.next());
            } else {
                recordSearchResult.put(0, null);
            }
            ret.setRecordSearchResult(recordSearchResult);
            ret.setSearchCondition(getSearchCondition());
        } catch (final SQLException e) {
        	// MI-E-0057=レコードの検索処理に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0057");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            facade.close();
            try {
                getPreparedStatement().close();
            } catch (Exception ex) {
                getLogger().warn(ex);
            }
        }
        return ret;
    }

    /**
     * select count(*) を発行しレコード件数を返します。
     * <p>
     * 条件指定に従い、一致検索或いは曖昧検索を行い、レコード件数を返します。
     * </p>
     *
     * @param dto レコード検索条件 DTO
     * @param form テーブルフォーム DTO
     * @param table テーブル DB 内定義 DTO
     * @return int レコード数
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO#doSelect(jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO)
     */
    public int getRowCount(
            final RecordSearchConditionDTO dto,
            final TableFormDTO form) throws DAOException {
        final SelectSqlCondition condition = createSelectSqlCondition(dto,
            form);
        final String query;
        if (dto.getTypeOfRetrieval() == TypeOfRetrieval.STRICTNESS) {
            query = rowCount(condition);
        } else if (dto.getTypeOfRetrieval() == TypeOfRetrieval.VAGUENESS) {
            query = rowCountLike(condition);
        } else if (dto.getTypeOfRetrieval() == TypeOfRetrieval.UNRESTRICTED) {
            condition.getWheresMap().clear();
            query = rowCount(condition);
        } else {
            try {
                getPreparedStatement().close();
            } catch (Exception ex) {
            }
            final String message = "TypeOfRetrieval enum is illegal state.";
            getLogger().fatal(message);
            throw new DAOException(message);
        }


        final PreparedStatement preparedStatement = getPreparedStatement(query);
        final ResultSet resultSet;
        try {
            resultSet = preparedStatement.executeQuery();
        } catch (final SQLException e) {
            try {
                getPreparedStatement().close();
            } catch (final SQLException ex) {
                getLogger().warn(ex);
            }
            // MI-E-0060=レコード件数の取得に失敗しました。
            /*final String message = MessageUtils.getMessage("MI-E-0060");*/
            final String message = e.getLocalizedMessage();
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }

        try {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }
        } catch (final SQLException e) {
            // MI-E-0060=レコード件数の取得に失敗しました。
            /*final String message = MessageUtils.getMessage("MI-E-0060");*/
        	final String message = e.getLocalizedMessage();
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                resultSet.close();
            } catch (Exception ex) {
                getLogger().warn(ex);
            }
            try {
                getPreparedStatement().close();
            } catch (Exception ex) {
                getLogger().warn(ex);
            }
        }
    }

    /**
     * select count(*) を発行しレコード件数を返します。
     * <p>
     * 条件指定に従い、一致検索或いは曖昧検索を行い、レコード件数を返します。
     * </p>
     *
     * @param dto レコード検索条件 DTO
     * @param form テーブルフォーム DTO
     * @param table テーブル DB 内定義 DTO
     * @return int レコード数
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO#doSelect(jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO)
     */
    public int getRowCountTab(
            final RecordSearchConditionDTO dto,
            final TableDto table) throws DAOException {
        final SelectSqlCondition condition = createSelectSqlConditionTab(dto,
            table);
        final String query;
        if (dto.getTypeOfRetrieval() == TypeOfRetrieval.STRICTNESS) {
            query = rowCount(condition);
        } else if (dto.getTypeOfRetrieval() == TypeOfRetrieval.VAGUENESS) {
            query = rowCountLike(condition);
        } else if (dto.getTypeOfRetrieval() == TypeOfRetrieval.UNRESTRICTED) {
            condition.getWheresMap().clear();
            query = rowCount(condition);
        } else {
            try {
                getPreparedStatement().close();
            } catch (Exception ex) {
            }
            final String message = "TypeOfRetrieval enum is illegal state.";
            getLogger().fatal(message);
            throw new DAOException(message);
        }


        final PreparedStatement preparedStatement = getPreparedStatement(query);
        final ResultSet resultSet;
        try {
            resultSet = preparedStatement.executeQuery();
        } catch (final SQLException e) {
            try {
                getPreparedStatement().close();
            } catch (final SQLException ex) {
                getLogger().warn(ex);
            }
            // MI-E-0060=レコード件数の取得に失敗しました。
            /*final String message = MessageUtils.getMessage("MI-E-0060");*/
            final String message = e.getLocalizedMessage();
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }

        try {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }
        } catch (final SQLException e) {
            // MI-E-0060=レコード件数の取得に失敗しました。
            /*final String message = MessageUtils.getMessage("MI-E-0060");*/
        	final String message = e.getLocalizedMessage();
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                resultSet.close();
            } catch (Exception ex) {
                getLogger().warn(ex);
            }
            try {
                getPreparedStatement().close();
            } catch (Exception ex) {
                getLogger().warn(ex);
            }
        }
    }

    /**
     * update を発行しレコードを更新します。
     *
     * @param records レコード保持マップ
     * @param dto 保存条件 DTO
     * @param table テーブル DB 内定義 DTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO#doUpdate(java.util.Map, jp.co.systemexe.dbu.dbace.persistance.dto.RecordSaveConditionDTO)
     */
    public void doUpdate(
    		final Map<String, String> records,
            final RecordSaveConditionDTO dto,
            final TableDefinitionDTO table,
            final Map<String, TableItemDTO> tableItemMap,
    		final String databaseId,
    		final UserInfo userInfo
    		)
            throws DAOException {
        final SimpleSqlCondition condition = new SimpleSqlCondition();
        condition.setTableId(dto.getTableId());
        int aliasindex = 1;
        for (final Iterator<String> ite = records.keySet().iterator(); ite.hasNext();) {
            final String name = ite.next();
            condition.addValues(name, records.get(name));
            condition.addAliasNameMap(String.format("COL%d", aliasindex++), name);
            condition.addJdbcMetaData(name, table.getDefinitionOfColumnMap().get(name).getJDBCMetaDataType());
            condition.addHtmlElement(name, tableItemMap.get(name).getHtmlElement());
        }
        for (final Iterator<String> ite = dto.getConditions().keySet().iterator(); ite.hasNext();) {
            final String name = ite.next();
            condition.addWheres(name, dto.getConditions().get(name));
        }
        condition.setConnectDefinitionId(dto.getConnectDefinitionId());
        update(condition, databaseId, userInfo);
    }

    /**
     * DatabaseTableDAOImpl の生成。
     * <p>コンストラクタ。</p>
     */
    public SQLServerDatabaseTableDAOImpl() {
        return;
    }

    /**
     * select count(*) を発行しレコード件数を返します。
     * <p>
     * 条件指定に従い、一致検索或いは曖昧検索を行い、レコード件数を返します。
     * </p>
     *
     * @param dto レコード検索条件 DTO
     * @param form テーブルフォーム DTO
     * @return int レコード数
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO#doSelect(jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO)
     */
	@Override
    public int getRowCount(
            final RecordSearchConditionDTO dto) throws DAOException {
        final SelectSqlCondition condition = createSelectSqlCondition(dto);
        final String query;
        if (dto.getTypeOfRetrieval() == TypeOfRetrieval.STRICTNESS) {
            query = rowCount(condition);
        } else if (dto.getTypeOfRetrieval() == TypeOfRetrieval.VAGUENESS) {
            query = rowCountLike(condition);
        } else if (dto.getTypeOfRetrieval() == TypeOfRetrieval.UNRESTRICTED) {
            condition.getWheresMap().clear();
            query = rowCount(condition);
        } else {
            try {
                getPreparedStatement().close();
            } catch (Exception ex) {
            }
            final String message = "TypeOfRetrieval enum is illegal state.";
            getLogger().fatal(message);
            throw new DAOException(message);
        }


        final PreparedStatement preparedStatement = getPreparedStatement(query);
        final ResultSet resultSet;
        try {
            resultSet = preparedStatement.executeQuery();
        } catch (final SQLException e) {
            try {
                getPreparedStatement().close();
            } catch (final SQLException ex) {
                getLogger().warn(ex);
            }
            // MI-E-0060=レコード件数の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0060");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }

        try {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }
        } catch (final SQLException e) {
            // MI-E-0060=レコード件数の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0060");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                resultSet.close();
            } catch (Exception ex) {
                getLogger().warn(ex);
            }
            try {
                getPreparedStatement().close();
            } catch (Exception ex) {
                getLogger().warn(ex);
            }
        }
    }

}
