/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

/**
 * EASY用に定義された、定数を文字列に変換して戻します。
 * TODO:次期バージョンに向けて、大幅な見直しをかけること
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class DefaultValueAnalysis {

    /**
     * ロガーへの参照を保持します。
     */
    private final Logger logger;

    private UserInfo userInfo;

    /**
     * 区切り文字
     */
    private final static String DELIMITER_PATTERN = "\\$.+?\\}";

    /**
     * 更新パターン
     */
    private final static String UPDATE_PATTERN = "\\$.+?\\{";

    /**
     * 定数パターン
     */
    private final static String CONSTANT_PATTERN = "\\{.+?\\}";//\{ghgtet\}

    public DefaultValueAnalysis(UserInfo userInfo) {
        this.userInfo = userInfo;
        logger = LoggerFactory.getLogger(this.getClass().getName());
    }

    /**
     * テスト用メインクラス
     *
     * @param args
     */
    public static void main(String args[]) {
        final UserInfo userInfo = new UserInfo();
        userInfo.setId("user01");
        final DefaultValueAnalysis compiler = new DefaultValueAnalysis(userInfo);
        final List<UpdatePattern> updatePatternList = new ArrayList<UpdatePattern>();
        updatePatternList.add(UpdatePattern.INSERT);
        updatePatternList.add(UpdatePattern.UPDATE);

        for (final UpdatePattern updatePattern : updatePatternList) {
            System.out.println("result:" + compiler.analysis("${SYSDATE}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$I{SYSDATE}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$U{SYSDATE}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$IU{SYSDATE}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$UI{SYSDATE}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("${LOGIN_USER}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$I{LOGIN_USER}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$U{LOGIN_USER}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$IU{LOGIN_USER}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$UI{LOGIN_USER}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("${SYSDATE}${SYSDATE}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("hoge", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$UI{LOGIN_USERA}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("$AA{LOGIN_USERA}", updatePattern, "def"));
            System.out.println("result:" + compiler.analysis(null, updatePattern, "def"));
            System.out.println("result:" + compiler.analysis("", updatePattern, "def"));
        }
    }

    /**
     * 定数値を文字列に変更した値を返します。
     * <p>
     * 定数以外の文字列は無視されます。
     * </p>
     *
     * @param expressions 既定値
     * @param updatePattern 更新区分
     * @param columnData カラムデータ
     */
    public String analysis(
            final String expressions,
            final UpdatePattern updatePattern,
            final String columnData) {
        logger.debug("expressions:" + expressions + ", UpdatePattern:" + updatePattern + ", columnData:" + columnData);
        if (StringUtils.isEmpty(expressions)) {						//既定値が未定義の時
            if (updatePattern == UpdatePattern.INSERT) {			//新規登録の時
                return expressions;									//既定値を返す
            } else {
                return columnData;									//データ値を返す
            }
        }

        final List<String> exs = expressionsParsing(expressions, DELIMITER_PATTERN);
        if (exs.size() != 0) {
            final String ex = exs.get(0);
            try {
                final UpdatePattern pattern = UpdatePattern.patternOf(parsing(ex ,UPDATE_PATTERN));
                final ConstantPattern constantPattern = ConstantPattern.valueOf(parsing(ex ,CONSTANT_PATTERN));
                if (pattern == UpdatePattern.ALL
                        || pattern == UpdatePattern.INSERT_AND_UPDATE) {
                    if (constantPattern == ConstantPattern.SYSDATE) {
                        return getSysdate("yyyy/MM/dd HH:mm:ss.SSS");
                    } else {
                        return getLoginUser();
                    }
                } else if (pattern == updatePattern) {
                    if (constantPattern == ConstantPattern.SYSDATE) {
                        return getSysdate("yyyy/MM/dd HH:mm:ss.SSS");
                    } else {
                        return getLoginUser();
                    }
                } else {
                    if (updatePattern == UpdatePattern.INSERT) {
                        return "";
                    } else {
                        return columnData;
                    }
                }
            } catch (final IllegalArgumentException e) {
                logger.warn(e.getMessage());
                if (updatePattern == UpdatePattern.INSERT) {
                    return expressions;
                } else {
                    return columnData;
                }
            }
        } else {
            if (updatePattern == UpdatePattern.INSERT) {
                return expressions;
            } else {
                return columnData;
            }
        }
    }

    /**
     * 更新パターン、定数パターンを切り出して戻します。
     *
     * @param expressions
     * @param pattern
     * @return
     */
    private String parsing(final String expressions, final String pattern) {
        Pattern pat = Pattern.compile(pattern);
        Matcher mat = pat.matcher(expressions);

        if(mat.find()) {
            logger.debug("--->" + expressions.substring(mat.start() + 1, mat.end() - 1));
            return expressions.substring(mat.start() + 1, mat.end() - 1).trim();
        } else {
            return "";
        }
    }

    /**
     * 定数を区切り文字単位で切り分けて戻します。
     *
     * @param expressions
     * @param pattern
     * @return
     */
    private List<String> expressionsParsing(final String expressions, final String pattern) {
        Pattern pat = Pattern.compile(pattern);
        Matcher mat = pat.matcher(expressions);

        final List<String> ret = new ArrayList<String>();
        while(mat.find()) {
            logger.debug("->" + expressions.substring(mat.start(), mat.end()));
            ret.add(expressions.substring(mat.start(), mat.end()));
        }
        return ret;
    }

    /**
     * 指定したフォーマットのシステム日付を返します。
     *
     * @param format
     * @return
     */
    private String getSysdate(final String format) {
        final SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(new Date());
    }

    /**
     * 現在ログインしている、ログインユーザのユーザIDを返します。
     *
     * @return
     */
    private String getLoginUser() {
        return userInfo.getId();
//    	MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//    	return myUserDetails.getUserid();
    }

    /**
     * 更新パターン列挙体
     *
     * @author  EXE 島田 雄一郎
     * @version 0.0.0
     */
    public enum UpdatePattern {
        ALL(""),
        INSERT_AND_UPDATE("IU"),
        INSERT("I"),
        UPDATE("U");

        private static Map<String, UpdatePattern> map;
        static {
            map = new HashMap<String, UpdatePattern>();
            for (final UpdatePattern buff : values()) {
                map.put(buff.getKbn(), buff);
            }
        }

        /**
         * 更新パターン文字列より、更新パターン列挙体を戻します。
         *
         * @param type
         * @return
         */
        public static UpdatePattern patternOf(
                final String pattern) {
            if (pattern == null) {
            	// MI-F-0007=既定値の解析に失敗しました。更新パターン {0} は存在しません。
            	final String args[] = {pattern};
                throw new IllegalArgumentException(MessageUtils.getMessage("MI-F-0007", args));
            } else if (map.containsKey(pattern)) {
                return map.get(pattern);
            } else if (pattern.indexOf("I") != -1
                            && pattern.indexOf("U") != -1) {
                return UpdatePattern.INSERT_AND_UPDATE;
            } else {
            	// MI-F-0006=既定値の解析に失敗しました。更新区分 {0} は存在しません。
            	final String args[] = {pattern};
                throw new IllegalArgumentException(MessageUtils.getMessage("MI-F-0006", args));
            }
        }

        private String kbn;
        public String getKbn() {
            return kbn;
        }

        private UpdatePattern(final String kbn) {
            this.kbn = kbn;
        }
    }

    /**
     * 定数パターン列挙体
     *
     * @author  EXE 島田 雄一郎
     * @version 0.0.0
     */
    private enum ConstantPattern {
        SYSDATE,
        LOGIN_USER;
    }
}
