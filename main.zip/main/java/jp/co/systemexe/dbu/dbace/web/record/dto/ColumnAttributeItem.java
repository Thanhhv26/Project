/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.OperationDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.ColsDto.ColDto;

/**
 *
 * 対象レコード編集/確認画面要素表示用プロパティ
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class ColumnAttributeItem implements Serializable {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 7409159520614431475L;

    /**
     * カラムHTML属性
     */
    private DefinedHtmlElement columnAttribute;

    /**
     * カラムID
     */
    private String columnId;

    /**
     * カラム名
     */
    private String columnLabel;

    /**
     * カラムデータ
     */
    private String columnData;

    /**
     * カラム属性：ラジオボタン
     */
    private SelectableItem[] columnRadioItems;

    /**
     * カラム属性：ラジオボタンの選択されたプロパティ
     */
    private String columnRadio;

    /**
     * カラム属性：プルダウンリスト
     */
    private SelectableItem[] columnSelectItems;

    /**
     * カラム属性：プルダウンリストの選択されたプロパティ
     */
    private String columnSelect;

    /**
     * check data Select
     */
    private boolean checkDataSelect;

    /**
     * カラムの説明
     */
    private String columnExplanation;

    /**
     * 登録・更新時に表示する項目か否か。
     */
    private boolean displayrecordedit;

    /**
     * 更新可能な項目か否か。
     */
    private boolean editing;

    private boolean isUpdateKey;

    /**
     * カラムに対する、関連項目があるか否か。
     * <p>
     * プルダウンデータの場合に関連項目があるか否かを返します。
     */
    private boolean relatedSelectItems;

    /**
     * columnAttribute を戻します。
     *
     * @return DefinedHtmlElement
     */
    public DefinedHtmlElement getColumnAttribute() {
        return columnAttribute;
    }

    /**
     * columnAttribute を設定します。
     *
     * @param DefinedHtmlElement columnAttribute
     */
    public void setColumnAttribute(DefinedHtmlElement columnAttribute) {
        this.columnAttribute = columnAttribute;
    }

    /**
     * columnExplanation を戻します。
     *
     * @return String
     */
    public String getColumnExplanation() {
        return columnExplanation;
    }

    /**
     * columnExplanation を設定します。
     *
     * @param String columnExplanation
     */
    public void setColumnExplanation(String columnExplanation) {
        this.columnExplanation = columnExplanation;
    }

    /**
     * columnId を戻します。
     *
     * @return String
     */
    public String getColumnId() {
        return columnId;
    }

    /**
     * columnId を設定します。
     *
     * @param String columnId
     */
    public void setColumnId(String columnId) {
        this.columnId = columnId;
    }

    /**
     * columnLabel を戻します。
     *
     * @return String
     */
    public String getColumnLabel() {
        return columnLabel;
    }

    /**
     * columnLabel を設定します。
     *
     * @param String columnLabel
     */
    public void setColumnLabel(String columnLabel) {
        this.columnLabel = columnLabel;
    }

    /**
     * columnRadio を戻します。
     *
     * @return String
     */
    public String getColumnRadio() {
        return columnRadio;
    }

    /**
     * columnRadio を設定します。
     *
     * @param String columnRadio
     */
    public void setColumnRadio(String columnRadio) {
        this.columnRadio = columnRadio;
    }

    /**
     * columnRadioItems を戻します。
     *
     * @return SelectableItem[]
     */
    public SelectableItem[] getColumnRadioItems() {
        return columnRadioItems;
    }

    /**
     * columnRadioItems を設定します。
     *
     * @param SelectableItem[] columnRadioItems
     */
    public void setColumnRadioItems(SelectableItem[] columnRadioItems) {
        this.columnRadioItems = columnRadioItems;
    }

    /**
     * columnSelect を戻します。
     *
     * @return String
     */
    public String getColumnSelect() {
        return columnSelect;
    }

    /**
     * columnSelect を設定します。
     *
     * @param String columnSelect
     */
    public void setColumnSelect(String columnSelect) {
        this.columnSelect = columnSelect;
    }

    /**
     * columnSelectItems を戻します。
     *
     * @return SelectableItem[]
     */
    public SelectableItem[] getColumnSelectItems() {
        return columnSelectItems;
    }

    /**
     * columnSelectItems を設定します。
     *
     * @param SelectableItem[] columnSelectItems
     */
    public void setColumnSelectItems(SelectableItem[] columnSelectItems) {
        this.columnSelectItems = columnSelectItems;
    }

    /**
     * recordediting を戻します。
     *
     * @return boolean
     */
    public boolean isDisplayRecordEdit() {
        return displayrecordedit;
    }

    /**
     * recordediting を設定します。
     *
     * @param boolean editing
     */
    public void setDisplayRecordEdit(boolean displayrecordedit) {
        this.displayrecordedit = displayrecordedit;
    }

    /**
     * editing を戻します。
     *
     * @return boolean
     */
    public boolean isEditing() {
        return editing;
    }

    /**
     * editing を設定します。
     *
     * @param boolean editing
     */
    public void setEditing(boolean editing) {
        this.editing = editing;
    }

    /**
     * columnData を戻します。
     *
     * @return String
     */
    public String getColumnData() {
        return columnData;
    }

    /**
     * columnData を設定します。
     *
     * @param String columnData
     */
    public void setColumnData(String columnData) {
        this.columnData = columnData;
    }

    /**
     * relatedSelectItems を戻します。
     *
     * @return boolean
     */
    public boolean isRelatedSelectItems() {
        return relatedSelectItems;
    }

    /**
     * relatedSelectItems を設定します。
     *
     * @param boolean relatedSelectItems
     */
    public void setRelatedSelectItems(boolean relatedSelectItems) {
        this.relatedSelectItems = relatedSelectItems;
    }

    /**
	 * @return the operations
	 */
	public OperationDto getOperations() {
		return operations;
	}

	/**
	 * @param operations the operations to set
	 */
	public void setOperations(OperationDto operations) {
		this.operations = operations;
	}

	/**
	 * @return the isUpdateKey
	 */
	public boolean isUpdateKey() {
		return isUpdateKey;
	}

	/**
	 * @param isUpdateKey the isUpdateKey to set
	 */
	public void setUpdateKey(boolean isUpdateKey) {
		this.isUpdateKey = isUpdateKey;
	}

	/**
	 * @return true/false
	 */
	public boolean isCheckDataSelect() {
		return checkDataSelect;
	}

	/**
	 * @param checkDataSelect
	 */
	public void setCheckDataSelect(boolean checkDataSelect) {
		this.checkDataSelect = checkDataSelect;
	}

	public OperationDto operations = new OperationDto();

	public Map<String, ColDto> cols = new HashMap<String, ColDto>();

}
