/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import lombok.Setter;

/**
 * 項目表示定義 DTO。
 * <p>
 * 各項目の画面上での表示・制御定義情報を保持する DTO です。ビジネスロジックから
 * プレゼンテーション層に情報を通知するための VO です。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class ColumnDisplayDefinitionDTO implements Serializable {
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
     * VIEWか否か
     */
    private boolean isView;

    private boolean isOrderDesc;

    /**
     * カラム名マップ。
     * <p>SortedMap&lt;インデックス番号, カラム名&gt;</p>
     */
    @Setter
    private SortedMap<Integer, String> columnNames = new TreeMap<Integer, String>();

    /**
     * リポジトリ内のカラム ID - カラムの画面上定義保持マップ。
     * <p>Map&lt;カラム ID, TableItemDTO&gt;</p>
     */
    private Map<String, TableItemDTO> itemDefinitions = new HashMap<String, TableItemDTO>();

    /**
     * データベース内のカラム定義保持マップ。
     * <p>Map&lt;カラム ID,DefinitionOfColumn&gt;</p>
     */
    private LinkedHashMap<String, DefinitionOfColumn> definitionOfColumns = new LinkedHashMap<String, DefinitionOfColumn>();

    /**
     * カラム名マップを戻します。
     * <p>
     * このマップのインデックス番号がカラムの並び順になります。</p>
     *
     * @return SortedMap&lt;インデックス番号, カラム名&gt;
     */
    public SortedMap<Integer, String> getColumnNames() {
        return columnNames;
    }

    /**
     * データベース内のカラム定義保持マップを戻します。
     *
     * @return Map&lt;カラム ID,DefinitionOfColumn&gt;
     */
    public Map<String, DefinitionOfColumn> getDefinitionOfColumns() {
        return definitionOfColumns;
    }

    /**
     * リポジトリ内のカラム ID - カラムの画面上定義保持マップを戻します。
     * <p>
     * カラム ID と、カラムに対する画面上での制御定義情報オブジェクトのマップを
     * 戻します。カラム仮名や入力値検査仕様などを戻します。</p>
     *
     * @return Map&lt;カラム ID, TableItemDTO&gt;
     */
    public Map<String, TableItemDTO> getItemDefinitions() {
        return itemDefinitions;
    }

    /**
     * @param itemDefinitions
     */
    public void setItemDefinitions(Map<String, TableItemDTO> itemDefinitions) {
        this.itemDefinitions = itemDefinitions;
    }

    /**
     * ColumnDisplayDefinitionDTO の生成。
     * <p>コンストラクタ。</p>
     */
    public ColumnDisplayDefinitionDTO() {
        return;
    }

    /**
     * isView を戻します。
     *
     * @return boolean
     */
    public boolean isView() {
        return isView;
    }

    /**
     * isView を設定します。
     *
     * @param boolean isView
     */
    public void setView(boolean isView) {
        this.isView = isView;
    }

    /**
     * isOrderDesc を戻します。
     *
     * @return boolean
     */
    public boolean isOrderDesc() {
        return isOrderDesc;
    }

    /**
     * isOrderDesc を設定します。
     *
     * @param boolean isOrderDesc
     */
    public void setOrderDesc(boolean isOrderDesc) {
        this.isOrderDesc = isOrderDesc;
    }
}
