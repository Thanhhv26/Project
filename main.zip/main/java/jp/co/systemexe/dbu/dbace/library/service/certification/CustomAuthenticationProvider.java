package jp.co.systemexe.dbu.dbace.library.service.certification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import lombok.Setter;

/**
 * @author systemEXE VietNam
 */
public class CustomAuthenticationProvider implements AuthenticationProvider {

    protected Logger logger = LoggerFactory.getLogger(CustomAuthenticationProvider.class);

	@Setter
	private UserDetailsService userDetailsService;

	/*
	 * (non-Javadoc)
	 *
	 * @see org.springframework.security.authentication.AuthenticationProvider#
	 * authenticate(org.springframework.security.core.Authentication)
	 */
	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {

	    logger.info("BEGIN - Authenticate");

		UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) authentication;
		String username = String.valueOf(auth.getPrincipal());

		UserDetails userDetail = userDetailsService.loadUserByUsername(username);
		// ユーザーID存在チェック
		if (userDetail == null) {
			throw new BadCredentialsException("Bad authentication.");
		}
		// Return an authenticated token, containing user data and authorities
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
				userDetail, userDetail.getPassword(), userDetail.getAuthorities());

		logger.info("END - Authenticate");
		return token;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.springframework.security.authentication.AuthenticationProvider#supports
	 * (java.lang.Class)
	 */
	@Override
	public boolean supports(Class<?> aClass) {
		return aClass.equals(UsernamePasswordAuthenticationToken.class);
	}
}
