/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.dto;
import java.util.List;

import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import lombok.Data;
@Data
public class SelectItemDTO {
	String connectDefinitionId;
	String tableId;
	String tableLabel;
	String itemId;
	String defaultValue;
	String addedId;
	String addedLabel;
	List<TrRowDTO> selectableListItems;
	String sqlString;
	String sqlParameters;
	UserInfo userInfo;
}
