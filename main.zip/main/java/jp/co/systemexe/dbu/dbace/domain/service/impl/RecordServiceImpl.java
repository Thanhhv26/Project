/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableComparisonOperator;
import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableLogicalOperator;
import jp.co.systemexe.dbu.dbace.common.util.DateUtils;
import jp.co.systemexe.dbu.dbace.common.util.DefaultValueAnalysis;
import jp.co.systemexe.dbu.dbace.common.util.DefaultValueAnalysis.UpdatePattern;
import jp.co.systemexe.dbu.dbace.common.util.UUIDKeyGenerator;
import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportInformationDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportResultDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.IdSelectTableLabeExtendConnectDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.ResultMessageItem;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfEnvironmentSetting;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfFileImportResultLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfSearchConditionControlLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfTableLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.ImportFromFileToTableLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.OutputsToFileWithTableDataLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfSearchConditionControlLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.RecordAddUpdateProcessingOfDatabaseLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.RecordAdditionProcessingToDatabaseLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.RecordDeleteProcessingOfDatabaseLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.RecordUpdateProcessingOfDatabaseLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.RetrievalProcessingOfRecordFromDatabaseLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.TableNameListIsAcquiredFromRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.service.RecordService;
import jp.co.systemexe.dbu.dbace.library.service.AbstractService;
import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.TableIdDefinition;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DeleteRecordDto;
import jp.co.systemexe.dbu.dbace.persistance.dto.OutputSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordEditInputDto;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchResultDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TypeOfRetrieval;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.GeneralUserOperationAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;
import jp.co.systemexe.dbu.dbace.presentation.FileOutputTableData;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.presentation.UploadFileType;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;
import jp.co.systemexe.dbu.dbace.presentation.check.LogicalCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.ColsDto.ColDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemMultiDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.OptionalDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.OptionalMultiDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.record.dto.ColumnAttributeItem;
import jp.co.systemexe.dbu.dbace.web.record.dto.ColumnAttributeItemDTO;
import jp.co.systemexe.dbu.dbace.web.record.dto.ColumnPrimaryKeyItem;
import jp.co.systemexe.dbu.dbace.web.record.dto.DownloadFileInfo;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DataParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DataResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DeleteParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DeleteResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DownloadResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200LoadParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200LoadResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200ResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200SearchParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200SearchResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200TableFormDTO;
import jp.co.systemexe.dbu.dbace.web.record.dto.SearchConditionItem;
import jp.co.systemexe.dbu.dbace.web.record.dto.SearchResultHeaderItem;
import jp.co.systemexe.dbu.dbace.web.record.dto.SelectTargetedColumnSearchCondition;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;

/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 Mar 15, 2017
 */

@Service
public class RecordServiceImpl extends AbstractService implements RecordService {

	private static final long serialVersionUID = 1L;
	@Autowired
	MessageService messageService;

	/**
	 * Load a record in database, this function is applied for edit, view,
	 * delete screen.
	 *
	 * @author bao-anh
	 */
	@Override
	public FRM0200LoadResultModel doLoadRecord(FRM0200LoadParam loadParam) throws ApplicationDomainLogicException {
		FRM0200LoadResultModel model = new FRM0200LoadResultModel();
		model.setConnectDefinisionId(loadParam.getConnectDefinisionId());
		model.setTableId(loadParam.getTableId());
		model.setActionType(loadParam.getActionType());
		/*
		 * AcquisitionOfConnectDefinitionListLogic logic1 = new
		 * AcquisitionOfConnectDefinitionListLogic();
		 */
		try {
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());

			final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			final RecordEditorInformationDTO tableDefinitionDTO = recordFromDatabaseLogic.getRecordEditorInformation(
					model.getConnectDefinisionId(), tableFormDTO, loadParam.getUserInfo().getId());
			ColumnDisplayDefinitionDTO displayDef = recordFromDatabaseLogic.getColumnsDisplay(
					model.getConnectDefinisionId(), model.getTableId(), tableDefinitionDTO,
					loadParam.getUserInfo().getId());

			if (isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {
				model.setIsMultiTable(Boolean.TRUE);
				if (checkDifferenceOfColumnOnRepositoryAndDatabase(model.getConnectDefinisionId(), model.getTableId(),
						displayDef)) {
					// MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
					model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
					return model;
				}

			} else {
				model.setIsMultiTable(Boolean.FALSE);
				if (checkDifferenceOfColumnOnRepositoryAndDatabase(displayDef)) {
					// MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
					model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
					return model;
				}
			}

			Map<String, String> currentObject = loadParam.getCurrentObject();
			ColumnAttributeItem[] columnAttributeItems = createColumnAttributeItems(model, displayDef,
					tableDefinitionDTO, currentObject, loadParam.getUserInfo(), model.getActionType());
			model.setCurrentObject(currentObject);
			model.setColumnAttributeItems(columnAttributeItems);
			model.setColumnsDisplayDefinition(displayDef);

		} catch (ApplicationDomainLogicException e) {
			model.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			return model;
		}

		setPermissionToView(model, loadParam.getUserInfo());
		return model;
	}

	/**
	 * Get list tables in repository.xml
	 */
	@Override
	public List<IdSelectTableLabeExtendConnectDTO> getAllTableList(UserInfoDTO userInfoDTO)
			throws ApplicationDomainLogicException {
		final TableNameListIsAcquiredFromRepositoryLogic repository = new TableNameListIsAcquiredFromRepositoryLogic();
		// リポジトリXML上に登録されているテーブル一覧を取得
		try {
			List<IdSelectTableLabeExtendConnectDTO> repList = repository.getAllTableNameList(userInfoDTO);
			// sort by TableName
			Collections.sort(repList, new Comparator<IdSelectTableLabeExtendConnectDTO>() {
				@Override
				public int compare(final IdSelectTableLabeExtendConnectDTO o1,
						final IdSelectTableLabeExtendConnectDTO o2) {
					return o1.getTableConnectLabel().compareTo(o2.getTableConnectLabel());
				}
			});
			return repList;
		} catch (final ApplicationDomainLogicException e) {
			throw new ApplicationDomainLogicException(e);
		}
	}

	/**
	 *
	 * @param dbConnectInfomationDTO
	 * @param searchConditionDTO
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public int countRecord(DbConnectInfomationDTO dbConnectInfomationDTO, RecordSearchConditionDTO searchConditionDTO)
			throws ApplicationDomainLogicException {
		RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		return logic.getCountRecords(searchConditionDTO, dbConnectInfomationDTO);
	}

	/**
	 * validateDownload
	 */
	public FRM0200DownloadResultModel validateDownload(DownloadFileInfo param) throws ApplicationDomainLogicException {
		FRM0200DownloadResultModel model = new FRM0200DownloadResultModel();
		model.setConnectDefinisionId(param.getConnectDefinisionId());
		model.setTableId(param.getTableId());

		UserInfo userInfo = param.getUserInfo();
		SearchConditionItem[] searchConditionItems = null;
		try {
			String jsonString = param.getJsonSearchConditionItems();
			ObjectMapper mapper = new ObjectMapper();
			mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
			searchConditionItems = mapper.readValue(jsonString,
					TypeFactory.defaultInstance().constructArrayType(SearchConditionItem.class));
			param.setSearchConditionItems(searchConditionItems);

		} catch (JsonParseException e) {
			model.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			return model;
		} catch (JsonMappingException e) {
			model.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			return model;
		} catch (IOException e) {
			model.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			return model;
		}
		// ダウンロード前に検索を行ってください
		if (!param.getCheckSearchBeforeDownload()) {
			model.getMessageInfo().add(new MessageInfo("MI-E-0072", MessageType.INFO, messageService));
			return model;
		}
		FileOutputTableData output = FileOutputTableData.valueOf(param.getFileType());
		RetrievalProcessingOfRecordFromDatabaseLogic recordLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		// Load table multi
		TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
		TableFormDTO tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());

		if (isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {
			Map<String, TableItemDTO> tableItemChilds = getRelateTableItemDTO(model.getConnectDefinisionId(),
					tableFormDTO);
			tableFormDTO.getTableItemMap().putAll(tableItemChilds);
		}
		
		RecordEditorInformationDTO dto = null;
		try{
			dto = recordLogic.getRecordEditorInformation(model.getConnectDefinisionId(), tableFormDTO, userInfo.getId());
		} catch (ApplicationDomainLogicException e){
			model.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			return model;
		}		

		RecordSearchConditionDTO beforeRecordSearchConditionItems = new RecordSearchConditionDTO();
		beforeRecordSearchConditionItems.setConnectDefinitionId(model.getConnectDefinisionId());
		beforeRecordSearchConditionItems.setTableId(model.getTableId());
		beforeRecordSearchConditionItems.setTopIndex(0);
		// beforeRecordSearchConditionItems.setRecordCount(SystemProperties.getSearchMaxRecordCount());
		beforeRecordSearchConditionItems.setTypeOfRetrieval(TypeOfRetrieval.STRICTNESS);
		beforeRecordSearchConditionItems.setOrderAsc(tableFormDTO.getOrderDesc());

		ColumnDisplayDefinitionDTO displayDef = recordLogic.getColumnsDisplay(model.getConnectDefinisionId(),
				model.getTableId(), dto, userInfo.getId());

		if (!checkRecordSearchCondition(param.getSearchConditionItems(), displayDef, model.getMessageInfo())) {
			model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
			return model;
		} else if (checkDifferenceOfColumnOnRepositoryAndDatabase(model.getConnectDefinisionId(), model.getTableId(),
				displayDef)) {
			model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
			return model;
		}
		// 機能 #14429 - Comment by bao-anh
		/*
		 * else if (!isOutputColumnCountValidater(output,
		 * dto.getTableForm().getTableItemMap(), param.getIsExportAll())) {
		 * model.getMessageInfo().add(new MessageInfo("MI-E-0148",
		 * MessageType.ERROR, messageService)); return model; }
		 */
		else {
			int index = 0;
			for (final SearchConditionItem item : param.getSearchConditionItems()) {
				if (StringUtils.isNotEmpty(item.getTargetedColumnId())
						|| StringUtils.isNotEmpty(item.getComparisonOperator())
						|| StringUtils.isNotEmpty(item.getTargetedColumnSearchCondition())
						|| !item.isEmptyLogicalOperator()) {
					SelectConditionItem condition = new SelectConditionItem();
					condition.setColumnId(item.getTargetedColumnId());
					condition.setComparisonOperator(
							SqlWhereTableComparisonOperator.valueOf(item.getComparisonOperator()));
					condition.setValue(item.getTargetedColumnSearchCondition());

					if (item.getLogicalOperator() == null) {
						condition.setLogicalOperator(SqlWhereTableLogicalOperator.blank);
					} else {
						condition.setLogicalOperator(SqlWhereTableLogicalOperator.valueOf(item.getLogicalOperator()));
					}

					final DefinitionOfColumn defColumn = dto.getTableDef().getDefinitionOfColumnMap()
							.get(item.getTargetedColumnId());
					condition.setJDBCMetaDataType(defColumn.getJDBCMetaDataType());
					condition.setColumnTypeName(defColumn.getColumnTypeName());

					beforeRecordSearchConditionItems.getConditions().put(index, condition);
					index++;
				}
			}

			File readFile = null;
			// FileInputStream inputStream = null;
			// OutputStream outputStream = null;
			try {

				UUIDKeyGenerator generator = new UUIDKeyGenerator();
				File tempDir = new File(SystemProperties.getImportTempFilePath() + File.separator);
				String filePath = SystemProperties.getImportTempFilePath() + File.separator + generator.nextKeyValue()
						+ "." + output.getExtension();
				boolean dirCreated = false;
				if (!(tempDir.exists())) {
					try {
						tempDir.mkdir();
						dirCreated = true;
					} catch (SecurityException se) {
						getLogger().error(se.getMessage());
					}

				} else {
					dirCreated = true;
				}

				if (dirCreated) {
					readFile = new File(filePath);
					readFile.createNewFile();
				}

				SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
				String fileName = format.format(new Date()) + "." + output.getExtension();
				model.setFilePath(filePath);
				model.setFileName(fileName);

				OutputsToFileWithTableDataLogic outputFile = new OutputsToFileWithTableDataLogic(output);
				outputFile.outputFile(model.getConnectDefinisionId(), model.getTableId(),
						beforeRecordSearchConditionItems, dto, param.getIsExportAll(), filePath, userInfo);

			} catch (ApplicationDomainLogicException e) {
				model.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			} catch (Exception e) {
				final String message = "ファイルの出力に失敗しました。(" + e.getMessage() + ")";
				getLogger().fatal(message, e);
				model.getMessageInfo().add(new MessageInfo(message, MessageType.ERROR));
			} catch (OutOfMemoryError e) {
				getLogger().error(MessageUtils.getMessage("MI-E-0147"), e);
				model.getMessageInfo().add(new MessageInfo("MI-E-0147", MessageType.ERROR, messageService));
			} // finally {
				// if (inputStream != null) {
				// try {
				// inputStream.close();
				// } catch (IOException e) {
				// getLogger().error(e.getMessage());
				// }
				// }
				//
				// if (outputStream != null) {
				// try {
				// outputStream.close();
				// } catch (IOException e) {
				// getLogger().error(e.getMessage());
				// }
				// }
				// }
		}
		return model;
	}

	/**
	 * 「ファイルに出力する」ボタンのイベントハンドラ
	 * <p>
	 * 現在表示されている条件で、Excel出力を行います。
	 * </p>
	 */
	@Override
	public FRM0200DownloadResultModel doDownload(DownloadFileInfo param) {
		FRM0200DownloadResultModel model = new FRM0200DownloadResultModel();
		// model.setConnectDefinisionId(param.getConnectDefinisionId());
		// model.setTableId(param.getTableId());
		//
		// File readFile = null;
		// FileInputStream inputStream = null;
		// OutputStream outputStream = null;
		//
		// // ダウンロード前に検索を行ってください
		// if (!param.getCheckSearchBeforeDownload()) {
		// model.getMessageInfo().add(new MessageInfo("MI-E-0072",
		// MessageType.INFO, messageService));
		// return model;
		// }
		//
		// try {
		// UserInfo userInfo = param.getUserInfo();
		//
		// RetrievalProcessingOfRecordFromDatabaseLogic recordLogic = new
		// RetrievalProcessingOfRecordFromDatabaseLogic();
		// // Load table multi
		// TableNameListIsAcquiredFromRepositoryLogic logic = new
		// TableNameListIsAcquiredFromRepositoryLogic();
		// TableFormDTO tableFormDTO =
		// logic.getTableFormDTO(model.getConnectDefinisionId(),
		// model.getTableId());
		//
		// if (isMultiTable(model.getConnectDefinisionId(), model.getTableId()))
		// {
		// Map<String, TableItemDTO> tableItemChilds =
		// getRelateTableItemDTO(model.getConnectDefinisionId(),
		// tableFormDTO);
		// tableFormDTO.getTableItemMap().putAll(tableItemChilds);
		// }
		//
		// RecordEditorInformationDTO dto =
		// recordLogic.getRecordEditorInformation(model.getConnectDefinisionId(),
		// tableFormDTO, userInfo.getId());
		//
		// RecordSearchConditionDTO beforeRecordSearchConditionItems = new
		// RecordSearchConditionDTO();
		// beforeRecordSearchConditionItems.setConnectDefinitionId(model.getConnectDefinisionId());
		// beforeRecordSearchConditionItems.setTableId(model.getTableId());
		// beforeRecordSearchConditionItems.setTopIndex(0);
		// beforeRecordSearchConditionItems
		// .setRecordCount(Integer.parseInt(String.valueOf(SystemProperties.getDisplayedNumberOfRecords())));
		// beforeRecordSearchConditionItems.setRecordCount(SystemProperties.getSearchMaxRecordCount());
		// beforeRecordSearchConditionItems.setTypeOfRetrieval(TypeOfRetrieval.STRICTNESS);
		// beforeRecordSearchConditionItems.setOrderAsc(tableFormDTO.getOrderDesc());
		//
		// ColumnDisplayDefinitionDTO displayDef =
		// recordLogic.getColumnsDisplay(model.getConnectDefinisionId(),
		// model.getTableId(), dto, userInfo.getId());
		//
		// if (!checkRecordSearchCondition(param.getSearchConditionItems(),
		// displayDef, model.getMessageInfo())) {
		// model.getMessageInfo().add(new MessageInfo("MI-E-0121",
		// MessageType.ERROR, messageService));
		// } else if
		// (checkDifferenceOfColumnOnRepositoryAndDatabase(model.getConnectDefinisionId(),
		// model.getTableId(), displayDef)) {
		// // MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
		// model.getMessageInfo().add(new MessageInfo("MI-E-0121",
		// MessageType.ERROR, messageService));
		// } else {
		// int index = 0;
		// for (final SearchConditionItem item :
		// param.getSearchConditionItems()) {
		// if (StringUtils.isNotEmpty(item.getTargetedColumnId())
		// || StringUtils.isNotEmpty(item.getComparisonOperator())
		// || StringUtils.isNotEmpty(item.getTargetedColumnSearchCondition())
		// || !item.isEmptyLogicalOperator()) {
		// SelectConditionItem condition = new SelectConditionItem();
		// condition.setColumnId(item.getTargetedColumnId());
		// condition.setComparisonOperator(
		// SqlWhereTableComparisonOperator.valueOf(item.getComparisonOperator()));
		// condition.setValue(item.getTargetedColumnSearchCondition());
		//
		// if (item.getLogicalOperator() == null) {
		// condition.setLogicalOperator(SqlWhereTableLogicalOperator.blank);
		// } else {
		// condition.setLogicalOperator(
		// SqlWhereTableLogicalOperator.valueOf(item.getLogicalOperator()));
		// }
		//
		// final DefinitionOfColumn defColumn =
		// dto.getTableDef().getDefinitionOfColumnMap()
		// .get(item.getTargetedColumnId());
		// condition.setJDBCMetaDataType(defColumn.getJDBCMetaDataType());
		// condition.setColumnTypeName(defColumn.getColumnTypeName());
		//
		// beforeRecordSearchConditionItems.getConditions().put(index,
		// condition);
		// index++;
		// }
		// }
		//
		// FileOutputTableData output =
		// FileOutputTableData.valueOf(param.getFileType());
		// if (!isOutputColumnCountValidater(output,
		// dto.getTableForm().getTableItemMap(),
		// param.getIsExportAll())) {
		// String message = MessageUtils.getMessage("MI-E-0148");
		// getLogger().error(message);
		// model.getMessageInfo().add(new MessageInfo("MI-E-0148",
		// MessageType.ERROR, messageService));
		// }
		//
		// OutputsToFileWithTableDataLogic outputFile = new
		// OutputsToFileWithTableDataLogic(output);
		//
		// UUIDKeyGenerator generator = new UUIDKeyGenerator();
		// File tempDir = new File(SystemProperties.getImportTempFilePath() +
		// File.separator);
		// String filePath = SystemProperties.getImportTempFilePath() +
		// File.separator + generator.nextKeyValue()
		// + "." + output.getExtension();
		// boolean dirCreated = false;
		// if (!(tempDir.exists())) {
		// try {
		// tempDir.mkdir();
		// dirCreated = true;
		// } catch (SecurityException se) {
		// getLogger().error(se.getMessage());
		// }
		//
		// } else {
		// dirCreated = true;
		// }
		//
		// if (dirCreated) {
		// readFile = new File(filePath);
		// readFile.createNewFile();
		// }
		//
		//
		// SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		// String fileName = format.format(new Date()) + "." +
		// output.getExtension();
		// model.setFilePath(filePath);
		// model.setFileName(fileName);
		//
		// outputFile.outputFile(model.getConnectDefinisionId(),
		// model.getTableId(),
		// beforeRecordSearchConditionItems, dto, param.getIsExportAll(),
		// filePath, userInfo);
		//
		// }
		//
		// } catch (ApplicationDomainLogicException e) {
		// model.getMessageInfo().add(new MessageInfo(e.getMessage(),
		// MessageType.ERROR));
		// } catch (Exception e) {
		// final String message = "ファイルの出力に失敗しました。(" + e.getMessage() + ")";
		// getLogger().fatal(message, e);
		// model.getMessageInfo().add(new MessageInfo(message,
		// MessageType.ERROR));
		// } catch (OutOfMemoryError e) {
		// getLogger().error(MessageUtils.getMessage("MI-E-0147"), e);
		// model.getMessageInfo().add(new MessageInfo("MI-E-0147",
		// MessageType.ERROR, messageService));
		// } finally {
		// if (inputStream != null) {
		// try {
		// inputStream.close();
		// } catch (IOException e) {
		// getLogger().error(e.getMessage());
		// }
		// }
		//
		// if (outputStream != null) {
		// try {
		// outputStream.close();
		// } catch (IOException e) {
		// getLogger().error(e.getMessage());
		// }
		// }
		// }

		return model;
	}

	/**
	 *
	 * @param tableId
	 * @param itemId
	 * @return
	 */
	private String formatColumnMultiTable(String tableId, String itemId) {
		TableIdDefinition tableIdDefinition = new TableIdDefinition(tableId);
		return String.format("\"%s\".\"%s\".\"%s\"", tableIdDefinition.getSchem(), tableIdDefinition.getTable(),
				itemId);
	}

	/**
	 *
	 */
	@Override
	public FRM0200DeleteResultModel doOnceDelete(FRM0200DeleteParam deleteParam)
			throws ApplicationDomainLogicException {
		final AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
		FRM0200DeleteResultModel model = new FRM0200DeleteResultModel();
		model.setConnectDefinisionId(deleteParam.getConnectDefinisionId());
		model.setTableId(deleteParam.getTableId());

		TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
		TableFormDTO tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());

		RetrievalProcessingOfRecordFromDatabaseLogic recordLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		UserInfo userInfo = deleteParam.getUserInfo();
		RecordDeleteProcessingOfDatabaseLogic deleteLogic = new RecordDeleteProcessingOfDatabaseLogic(userInfo);
		RecordEditorInformationDTO recordEditorInformationDTO = null;
		TableDefinitionDTO tableDefinitionDTO = null;
		try{
			recordEditorInformationDTO = recordLogic.getRecordEditorInformation(model.getConnectDefinisionId(), tableFormDTO, userInfo.getId());
			tableDefinitionDTO = recordEditorInformationDTO.getTableDef();
		}catch(Exception e){
			model.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			return model;
		}
		// Map<String, RecordSearchConditionDTO> recordDeleteConditionDTO = new
		// HashMap<String, RecordSearchConditionDTO>();

		if (isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {
			model.setIsMultiTable(Boolean.TRUE);
			try {
				Map<String, Map<String, String>> dataByTables = new TreeMap<String, Map<String, String>>();
				for (Iterator<String> iterator = deleteParam.getCurrentObject().keySet().iterator(); iterator
						.hasNext();) {
					String colKey = (String) iterator.next();
					if (tableFormDTO.getTableItemMap().containsKey(colKey)) {
						TableItemDTO tableItemDTO = tableFormDTO.getTableItemMap().get(colKey);
						Map<String, ColDto> colsMap = tableItemDTO.getCols();
						if (colsMap != null && colsMap.size() > 0) {
							for (Iterator<ColDto> iterator2 = colsMap.values().iterator(); iterator2.hasNext();) {
								ColDto colDto = (ColDto) iterator2.next();
								Map<String, String> dataMap = null;
								if (dataByTables.containsKey(colDto.getTableID())) {
									dataMap = dataByTables.get(colDto.getTableID());
								} else {
									dataMap = new TreeMap<String, String>();
									dataByTables.put(colDto.getTableID(), dataMap);
								}

								if (!dataMap.containsKey(colDto.getItemID())) {
									String value = deleteParam.getCurrentObject().get(colKey);
									if (recordEditorInformationDTO.getDbConnectInfomationDTO()
											.getDatabaseTypeConnectionDestination().getKey()
											.equals(DatabaseTypeConnectionDestination.Oracle.getKey())) {
										if (tableItemDTO.getHtmlElement().getKey()
												.equals(DefinedHtmlElement.INPUT_DATE.getKey())) {
											if (!StringUtils.isEmpty(value)) {
												value = value.concat(DateUtils.TIMESTAMP_ZERO_FORMAT);
											}
										} else if (tableItemDTO.getHtmlElement().getKey()
												.equals(DefinedHtmlElement.INPUT_DATETIME.getKey())) {
											if (!StringUtils.isEmpty(value)) {
												value = value.concat(DateUtils.ZERO_FORMAT);
											}
										} else if (tableItemDTO.getHtmlElement().getKey()
												.equals(DefinedHtmlElement.INPUT_TIME.getKey())) {
											DateFormat dateFormat = new SimpleDateFormat(DateUtils.DATE_FORMAT);
											Date date = new Date();

											if (!StringUtils.isEmpty(value)) {
												value = dateFormat.format(date).toString()
														.concat(" " + value + DateUtils.ZERO_FORMAT);
											}
										}
									}
									dataMap.put(colDto.getItemID(), value);
								}
							}
						}
					}
				}

				// 該当テーブルにおいてXMLで「tableForm->tables->table」のCommitNOの最大値を取得
				Map<String, TableDto> tables = tableFormDTO.getTableMap();
				// ①該当テーブルにおいてXMLで「tableForm->tables->table」のCommitNOが最大値から降順に次の処理を行う
				// ※2つのテーブルを用いたマルチテーブルの場合、2回処理を行う
				tables = sortByCommitNo(tables, true);

				for (Iterator<String> iterator = tables.keySet().iterator(); iterator.hasNext();) {
					String tableKey = (String) iterator.next();
					int index = 0;
					Map<String, String> dataMap = dataByTables.get(tableKey);
					TableDto tableDto = tables.get(tableKey);
					SortedMap<Integer, SelectConditionItem> listConditions = new TreeMap<Integer, SelectConditionItem>();
					final TableFormDTO tableFormDto = acquisitionOfTableLogic
							.getTableFormDTO(model.getConnectDefinisionId(), tableDto.getId());
					for (Iterator<ItemMultiDto> iterator2 = tableDto.getItemMultiDto().iterator(); iterator2
							.hasNext();) {
						ItemMultiDto itemMultiDto = (ItemMultiDto) iterator2.next();
						// 該当テーブルにおいてXMLで「tableForm->tables->table->item」のisUpdateKeyがtrueの項目を洗い出す
						if (itemMultiDto
								.isUpdateKey() /*
												 * && dataMap.get(itemMultiDto.
												 * getId()) != null
												 */) {
							SelectConditionItem condition = new SelectConditionItem();
							condition.setColumnId(itemMultiDto.getId());
							if (dataMap.get(itemMultiDto.getId()) != null) {
								condition.setComparisonOperator(SqlWhereTableComparisonOperator.equal);
							} else {
								condition.setComparisonOperator(SqlWhereTableComparisonOperator.isNull);
							}

							String columnName = formatColumnMultiTable(tableKey, itemMultiDto.getId());
							DefinitionOfColumn defColumn = tableDefinitionDTO.getDefinitionOfColumnMap()
									.get(columnName);

							condition.setJDBCMetaDataType(defColumn.getJDBCMetaDataType());
							condition.setColumnTypeName(defColumn.getColumnTypeName());

							condition.setValue(dataMap.get(itemMultiDto.getId()));
							listConditions.put(index, condition);
							if (listConditions.size() > 1) {
								listConditions.get(index - 1).setLogicalOperator(SqlWhereTableLogicalOperator.and);
							}
							index++;
						}
					}

					if (listConditions.size() > 0) {
						// ②各テーブルへのメンテナンスが、「DELETE、なにもしない」のいずれかか、処理順(CommitNO)の降順で判断する
						// ①の件数が1件の場合 ※下記の「●」はボタンにより「1～3」のいずれかになります
						Boolean executeFlg = false;
						for (OptionalMultiDto optionalMultiDto : tableDto.getOptionalMultiDto()) {
							// XMLで「tableForm->tables->table->optional->delete」のExclusion●が「false」の場合
							if (deleteParam.isExclusion1() && !optionalMultiDto.getDelete().isExclusion1()) {
								executeFlg = true;
							} else if (deleteParam.isExclusion2() && !optionalMultiDto.getDelete().isExclusion2()) {
								executeFlg = true;
							} else if (deleteParam.isExclusion3() && !optionalMultiDto.getDelete().isExclusion3()) {
								executeFlg = true;
							} else {
								// XMLで「tableForm->tables->table->optional->delete」のExclusion●が「true」の場合
								// no thing
								executeFlg = false;
							}
						}

						if (executeFlg) {
							RecordSearchConditionDTO deleteCondition = new RecordSearchConditionDTO();
							deleteCondition.setConnectDefinitionId(model.getConnectDefinisionId());
							deleteCondition.setTableId(tableDto.getId());
							deleteCondition.setTableLabel(tableFormDto.getTableFormLabel());
							deleteCondition.getConditions().putAll(listConditions);
							deleteCondition.setTypeOfRetrieval(TypeOfRetrieval.STRICTNESS);

							// RDBの該当テーブルに対して、上記の項目に対して画面の値をセットし、件数を取得する
							int countSQL = recordLogic.getCountRecords(deleteCondition,
									recordEditorInformationDTO.getDbConnectInfomationDTO(), tableDto);

							if (countSQL == 0) {
								// ①の件数が0件の場合
								// 何もしない
							} else if (countSQL == 1) {
								// ①の件数が1件の場合 ※下記の「●」はボタンにより「1～3」のいずれかになります
								// recordDeleteConditionDTO.put(tableDto.getId(),
								// deleteCondition);
								deleteLogic.addProcess(deleteCondition);
							} else {
								// 結果が「0,1」以外のテーブルがある場合、「XXXテーブルのキー設定が不正です。」のエラーメッセージを出力し、処理を終了する
								String[] args = { tableFormDto.getTableFormLabel() };
								model.getMessageInfo().add(new MessageInfo("FRM0200.delete.E1-001", MessageType.ERROR,
										args, messageService));
								return model;
							}
						}
					} else {
						// 該当テーブルにおいてXMLで「tableForm->item」のisUpdatekeyがtrueの場合、その項目をWHERE条件としてセットしRDBへSELECTを行う
						// 結果が「1」以外の場合、「既にデータが削除されているか、XXXテーブルのキー設定が不正です」のエラーメッセージを出力し、処理を終了する
						String[] args = { tableFormDto.getTableFormLabel() };
						model.getMessageInfo()
								.add(new MessageInfo("FRM0200.delete.E1-004", MessageType.ERROR, args, messageService));
						return model;
					}
				}
				if (deleteLogic.hasProcesses()) {
					// ③RDBへのデータメンテナンスを処理順(CommitNO)の降順で行う。トランザクションの開始
					// ②で決まったDELETE、なにもしない のいずれかの処理を行う
					DeleteRecordDto inputDto = new DeleteRecordDto();
					inputDto.setDbConnectInfomationDTO(recordEditorInformationDTO.getDbConnectInfomationDTO());
					deleteLogic.execute(inputDto);
				}

				// //
				// ②各テーブルへのメンテナンスが、「DELETE、なにもしない」のいずれかか、処理順(CommitNO)の降順で判断する
				// // ①の件数が1件の場合 ※下記の「●」はボタンにより「1～3」のいずれかになります
				// RecordDeleteProcessingOfDatabaseLogic deleteLogic = new
				// RecordDeleteProcessingOfDatabaseLogic(userInfo);
				// Boolean executeFlg = false;
				// for (Iterator<String> iterator =
				// recordDeleteConditionDTO.keySet().iterator();
				// iterator.hasNext();) {
				// String tableName = (String) iterator.next();
				//
				// if (tables.containsKey(tableName)) {
				// TableDto tableDto = tables.get(tableName);
				// for (OptionalMultiDto optionalMultiDto :
				// tableDto.getOptionalMultiDto()) {
				// //
				// XMLで「tableForm->tables->table->optional->delete」のExclusion●が「false」の場合
				// if (deleteParam.isExclusion1() &&
				// !optionalMultiDto.getDelete().isExclusion1()) {
				// deleteLogic.addProcess(recordDeleteConditionDTO.get(tableDto.getId()));
				// executeFlg = true;
				// } else if (deleteParam.isExclusion2() &&
				// !optionalMultiDto.getDelete().isExclusion2()) {
				// deleteLogic.addProcess(recordDeleteConditionDTO.get(tableDto.getId()));
				// executeFlg = true;
				// } else if (deleteParam.isExclusion3() &&
				// !optionalMultiDto.getDelete().isExclusion3()) {
				// deleteLogic.addProcess(recordDeleteConditionDTO.get(tableDto.getId()));
				// executeFlg = true;
				// } else {
				// //
				// XMLで「tableForm->tables->table->optional->delete」のExclusion●が「true」の場合
				// // no thing
				// }
				// }
				// }
				// }
				// if (executeFlg) {
				// // ③RDBへのデータメンテナンスを処理順(CommitNO)の降順で行う。トランザクションの開始
				// // ②で決まったDELETE、なにもしない のいずれかの処理を行う
				// DeleteRecordDto inputDto = new DeleteRecordDto();
				// inputDto.setDbConnectInfomationDTO(recordEditorInformationDTO.getDbConnectInfomationDTO());
				// deleteLogic.execute(inputDto);
				// }
			} catch (ApplicationDomainLogicException e) {
				// 処理の途中でエラーとなった場合は、ロールバックを行い、「XXX(テーブル表示名)の(DELETE)処理でエラーになりました。」とエラーメッセージを出力。
				// DELETEのそれぞれの結果が「1」以外がある場合、ロールバックを行い、「XXXテーブルのキー設定が不正です。」とエラーメッセージを出力。
				// String[] args = { tableFormDTO.getTableFormLabel() };
				// model.getMessageInfo()
				// .add(new MessageInfo("FRM0200.delete.E1-002",
				// MessageType.ERROR, args, messageService));
				model.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
				return model;
			}

		} else {
			model.setIsMultiTable(Boolean.FALSE);
			int index = 0;
			try {
				// 該当テーブルにおいてXMLで「tableForm->item」のisUpdatekeyがtrueの項目が1つもない場合、
				// 「XXXテーブルのキー設定が不正です。」のエラーメッセージを出力し、処理を終了する
				RecordSearchConditionDTO deleteCondition = new RecordSearchConditionDTO();
				deleteCondition.setConnectDefinitionId(model.getConnectDefinisionId());
				deleteCondition.setTableId(tableFormDTO.getTableFormId());
				deleteCondition.setTypeOfRetrieval(TypeOfRetrieval.STRICTNESS);
				// recordDeleteConditionDTO.put(tableFormDTO.getTableFormId(),
				// deleteCondition);

				for (Iterator<TableItemDTO> iterator = tableFormDTO.getTableItemMap().values().iterator(); iterator
						.hasNext();) {
					TableItemDTO tableItemDTO = (TableItemDTO) iterator.next();
					if (tableItemDTO.isUpdateKey()) {
						// tableItems.add(tableItemDTO);
						SelectConditionItem condition = new SelectConditionItem();
						condition.setComparisonOperator(SqlWhereTableComparisonOperator.equal);
						condition.setColumnId(tableItemDTO.getItemId());
						condition.setValue(deleteParam.getCurrentObject().get(tableItemDTO.getItemId()));

						DefinitionOfColumn defColumn = tableDefinitionDTO.getDefinitionOfColumnMap()
								.get(tableItemDTO.getItemId());
						condition.setJDBCMetaDataType(defColumn.getJDBCMetaDataType());
						condition.setColumnTypeName(defColumn.getColumnTypeName());

						deleteCondition.getConditions().put(index, condition);
						if (deleteCondition.getConditions().size() > 1) {
							deleteCondition.getConditions().get(index - 1)
									.setLogicalOperator(SqlWhereTableLogicalOperator.and);
						}
						index++;
					}
				}

				// 該当テーブルにおいてXMLで「tableForm->item」のisUpdatekeyがtrueの項目が1つもない場合、
				// 「XXXテーブルのキー設定が不正です」のエラーメッセージを出力し、処理を終了する
				if (deleteCondition.getConditions().size() > 0) {
					// RDBの該当テーブルに対して、上記の項目に対して画面の値をセットし、件数を取得する
					int countSQL = recordLogic.getCountRecords(deleteCondition,
							recordEditorInformationDTO.getDbConnectInfomationDTO());
					if (countSQL == 0) {
						// "・【データ操作（削除）】画面で削除対象データを削除（「はい」ボタン押下）したが、他のユーザが先に削除した場合、下記の「エラーメッセジ」を表示することを確認
						// 「エラーメッセージ」
						// データの削除に失敗しました
						// ※DBに削除対象データが存在しないことを確認"
						model.getMessageInfo()
								.add(new MessageInfo("FRM0200.delete.E1-005", MessageType.ERROR, messageService));
						return model;
					} else if (countSQL == 1) {
						// recordDeleteConditionDTO.put(tableFormDTO.getTableFormId(),
						// deleteCondition);
						deleteLogic.addProcess(deleteCondition);
					} else {
						// ■通常テーブル
						// 該当テーブルにおいてXMLで「tableForm->item」のisUpdatekeyがtrueの場合、その項目をWHERE条件としてセットしRDBへSELECTを行う
						// 結果が「1」以外の場合、「既にデータが削除されているか、XXXテーブルのキー設定が不正です」のエラーメッセージを出力し、処理を終了する
						// 上記の処理について、プログラミングの修正をお願いします。
						// ※確認の為、エビデンスを付けてください。
						String[] args = { tableFormDTO.getTableFormLabel() };
						model.getMessageInfo()
								.add(new MessageInfo("FRM0200.delete.E1-004", MessageType.ERROR, args, messageService));
						return model;
					}
				} else {
					String[] args = { tableFormDTO.getTableFormLabel() };
					model.getMessageInfo()
							.add(new MessageInfo("FRM0200.delete.E1-001", MessageType.ERROR, args, messageService));
					return model;
				}

				// for (Iterator<String> iterator =
				// recordDeleteConditionDTO.keySet().iterator();
				// iterator.hasNext();) {
				// String tableName = (String) iterator.next();
				// deleteLogic.addProcess(recordDeleteConditionDTO.get(tableName));
				// }

				if (deleteLogic.hasProcesses()) {
					// ③RDBへのデータメンテナンスを処理順(CommitNO)の降順で行う。トランザクションの開始
					DeleteRecordDto inputDto = new DeleteRecordDto();
					inputDto.setDbConnectInfomationDTO(recordEditorInformationDTO.getDbConnectInfomationDTO());
					deleteLogic.execute(inputDto);
				}

			} catch (ApplicationDomainLogicException e) {
				String[] args = { tableFormDTO.getTableFormLabel() };
				model.getMessageInfo()
						.add(new MessageInfo("FRM0200.delete.E1-002", MessageType.ERROR, args, messageService));
				return model;
			}

		}

		// 成功した場合は、「削除を行いました」成功メッセージを出力し、画面を閉じます。
		model.getMessageInfo().add(new MessageInfo("FRM0200.delete.E1-003", MessageType.SUCCESS, messageService));
		return model;
	}

	/**
	 *
	 */
	@Override
	public List<SelectableItem> doSearchSelectObjectList(SelectTargetedColumnSearchCondition searchParam) {
		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		RecordEditorInformationDTO recordInfo;

		try {
			UserInfo userInfo = searchParam.getUserInfo();
			// Load table multi
			final TableNameListIsAcquiredFromRepositoryLogic logic1 = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO = logic1.getTableFormDTO(searchParam.getCurrentConnectDefinisionId(),
					searchParam.getCurrentTableId());

			if (isMultiTable(searchParam.getCurrentConnectDefinisionId(), searchParam.getCurrentTableId())) {

				Map<String, TableItemDTO> tableItemChilds = getRelateTableItemDTO(
						searchParam.getCurrentConnectDefinisionId(), tableFormDTO);
				tableFormDTO.getTableItemMap().putAll(tableItemChilds);

				final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();

				recordInfo = recordFromDatabaseLogic.getRecordEditorInformation(
						searchParam.getCurrentConnectDefinisionId(), tableFormDTO, userInfo.getId());
			} else {
				final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
				recordInfo = recordFromDatabaseLogic.getRecordEditorInformation(
						searchParam.getCurrentConnectDefinisionId(), tableFormDTO, userInfo.getId());
			}

			SelectOneMenuItem[] items = logic.getSelectableMap(searchParam.getCurrentColumnId(),
					new HashMap<String, String>(), recordInfo.getDbConnectInfomationDTO(),
					recordInfo.getTableForm().getTableItemMap().get(searchParam.getCurrentColumnId()));
			if (null == items) {
				items = recordInfo.getTableForm().getTableItemMap().get(searchParam.getCurrentColumnId())
						.getSelectableItems();
			}
			List<SelectableItem> filteredItemList = new ArrayList<SelectableItem>();
			for (final SelectOneMenuItem buff : items) {
				final String label = buff.getLabel();
				if (null == searchParam.getSearchCondition() || "" == searchParam.getSearchCondition()) {
					final SelectableItem item = new SelectableItem();
					item.setValue(buff.getValue());
					item.setLabel(label);
					filteredItemList.add(item);
				} else {
					if (null != label && label.contains(searchParam.getSearchCondition())) {
						final SelectableItem item = new SelectableItem();
						item.setValue(buff.getValue());
						item.setLabel(label);
						filteredItemList.add(item);
					}
				}
			}

			// searchParam.setResultRowCount(filteredItemList.size());
			// searchParam.setNowViewableRecordCount(searchParam.getResultRowCount()
			// - searchParam.MAX_ITEM_COUNT * (searchParam.getPageIndex() + 1) >
			// 0
			// ? searchParam.MAX_ITEM_COUNT * (searchParam.getPageIndex() + 1) :
			// searchParam.getResultRowCount());
			// searchParam.setColumnContentsItems(new
			// ArrayList<SelectOneMenuItem>());
			// final int startindex =
			// getPageStartViewableRecordCount(searchParam.getResultRowCount(),
			// searchParam.getNowViewableRecordCount(),
			// searchParam.MAX_ITEM_COUNT) - 1;
			// final int endindex =
			// getPageEndViewableRecordCount(searchParam.getResultRowCount(),
			// searchParam.getNowViewableRecordCount()) - 1;
			//
			// for (int count = startindex; count <= endindex; count++) {
			// searchParam.getColumnContentsItems().add(filteredItemList.get(count));
			// }
			searchParam.setColumnContentsItems(new ArrayList<SelectableItem>());
			searchParam.getColumnContentsItems().addAll(filteredItemList);
			Collections.sort(searchParam.getColumnContentsItems(), new Comparator<SelectableItem>() {
				public int compare(SelectableItem b1, SelectableItem b2) {
					return b1.getValue().compareTo(b2.getValue());
				}
			});

		} catch (ApplicationDomainLogicException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return searchParam.getColumnContentsItems();
	}

	/**
	 *
	 */
	@Override
	public FRM0200SearchResultModel doSearchData(FRM0200SearchParam searchParam)
			throws ApplicationDomainLogicException {
		FRM0200SearchResultModel model = new FRM0200SearchResultModel();
		model.setConnectDefinisionId(searchParam.getConnectDefinisionId());
		model.setTableId(searchParam.getTableId());
		if (!isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {
			model = doSearchDataForSingleTable(searchParam, model);
			model.setIsMultiTable(Boolean.FALSE);
		} else {
			model = doSearchDataForMultiTable(searchParam, model);
			model.setIsMultiTable(Boolean.TRUE);
		}
		setPermissionToView(model, searchParam.getUserInfo());
		return model;
	}

	/**
	 *
	 */
	@Override
	public FRM0200SearchResultModel doInitSearch(FRM0200SearchParam searchParam)
			throws ApplicationDomainLogicException {
		FRM0200SearchResultModel model = new FRM0200SearchResultModel();
		model.setConnectDefinisionId(searchParam.getConnectDefinisionId());
		model.setTableId(searchParam.getTableId());
		if (!isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {
			model = doInitSearchForSingleTable(model, searchParam.getUserInfo().getId());
			model.setIsMultiTable(Boolean.FALSE);
		} else {
			model = doInitSearchForMultiTable(model, searchParam.getUserInfo());
			model.setIsMultiTable(Boolean.TRUE);
		}
		setPermissionToView(model, searchParam.getUserInfo());
		model.setMaxSearchConditionSize(FRM0200SearchParam.MAX_SEARCH_CONDITION_SIZE);
		model.setMaxSearchConditionSizeError(
				messageService.getMessage("MI-E-0073", FRM0200SearchParam.MAX_SEARCH_CONDITION_SIZE));
		return model;
	}

	/**
	 *
	 */
	@Override
	public FRM0200SearchResultModel doOutputSearchCondition(FRM0200SearchParam searchParam)
			throws ApplicationDomainLogicException {
		FRM0200SearchResultModel model = new FRM0200SearchResultModel();
		model.setConnectDefinisionId(searchParam.getConnectDefinisionId());
		model.setTableId(searchParam.getTableId());

		final List<SelectConditionItem> list = new ArrayList<SelectConditionItem>();
		final ColumnDisplayDefinitionDTO def;
		RecordEditorInformationDTO tableDefinitionDTO;
		UserInfo userInfo = searchParam.getUserInfo();
		try {
			// Load table multi
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			model.setTableLabel(tableFormDTO.getTableFormLabel());

			if (isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {

				Map<String, TableItemDTO> tableItemChilds = getRelateTableItemDTO(model.getConnectDefinisionId(),
						tableFormDTO);
				tableFormDTO.getTableItemMap().putAll(tableItemChilds);

				final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();

				tableDefinitionDTO = recordFromDatabaseLogic.getRecordEditorInformation(model.getConnectDefinisionId(),
						tableFormDTO, userInfo.getId());

				def = recordFromDatabaseLogic.getColumnsDisplay(model.getConnectDefinisionId(), model.getTableId(),
						tableDefinitionDTO, userInfo.getId());

				if (checkDifferenceOfColumnOnRepositoryAndDatabase(model.getConnectDefinisionId(), model.getTableId(),
						def)) {
					// MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
					// addPageMessage(MessageUtils.getMessage("MI-E-0121"));
					model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
					return model;
				}

			} else {
				final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
				tableDefinitionDTO = recordFromDatabaseLogic.getRecordEditorInformation(model.getConnectDefinisionId(),
						tableFormDTO, userInfo.getId());

				def = recordFromDatabaseLogic.getColumnsDisplay(model.getConnectDefinisionId(), model.getTableId(),
						tableDefinitionDTO, userInfo.getId());

				if (checkDifferenceOfColumnOnRepositoryAndDatabase(def)) {
					// MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
					// addPageMessage(MessageUtils.getMessage("MI-E-0121"));
					model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
					return model;
				}
			}

			// 検索条件の入力値チェック
			if (!checkRecordSearchCondition(searchParam.getSearchConditionItems(), def, model.getMessageInfo())) {
				return model;
			}
			// 固定条件
			final List<SelectConditionItem> commonSelectItems = getOutputCommonSearchCondition(
					model.getConnectDefinisionId(), model.getTableId(), userInfo.getId());

			for (final SearchConditionItem item : searchParam.getSearchConditionItems()) {
				if (item.exist()) {
					final SelectConditionItem condition = new SelectConditionItem();
					condition.setColumnId(item.getTargetedColumnId());
					condition.setComparisonOperator(
							SqlWhereTableComparisonOperator.valueOf(item.getComparisonOperator()));
					condition.setValue(item.getTargetedColumnSearchCondition());

					if (item.getLogicalOperator() == null) {
						condition.setLogicalOperator(SqlWhereTableLogicalOperator.blank);
					} else {
						condition.setLogicalOperator(SqlWhereTableLogicalOperator.valueOf(item.getLogicalOperator()));
					}
					if (!isExistSelectCondtionItem(commonSelectItems, condition)) {
						list.add(condition);
					}
				}
			}

			final PreservationOfSearchConditionControlLogic searchConditionControlLogic = new PreservationOfSearchConditionControlLogic();

			final OutputSearchConditionDTO dto = new OutputSearchConditionDTO();
			dto.setConnectDefinitionId(searchParam.getConnectDefinisionId());
			dto.setTableId(searchParam.getTableId());

			dto.setUserId(userInfo.getId());
			dto.setList(list);
			dto.setFileName(userInfo.getId());
			dto.setCommon(false);
			dto.setUpdate(false);
			searchConditionControlLogic.save(dto);
		} catch (final ApplicationDomainLogicException e) {
			// addPageMessage(e);
			model.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
			return model;
		}

		// MI-I-0010=検索条件を保存しました。
		// addPageMessage(MessageUtils.getMessage("MI-I-0010"));
		model.getMessageInfo().add(new MessageInfo("MI-I-0010", MessageType.SUCCESS, messageService));
		return model;
	}

	/**
	 *
	 * @param searchParam
	 * @param model
	 * @return
	 */
	private FRM0200SearchResultModel doSearchDataForSingleTable(
			FRM0200SearchParam searchParam,
			FRM0200SearchResultModel model) {
		try {
			//get info from xml
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			model.setTableLabel(tableFormDTO.getTableFormLabel());

			//get info from db
			final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			final RecordEditorInformationDTO tableDefinitionDTO = recordFromDatabaseLogic.getRecordEditorInformation(
					model.getConnectDefinisionId(), tableFormDTO, searchParam.getUserInfo().getId());

			final ColumnDisplayDefinitionDTO def = recordFromDatabaseLogic.getColumnsDisplay(
					model.getConnectDefinisionId(), model.getTableId(), tableDefinitionDTO,
					searchParam.getUserInfo().getId());

			if (checkDifferenceOfColumnOnRepositoryAndDatabase(def)) {
				// MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
				// addPageMessage(MessageUtils.getMessage("MI-E-0121"));
				model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
				return model;
			}

			if (!checkRecordSearchCondition(searchParam.getSearchConditionItems(), def, model.getMessageInfo())) {
				return model;
			}			
			
			final RecordSearchResultDTO dto = recordSearch(searchParam,  def, tableDefinitionDTO);
			
			if(searchParam.isCountData()){
				model.setResultRowCount(dto.getResultRowCount());
				return model;
			}
			
			createDisplayRecords(dto.getRecordSearchResult(), def, model, true, tableDefinitionDTO);
			model.setOrderDesc(tableFormDTO.getOrderDesc());
			model.setResultRowCount(dto.getResultRowCount());
			model.setColumnsDisplayDefinition(def);
			model.setRecordSearchResultDTO(dto);
			return model;
		} catch (final ApplicationDomainLogicException e) {
			// addPageMessage(e);
			model.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
			return model;
		} catch (final Exception e) {
			getLogger().fatal(e.getMessage(), e);
			// addPageMessage(e.getMessage());
			model.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
			return model;
		}
	}

	/**
	 *
	 * @param searchParam
	 * @param model
	 * @return
	 */
	private FRM0200SearchResultModel doSearchDataForMultiTable(FRM0200SearchParam searchParam,
			FRM0200SearchResultModel model) {
		final ColumnDisplayDefinitionDTO displayDef;
		try {
			// Load table multi
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			model.setTableLabel(tableFormDTO.getTableFormLabel());

			Map<String, TableItemDTO> tableItemChilds = getRelateTableItemDTO(model.getConnectDefinisionId(),
					tableFormDTO);
			tableFormDTO.getTableItemMap().putAll(tableItemChilds);

			final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			final RecordEditorInformationDTO tableDefinitionDTO = recordFromDatabaseLogic.getRecordEditorInformation(
					model.getConnectDefinisionId(), tableFormDTO, searchParam.getUserInfo().getId());

			// try {
			// Check selected table is multi-table?
			displayDef = recordFromDatabaseLogic.getColumnsDisplay(model.getConnectDefinisionId(), model.getTableId(),
					tableDefinitionDTO, searchParam.getUserInfo().getId());
			if (checkDifferenceOfColumnOnRepositoryAndDatabase(model.getConnectDefinisionId(), model.getTableId(),
					displayDef)) {
				// MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
				// addPageMessage(MessageUtils.getMessage("MI-E-0121"));
				model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
				return model;
			}

			// } catch (final ApplicationDomainLogicException e) {
			// // addPageMessage(e);
			// model.getMessageInfo().add(new MessageInfo(e,
			// MessageType.ERROR));
			// return model;
			// }

			if (!checkRecordSearchCondition(searchParam.getSearchConditionItems(), displayDef,
					model.getMessageInfo())) {
				return model;
			}

			final RecordSearchResultDTO dto = recordSearch(
					searchParam,
					displayDef,
					tableDefinitionDTO);
			
			if(searchParam.isCountData()){
				model.setResultRowCount(dto.getResultRowCount());
				return model;
			}

			createDisplayRecords(dto.getRecordSearchResult(), displayDef, model, true, tableDefinitionDTO);
			model.setOrderDesc(tableFormDTO.getOrderDesc());
			model.setResultRowCount(dto.getResultRowCount());
			model.setColumnsDisplayDefinition(displayDef);
			model.setRecordSearchResultDTO(dto);
			return model;
		} catch (final ApplicationDomainLogicException e) {
			// addPageMessage(e);
			model.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
			return model;
		}
		// catch (final Exception e) {
		// getLogger().fatal(e.getMessage(), e);
		// // addPageMessage(e.getMessage());
		// model.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
		// return model;
		// }
	}

	/**
	 * SelectCondtionItemリストに指定された条件が存在するかを返します
	 *
	 * @return true：存在する false：存在しない
	 *
	 */
	private boolean isExistSelectCondtionItem(final List<SelectConditionItem> selectCondtionItems,
			SelectConditionItem findCondtionItem) {
		for (final SelectConditionItem item : selectCondtionItems) {
			if (item.IsEqualCondtion(findCondtionItem)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Init search screen for single table
	 *
	 * @param model
	 * @return
	 */
	private FRM0200SearchResultModel doInitSearchForSingleTable(FRM0200SearchResultModel model, String userId) {
		//old process => check from xml and database => BEGIN
		/*final ColumnDisplayDefinitionDTO displayDef;
		try {			
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			model.setTableLabel(tableFormDTO.getTableFormLabel());
			model.setSortConditionMap(tableFormDTO.getSortConditionMap());
			final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			final RecordEditorInformationDTO tableDefinitionDTO = recordFromDatabaseLogic.getRecordEditorInformation(model.getConnectDefinisionId(), tableFormDTO, userId);
			displayDef = recordFromDatabaseLogic.getColumnsDisplay(model.getConnectDefinisionId(), model.getTableId(), tableDefinitionDTO, userId);
			model.setOrderDesc(displayDef.isOrderDesc());
			if (checkDifferenceOfColumnOnRepositoryAndDatabase(displayDef)) {
				model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
				return model;
			}
			SearchConditionItem defaultSearchConditionItem = new SearchConditionItem();
			model.setSearchConditionItems(createSearchConditionItems(model.getConnectDefinisionId(), model.getTableId(), null, displayDef, defaultSearchConditionItem, userId));
			model.setDefaultSearchConditionItem(defaultSearchConditionItem);
			model.setColumnsDisplayDefinition(displayDef);
		} catch (final ApplicationDomainLogicException e) {
			// addPageMessage(e);
			model.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
			return model;
		}*/
		//old process => check from xml and database => END
		
		//JUST GET INFO FROM XML -- BEGIN
		final String connectId = model.getConnectDefinisionId();
		final String tableId = model.getTableId();
		final TableNameListIsAcquiredFromRepositoryLogic repositoryLogic;
		final TableFormDTO tableXML;
		final ColumnDisplayDefinitionDTO displayDef;
		try {
			// Get table from xml
			repositoryLogic = new TableNameListIsAcquiredFromRepositoryLogic();
			tableXML = repositoryLogic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			//check table exists in xml
			if(tableXML == null){
				final String messageCode = "frm0200.table.not.exists.xml";
				final MessageInfo message = new MessageInfo(messageCode, MessageType.ERROR, messageService);
				model.getMessageInfo().add(message);
				return model;
			}
			//set info for displayDef
			displayDef = new ColumnDisplayDefinitionDTO();
			SortedMap<Integer, String> columnNames = tableXML.getColumnNames();
			Map<String, TableItemDTO> itemDefinitions = tableXML.getTableItemMap();
			displayDef.setColumnNames(columnNames);
			displayDef.setItemDefinitions(itemDefinitions);
			//set info model
			model.setTableLabel(tableXML.getTableFormLabel());
			model.setSortConditionMap(tableXML.getSortConditionMap());
			model.setOrderDesc(tableXML.getOrderDesc());
			SearchConditionItem defaultSearchConditionItem = new SearchConditionItem();
			model.setSearchConditionItems(createSearchConditionItems(connectId, tableId, null, displayDef, defaultSearchConditionItem, userId));
			model.setDefaultSearchConditionItem(defaultSearchConditionItem);
			model.setColumnsDisplayDefinition(displayDef);
		} catch (final ApplicationDomainLogicException e) {
			model.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
			return model;
		}
		//JUST GET INFO FROM XML -- END
		return model;
	}

	/**
	 * レコードを検索して戻します。
	 * <p>
	 * 特に検索条件を指定せず、指定されたインデックスから指定した数のレコードを 戻します。
	 * </p>
	 * <p>
	 * 初期表示或いは「前へ」「次へ」ボタンによる参照用に使用する、同名メソッド のオーバーロードです。
	 * </p>
	 *
	 * @param topIndex
	 * @param recordCount
	 * @return RecordSearchResultDTO レコード検索結果 DTO
	 * @throws ApplicationDomainLogicException
	 */
	/*
	 * private RecordSearchResultDTO recordSearch(String connectDefinisionId,
	 * String tableId, final int topIndex, final int recordCount, final boolean
	 * isOrderDesc, RecordEditorInformationDTO tableDefinitionDTO, UserInfo
	 * userInfo) throws ApplicationDomainLogicException { final
	 * RecordSearchConditionDTO dto = new RecordSearchConditionDTO();
	 * dto.setConnectDefinitionId(connectDefinisionId); dto.setTableId(tableId);
	 * dto.setRecordCount(recordCount); dto.setTopIndex(topIndex);
	 * dto.setTypeOfRetrieval(TypeOfRetrieval.UNRESTRICTED);
	 * dto.setOrderAsc(isOrderDesc == false); //
	 * this.beforeRecordSearchConditionItems = dto; return new
	 * RetrievalProcessingOfRecordFromDatabaseLogic().getRecords(dto,
	 * tableDefinitionDTO.getDbConnectInfomationDTO(),
	 * tableDefinitionDTO.getTableDef(), tableDefinitionDTO.getTableForm(),
	 * userInfo, ""); }
	 */

	/**
	 *
	 * @param model
	 * @return
	 */
	private FRM0200SearchResultModel doInitSearchForMultiTable(FRM0200SearchResultModel model, UserInfo userInfo) {
		//old process => check from xml and database => BEGIN
		/*final ColumnDisplayDefinitionDTO displayDef;
		try {
			// Load table multi
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			model.setTableLabel(tableFormDTO.getTableFormLabel());
			model.setSortConditionMap(tableFormDTO.getSortConditionMap());
			// Load Items relate
			Map<String, TableItemDTO> tableItemChilds = getRelateTableItemDTO(model.getConnectDefinisionId(), tableFormDTO);
			tableFormDTO.getTableItemMap().putAll(tableItemChilds);
			final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			final RecordEditorInformationDTO tableDefinitionDTO = recordFromDatabaseLogic.getRecordEditorInformation(model.getConnectDefinisionId(), tableFormDTO, userInfo.getId());
			displayDef = recordFromDatabaseLogic.getColumnsDisplay(model.getConnectDefinisionId(), model.getTableId(), tableDefinitionDTO, userInfo.getId());
			if (checkDifferenceOfColumnOnRepositoryAndDatabase(model.getConnectDefinisionId(), model.getTableId(), displayDef)) {
				model.getMessageInfo().add(new MessageInfo("MI-E-0121", MessageType.ERROR, messageService));
				return model;
			}
			Map<String, TableItemDTO> displayColumns = new HashMap<String, TableItemDTO>();
			for (Iterator<String> iterator = displayDef.getItemDefinitions().keySet().iterator(); iterator.hasNext();) {
				String key = (String) iterator.next();
				if (displayDef.getItemDefinitions().get(key).isRoot()) {
					displayColumns.put(key, displayDef.getItemDefinitions().get(key));
				}
			}
			displayDef.getItemDefinitions().clear();
			displayDef.getItemDefinitions().putAll(displayColumns);
			// Create search condition
			SearchConditionItem defaultSearchConditionItem = new SearchConditionItem();
			model.setSearchConditionItems(createSearchConditionItems(model.getConnectDefinisionId(), model.getTableId(), null, displayDef, defaultSearchConditionItem, userInfo.getId()));
			model.setDefaultSearchConditionItem(defaultSearchConditionItem);
			if (!checkRecordSearchCondition(model.getSearchConditionItems(), displayDef, model.getMessageInfo())) {
				return model;
			}
			model.setOrderDesc(displayDef.isOrderDesc());
			model.setColumnsDisplayDefinition(displayDef);
		} catch (final ApplicationDomainLogicException e) {
			// addPageMessage(e);
			model.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
			return model;
		}*/
		//old process => check from xml and database => END
		
		//JUST GET INFO FROM XML -- BEGIN
		final String connectId = model.getConnectDefinisionId();
		final String tableId = model.getTableId();
		final TableNameListIsAcquiredFromRepositoryLogic repositoryLogic;
		final TableFormDTO tableXML;
		final ColumnDisplayDefinitionDTO displayDef;
		try {
			// Get table from xml
			repositoryLogic = new TableNameListIsAcquiredFromRepositoryLogic();
			tableXML = repositoryLogic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());	
			//check table exists in xml
			if(tableXML == null){
				final String messageCode = "frm0200.table.not.exists.xml";
				final MessageInfo message = new MessageInfo(messageCode, MessageType.ERROR, messageService);
				model.getMessageInfo().add(message);
				return model;
			}
			//set info for displayDef 
			displayDef = new ColumnDisplayDefinitionDTO();
			SortedMap<Integer, String> columnNames = tableXML.getColumnNames();
			Map<String, TableItemDTO> itemDefinitions = tableXML.getTableItemMap();
			displayDef.setColumnNames(columnNames);
			displayDef.setItemDefinitions(itemDefinitions);			
			// Load Items relate
			Map<String, TableItemDTO> tableItemChilds = getRelateTableItemDTO(connectId, tableXML);
			tableXML.getTableItemMap().putAll(tableItemChilds);
			
			Map<String, TableItemDTO> displayColumns = new HashMap<String, TableItemDTO>();
			for (Iterator<String> iterator = displayDef.getItemDefinitions().keySet().iterator(); iterator.hasNext();) {
				String key = (String) iterator.next();
				if (displayDef.getItemDefinitions().get(key).isRoot()) {
					displayColumns.put(key, displayDef.getItemDefinitions().get(key));
				}
			}
			displayDef.getItemDefinitions().clear();
			displayDef.getItemDefinitions().putAll(displayColumns);
			//set info for model
			model.setTableLabel(tableXML.getTableFormLabel());
			model.setSortConditionMap(tableXML.getSortConditionMap());
			model.setOrderDesc(tableXML.getOrderDesc());
			SearchConditionItem defaultSearchConditionItem = new SearchConditionItem();
			model.setSearchConditionItems(createSearchConditionItems(connectId, tableId, null, displayDef, defaultSearchConditionItem, userInfo.getId()));
			model.setDefaultSearchConditionItem(defaultSearchConditionItem);
			if (!checkRecordSearchCondition(model.getSearchConditionItems(), displayDef, model.getMessageInfo())) {
				return model;
			}
			model.setColumnsDisplayDefinition(displayDef);
		} catch (final ApplicationDomainLogicException e) {
			model.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
			return model;
		}
		//JUST GET INFO FROM XML -- END
		return model;
	}

	/**
	 * レコードを検索して戻します。
	 * <p>
	 * 特に検索条件を指定せず、指定されたインデックスから指定した数のレコードを 戻します。
	 * </p>
	 * <p>
	 * 初期表示或いは「前へ」「次へ」ボタンによる参照用に使用する、同名メソッド のオーバーロードです。
	 * </p>
	 *
	 * @param topIndex
	 * @param recordCount
	 * @return RecordSearchResultDTO レコード検索結果 DTO
	 * @throws ApplicationDomainLogicException
	 */
	/*
	 * private RecordSearchResultDTO recordSearch(final int topIndex, final int
	 * recordCount, final RecordSearchConditionDTO dto, UserInfo userInfo)
	 * throws ApplicationDomainLogicException { dto.setTopIndex(topIndex);
	 * dto.setRecordCount(recordCount); // this.beforeRecordSearchConditionItems
	 * = dto; // UserInfo userInfo = getUserInfo(); final
	 * RetrievalProcessingOfRecordFromDatabaseLogic logic = new
	 * RetrievalProcessingOfRecordFromDatabaseLogic(); final
	 * RecordEditorInformationDTO recordInfoDTO =
	 * logic.getRecordEditorInformation(dto.getConnectDefinitionId(),
	 * dto.getTableId(), userInfo.getId());
	 *
	 * return new RetrievalProcessingOfRecordFromDatabaseLogic().getRecords(dto,
	 * recordInfoDTO.getDbConnectInfomationDTO(), recordInfoDTO.getTableDef(),
	 * recordInfoDTO.getTableForm(), userInfo, ""); }
	 */

	/**
	 * 検索条件リストを作成します。
	 *
	 * @param conditionDTO
	 * @return
	 */
	private SearchConditionItem[] createSearchConditionItems(String connectDefinisionId, String tableId,
			final RecordSearchConditionDTO conditionDTO, final ColumnDisplayDefinitionDTO displayDef,
			SearchConditionItem defaultSearchConditionItem, String userId) throws ApplicationDomainLogicException {

		final List<SearchConditionItem> ret = new ArrayList<SearchConditionItem>();
		final List<SearchConditionItem> commonSearchConditionItems = new ArrayList<SearchConditionItem>();
		final List<SearchConditionItem> userSearchCondtionItems = new ArrayList<SearchConditionItem>();
		final SelectableItem[] conditionColumnItems = createSearchConditionColumnItem(displayDef);
		final SelectableItem[] conditionColumnSelectItems = createSearchConditionColumnSelectItem(displayDef);

		final SelectableItem[] comparisonOperatorItems = createComparisonOperator();
		final SelectableItem[] logicalOperatorItems = createLogicalOperatorItems();

		if (conditionDTO == null || conditionDTO.getConditions().size() == 0) {
			// 固定条件
			final List<SelectConditionItem> commonSelectItems = getOutputCommonSearchCondition(connectDefinisionId,
					tableId, userId);
			final List<SelectConditionItem> userSelectItems = getOutputUserSearchCondition(connectDefinisionId, tableId,
					userId);
			if (commonSelectItems.size() != 0) {
				for (final SelectConditionItem commonSelectItem : commonSelectItems) {
					final SearchConditionItem item = new SearchConditionItem();
					item.setTargetedColumnId(commonSelectItem.getColumnId());
					item.setTargetedColumnIdItems(conditionColumnItems);
					item.setTargetedColumnIdIsSelect(commonSelectItem.getColumnId());
					item.setTargetedColumnIdIsSelectItems(conditionColumnSelectItems);
					item.setComparisonOperator(commonSelectItem.getComparisonOperator().name());
					item.setComparisonOperatorItems(comparisonOperatorItems);
					item.setTargetedColumnSearchCondition(commonSelectItem.getValue());
					item.setLogicalOperator(commonSelectItem.getLogicalOperator().name());
					item.setLogicalOperatorItems(logicalOperatorItems);
					item.setIsAddConditionRow(false);
					item.setIsRemoveConditionRow(false);
					commonSearchConditionItems.add(item);
				}
				SearchConditionItem lastitem = commonSearchConditionItems.get(commonSearchConditionItems.size() - 1);
				lastitem.setIsAddConditionRow(true);
				if (userSelectItems.size() == 0) {
					lastitem.setLogicalOperator(SqlWhereTableLogicalOperator.blank.name());
				} else {
					lastitem.setLogicalOperator(SqlWhereTableLogicalOperator.and.name());
				}
			}

			// ユーザー条件
			if (userSelectItems.size() == 0) {
				final SearchConditionItem item = new SearchConditionItem();
				item.setTargetedColumnId("");
				item.setTargetedColumnIdItems(conditionColumnItems);
				item.setTargetedColumnIdIsSelect("");
				item.setTargetedColumnIdIsSelectItems(conditionColumnSelectItems);
				item.setComparisonOperatorItems(comparisonOperatorItems);
				item.setLogicalOperatorItems(logicalOperatorItems);

				userSearchCondtionItems.add(item);
			} else {
				for (final SelectConditionItem userSelectItem : userSelectItems) {
					final SearchConditionItem item = new SearchConditionItem();
					item.setTargetedColumnId(userSelectItem.getColumnId());
					// ADD 初期化の問題を対応 2016/07/26 ↓
					item.setTargetedColumnIdIsSelectLabel(
							getLabelById(userSelectItem.getColumnId(), conditionColumnSelectItems));
					// ADD 初期化の問題を対応 2016/07/26 ↑
					item.setTargetedColumnIdItems(conditionColumnItems);
					item.setTargetedColumnIdIsSelect(userSelectItem.getColumnId());
					item.setTargetedColumnIdIsSelectItems(conditionColumnSelectItems);
					item.setComparisonOperator(userSelectItem.getComparisonOperator().name());
					item.setComparisonOperatorItems(comparisonOperatorItems);
					item.setTargetedColumnSearchCondition(userSelectItem.getValue());
					item.setLogicalOperator(userSelectItem.getLogicalOperator().name());
					item.setLogicalOperatorItems(logicalOperatorItems);
					userSearchCondtionItems.add(item);
				}
			}
		} else {
			for (final Integer index : conditionDTO.getConditions().keySet()) {
				final SelectConditionItem selectItem = conditionDTO.getConditions().get(index);
				final SearchConditionItem item = new SearchConditionItem();
				item.setTargetedColumnId(selectItem.getColumnId());
				// ADD 初期化の問題を対応 2016/07/26 ↓
				item.setTargetedColumnIdIsSelectLabel(
						getLabelById(selectItem.getColumnId(), conditionColumnSelectItems));
				// ADD 初期化の問題を対応 2016/07/26 ↑
				item.setTargetedColumnIdItems(conditionColumnItems);
				item.setTargetedColumnIdIsSelect(selectItem.getColumnId());
				item.setTargetedColumnIdIsSelectItems(conditionColumnSelectItems);
				item.setComparisonOperator(selectItem.getComparisonOperator().name());
				item.setComparisonOperatorItems(comparisonOperatorItems);
				item.setTargetedColumnSearchCondition(selectItem.getValue());
				item.setLogicalOperator(selectItem.getLogicalOperator().name());
				item.setLogicalOperatorItems(logicalOperatorItems);

				userSearchCondtionItems.add(item);
			}
		}
		if (commonSearchConditionItems.size() != 0)
			ret.addAll(commonSearchConditionItems);
		ret.addAll(userSearchCondtionItems);

		// ユーザー条件
		if (defaultSearchConditionItem != null) {
			defaultSearchConditionItem.setTargetedColumnId("");
			defaultSearchConditionItem.setTargetedColumnIdItems(conditionColumnItems);
			defaultSearchConditionItem.setTargetedColumnIdIsSelect("");
			defaultSearchConditionItem.setTargetedColumnIdIsSelectItems(conditionColumnSelectItems);
			defaultSearchConditionItem.setComparisonOperatorItems(comparisonOperatorItems);
			defaultSearchConditionItem.setLogicalOperatorItems(logicalOperatorItems);
		}

		return ret.toArray(new SearchConditionItem[0]);
	}

	/**
	 * 外部ファイルに保存されている、ユーザー検索条件を取得します。
	 *
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private List<SelectConditionItem> getOutputUserSearchCondition(String connectDefinisionId, String tableId,
			String userId) throws ApplicationDomainLogicException {
		final AcquisitionOfSearchConditionControlLogic logic = new AcquisitionOfSearchConditionControlLogic();

		final Map<String, String> map = logic.getUserFileNameMap(connectDefinisionId, tableId, userId);
		if (map.size() == 0) {
			return new ArrayList<SelectConditionItem>();
		} else {
			// R.2.1.0では１ユーザにつき、ファイルは１つ
			List<SelectConditionItem> ret = new ArrayList<SelectConditionItem>();
			for (final String filePath : map.keySet()) {
				for (SelectConditionItem item : logic.getSelectConditionItems(filePath)) {
					ret.add(item);
				}
				break;
			}
			return ret;
		}
	}

	/**
	 * 論理演算子プル段表示用リストを生成します。
	 *
	 * @return
	 */
	private SelectableItem[] createLogicalOperatorItems() {
		final List<SelectableItem> ret = new ArrayList<SelectableItem>();
		for (SqlWhereTableLogicalOperator logicalOperator : SqlWhereTableLogicalOperator.values()) {
			if (logicalOperator != SqlWhereTableLogicalOperator.blank) {
				final SelectableItem item = new SelectableItem();
				item.setValue(logicalOperator.name());
				item.setLabel(logicalOperator.getLabel());
				ret.add(item);
			}
		}
		return ret.toArray(new SelectableItem[0]);
	}

	/**
	 * 比較演算子プルダウン表示用リストを生成します。
	 *
	 * @param jdbc
	 * @return
	 */
	private SelectableItem[] createComparisonOperator() {

		final AcquisitionOfEnvironmentSetting logic = new AcquisitionOfEnvironmentSetting();

		final EnvironmentSettingDTO dto = logic.getAllProperties();
		final String[] searchComparisonOperatorOrders = dto.getSearchComparisonOperatorOrder().split(",");
		final List<SelectableItem> ret = new ArrayList<SelectableItem>();
		for (String searchComparisonOperator : searchComparisonOperatorOrders) {
			SqlWhereTableComparisonOperator comparisonOperator;
			try {
				comparisonOperator = SqlWhereTableComparisonOperator.valueOf(searchComparisonOperator);
			} catch (Exception e) {
				comparisonOperator = null;
			}
			if (null != comparisonOperator) {
				final SelectableItem item = new SelectableItem();
				item.setValue(comparisonOperator.name());
				item.setLabel(comparisonOperator.getLabel());
				ret.add(item);
			}
		}
		/*
		 * for (SqlWhereTableComparisonOperator comparisonOperator :
		 * SqlWhereTableComparisonOperator.values()) { if (comparisonOperator !=
		 * SqlWhereTableComparisonOperator.blank) { final SelectableItem item =
		 * new SelectableItem(); item.setValue(comparisonOperator.name());
		 * item.setLabel(comparisonOperator.getLabel()); ret.add(item); } }
		 */
		return ret.toArray(new SelectableItem[0]);
	}

	/**
	 * getLabelById
	 *
	 * @param id
	 * @param items
	 * @return
	 */
	private String getLabelById(String id, SelectableItem[] items) {
		for (SelectableItem item : items) {
			if (id.equals(item.getValue())) {
				return item.getLabel();
			}
		}
		return null;
	}

	/**
	 * 外部ファイルに保存されている、共通検索条件を取得します。
	 *
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private List<SelectConditionItem> getOutputCommonSearchCondition(String connectDefinisionId, String tableId,
			String userId) throws ApplicationDomainLogicException {
		final AcquisitionOfSearchConditionControlLogic logic = new AcquisitionOfSearchConditionControlLogic();

		final Map<String, String> map = logic.getCommonFileNameMap(connectDefinisionId, tableId, userId);
		if (map.size() == 0) {
			return new ArrayList<SelectConditionItem>();
		} else {
			// R.2.1.0では１ユーザにつき、ファイルは１つ
			List<SelectConditionItem> ret = new ArrayList<SelectConditionItem>();
			for (final String filePath : map.keySet()) {
				for (SelectConditionItem item : logic.getSelectConditionItems(filePath)) {
					ret.add(item);
				}
				break;
			}
			return ret;
		}
	}

	/**
	 * 検索条件リストのカラム名リストを作成します。
	 *
	 * @param displayDef
	 * @return
	 */
	private SelectableItem[] createSearchConditionColumnSelectItem(final ColumnDisplayDefinitionDTO displayDef) {
		final List<SelectableItem> ret = new ArrayList<SelectableItem>();
		final SortedMap<Integer, String> columnSortList = getColumnSortList(displayDef.getItemDefinitions());
		for (final Integer index : columnSortList.keySet()) {
			final String column = columnSortList.get(index);
			final TableItemDTO itemDef = displayDef.getItemDefinitions().get(column);
			if (itemDef != null && itemDef.isSelectKey()) {
				final SelectableItem item = new SelectableItem();
				item.setValue(column);
				item.setLabel(isSearchWindow(itemDef));
				ret.add(item);
			}
		}
		return ret.toArray(new SelectableItem[0]);
	}

	/**
	 *
	 * @param itemDef
	 * @return
	 */
	private String isSearchWindow(TableItemDTO itemDef) {
		if (DefinedHtmlElement.SELECT == itemDef.getHtmlElement()
				|| DefinedHtmlElement.INPUT_RADIO == itemDef.getHtmlElement()) {
			if (null != itemDef.getSelectableItems() && 0 < itemDef.getSelectableItems().length
					&& !itemDef.getSqlString().contains("@")) {
				return "true";
			}
		}
		return "false";
	}

	/**
	 * 検索条件リストのカラム名リストを作成します。
	 *
	 * @param displayDef
	 * @return
	 */
	private SelectableItem[] createSearchConditionColumnItem(final ColumnDisplayDefinitionDTO displayDef) {
		final List<SelectableItem> ret = new ArrayList<SelectableItem>();
		final SortedMap<Integer, String> columnSortList = getColumnSortList(displayDef.getItemDefinitions());
		for (final Integer index : columnSortList.keySet()) {
			final String column = columnSortList.get(index);
			final TableItemDTO itemDef = displayDef.getItemDefinitions().get(column);
			if (itemDef != null && itemDef.isSelectKey()) {
				final SelectableItem item = new SelectableItem();
				item.setValue(column);
				item.setLabel(itemDef.getItemLabel());
				ret.add(item);
			}
		}
		return ret.toArray(new SelectableItem[0]);
	}

	/**
	 * 画面表示用レコード明細の作成を行います。
	 * <p>
	 * 実際のレコードデータ、リポジトリ内の定義、FsacDB スキーマ定義を元にレコード 明細（レコードの一覧表）を作成します。
	 * </p>
	 * <p>
	 * ヘッダの作成、データ表の作成を同時に行います。
	 * </p>
	 *
	 * @param records
	 *            レコードデータ保持マップ
	 * @param displayDef
	 *            項目定義保持 DTO
	 */
	private void createDisplayRecords(
			final SortedMap<Integer, Map<String, String>> records,
			final ColumnDisplayDefinitionDTO displayDef, 
			FRM0200SearchResultModel model, 
			boolean isSearchData,
			RecordEditorInformationDTO tableDefinitionDTO) throws ApplicationDomainLogicException {

		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		final Map<String, SelectableItem[]> selectableMap = new HashMap<String, SelectableItem[]>();

		// this.searchResultHeaderItems = createHeaderItemArray(displayDef);
		if (model.getResultRowCount() > SystemProperties.getSearchMaxRecordCount()) {
			// MI-E-0125=該当データ件数が多すぎます。条件を絞り込み再度検索してください。
			// addPageMessage(MessageUtils.getMessage("MI-E-0125"));
			model.getMessageInfo().add(new MessageInfo("MI-E-0125", MessageType.ERROR, messageService));
			// this.searchResultDescriptionItems = new
			// SearchResultDescriptionItem[0];
			// this.nowViewableRecordCount = 0;
			model.setResultRowCount(0);
		} else if (records == null || records.get(0) == null) {
			// MI-E-0122=該当データが存在しません
			// addPageMessage(MessageUtils.getMessage("MI-E-0122"));
			model.getMessageInfo().add(new MessageInfo("MI-E-0122", MessageType.INFO, messageService));
			// this.searchResultDescriptionItems = new
			// SearchResultDescriptionItem[0];
			// this.nowViewableRecordCount = this.nowViewableRecordCount + 1;
		} else {
			// TODO:プルダウンデータ等をＩＤで出力する設定に戻す場合は、
			// 以下のコメント化を解除し、for文をコメント化する。
			// final SortedMap<Integer, Map<String, String>> columnDataLabel =
			// records;
			// final SortedMap<Integer, Map<String, String>> columnDataLabel =
			// new TreeMap<Integer, Map<String, String>>();
			final Map<String, TableItemDTO> ItemDefinitionsMap =  displayDef.getItemDefinitions();

			for (final Integer columnIndex : records.keySet()) {
				final Map<String, String> map = records.get(columnIndex);
				final Map<String, String> mapLabel = new HashMap<String, String>();
				for (final String columnName : map.keySet()) {
					final TableItemDTO item = this.getTableItemDTOByKeyFromMap(ItemDefinitionsMap, columnName);
					if(columnName.equalsIgnoreCase(item.getItemId())) {
						mapLabel.put(item.getItemLabel(), map.get(columnName));
					}
				}
				for (Map.Entry<String, String> entry : map.entrySet()){
					String columnName = entry.getKey();
					final TableItemDTO item = this.getTableItemDTOByKeyFromMap(ItemDefinitionsMap, columnName);
					if (item != null) {
						if (item.getHtmlElement() == DefinedHtmlElement.SELECT
								|| item.getHtmlElement() == DefinedHtmlElement.INPUT_RADIO) {
							if (StringUtils.isEmpty(map.get(columnName))) {
								map.put(item.getItemLabel(), "");
							} else {
								final String itemLabel = item.getItemLabel();
								final DbConnectInfomationDTO DbConnectInfo = tableDefinitionDTO.getDbConnectInfomationDTO();
								SelectableItem[] selectOneMenuItem = null;
								if (!selectableMap.containsKey(item.getItemId())) {									
									selectOneMenuItem = (SelectableItem[]) logic.getSelectableMap(itemLabel, mapLabel, DbConnectInfo, item);
									selectableMap.put(item.getItemId(), selectOneMenuItem);
									item.setSelectableItems(selectOneMenuItem);
								} else if (selectableMap.containsKey(item.getItemId())) {
									SelectableItem[] items = selectableMap.get(item.getItemId());
									boolean flag = false;
									if(items != null && items.length > 0){
										for (SelectableItem selectableItem : items) {
											if(selectableItem.getValue().equals(map.get(columnName))){
												item.setSelectableItems(items);
												flag = true;
												break;
											}else{
												flag = false;
											}
										}

										if(!flag){
											selectOneMenuItem = (SelectableItem[]) logic.getSelectableMap(itemLabel, mapLabel, DbConnectInfo, item);
											selectableMap.put(item.getItemId(), selectOneMenuItem);
											item.setSelectableItems(selectOneMenuItem);
										}
									}

								}
								map.put(columnName, logic.getSelectItem(item.getSelectableItems(), map.get(columnName),
										item.canDisplayNamePreview()));
							}
						} else {
							// MOD DBエースOracle日付対応 ↓
							// columnLabel.put(
							// columnName,
							// map.get(columnName));
							final DefinedHtmlElement element = item.getHtmlElement();
							if (element == DefinedHtmlElement.INPUT_DATE || element == DefinedHtmlElement.INPUT_DATETIME
									|| element == DefinedHtmlElement.INPUT_TIMESTAMP
									|| element == DefinedHtmlElement.INPUT_TIME) {
								String valueDsp = DateUtils.formatDateToString(map.get(columnName), element);
								map.put(columnName, valueDsp);
							} else {
								map.put(columnName, map.get(columnName));
								// MOD DBエースOracle日付対応 ↑
							}
						}
					}
				}
				// columnDataLabel.put(columnIndex, columnLabel);
			}

			// this.searchResultDescriptionItems = createBodyItemArray(records,
			// columnDataLabel, displayDef);
			// this.nowViewableRecordCount += records.size();
		}
	}

	// /**
	// * プルダウン用アイテムから、keyと一致する表示名を返します。
	// *
	// * @param items
	// * @param value
	// * @return
	// */
	// private String getSelectItem(final SelectableItem[] items, String key) {
	// if (items == null || items.length == 0) {
	// return "";
	// }
	//
	// for (SelectableItem item : items) {
	// if (item.getValue().equals(key)) {
	// return item.getLabel();
	// }
	// }
	// return "";
	// }

	/*
	 * Sort a map according to values.
	 *
	 * @param <K> the key of the map.
	 *
	 * @param <V> the value to sort according to.
	 *
	 * @param crunchifySortMap the map to sort.
	 *
	 * @return a map sorted on the values.
	 */
	public <K, V extends Comparable<? super V>> Map<String, TableDto> sortByCommitNo(final Map<String, TableDto> tables,
			Boolean sortDesc) {
		List<Map.Entry<String, TableDto>> entries = new ArrayList<Map.Entry<String, TableDto>>(tables.size());

		entries.addAll(tables.entrySet());

		// Sorts the specified list according to the order induced by the
		// specified comparator
		Collections.sort(entries, new Comparator<Map.Entry<String, TableDto>>() {
			@Override
			public int compare(final Map.Entry<String, TableDto> entry1, final Map.Entry<String, TableDto> entry2) {
				// Compares this object with the specified object for order
				TableDto tableDto1 = entry1.getValue();
				TableDto tableDto2 = entry2.getValue();
				if (!sortDesc) {
					return tableDto1.getCommitNO().compareTo(tableDto2.getCommitNO());
				} else {
					return tableDto2.getCommitNO().compareTo(tableDto1.getCommitNO());
				}
			}
		});

		Map<String, TableDto> sortedMap = new LinkedHashMap<String, TableDto>();

		// The Map.entrySet method returns a collection-view of the map
		for (Map.Entry<String, TableDto> entry : entries) {
			sortedMap.put(entry.getKey(), entry.getValue());
		}

		return sortedMap;
	}

	/**
	 * エクセルファイルを出力する際のカラム数のチェックを行います。
	 * <p>
	 * 出力するカラム数が256をより大きい場合は false を返します。<br />
	 * 出力するファイルがエクセル以外の場合は true を返します。
	 * </p>
	 *
	 * @return
	 */
	/*
	 * private boolean isOutputColumnCountValidater(final FileOutputTableData
	 * outputFile, Map<String, TableItemDTO> tableItemMap, Boolean
	 * outPutAllColumn) { if (FileOutputTableData.EXCEL != outputFile) { return
	 * true; } // final Map<String, TableItemDTO> tableItemMap // =
	 * getRecordEditorInformationDTO().getTableForm().getTableItemMap(); if
	 * (tableItemMap.size() > FileOutputTableData.EXCEL_MAX_COL_COUNT) { if
	 * (outPutAllColumn) { return false; } else { int columnCount = 0; for
	 * (final TableItemDTO dto : tableItemMap.values()) { if (dto.canPreview())
	 * { columnCount++; } }
	 *
	 * if (columnCount > FileOutputTableData.EXCEL_MAX_COL_COUNT) { return
	 * false; } else { return true; } } } else { return true; } }
	 */

	/**
	 * 検索条件の入力チェックを行います。 TODO:エラーチェックをエラー種別毎にわける
	 *
	 * @param definitionDTO
	 * @return
	 */
	private boolean checkRecordSearchCondition(SearchConditionItem[] searchConditionItems,
			final ColumnDisplayDefinitionDTO definitionDTO, List<MessageInfo> messageInfo) {

		SearchConditionItem lastItem = searchConditionItems[searchConditionItems.length - 1];
		for (final SearchConditionItem item : searchConditionItems) {
			if (searchConditionItems.length == 1 && StringUtils.isEmpty(item.getTargetedColumnId())
					&& StringUtils.isEmpty(item.getComparisonOperator())
					&& StringUtils.isEmpty(item.getTargetedColumnSearchCondition()) && item.isEmptyLogicalOperator()) {
				return true;
			}

			if (StringUtils.isEmpty(item.getTargetedColumnId())) {
				// MI-E-0094=対象カラムを選択してください。
				// addPageMessage(MessageUtils.getMessage("MI-E-0094"));
				messageInfo.add(new MessageInfo("MI-E-0094", MessageType.ERROR, messageService));
				return false;
			}

			if (StringUtils.isEmpty(item.getComparisonOperator())) {
				// MI-E-0106=比較演算を選択してください。
				// addPageMessage(MessageUtils.getMessage("MI-E-0106"));
				messageInfo.add(new MessageInfo("MI-E-0106", MessageType.ERROR, messageService));
				return false;
			}

			if (StringUtils.isEmpty(item.getTargetedColumnSearchCondition())
					&& !isNullCondition(item.getComparisonOperator())) {
				// MI-E-0075=検索条件を入力してください。
				// addPageMessage(MessageUtils.getMessage("MI-E-0075"));
				messageInfo.add(new MessageInfo("MI-E-0075", MessageType.ERROR, messageService));
				return false;
			}

			if (!item.equals(lastItem)) {
				if (StringUtils.isEmpty(item.getLogicalOperator())
						|| item.getLogicalOperator().toLowerCase().trim().equals("blank")) {
					// MI-E-0120=論理演算を選択してください。
					// addPageMessage(MessageUtils.getMessage("MI-E-0120"));
					messageInfo.add(new MessageInfo("MI-E-0120", MessageType.ERROR, messageService));
					return false;
				}
			} else if (!lastItem.isEmptyLogicalOperator()) {
				// MI-E-0080=最終行に論理演算は指定できません
				// addPageMessage(MessageUtils.getMessage("MI-E-0080"));
				messageInfo.add(new MessageInfo("MI-E-0080", MessageType.ERROR, messageService));
				return false;
			}

			final DefinitionOfColumn definitionOfColumn = definitionDTO.getDefinitionOfColumns()
					.get(item.getTargetedColumnId());
			if (isJDBCMetaDataTypeToDate(definitionOfColumn.getJDBCMetaDataType())) {
				if (isLikeComparisonOperator(item.getComparisonOperator())) {
					// MI-E-0092=対象カラムが{0}の場合には、比較演算子に曖昧検索(LIKE)条件は指定できません。
					final String args[] = { "日付型" };
					// addPageMessage(MessageUtils.getMessage("MI-E-0092",
					// args));
					messageInfo.add(new MessageInfo("MI-E-0092", MessageType.ERROR, args, messageService));
					return false;
				}

				if (!isNullCondition(item.getComparisonOperator())) {
					if (!isDate(item.getTargetedColumnSearchCondition())) {
						// MI-E-0098=日付は[YYYY/MM/DD]または、[YYYY/MM/DD
						// HH:MM:SS]形式で入力してください。
						// addPageMessage(MessageUtils.getMessage("MI-E-0098"));
						messageInfo.add(new MessageInfo("MI-E-0098", MessageType.ERROR, messageService));
						return false;
					}
				}
			}

			if (isJDBCMetaDataTypeToNumber(definitionOfColumn.getJDBCMetaDataType())) {
				if (isLikeComparisonOperator(item.getComparisonOperator())) {
					// MI-E-0092=対象カラムが{0}の場合には、比較演算子に曖昧検索(LIKE)条件は指定できません。
					final String args[] = { "数値型" };
					// addPageMessage(MessageUtils.getMessage("MI-E-0092",
					// args));
					messageInfo.add(new MessageInfo("MI-E-0092", MessageType.ERROR, args, messageService));
					return false;
				}

				if (!isNullCondition(item.getComparisonOperator())) {
					if (!isNumber(item.getTargetedColumnSearchCondition())) {
						// MI-E-0084=数値以外は入力できません。
						// addPageMessage(MessageUtils.getMessage("MI-E-0084"));
						final String args[] = { "数値型" };
						messageInfo.add(new MessageInfo("MI-E-0084", MessageType.ERROR, args, messageService));
						return false;
					}
				}
			}

			// }
		}
		// lastItem = searchConditionItems[searchConditionItems.length - 1];
		// if (lastItem != null) {
		// if (StringUtils.isNotEmpty(lastItem.getLogicalOperator())) {
		// if (SqlWhereTableLogicalOperator
		// .valueOf(lastItem.getLogicalOperator()) !=
		// SqlWhereTableLogicalOperator.blank) {
		// // MI-E-0080=最終行に論理演算は指定できません
		// // addPageMessage(MessageUtils.getMessage("MI-E-0080"));
		// messageInfo.add(new MessageInfo("MI-E-0080", MessageType.ERROR,
		// messageService));
		// return false;
		// }
		// }
		// }
		return true;
	}

	/**
	 * JDBCメタデータタイプが数値型か否かを返します。
	 *
	 * @param jdbc
	 * @return
	 */
	private boolean isJDBCMetaDataTypeToNumber(final JDBCMetaDataType jdbc) {
		if (jdbc == JDBCMetaDataType.TINYINT || jdbc == JDBCMetaDataType.SMALLINT || jdbc == JDBCMetaDataType.INTEGER
				|| jdbc == JDBCMetaDataType.BIGINT || jdbc == JDBCMetaDataType.FLOAT || jdbc == JDBCMetaDataType.REAL
				|| jdbc == JDBCMetaDataType.DOUBLE || jdbc == JDBCMetaDataType.NUMERIC
				|| jdbc == JDBCMetaDataType.DECIMAL) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 比較演算子が曖昧(LIKE)条件か否かを返します。
	 *
	 * @param comparisonOperator
	 * @return
	 */
	private boolean isLikeComparisonOperator(final String comparisonOperator) {
		if (comparisonOperator != null) {
			final SqlWhereTableComparisonOperator ope = SqlWhereTableComparisonOperator.valueOf(comparisonOperator);
			if (ope == SqlWhereTableComparisonOperator.likeContains
					|| ope == SqlWhereTableComparisonOperator.likeStartsWith
					|| ope == SqlWhereTableComparisonOperator.likeEndsWith
					|| ope == SqlWhereTableComparisonOperator.notLikeContains
					|| ope == SqlWhereTableComparisonOperator.notLikeStartsWith
					|| ope == SqlWhereTableComparisonOperator.notLikeEndsWith) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * JDBCメタデータタイプが日付型か否かを返します。
	 *
	 * @param jdbc
	 * @return
	 */
	private boolean isJDBCMetaDataTypeToDate(final JDBCMetaDataType jdbc) {
		if (jdbc == JDBCMetaDataType.DATE || jdbc == JDBCMetaDataType.TIME || jdbc == JDBCMetaDataType.TIMESTAMP) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 日付か否かを返します。
	 *
	 * @param date
	 * @return
	 */
	private boolean isDate(final String date) {
		final String pattern;
		if (date.matches("^[0-9]{4}/[0-9]{2}/[0-9]{2}$")) {
			pattern = "yyyy/MM/dd";
		} else if (date.matches("^[0-9]{2}:[0-9]{2}:[0-9]{2}$")) {
			pattern = "HH:mm:ss";
		} else if (date.matches("^[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$")) {
			pattern = "yyyy/MM/dd HH:mm:ss";
		} else if (date.matches("^[0-9]{4}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}.[0-9]{3}$")) {
			pattern = "yyyy/MM/dd HH:mm:ss";
		} else {
			return false;
		}

		return isDateStyleCheck(date, pattern);
	}

	/**
	 * 日付の様式の妥当性をチェックする・メソッド。
	 *
	 * @param value
	 *            チェック対象日付情報。
	 * @param pattern
	 *            日付と時刻のフォーマットを記述するパターン(java.text.SimpleDateFormat参照)。
	 * @return true: 妥当 / false:妥当ではない。
	 */
	private boolean isDateStyleCheck(final String value, final String pattern) {
		final SimpleDateFormat format = new SimpleDateFormat(pattern);
		format.setLenient(false);
		try {
			format.parse(value);
		} catch (final ParseException e) {
			return false;
		}
		return true;
	}

	/**
	 * 数値か否かを返します。
	 *
	 * @param num
	 * @return
	 */
	private boolean isNumber(final String num) {
		return num.matches("[-|\\+]{0,1}[0-9]+($|[\\.]{0,1}[0-9]+)");
	}

	/**
	 * 比較演算子がIS NULL(IS NOT NULL)条件か否かを返します。
	 *
	 * @param comparisonOperator
	 * @return
	 */
	private boolean isNullCondition(final String comparisonOperator) {
		if (comparisonOperator != null) {
			final SqlWhereTableComparisonOperator ope = SqlWhereTableComparisonOperator.valueOf(comparisonOperator);
			if (ope == SqlWhereTableComparisonOperator.isNull || ope == SqlWhereTableComparisonOperator.isNotNull) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 *
	 * @param connectDefinitionId
	 * @param tableFormDTO
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private Map<String, TableItemDTO> getRelateTableItemDTO(final String connectDefinitionId, TableFormDTO tableFormDTO)
			throws ApplicationDomainLogicException {
		final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
		Map<String, TableItemDTO> tableItemChilds = new HashMap<String, TableItemDTO>();
		for (Iterator<TableItemDTO> itemIte = tableFormDTO.getTableItemMap().values().iterator(); itemIte.hasNext();) {
			TableItemDTO item = itemIte.next();
			for (Iterator<ColDto> itemCol = item.getCols().values().iterator(); itemCol.hasNext();) {
				item.setRoot(true);
				ColDto colDto = itemCol.next();
				TableItemDTO tableItemDTO = logic.getTableItemDTO(connectDefinitionId, colDto.getTableID(),
						colDto.getItemID());
				if (tableItemDTO != null) {
					tableItemDTO.setRoot(false);
					tableItemChilds.put(formatColumn(colDto.getTableID(), colDto.getItemID(), true), tableItemDTO);
				}
			}
		}
		return tableItemChilds;
	}

	/**
	 *
	 * @param model
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public FRM0200ResultModel setPermissionToView(FRM0200ResultModel model, UserInfo userInfo)
			throws ApplicationDomainLogicException {
		Boolean permissionReference = Boolean.FALSE;
		Boolean permissionCopy = Boolean.FALSE;
		Boolean permissionRemove = Boolean.FALSE;
		Boolean permissionDeleteFirst = Boolean.FALSE;
		Boolean permissionDeleteSecond = Boolean.FALSE;
		Boolean permissionDeleteThird = Boolean.FALSE;
		Boolean permissionInsert = Boolean.FALSE;
		Boolean permissionUpdate = Boolean.FALSE;
		Boolean permissionUpload = Boolean.FALSE;
		Boolean permissionDownload = Boolean.FALSE;

		List<GeneralUserOperationAuthority> userOperationAuthority = userInfo
				.getGeneralUserOperationAuthorityList(model.getConnectDefinisionId());

		OptionalDto optionalDto = null;
		if (isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			if (tableFormDTO.getOptional() != null) {
				optionalDto = tableFormDTO.getOptional();
			}

			if (userInfo.getUserAuthority() != null && userInfo.getUserAuthority().isSystemAdministrator()) {
				permissionReference = Boolean.TRUE;// (optionalDto != null &&
													// optionalDto.getReference().isEnable());
				permissionRemove = (optionalDto != null && optionalDto.getDelete().isEnable());
				permissionDeleteFirst = (optionalDto != null && optionalDto.getDelete() != null
						&& optionalDto.getDelete().getFirst() != null && optionalDto.getDelete().getFirst().isEnable());
				permissionDeleteSecond = (optionalDto != null && optionalDto.getDelete() != null
						&& optionalDto.getDelete().getSecond() != null
						&& optionalDto.getDelete().getSecond().isEnable());
				permissionDeleteThird = (optionalDto != null && optionalDto.getDelete() != null
						&& optionalDto.getDelete().getThird() != null && optionalDto.getDelete().getThird().isEnable());
				permissionInsert = (optionalDto != null && optionalDto.getInsert().isEnable());
				permissionCopy = (optionalDto != null && optionalDto.getCopy().isEnable());
				permissionUpdate = (optionalDto != null && optionalDto.getUpdate().isEnable());
				permissionUpload = (optionalDto != null && optionalDto.getUpload().isEnable());
				permissionDownload = (optionalDto != null && optionalDto.getDownload().isEnable());

				if (optionalDto != null && optionalDto.getDelete() != null
						&& optionalDto.getDelete().getFirst() != null) {
					model.setDeleteFirstLabel(optionalDto.getDelete().getFirst().getLabel());
				}
				if (optionalDto != null && optionalDto.getDelete() != null
						&& optionalDto.getDelete().getSecond() != null) {
					model.setDeleteSecondLabel(optionalDto.getDelete().getSecond().getLabel());
				}
				if (optionalDto != null && optionalDto.getDelete() != null
						&& optionalDto.getDelete().getThird() != null) {
					model.setDeleteThirdLabel(optionalDto.getDelete().getThird().getLabel());
				}
			} else {
				for (GeneralUserOperationAuthority operationAuth : userOperationAuthority) {
					if (operationAuth.compareTo(GeneralUserOperationAuthority.REFERENCE) == 0) {
						permissionReference = Boolean.TRUE;
					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.COPY) == 0) {

					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.DELETE) == 0) {
						permissionRemove = Boolean.TRUE && (optionalDto != null && optionalDto.getDelete().isEnable());

						permissionDeleteFirst = Boolean.TRUE && (optionalDto != null && optionalDto.getDelete() != null
								&& optionalDto.getDelete().getFirst() != null
								&& optionalDto.getDelete().getFirst().isEnable());
						permissionDeleteSecond = Boolean.TRUE && (optionalDto != null && optionalDto.getDelete() != null
								&& optionalDto.getDelete().getSecond() != null
								&& optionalDto.getDelete().getSecond().isEnable());
						permissionDeleteThird = Boolean.TRUE && (optionalDto != null && optionalDto.getDelete() != null
								&& optionalDto.getDelete().getThird() != null
								&& optionalDto.getDelete().getThird().isEnable());

						if (optionalDto != null && optionalDto.getDelete() != null
								&& optionalDto.getDelete().getFirst() != null) {
							model.setDeleteFirstLabel(optionalDto.getDelete().getFirst().getLabel());
						}
						if (optionalDto != null && optionalDto.getDelete() != null
								&& optionalDto.getDelete().getSecond() != null) {
							model.setDeleteSecondLabel(optionalDto.getDelete().getSecond().getLabel());
						}
						if (optionalDto != null && optionalDto.getDelete() != null
								&& optionalDto.getDelete().getThird() != null) {
							model.setDeleteThirdLabel(optionalDto.getDelete().getThird().getLabel());
						}

					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.INSERT) == 0) {
						// In case current user is not admin,
						// GeneralUserOperationAuthorityList hasn't declare
						// permission copy, I use perission INSERT
						permissionCopy = Boolean.TRUE && (optionalDto != null && optionalDto.getCopy() != null
								&& optionalDto.getCopy().isEnable());
						permissionInsert = Boolean.TRUE && (optionalDto != null && optionalDto.getInsert() != null
								&& optionalDto.getInsert().isEnable());
					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.UPDATE) == 0) {
						permissionUpdate = Boolean.TRUE && (optionalDto != null && optionalDto.getUpdate() != null
								&& optionalDto.getUpdate().isEnable());
					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.IMPORT) == 0) {
						permissionUpload = Boolean.TRUE && (optionalDto != null && optionalDto.getUpload() != null
								&& optionalDto.getUpload().isEnable());
					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.DOWNLOAD) == 0) {
						permissionDownload = Boolean.TRUE && (optionalDto != null && optionalDto.getDownload() != null
								&& optionalDto.getDownload().isEnable());
					}
				}

			}

		} else {
			if (userInfo.getUserAuthority() != null && userInfo.getUserAuthority().isSystemAdministrator()) {
				permissionReference = Boolean.TRUE;
				permissionCopy = Boolean.TRUE;
				permissionRemove = Boolean.TRUE;
				permissionDeleteFirst = Boolean.TRUE;
				permissionDeleteSecond = Boolean.TRUE;
				permissionDeleteThird = Boolean.TRUE;
				permissionInsert = Boolean.TRUE;
				permissionUpdate = Boolean.TRUE;
				permissionUpload = Boolean.TRUE;
				permissionDownload = Boolean.TRUE;
			} else {
				for (GeneralUserOperationAuthority operationAuth : userOperationAuthority) {
					if (operationAuth.compareTo(GeneralUserOperationAuthority.REFERENCE) == 0) {
						permissionReference = Boolean.TRUE;
					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.COPY) == 0) {

					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.DELETE) == 0) {
						permissionRemove = Boolean.TRUE;
					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.INSERT) == 0) {
						permissionInsert = Boolean.TRUE;
						permissionCopy = Boolean.TRUE;
					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.UPDATE) == 0) {
						permissionUpdate = Boolean.TRUE;
					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.IMPORT) == 0) {
						permissionUpload = Boolean.TRUE;
					} else if (operationAuth.compareTo(GeneralUserOperationAuthority.DOWNLOAD) == 0) {
						permissionDownload = Boolean.TRUE;
					}
				}
			}
		}

		model.setPermissionReference(permissionReference);
		model.setPermissionCopy(permissionCopy);
		model.setPermissionRemove(permissionRemove);
		model.setPermissionDeleteFirst(permissionDeleteFirst);
		model.setPermissionDeleteSecond(permissionDeleteSecond);
		model.setPermissionDeleteThird(permissionDeleteThird);
		model.setPermissionInsert(permissionInsert);
		model.setPermissionUpdate(permissionUpdate);
		model.setPermissionUpload(permissionUpload);
		model.setPermissionDownload(permissionDownload);

		return model;
	}

	/**
	 *
	 * @param model
	 * @param displayDef
	 * @param recordEditorInformationDTO
	 * @param columnDatas
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private ColumnAttributeItem[] createColumnAttributeItems(FRM0200LoadResultModel model,
			ColumnDisplayDefinitionDTO displayDef, RecordEditorInformationDTO recordEditorInformationDTO,
			Map<String, String> columnDatas, UserInfo userInfo, String actionType)
			throws ApplicationDomainLogicException {
		boolean isMultiTable = false;
		if (isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {
			isMultiTable = true;
		}
		Map<String, String> mapLabel = new HashMap<String, String>();
		for (final String columnId : columnDatas.keySet()) {
			final TableItemDTO item = displayDef.getItemDefinitions().get(columnId);
			if(columnId.equals(item.getItemId()))
			{
				mapLabel.put(item.getItemLabel(), columnDatas.get(columnId));
			}
		}
		RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		Map<String, SelectableItem[]> selectableMap = new HashMap<String, SelectableItem[]>();

		final List<ColumnAttributeItem> items = new ArrayList<ColumnAttributeItem>();
		// Only TableItemDTO is root
		Map<String, TableItemDTO> displayColumns = new HashMap<String, TableItemDTO>();
		for (Iterator<String> iterator = displayDef.getItemDefinitions().keySet().iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			if (displayDef.getItemDefinitions().get(key).isRoot()) {
				displayColumns.put(key, displayDef.getItemDefinitions().get(key));
			}
		}
		displayDef.getItemDefinitions().clear();
		displayDef.getItemDefinitions().putAll(displayColumns);

		final SortedMap<Integer, String> columnSortList = getColumnSortList(displayDef.getItemDefinitions());
		boolean isRadioItems = false;
		boolean isSelectItems = false;
		for (final Integer index : columnSortList.keySet()) {
			final String name = columnSortList.get(index);
			final TableItemDTO tableItemDTO = displayDef.getItemDefinitions().get(name);

			final ColumnAttributeItem item = new ColumnAttributeItem();
			item.setColumnAttribute(tableItemDTO.getHtmlElement());
			item.setColumnId(name);
			item.setColumnLabel(tableItemDTO.getItemLabel());
			item.setColumnExplanation(tableItemDTO.getExplanation());
			item.setDisplayRecordEdit(tableItemDTO.canDisplayRecordEdit());

			item.setEditing(tableItemDTO.canEditing());
			item.setUpdateKey(tableItemDTO.isUpdateKey());
			item.setCheckDataSelect(false);
			if (isMultiTable) {
				item.cols = tableItemDTO.getCols();
				item.operations = tableItemDTO.getOperations();
			}

			if (tableItemDTO.getHtmlElement() == DefinedHtmlElement.INPUT_RADIO) {
				item.setColumnRadio(columnDatas.get(name));
				isRadioItems = true;
				if (StringUtils.isEmpty(item.getColumnRadio()) || item.getColumnRadio() == ""
						|| StringUtils.isBlank(item.getColumnRadio())) {
					item.setCheckDataSelect(true);
				}
			} else if (tableItemDTO.getHtmlElement() == DefinedHtmlElement.SELECT) {
				item.setColumnSelect(columnDatas.get(name));
				item.setRelatedSelectItems(tableItemDTO.isRelatedSelectItems());
				isSelectItems = true;
				if (StringUtils.isEmpty(item.getColumnSelect()) || item.getColumnSelect() == ""
						|| StringUtils.isBlank(item.getColumnSelect())) {
					item.setCheckDataSelect(true);
				}
			} else {
				// ADD DBエースOracle日付対応 ↓
				// データ操作(複写)で
				// 「該当テーブルにおいてXMLで「tableForm->item」のisUpdatekeyがfalseの場合、データ操作(検索)画面から取得した値を項目にセットする」の後に以下の仕様が追加されるようにしてください
				// 既存値」：NULL以外の場合「既存値」を表示する
				// 「既存値」：NULLの場合、データベースの値で表示する。
				final DefinedHtmlElement element = tableItemDTO.getHtmlElement();
				final DefaultValueAnalysis compiler = new DefaultValueAnalysis(userInfo);
				String defaultValueInsert;
				String defaultValueUpdate;
				defaultValueInsert = compiler.analysis(tableItemDTO.getDefaultValue(), UpdatePattern.INSERT,"");
				defaultValueUpdate = compiler.analysis(tableItemDTO.getDefaultValue(), UpdatePattern.UPDATE,"");
				if (element == DefinedHtmlElement.INPUT_DATE || element == DefinedHtmlElement.INPUT_DATETIME
						|| element == DefinedHtmlElement.INPUT_TIMESTAMP || element == DefinedHtmlElement.INPUT_TIME) {
					String valueDsp = DateUtils.formatDateToString(columnDatas.get(name), element);
					if (actionType.equals(UpdateDivision.copy.getKey()) && !tableItemDTO.isUpdateKey()) {
						if (StringUtils.isEmpty(tableItemDTO.getDefaultValue()) || tableItemDTO.getDefaultValue() == ""
								|| StringUtils.isBlank(tableItemDTO.getDefaultValue())) {
							item.setColumnData(valueDsp);
						} else {
							item.setColumnData(defaultValueInsert);
						}

					} else {
						if (StringUtils.isEmpty(defaultValueUpdate) || defaultValueUpdate == ""
								|| StringUtils.isBlank(defaultValueUpdate)) {
							item.setColumnData(valueDsp);
						}
						else
						{
							item.setColumnData(defaultValueUpdate);
						}
					}
					// ADD DBエースOracle日付対応↑
				} else {
					if (actionType.equals(UpdateDivision.copy.getKey()) && !tableItemDTO.isUpdateKey()) {
						if (StringUtils.isEmpty(tableItemDTO.getDefaultValue()) || tableItemDTO.getDefaultValue() == ""
								|| StringUtils.isBlank(tableItemDTO.getDefaultValue())) {
							item.setColumnData(columnDatas.get(name));
						} else {
							item.setColumnData(defaultValueInsert);
						}
					} else {
						if (StringUtils.isEmpty(defaultValueUpdate) || defaultValueUpdate == ""
								|| StringUtils.isBlank(defaultValueUpdate)) {
							item.setColumnData(columnDatas.get(name));
						}
						else
						{
							item.setColumnData(defaultValueUpdate);
						}
					}
				}
			}

			// ラジオボタンデータ取得
			if ((tableItemDTO.getHtmlElement() == DefinedHtmlElement.INPUT_RADIO)
					|| (tableItemDTO.getHtmlElement() == DefinedHtmlElement.SELECT)) {
				if (!selectableMap.containsKey(tableItemDTO.getItemId())) {
					SelectableItem[] selectOneMenuItem = (SelectableItem[]) logic.getSelectableMap(tableItemDTO.getItemLabel(), mapLabel,
							recordEditorInformationDTO.getDbConnectInfomationDTO(), tableItemDTO);
					selectableMap.put(tableItemDTO.getItemId(), selectOneMenuItem);
					if(selectOneMenuItem.length>0)
					{
						Collections.sort(Arrays.asList(selectOneMenuItem), new Comparator<SelectableItem>() {
							public int compare(SelectableItem b1, SelectableItem b2) {
								return b1.getLabel().compareTo(b2.getLabel());
							}
						});
					}

					tableItemDTO.setSelectableItems(selectOneMenuItem);
				}
			}

			items.add(item);
		}

		// ラジオボタン、プルダウンのカラムがある場合は、ラジオボタン、プルダウン用のデータを取得
		if (isRadioItems || isSelectItems) {
			// ラジオボタンデータ取得
			for (final ColumnAttributeItem item : items) {
				if (item.getColumnAttribute() == DefinedHtmlElement.INPUT_RADIO) {
					SelectableItem[] radioItemMap = new SelectableItem[0];
					TableItemDTO tableItemDTO = displayColumns.get(item.getColumnId());
					if (selectableMap.get(tableItemDTO.getItemId()) != null) {
						radioItemMap = selectableMap.get(tableItemDTO.getItemId());
					}

					item.setColumnRadioItems(radioItemMap);
					item.setColumnData(item.getColumnRadio());
					boolean flagDataExists = false;
					for (SelectOneMenuItem selectOneMenuItem : item.getColumnRadioItems()) {
						if (selectOneMenuItem.getValue().equals(item.getColumnRadio())
								|| selectOneMenuItem.getLabel().equals(item.getColumnRadio())) {
							if ((model.getActionType().equals("delete")
									|| model.getActionType().equals("view"))) {
								item.setColumnData(item.getColumnRadio());
								item.setColumnRadio(selectOneMenuItem.getLabel());
							} else {
								item.setColumnData(selectOneMenuItem.getValue());
								item.setColumnRadio(selectOneMenuItem.getValue());
							}
							flagDataExists = true;
							item.setCheckDataSelect(true);
						}
					}
					if (!flagDataExists) {
						item.setColumnRadio("");
					}

				} else if (item.getColumnAttribute() == DefinedHtmlElement.SELECT) {
					SelectableItem[] selectItemMap = new SelectableItem[0];
					TableItemDTO tableItemDTO = displayColumns.get(item.getColumnId());
					if (selectableMap.get(tableItemDTO.getItemId()) != null) {
						selectItemMap = selectableMap.get(tableItemDTO.getItemId());
					}

					item.setColumnSelectItems(selectItemMap);
					item.setColumnData(item.getColumnSelect());
					boolean flagDataExists = false;
					for (SelectOneMenuItem selectOneMenuItem : item.getColumnSelectItems()) {
						if (selectOneMenuItem.getValue() != null
								&& selectOneMenuItem.getValue().equals(item.getColumnSelect())
								|| selectOneMenuItem.getLabel() != null
										&& selectOneMenuItem.getLabel().equals(item.getColumnSelect())) {

							if ((model.getActionType().equals("delete")
									|| model.getActionType().equals("view"))) {
								item.setColumnData(item.getColumnSelect());
								item.setColumnSelect(selectOneMenuItem.getLabel());
							} else {
								item.setColumnData(selectOneMenuItem.getValue());
								item.setColumnSelect(selectOneMenuItem.getValue());
							}
							flagDataExists = true;
							item.setCheckDataSelect(true);
						}

					}
					if (!flagDataExists) {
						item.setColumnSelect("");
					}

				}
			}
		}
		return items.toArray(new ColumnAttributeItem[0]);
	}

	/**
	 * リポジトリとデータベースのカラムが変更されているか否かを返します。
	 *
	 * @param dto
	 * @return 変更されている場合はtrue、変更されていない場合はfalse
	 */
	private boolean checkDifferenceOfColumnOnRepositoryAndDatabase(final ColumnDisplayDefinitionDTO dto) {
		final CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic logic = new CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic();
		return logic.isDifference(dto);
	}

	/**
	 * レコードの検索処理を行います。
	 * <p>
	 * ユーザーが入力した検索条件を元にレコードを検索し、結果をコレクションに 設定して戻します。
	 * </p>
	 * <p>
	 * 一回の検索で取得するレコード数は MAX_VIEWABLE_RECORD_COUNT 件です。
	 * </p>
	 *
	 * @param type
	 *            完全一致 / 曖昧検索モード指定
	 * @return RecordSearchResultDTO レコード検索結果 DTO
	 * @throws ApplicationDomainLogicException
	 */
	private RecordSearchResultDTO recordSearch(
			final FRM0200SearchParam searchParam, 
			final ColumnDisplayDefinitionDTO definitionDTO,
			RecordEditorInformationDTO tableDefinitionDTO) throws ApplicationDomainLogicException {
		// this.nowViewableRecordCount = 0;
		final RecordSearchConditionDTO dto = new RecordSearchConditionDTO();
		dto.setConnectDefinitionId(searchParam.getConnectDefinisionId());
		dto.setTableId(searchParam.getTableId());
		dto.setOffSet(searchParam.getOffSet());
		dto.setLimit(searchParam.getLimit());
		dto.setTopIndex(0);
		dto.setRecordCount(SystemProperties.getSearchMaxRecordCount());
//		dto.setTopIndex((pageNumber - 1) * pageSize);
//		dto.setRecordCount(pageSize);

		dto.setTypeOfRetrieval(TypeOfRetrieval.STRICTNESS);
		dto.setOrderAsc(searchParam.isOrderDesc() == false);

		int index = 0;
		for (final SearchConditionItem item : searchParam.getSearchConditionItems()) {
			if (item.exist()) {
				final SelectConditionItem condition = new SelectConditionItem();
				condition.setColumnId(item.getTargetedColumnId());
				condition.setComparisonOperator(SqlWhereTableComparisonOperator.valueOf(item.getComparisonOperator()));
				condition.setValue(item.getTargetedColumnSearchCondition());

				if (item.getLogicalOperator() == null) {
					condition.setLogicalOperator(SqlWhereTableLogicalOperator.blank);
				} else {
					condition.setLogicalOperator(SqlWhereTableLogicalOperator.valueOf(item.getLogicalOperator()));
				}

				final DefinitionOfColumn defColumn = definitionDTO.getDefinitionOfColumns()
						.get(item.getTargetedColumnId());
				condition.setJDBCMetaDataType(defColumn.getJDBCMetaDataType());
				condition.setColumnTypeName(defColumn.getColumnTypeName());

				dto.getConditions().put(index, condition);
				index++;
			}
		}
		
		//count data
		if(searchParam.isCountData()){
			final DbConnectInfomationDTO connectionInfo = tableDefinitionDTO.getDbConnectInfomationDTO();
			final TableFormDTO tableFormDTO = tableDefinitionDTO.getTableForm();
			final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			final int resultRowCount = logic.getCountRecord(dto, connectionInfo, tableFormDTO);
			final RecordSearchResultDTO result = new RecordSearchResultDTO();
			result.setResultRowCount(resultRowCount);
			return result;
		}

		return new RetrievalProcessingOfRecordFromDatabaseLogic().getRecords(
				dto,
				tableDefinitionDTO.getDbConnectInfomationDTO(), 
				tableDefinitionDTO.getTableDef(),
				tableDefinitionDTO.getTableForm(), 
				searchParam.getAction(),
				searchParam.getUserInfo());
	}

	/**
	 *
	 * @param connectDefinisionId
	 * @param tableFormId
	 * @return
	 */
	private boolean isMultiTable(final String connectDefinisionId, final String tableFormId)
			throws ApplicationDomainLogicException {
		final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
		return logic.isMultiTable(connectDefinisionId, tableFormId);
	}

	/**
	 *
	 * @param tableId
	 * @param itemId
	 * @return
	 */
	private String formatColumn(String tableId, String itemId, boolean isMulti) {
		TableIdDefinition tableIdDefinition = new TableIdDefinition(tableId);
		if (isMulti) {
			return String.format("\"%s\".\"%s\".\"%s\"", tableIdDefinition.getSchem(), tableIdDefinition.getTable(),
					itemId);
		} else {
			return String.format("\"%s\".\"%s\"", tableIdDefinition.getTable(), itemId);
		}
	}

	/**
	 * ラジオボタンを作成して戻します。
	 *
	 * @param columnDatas
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private Map<String, SelectableItem[]> createRadioItems(final Map<String, String> columnDatas,
			String selectedConnectDefinisionId, String tableId, RecordEditorInformationDTO recordEditorInformationDTO,
			UserInfo userInfo) throws ApplicationDomainLogicException {
		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		// final UserInfo userInfo = getUserInfo();
		final ColumnDisplayDefinitionDTO columnDef;
		columnDef = logic.getColumnDisplayDefinition(selectedConnectDefinisionId, tableId, columnDatas,
				recordEditorInformationDTO.getDbConnectInfomationDTO(), recordEditorInformationDTO.getTableDef(),
				recordEditorInformationDTO.getTableForm(), userInfo.getName());

		final Map<String, SelectableItem[]> ret = new HashMap<String, SelectableItem[]>();

		for (final String columnName : columnDef.getItemDefinitions().keySet()) {
			ret.put(columnName, columnDef.getItemDefinitions().get(columnName).getSelectableItems());
		}

		return ret;
	}

	/**
	 * プルダウンリストを作成して戻します。
	 *
	 * @param columnDatas
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private Map<String, SelectableItem[]> createSelectItems(final Map<String, String> columnDatas,
			String selectedConnectDefinisionId, String tableId, RecordEditorInformationDTO recordEditorInformationDTO,
			UserInfo userInfo) throws ApplicationDomainLogicException {
		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		// final UserInfo userInfo = getUserInfo();
		final ColumnDisplayDefinitionDTO columnDef;
		columnDef = logic.getColumnDisplayDefinition(selectedConnectDefinisionId, tableId, columnDatas,
				recordEditorInformationDTO.getDbConnectInfomationDTO(), recordEditorInformationDTO.getTableDef(),
				recordEditorInformationDTO.getTableForm(), userInfo.getName());

		final Map<String, SelectableItem[]> ret = new HashMap<String, SelectableItem[]>();

		for (final String columnName : columnDef.getItemDefinitions().keySet()) {
			ret.put(columnName, columnDef.getItemDefinitions().get(columnName).getSelectableItems());
		}

		return ret;
	}

	/**
	 * リポジトリとデータベースのカラムが変更されているか否かを返します。
	 *
	 * @param dto
	 * @return 変更されている場合はtrue、変更されていない場合はfalse
	 * @throws ApplicationDomainLogicException
	 */
	private boolean checkDifferenceOfColumnOnRepositoryAndDatabase(final String connectDefinisionId,
			final String tableId, final ColumnDisplayDefinitionDTO dto) throws ApplicationDomainLogicException {
		final CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic logic = new CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic();
		return logic.isDifference(connectDefinisionId, tableId, dto);
	}

	/**
	 * リポジトリに登録されている表示順で整列されたカラムIDのマップを返します。
	 *
	 * @param map
	 * @return
	 */
	private SortedMap<Integer, String> getColumnSortList(final Map<String, TableItemDTO> map) {
		final SortedMap<Integer, String> ret = new TreeMap<Integer, String>();
		for (final String columnId : map.keySet()) {
			final TableItemDTO item = map.get(columnId);
			ret.put(item.getSortIndex(), columnId);
		}
		return ret;
	}
	//
	// /**
	// * レコードの検索処理を行います。
	// * <p>
	// * ユーザーが入力した検索条件を元にレコードを検索し、結果をコレクションに 設定して戻します。
	// * </p>
	// * <p>
	// * 一回の検索で取得するレコード数は MAX_VIEWABLE_RECORD_COUNT 件です。
	// * </p>
	// *
	// * @param type
	// * 完全一致 / 曖昧検索モード指定
	// * @return RecordSearchResultDTO レコード検索結果 DTO
	// * @throws ApplicationDomainLogicException
	// */
	// private RecordSearchResultDTO searchOneRecord(final Map<String,
	// DefinitionOfColumn> definitionOfColumns,
	// String selectedConnectDefinisionId, String tableId,
	// RecordEditorInformationDTO recordEditorInformationDTO,
	// ColumnPrimaryKeyItem columnPrimaryKeyItem, UserInfo userInfo, String
	// action)
	// throws ApplicationDomainLogicException {
	// final RecordSearchConditionDTO dto = new RecordSearchConditionDTO();
	// dto.setConnectDefinitionId(selectedConnectDefinisionId);
	// dto.setTableId(tableId);
	// dto.setTopIndex(0);
	// dto.setRecordCount(1);
	// dto.setTypeOfRetrieval(TypeOfRetrieval.STRICTNESS);
	// dto.setOrderAsc(true);
	//
	// int index = 0;
	// for (final String name : columnPrimaryKeyItem.getColumnData().keySet()) {
	// final SelectConditionItem condition = new SelectConditionItem();
	// condition.setColumnId(name);
	// condition.setComparisonOperator(SqlWhereTableComparisonOperator.equal);
	// condition.setValue(columnPrimaryKeyItem.getColumnData().get(name));
	// condition.setJDBCMetaDataType(columnPrimaryKeyItem.getColumnjdbcMetaDataType().get(name));
	// condition.setColumnTypeName(definitionOfColumns.get(name).getColumnTypeName());
	//
	// if (index < (columnPrimaryKeyItem.getColumnData().size() - 1)) {
	// condition.setLogicalOperator(SqlWhereTableLogicalOperator.and);
	// } else {
	// condition.setLogicalOperator(SqlWhereTableLogicalOperator.blank);
	// }
	//
	// dto.getConditions().put(index, condition);
	//
	// index++;
	// }
	//
	// return new
	// RetrievalProcessingOfRecordFromDatabaseLogic().getOneRecord(dto,
	// recordEditorInformationDTO.getDbConnectInfomationDTO(),
	// recordEditorInformationDTO.getTableDef(),
	// recordEditorInformationDTO.getTableForm(), userInfo, action);
	// }

	/**
	 * 登録時のカラムIDとカラムデータデフォルト値のマップを生成して戻します。
	 *
	 * @param map
	 * @return
	 */
	private Map<String, String> createDefaultColumnDataMap(final Map<String, TableItemDTO> map, UserInfo userInfo) {
		final Map<String, String> ret = new HashMap<String, String>();
		final DefaultValueAnalysis constantCompiler = new DefaultValueAnalysis(userInfo);
		final ColumnPrimaryKeyItem columnPrimaryKeyItem = new ColumnPrimaryKeyItem();
		final UpdateDivision division = UpdateDivision.keyOf(columnPrimaryKeyItem.getUpdateDivision());
		final UpdatePattern updatePattern;
		if (division == UpdateDivision.insert || division == UpdateDivision.copy) {
			updatePattern = UpdatePattern.INSERT;
		} else {
			updatePattern = UpdatePattern.UPDATE;
		}

		for (final String name : map.keySet()) {
			final TableItemDTO dto = map.get(name);
			ret.put(name, constantCompiler.analysis(dto.getDefaultValue(), updatePattern, ""));
		}
		return ret;
	}

	/**
	 * 更新時のカラムIDとカラムデータデフォルト値のマップを生成して戻します。
	 *
	 * @param map
	 * @return
	 */
	/*
	 * private Map<String, String> createDefaultColumnDataMap(final Map<String,
	 * TableItemDTO> map, final Map<String, String> columDatas, UserInfo
	 * userInfo) { final Map<String, String> ret = new HashMap<String,
	 * String>(); final DefaultValueAnalysis constantCompiler = new
	 * DefaultValueAnalysis(userInfo); final ColumnPrimaryKeyItem
	 * columnPrimaryKeyItem = new ColumnPrimaryKeyItem(); final UpdateDivision
	 * division =
	 * UpdateDivision.keyOf(columnPrimaryKeyItem.getUpdateDivision()); final
	 * UpdatePattern updatePattern; if (division == UpdateDivision.insert ||
	 * division == UpdateDivision.copy) { updatePattern = UpdatePattern.INSERT;
	 * } else { updatePattern = UpdatePattern.UPDATE; } for (final String name :
	 * map.keySet()) { final TableItemDTO dto = map.get(name); String
	 * defaultValue; if (division == UpdateDivision.copy) {
	 *
	 * if (columnPrimaryKeyItem.getColumnData().containsKey(name)) {
	 * defaultValue = dto.getDefaultValue(); } else { defaultValue =
	 * columDatas.get(name); }
	 *
	 * defaultValue = dto.getDefaultValue(); if (null == defaultValue || 0 ==
	 * defaultValue.length()) { if
	 * (columnPrimaryKeyItem.getColumnData().containsKey(name)) { defaultValue =
	 * null; } else { defaultValue = columDatas.get(name); } }
	 *
	 * } else { defaultValue = dto.getDefaultValue(); } ret.put(name,
	 * constantCompiler.analysis(defaultValue, updatePattern,
	 * columDatas.get(name))); } return ret; }
	 */

	/**
	 *
	 * 更新可能な項目か否か。
	 * <p>
	 * リポジトリ情報の更新可能区分を判定し、該当カラムが編集可能かどうかを返します。<BR />
	 * なお、更新処理の場合、該当カラムがキー項目の場合は編集可能項目であっても、編集不可(false)を返します。
	 * </p>
	 *
	 * @param tableItemDTO
	 * @param updateDivision
	 * @return
	 */
	private boolean canEditing(final TableItemDTO tableItemDTO, final UpdateDivision updateDivision) {

		if (tableItemDTO.canEditing()) {
			if (updateDivision == UpdateDivision.update && tableItemDTO.isUpdateKey()) {
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}
	}

	/**
	 * レコード一覧テーブルのヘッダ要素配列を生成して戻します。
	 * <p>
	 * テーブルのカラム名を表示するヘッダ要素の配列を生成して戻します。
	 * </p>
	 * <p>
	 * 一覧表示に表示する、更新処理の際のキー項目が設定されているカラムのみ 表示します。
	 * </p>
	 *
	 * @param dto
	 * @return
	 */
	@SuppressWarnings("unused")
	private SearchResultHeaderItem[] createHeaderItemArray(final ColumnDisplayDefinitionDTO dto) {
		final SortedMap<Integer, SearchResultHeaderItem> smap = new TreeMap<Integer, SearchResultHeaderItem>();
		final SortedMap<Integer, String> columns = getColumnSortList(dto.getItemDefinitions());
		for (final Integer index : columns.keySet()) {
			final String column = columns.get(index);
			final TableItemDTO def = dto.getItemDefinitions().get(column);
			if (def != null && (def.canPreview() || def.isUpdateKey())) {
				final SearchResultHeaderItem item = new SearchResultHeaderItem();
				item.setColumnId(def.getItemId());
				item.setColumnLabel(def.getItemLabel());
				item.setJdbcMetaData(
						dto.getDefinitionOfColumns().get(def.getItemId()).getJDBCMetaDataType().getDataType());

				if (dto.getDefinitionOfColumns().get(def.getItemId()).isPrimaryKey() || def.isUpdateKey()) {
					item.setPrimaryKey(true);
				} else {
					item.setPrimaryKey(false);
				}

				item.setCanPreview(def.canPreview());

				smap.put(index, item);
			}
		}
		final SearchResultHeaderItem[] ret = new SearchResultHeaderItem[1];
		ret[0] = new SearchResultHeaderItem();
		ret[0].setSearchResultHeaderDetailItems(
				smap.values().toArray(new SearchResultHeaderItem[smap.values().size()]));
		return ret;
	}

	/**
	 * @author LUONG THI THANH TRUC
	 * @version 6.0 Mar 31, 2017 「登録」ボタンのイベントハンドラ。
	 *          リポジトリとDBのカラム情報を比較し、DBが変更(ALTER等)されていた場合は、 エラーメッセージを表示します。
	 *          選択された行のプライマリキー情報、カラムデータをSessionに保存し、 対象レコード編集画面要素に新規登録モードで遷移します。
	 * @return Class
	 */

	@Override
	public FRM0200DataResultModel doInsertTable(FRM0200DataParam model) throws ApplicationDomainLogicException {
		FRM0200DataResultModel resultModel = new FRM0200DataResultModel();
		resultModel.setStatus(true);
		MessageInfo error = new MessageInfo();
		ColumnDisplayDefinitionDTO displayDef = new ColumnDisplayDefinitionDTO();
		RecordEditorInformationDTO recordEditorInformationDTO = new RecordEditorInformationDTO();
		ColumnPrimaryKeyItem columnPrimaryKeyItem = new ColumnPrimaryKeyItem();
		try {
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO;
			tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			model.setTableLabel(tableFormDTO.getTableFormLabel());

			final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			recordEditorInformationDTO = recordFromDatabaseLogic.getRecordEditorInformation(
					model.getConnectDefinisionId(), tableFormDTO, model.getUserInfo().getId());

			// Check selected table is multi-table?
			displayDef = recordFromDatabaseLogic.getColumnsDisplay(model.getConnectDefinisionId(), model.getTableId(),
					recordEditorInformationDTO, model.getUserInfo().getId());
			if (checkDifferenceOfColumnOnRepositoryAndDatabase(model.getConnectDefinisionId(), model.getTableId(),
					displayDef)) {
				// MI-E-0121=データベースの項目（カラム）情報が変更されています。アプリケーション管理者にご連絡ください。
				// addPageMessage(MessageUtils.getMessage("MI-E-0121"));
				error = new MessageInfo("MI-E-0121", MessageType.ERROR, messageService);
				resultModel.getMessageInfo().add(error);
				return resultModel;
			}
			columnPrimaryKeyItem.setUpdateDivision(UpdateDivision.insert.getKey());
			columnPrimaryKeyItem.setTableId(model.getTableId());

			final UpdateDivision division = UpdateDivision.keyOf(columnPrimaryKeyItem.getUpdateDivision());
			final List<ColumnAttributeItem> items = new ArrayList<ColumnAttributeItem>();
			Map<String, String> columnDatas = new HashMap<String, String>();
			columnDatas = createDefaultColumnDataMap(displayDef.getItemDefinitions(), model.getUserInfo());
			Map<String, TableItemDTO> displayColumns = new HashMap<String, TableItemDTO>();
			for (Iterator<String> iterator = displayDef.getItemDefinitions().keySet().iterator(); iterator.hasNext();) {
				String key = (String) iterator.next();
				if (displayDef.getItemDefinitions().get(key).isRoot()) {
					displayColumns.put(key, displayDef.getItemDefinitions().get(key));
				}
			}
			displayDef.getItemDefinitions().clear();
			displayDef.getItemDefinitions().putAll(displayColumns);

			final SortedMap<Integer, String> columnSortList = getColumnSortList(displayDef.getItemDefinitions());
			boolean isRadioItems = false;
			boolean isSelectItems = false;
			for (final Integer index : columnSortList.keySet()) {
				final String name = columnSortList.get(index);
				final TableItemDTO tableItemDTO = displayDef.getItemDefinitions().get(name);

				final ColumnAttributeItem item = new ColumnAttributeItem();
				item.setColumnAttribute(tableItemDTO.getHtmlElement());
				item.setColumnId(name);
				item.setColumnLabel(tableItemDTO.getItemLabel());
				item.setColumnExplanation(tableItemDTO.getExplanation());
				item.setDisplayRecordEdit(tableItemDTO.canDisplayRecordEdit());
				item.setUpdateKey(tableItemDTO.isUpdateKey());
				item.setEditing(canEditing(tableItemDTO, division));
				if (isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {
					item.cols = tableItemDTO.getCols();
					item.operations = tableItemDTO.getOperations();
				}

				if (tableItemDTO.getHtmlElement() == DefinedHtmlElement.INPUT_RADIO) {
					item.setColumnRadio(columnDatas.get(name));
					isRadioItems = true;
				} else if (tableItemDTO.getHtmlElement() == DefinedHtmlElement.SELECT) {
					item.setColumnSelect(columnDatas.get(name));
					item.setRelatedSelectItems(tableItemDTO.isRelatedSelectItems());
					isSelectItems = true;
				} else {
					// ADD DBエースOracle日付対応 ↓
					/*
					 * final DefinedHtmlElement element =
					 * tableItemDTO.getHtmlElement(); if (element ==
					 * DefinedHtmlElement.INPUT_DATE || element ==
					 * DefinedHtmlElement.INPUT_DATETIME || element ==
					 * DefinedHtmlElement.INPUT_TIMESTAMP) { String valueDsp =
					 * DateUtils.formatDateToString(columnDatas.get(name),
					 * element); item.setColumnData(valueDsp); // ADD
					 * DBエースOracle日付対応↑ } else {
					 * item.setColumnData(columnDatas.get(name)); }
					 */
					final DefaultValueAnalysis compiler = new DefaultValueAnalysis(model.getUserInfo());
					String defaultValueInsert;
					defaultValueInsert = compiler.analysis(tableItemDTO.getDefaultValue(), UpdatePattern.INSERT,"");
					item.setColumnData(defaultValueInsert);
				}
				items.add(item);
			}

			// ラジオボタン、プルダウンのカラムがある場合は、ラジオボタン、プルダウン用のデータを取得
			if (isRadioItems || isSelectItems) {
				// ラジオボタンデータ取得
				Map<String, SelectableItem[]> radioItemMap = null;
				if (isRadioItems) {
					radioItemMap = createRadioItems(columnDatas, model.getConnectDefinisionId(), model.getTableId(),
							recordEditorInformationDTO, model.getUserInfo());
					for (Iterator<SelectableItem[]> iterator = radioItemMap.values().iterator(); iterator
							.hasNext();) {
						SelectableItem[] selectOneMenuItem = (SelectableItem[]) iterator.next();
						Collections.sort(Arrays.asList(selectOneMenuItem), new Comparator<SelectableItem>() {
							public int compare(SelectableItem b1, SelectableItem b2) {
								return b1.getLabel().compareTo(b2.getLabel());
							}
						});
					}
				}

				Map<String, SelectableItem[]> selectItemMap = null;
				// プルダウンデータ取得
				if (isSelectItems) {
					selectItemMap = createSelectItems(columnDatas, model.getConnectDefinisionId(), model.getTableId(),
							recordEditorInformationDTO, model.getUserInfo());
					for (Iterator<SelectableItem[]> iterator = selectItemMap.values().iterator(); iterator
							.hasNext();) {
						SelectableItem[] selectOneMenuItem = (SelectableItem[]) iterator.next();
						Collections.sort(Arrays.asList(selectOneMenuItem), new Comparator<SelectOneMenuItem>() {
							public int compare(SelectOneMenuItem b1, SelectOneMenuItem b2) {
								return b1.getLabel().compareTo(b2.getLabel());
							}
						});

					}
				}

				for (final ColumnAttributeItem item : items) {
					if (item.getColumnAttribute() == DefinedHtmlElement.INPUT_RADIO) {
						item.setColumnRadioItems(radioItemMap.get(item.getColumnId()));
					} else if (item.getColumnAttribute() == DefinedHtmlElement.SELECT) {
						item.setColumnSelectItems(selectItemMap.get(item.getColumnId()));
					}
				}
			}
			resultModel.columnAttributeItems = items.toArray(new ColumnAttributeItem[0]);
			resultModel.setConnectDefinisionId(model.getConnectDefinisionId());
			resultModel.setTableId(model.getTableId());
			if (isMultiTable(model.getConnectDefinisionId(), model.getTableId())) {
				resultModel.setTypeTable(true);

			} else {
				resultModel.setTypeTable(false);
			}
		} catch (final ApplicationDomainLogicException e) {
			// addPageMessage(e);
			resultModel.setStatus(false);
			resultModel.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			return resultModel;
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
			// addPageMessage(e.getMessage());
			resultModel.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			return resultModel;
		}
		return resultModel;
	}

	/**
	 * カラムデータのチェック処理を行います。
	 *
	 * @param form
	 * @param columnDef
	 */
	private FRM0200DataResultModel checkColumnData(List<ColumnAttributeItemDTO> attributeItems,
			String selectedConnectDefinisionId, String tableId, RecordEditorInformationDTO recordEditorInformationDTO,
			UserInfo userInfo) throws ApplicationDomainLogicException {
		FRM0200DataResultModel resultModel = new FRM0200DataResultModel();
		MessageInfo error = new MessageInfo();
		boolean isCheck = true;
		final Map<String, String> columnDataItems = new HashMap<String, String>();
		for (ColumnAttributeItemDTO item : attributeItems) {
			if (isMultiTable(selectedConnectDefinisionId, tableId)) {
				for (TableItemDTO tableItemDTO : recordEditorInformationDTO.getTableForm().getTableItemMap().values()) {
					if (tableItemDTO.isUpdateKey()) {
						if (item.getColumnId().equals(tableItemDTO.getItemId())) {
							if (StringUtils.isEmpty(item.getColumnData()) || StringUtils.isBlank(item.getColumnData())
									|| item.getColumnData() == null || item.getColumnData() == "") {
								isCheck = false;
								String[] args = { tableItemDTO.getItemLabel() };
								if (tableItemDTO.getHtmlElement().getKey().equals(DefinedHtmlElement.SELECT.getKey())
										|| tableItemDTO.getHtmlElement().getKey()
												.equals(DefinedHtmlElement.INPUT_RADIO.getKey())) {
									// MI-E-00081={0}を選択してください
									error = new MessageInfo("MI-E-00081", MessageType.ERROR, args, messageService);
								} else {
									// MI-E-0008={0}を入力してください
									error = new MessageInfo("MI-E-0008", MessageType.ERROR, args, messageService);
								}
								error.setId(tableItemDTO.getItemId());
								resultModel.getMessageInfo().add(error);
								break;

							}
						}
					}
				}
			}

			columnDataItems.put(item.getColumnId(), item.getColumnData());
		}
		final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		final ColumnDisplayDefinitionDTO columnDef = recordFromDatabaseLogic
				.getColumnsDisplay(selectedConnectDefinisionId, tableId, recordEditorInformationDTO, userInfo.getId());

		final LogicalCheckCommand logicalCheckCommand = new LogicalCheckCommand(columnDef);
		final CheckMessageDTO checkMessageDTO = logicalCheckCommand.check(
				recordEditorInformationDTO.getDbConnectInfomationDTO(), columnDataItems,
				recordEditorInformationDTO.getTableForm().getTableItemMap());

		for (ColumnAttributeItemDTO item : attributeItems) {
			if (checkMessageDTO.hasWarning(item.getColumnId())) {
				for (final String message : checkMessageDTO.getMessages(item.getColumnId())) {
					isCheck = false;
					// TODO:表示メッセージをかえるか、出力場所を変更する
					error = new MessageInfo(message, MessageType.ERROR, messageService);
					error.setId(item.getColumnId());
					resultModel.getMessageInfo().add(error);
				}
			}
		}
		resultModel.setStatus(isCheck);
		return resultModel;
	}

	/**
	 * 関連カラムデータの更新ボタン押下時のイベントハンドラを登録するか否かを返します。
	 * <p>
	 * プルダウンに関連カラムデータがある場合は、 onchageイベントのjavascriptを返します。
	 * </p>
	 *
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public FRM0200DataResultModel getColumnSelectPulldownOnchange(FRM0200DataParam model) throws ApplicationDomainLogicException {
		FRM0200DataResultModel resultModel = new FRM0200DataResultModel();
		ColumnAttributeItem[] attributeItems = model.getAttributeItems();
		Integer columnAttributeIndex = model.getColumnAttributeIndex();
		resultModel.setStatus(true);
		if (null == attributeItems)
			return null;
		if (attributeItems[columnAttributeIndex].isRelatedSelectItems()) {
			RecordEditorInformationDTO recordEditorInformationDTO = new RecordEditorInformationDTO();
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			TableFormDTO tableFormDTO;
			tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			recordEditorInformationDTO = recordFromDatabaseLogic.getRecordEditorInformation(
								model.getConnectDefinisionId(), tableFormDTO, model.getUserInfo().getId());
			/*return "onchangeSelectItem('" + attributeItems[columnAttributeIndex].getColumnId() + "')";*/
			doUpdateOfRelatedItem(attributeItems, attributeItems[columnAttributeIndex].getColumnLabel(), recordEditorInformationDTO, model.getUserInfo());
			resultModel.setColumnAttributeItems(attributeItems);
		} else {
			resultModel.setStatus(false);
		}
		return resultModel;
	}

	   /**
     * プルダウンリストを作成して戻します。
     *
     * @param columnDatas
     * @return
     * @throws ApplicationDomainLogicException
     */
    public Map<String, SelectableItem[]> createSelectItemsChange(
            final String columnLabel,
            final Map<String, String> columnDatas,
            RecordEditorInformationDTO recordEditorInformationDTO,
			UserInfo userInfo)
            throws ApplicationDomainLogicException {
        final RetrievalProcessingOfRecordFromDatabaseLogic logic
            = new RetrievalProcessingOfRecordFromDatabaseLogic();
        final Map<String, SelectableItem[]> selecteItems;
        selecteItems = logic.setSelectableMap(
                            columnLabel,
                            columnDatas,
                            recordEditorInformationDTO.getDbConnectInfomationDTO(),
                            recordEditorInformationDTO.getTableForm(),
                            userInfo.getName());

        final Map<String, SelectableItem[]> ret
            = new HashMap<String, SelectableItem[]>();
        for (final String id : selecteItems.keySet()) {
            final SelectableItem[] selectableItems
                = selecteItems.get(id);
            ret.put(id, selectableItems);
        }

        return ret;
    }

	/**
     * 関連カラムデータの更新ボタン押下時のイベントハンドラ。
     *
     * <p>
     * プルダンリストを再取得します。
     * </p>
	 * @throws ApplicationDomainLogicException
     */
    public void doUpdateOfRelatedItem(ColumnAttributeItem[] columnAttributeItems, String changedColumnLabel, RecordEditorInformationDTO recordEditorInformationDTO,
			UserInfo userInfo) throws ApplicationDomainLogicException {
        final Map<String, String> columnDatas = new HashMap<String, String>();
        for (final ColumnAttributeItem item : columnAttributeItems) {
            if (item.getColumnAttribute()
                    == DefinedHtmlElement.SELECT) {
                columnDatas.put(item.getColumnLabel(), item.getColumnSelect());
            } else if (item.getColumnAttribute()
                        == DefinedHtmlElement.INPUT_RADIO) {
                columnDatas.put(item.getColumnLabel(), item.getColumnRadio());
            } else {
                columnDatas.put(item.getColumnLabel(), item.getColumnData());
            }
        }
        try {
            final Map<String, SelectableItem[]> map
                = createSelectItemsChange(changedColumnLabel, columnDatas, recordEditorInformationDTO, userInfo);

            for (final ColumnAttributeItem item : columnAttributeItems) {
                if (item.getColumnAttribute()
                        == DefinedHtmlElement.SELECT) {
                    if (map.containsKey(item.getColumnId())) {
                    	item.setColumnSelect(null);
                        item.setColumnSelectItems(map.get(item.getColumnId()));
                    }
                }
            }
        } catch (final ApplicationDomainLogicException e) {
        	logger.error(e.getMessage());
			throw new ApplicationDomainLogicException(e.getMessage());
        }
    }

	/**
	 * 新規登録、更新、削除データをマップに詰め替えます。
	 *
	 * @param columnMap
	 *            columnId,columnDataのマップ
	 */
	private Map<String, String> createUpdateColumnMap(List<ColumnAttributeItemDTO> attributeItems) {
		final Map<String, String> columnMap = new HashMap<String, String>();
		for (ColumnAttributeItemDTO item : attributeItems) {
			columnMap.put(item.getColumnId(), item.getColumnData());
		}
		return columnMap;
	}

	/**
	 * @author LUONG THI THANH TRUC
	 * @version 6.0 Mar 31, 2017 データベースにレコードの新規登録、更新処理を行います。
	 */
	private FRM0200DataResultModel save(List<ColumnAttributeItemDTO> attributeItems, String connectDefinisionId,
			String tableId, RecordEditorInformationDTO recordEditorInformationDTO,
			ColumnPrimaryKeyItem columnPrimaryKeyItem, UserInfo userInfo) throws ApplicationDomainLogicException {
		FRM0200DataResultModel resultModel = new FRM0200DataResultModel();
		resultModel.setStatus(true);
		MessageInfo error = new MessageInfo();
		final Map<String, String> columnMap = createUpdateColumnMap(attributeItems);
		final UpdateDivision div = UpdateDivision.keyOf(columnPrimaryKeyItem.getUpdateDivision());
		Map<String, FRM0200TableFormDTO> listTableFormDTO = new HashMap<String, FRM0200TableFormDTO>();
		RecordEditInputDto param = new RecordEditInputDto();
		param.setDbConnectInfomationDTO(recordEditorInformationDTO.getDbConnectInfomationDTO());
		// UserInfo userInfo = getUserInfo();
		param.setUserInfo(userInfo);
		param.setConnectDefinitionId(connectDefinisionId);
		param.setTableId(tableId);
		param.setUserInfo(userInfo);
		param.setAttributeItems(attributeItems);
		param.setRecordEditorInformationDTO(recordEditorInformationDTO);
		// Check status table
		Boolean isCheck = false;
		// Muilti Table
		if (isMultiTable(connectDefinisionId, tableId)) {
			final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			TableFormDTO tableFormDTO;
			tableFormDTO = logic.getTableFormDTO(connectDefinisionId, tableId);
			// ①該当テーブルにおいてXMLで「tableForm->tables->table」のCommitNOが「1」から順番に次の処理を行う
			// ※2つのテーブルを用いたマルチテーブルの場合、2回処理を行う
			List<TableDto> tableDtoList = new ArrayList<>(tableFormDTO.getTableMap().values());
			Collections.sort(tableDtoList, new Comparator<TableDto>() {
				@Override
				public int compare(final TableDto o1, final TableDto o2) {
					return o1.getCommitNO().compareTo(o2.getCommitNO());
				}
			});
			for (TableDto tab : tableDtoList) {
				FRM0200TableFormDTO fRM0200TableFormDTO = new FRM0200TableFormDTO();
				List<ItemMultiDto> keyItems = new ArrayList<ItemMultiDto>();
				List<ItemMultiDto> keyNotItems = new ArrayList<ItemMultiDto>();
				List<ItemMultiDto> items = new ArrayList<ItemMultiDto>();
				Map<String, String> itemAdd = new HashMap<String, String>();
				Map<String, String> itemNotNull = new HashMap<String, String>();
				TableFormDTO tableFormDTOChild = new TableFormDTO();
				tableFormDTOChild = logic.getTableFormDTO(connectDefinisionId, tab.getId());
				RecordEditorInformationDTO recordEditorDTO = new RecordEditorInformationDTO();
				recordEditorDTO = recordFromDatabaseLogic.getRecordEditorInformation(connectDefinisionId,
						tableFormDTOChild, userInfo.getId());
				final AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
				final TableFormDTO tableFormDto = acquisitionOfTableLogic.getTableFormDTO(connectDefinisionId,
						tab.getId());
				if (recordEditorDTO.getDbConnectInfomationDTO().getDatabaseTypeConnectionDestination().getKey()
						.equals(DatabaseTypeConnectionDestination.Oracle.getKey())) {
					Map<String, TableItemDTO> itemMap = new HashMap<String, TableItemDTO>();
					for (Iterator<TableItemDTO> iterator = recordEditorDTO.getTableForm().getTableItemMap().values()
							.iterator(); iterator.hasNext();) {
						TableItemDTO itemSet = (TableItemDTO) iterator.next();
						if (itemSet.getHtmlElement().getKey().equals(DefinedHtmlElement.INPUT_DATE.getKey())
								|| itemSet.getHtmlElement().getKey().equals(DefinedHtmlElement.INPUT_DATETIME.getKey())
								|| itemSet.getHtmlElement().getKey().equals(DefinedHtmlElement.INPUT_TIME.getKey())) {
							itemSet.setHtmlElement(DefinedHtmlElement.INPUT_TIMESTAMP);
						} else {
							itemSet.setHtmlElement(itemSet.getHtmlElement());
						}
						itemMap.put(itemSet.getItemId(), itemSet);
					}
					recordEditorDTO.getTableForm().setTableItemMap(itemMap);
					tableFormDto.setTableItemMap(itemMap);
				}

				Boolean statusCheckItem = false;
				if (tableFormDto == null) {
					// MI-E-0033=テーブル情報が存在しません。
					throw new ApplicationDomainLogicException(MessageUtils.getMessage("MI-E-0033"));
				}
				// 該当テーブルにおいてXMLで「tableForm->tables->table->item」のisUpdateKeyがtrueの項目を洗い出す
				for (final ItemMultiDto item : tab.getItemMultiDto()) {
					if (item.isUpdateKey()) {
						keyItems.add(item);
					} else {
						keyNotItems.add(item);
					}
					items.add(item);
				}
				SortedMap<Integer, SelectConditionItem> listConditions = new TreeMap<Integer, SelectConditionItem>();
				// RDBの該当テーブルに対して、上記の項目に対して画面の値をセットし、件数を取得する
				for (int i = 0; i < keyItems.size(); i++) {
					ItemMultiDto col = keyItems.get(i);
					for (ColumnAttributeItemDTO item : attributeItems) {
						if (tableFormDTO.getTableItemMap().keySet().contains(item.getColumnId())) {
							Collection<ColDto> colDtos = tableFormDTO.getTableItemMap().get(item.getColumnId())
									.getCols().values();
							for (ColDto colDto : colDtos) {
								if (colDto.getTableID().equals(tab.getId())) {
									if (col.getId().equals(colDto.getItemID())) {
										SelectConditionItem condition = new SelectConditionItem();

										if (i == 0 || (i > 0 && i < keyItems.size() - 1)) {
											if (keyItems.size() > 1) {
												condition.setLogicalOperator(SqlWhereTableLogicalOperator.and);
											}
										}
										if (keyItems.size() > 0) {
											condition.setComparisonOperator(SqlWhereTableComparisonOperator.equal);
										} else {
											condition.setComparisonOperator(SqlWhereTableComparisonOperator.isNull);
										}
										condition.setColumnId(col.getId());
										condition.setColumnTypeName(col.getId());
										condition.setValue(item.getColumnData());
										condition.setJDBCMetaDataType(recordEditorDTO.getTableDef()
												.getDefinitionOfColumnMap().get(col.getId()).getJDBCMetaDataType());
										listConditions.put(i, condition);
									}

								}
							}
						}
					}
				}

				RecordSearchConditionDTO addCondition = new RecordSearchConditionDTO();
				addCondition.setConnectDefinitionId(connectDefinisionId);
				addCondition.setTableId(tab.getId());
				addCondition.getConditions().putAll(listConditions);
				addCondition.setTypeOfRetrieval(TypeOfRetrieval.STRICTNESS);

				// RDBの該当テーブルに対して、上記の項目に対して画面の値をセットし、件数を取得する
				int countSQL = recordFromDatabaseLogic.getCountRecords(addCondition,
						recordEditorInformationDTO.getDbConnectInfomationDTO(), tab);
				// 結果が「0,1」以外のテーブルがある場合、「XXXテーブルのキー設定が不正です。」のエラーメッセージを出力し、処理を終了する
				if (countSQL > 1) {
					String[] args = { tableFormDto.getTableFormLabel() };
					error = new MessageInfo("FRM0200.add.E1-002", MessageType.ERROR, args, messageService);
					resultModel.getMessageInfo().add(error);
					resultModel.setStatus(false);
					return resultModel;
					// ②各テーブルへのメンテナンスが、「INSERT、UPDATE、なにもしない」のいずれかか、処理順(CommitNO)の順番で判断する
				} else {
					// List all item in Table
					for (ColumnAttributeItemDTO itemValue : attributeItems) {
						if (tableFormDTO.getTableItemMap().keySet().contains(itemValue.getColumnId())) {
							Collection<ColDto> colDtos = tableFormDTO.getTableItemMap().get(itemValue.getColumnId())
									.getCols().values();
							for (ColDto colDto : colDtos) {
								if (colDto.getTableID().equals(tab.getId())) {
									if (!itemAdd.containsKey(colDto.getItemID())) {
										itemAdd.put(colDto.getItemID(), itemValue.getColumnData());
									}
								}
							}
						}
					}

					// Check Item IsUpdateKey Is Null
					for (int j = 0; j < keyNotItems.size(); j++) {
						ItemMultiDto columns = keyNotItems.get(j);
						for (ColumnAttributeItemDTO itemValue : attributeItems) {
							if (columns.getId().equals(itemValue.getColumnId())) {
								if (StringUtils.isEmpty(itemValue.getColumnData())
										|| StringUtils.isBlank(itemValue.getColumnData())
										|| (itemValue.getColumnData() == null)) {
									itemNotNull.put(itemValue.getColumnId(), itemValue.getColumnData());
									break;
								}
							}
						}
					}
					if (itemNotNull.size() == keyNotItems.size()) {
						statusCheckItem = true;
					}

					for (OptionalMultiDto optionalMultiDto : tab.getOptionalMultiDto()) {
						// ①の件数が0件の場合
						if (countSQL == 0) {
							// データ操作(登録)画面----------------------------------------------------------------------------------------
							if (div == UpdateDivision.insert) {
								// XMLで「tableForm->tables->table->optional->insert」のNotAddNewが「false」の場合
								// 処理対象のテーブルはINSERT
								if (!optionalMultiDto.getInsert().isNotAddNew()) {
									fRM0200TableFormDTO.setCountRecord(0);
									fRM0200TableFormDTO.setTableFormDTO(tableFormDto);
									fRM0200TableFormDTO.setListItem(itemAdd);
									fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
									fRM0200TableFormDTO.setStatus(false);
									listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
								} else {
									// XMLで「tableForm->tables->table->optional->insert」のNotAddNewが「true」の場合
									// 処理対象のテーブルの項目でisUpdateKeyの値が「false」の項目でいずれかの画面上の値がある場合は、INSERT
									if (!statusCheckItem) {
										fRM0200TableFormDTO.setCountRecord(0);
										fRM0200TableFormDTO.setTableFormDTO(tableFormDto);
										fRM0200TableFormDTO.setListItem(itemAdd);
										fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
										fRM0200TableFormDTO.setStatus(false);
										listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
									}
									// 処理対象のテーブルの項目でisUpdateKeyの値が「false」の項目すべてが、画面上、値無しの場合、なにも行わない
									else {
										fRM0200TableFormDTO.setStatus(true);
										listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
									}
								}
							}
							// データ操作(編集)画面----------------------------------------------------------------------------------------
							if (div == UpdateDivision.update) {
								// ①の件数が0件のテーブルはINSERT処理になる
								fRM0200TableFormDTO.setCountRecord(0);
								fRM0200TableFormDTO.setTableFormDTO(tableFormDto);
								fRM0200TableFormDTO.setListItem(itemAdd);
								fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
								fRM0200TableFormDTO.setStatus(false);
								listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
							}
							// データ操作(複写)画面----------------------------------------------------------------------------------------
							if (div == UpdateDivision.copy) {
								// XMLで「tableForm->tables->table->optional->copy」のNotAddNewが「false」の場合
								// 処理対象のテーブルはINSERT
								if (!optionalMultiDto.getCopy().isNotAddNew()) {
									fRM0200TableFormDTO.setCountRecord(0);
									fRM0200TableFormDTO.setTableFormDTO(tableFormDto);
									fRM0200TableFormDTO.setListItem(itemAdd);
									fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
									fRM0200TableFormDTO.setStatus(false);
									listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
								}
								// XMLで「tableForm->tables->table->optional->copy」のNotAddNewが「true」の場合
								// 処理対象のテーブルの項目でisUpdateKeyの値が「false」の項目でいずれかの画面上の値がある場合は、INSERT
								else {
									if (!statusCheckItem) {
										fRM0200TableFormDTO.setCountRecord(0);
										fRM0200TableFormDTO.setTableFormDTO(tableFormDto);
										fRM0200TableFormDTO.setListItem(itemAdd);
										fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
										fRM0200TableFormDTO.setStatus(false);
										listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
									}
									// 処理対象のテーブルの項目でisUpdateKeyの値が「false」の項目すべてが、画面上、値無しの場合、なにも行わない
									else {
										fRM0200TableFormDTO.setStatus(true);
										listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
									}
								}
							}
						}
						// ①の件数が1件の場合
						if (countSQL == 1) {
							if (div == UpdateDivision.insert) {
								// XMLで「tableForm->tables->table->optional->insert」のOverWriteが「true」の場合
								// 処理対象のテーブルはUPDATE
								if (optionalMultiDto.getInsert().isOverWrite()) {
									fRM0200TableFormDTO.setCountRecord(1);
									fRM0200TableFormDTO.setTableFormDTO(recordEditorDTO.getTableForm());
									fRM0200TableFormDTO.setListItem(itemAdd);
									fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
									fRM0200TableFormDTO.setStatus(false);
									listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
								}
								// XMLで「tableForm->tables->table->optional->insert」のOverWriteが「false」の場合
								// 処理対象のテーブルはなにも行わない
								else {
									fRM0200TableFormDTO.setStatus(true);
									listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
								}
							}
							// データ操作(編集)画面----------------------------------------------------------------------------------------
							if (div == UpdateDivision.update) {
								// XMLで「tableForm->tables->table->optional->update」のDeleteが「true」の場合
								if (optionalMultiDto.getUpdate().isDelete()) {
									// 処理対象のテーブルの項目でisUpdateKeyの値が「false」の項目すべてが、画面上、値無しの場合DELETE
									if (statusCheckItem) {
										fRM0200TableFormDTO.setCountRecord(2);
										fRM0200TableFormDTO.setTableFormDTO(recordEditorDTO.getTableForm());
										fRM0200TableFormDTO.setListItem(itemAdd);
										fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
										fRM0200TableFormDTO.setRecordSearchConditionDTO(addCondition);
										fRM0200TableFormDTO.setStatus(false);
										listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
									}
									// 処理対象のテーブルの項目でisUpdateKeyの値が「false」の項目でいずれかの画面上の値がある場合は、次の処理へ進む
									else {
										// 「tableForm->tables->table->optional->update」のNotOverWriteが「false」の場合
										// 処理対象のテーブルはUPDATE
										if (!optionalMultiDto.getUpdate().isNotOverWrite()) {
											fRM0200TableFormDTO.setCountRecord(1);
											fRM0200TableFormDTO.setTableFormDTO(recordEditorDTO.getTableForm());
											fRM0200TableFormDTO.setListItem(itemAdd);
											fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
											fRM0200TableFormDTO.setStatus(false);
											listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
										}
										// 「tableForm->tables->table->optional->update」のNotOverWriteが「true」の場合
										// 処理対象のテーブルはなにも行わない
										else {
											fRM0200TableFormDTO.setStatus(true);
											listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
										}
									}
								}
								// XMLで「tableForm->tables->table->optional->update」のDeleteが「false」の場合
								else {
									// 「tableForm->tables->table->optional->update」のNotOverWriteが「false」の場合
									// 処理対象のテーブルはUPDATE
									if (!optionalMultiDto.getUpdate().isNotOverWrite()) {
										fRM0200TableFormDTO.setCountRecord(1);
										fRM0200TableFormDTO.setTableFormDTO(recordEditorDTO.getTableForm());
										fRM0200TableFormDTO.setListItem(itemAdd);
										fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
										fRM0200TableFormDTO.setStatus(false);
										listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
									}
									// 「tableForm->tables->table->optional->update」のNotOverWriteが「true」の場合
									// 処理対象のテーブルはなにも行わない
									else {
										fRM0200TableFormDTO.setStatus(true);
										listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
									}
								}
							}
							// データ操作(複写)画面----------------------------------------------------------------------------------------
							if (div == UpdateDivision.copy) {
								// XMLで「tableForm->tables->table->optional->copy」のOverWriteが「true」の場合
								// 処理対象のテーブルはUPDATE
								if (optionalMultiDto.getCopy().isOverWrite()) {
									fRM0200TableFormDTO.setCountRecord(1);
									fRM0200TableFormDTO.setTableFormDTO(recordEditorDTO.getTableForm());
									fRM0200TableFormDTO.setListItem(itemAdd);
									fRM0200TableFormDTO.setRecordEditorDTO(recordEditorDTO);
									fRM0200TableFormDTO.setStatus(false);
									listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
								}
								// XMLで「tableForm->tables->table->optional->copy」のOverWriteが「false」の場合
								// 処理対象のテーブルはなにも行わない
								else {
									fRM0200TableFormDTO.setStatus(true);
									listTableFormDTO.put(tab.getId(), fRM0200TableFormDTO);
								}

							}
						}
						param.setListTableFormDTO(listTableFormDTO);
					}
				}
			}
			// NotAddNewやNotOverWriteなどの組み合わせで、結果としてINSERTもUPDATEも行わなかったときです
			// その場合は、何か処理した時と同じく「データをXXしました」と表示してください。
			// 「登録画面の設定、及びデータ内容により、どのオブジェクトにもデータ操作を行いませんでした」
			// 「編集画面の設定、及びデータ内容により、どのオブジェクトにもデータ操作を行いませんでした」
			// 「複写画面の設定、及びデータ内容により、どのオブジェクトにもデータ操作を行いませんでした」

			for (Iterator<FRM0200TableFormDTO> iterator = param.getListTableFormDTO().values().iterator(); iterator
					.hasNext();) {
				FRM0200TableFormDTO fRM0200TableFormDto = (FRM0200TableFormDTO) iterator.next();

				if (fRM0200TableFormDto.status == false) {
					isCheck = true;
				}
			}

			if (isCheck == false) {
				if (div == UpdateDivision.insert) {
					error = new MessageInfo("FRM0200.add.E1-004", MessageType.INFO, messageService);
					resultModel.getMessageInfo().add(error);
					resultModel.setStatus(false);
					return resultModel;
				} else if (div == UpdateDivision.update) {
					error = new MessageInfo("FRM0200.edit.E1-004", MessageType.INFO, messageService);
					resultModel.getMessageInfo().add(error);
					resultModel.setStatus(false);
					return resultModel;
				} else {
					error = new MessageInfo("FRM0200.copy.E1-004", MessageType.INFO, messageService);
					resultModel.getMessageInfo().add(error);
					resultModel.setStatus(false);
					return resultModel;
				}
			} else {
				// Start Transaction
				final RecordAddUpdateProcessingOfDatabaseLogic logicAdd = new RecordAddUpdateProcessingOfDatabaseLogic();
				try {
					// ③RDBへのデータメンテナンスを処理順(CommitNO)の順番で行う。トランザクションの開始
					// ②で決まったINSERT、UPDATE、なにもしない のいずれかの処理を行う
					logicAdd.execute(param);
				} catch (ApplicationDomainLogicException e) {
					// 処理の途中でエラーとなった場合は、ロールバックを行い、「XXX(テーブル表示名)の(INSERT、UPDATE)処理でエラーになりました。」とエラーメッセージを出力。
					// 成功した場合は、「登録を行いました」成功メッセージを出力し、画面を閉じます。
					logger.error(e.getMessage(), e);
					error = new MessageInfo(e.getMessage(), MessageType.ERROR, messageService);
					resultModel.getMessageInfo().add(error);
					resultModel.setStatus(false);
					return resultModel;
				}
			}

		} else {
			// Table
			final AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
			final TableFormDTO tableFormDto = acquisitionOfTableLogic.getTableFormDTO(connectDefinisionId, tableId);
			if (tableFormDto == null) {
				// MI-E-0033=テーブル情報が存在しません。
				error = new MessageInfo("MI-E-0033", MessageType.ERROR, messageService);
				resultModel.getMessageInfo().add(error);
				resultModel.setStatus(false);
				return resultModel;
			}
			if (recordEditorInformationDTO.getDbConnectInfomationDTO().getDatabaseTypeConnectionDestination().getKey()
					.equals(DatabaseTypeConnectionDestination.Oracle.getKey())) {
				Map<String, TableItemDTO> itemMap = new HashMap<String, TableItemDTO>();
				for (Iterator<TableItemDTO> iterator = recordEditorInformationDTO.getTableForm().getTableItemMap()
						.values().iterator(); iterator.hasNext();) {
					TableItemDTO itemSet = (TableItemDTO) iterator.next();
					if (itemSet.getHtmlElement().getKey().equals(DefinedHtmlElement.INPUT_DATE.getKey())
							|| itemSet.getHtmlElement().getKey().equals(DefinedHtmlElement.INPUT_DATETIME.getKey())
							|| itemSet.getHtmlElement().getKey().equals(DefinedHtmlElement.INPUT_TIME.getKey())) {
						itemSet.setHtmlElement(DefinedHtmlElement.INPUT_TIMESTAMP);
					} else {
						itemSet.setHtmlElement(itemSet.getHtmlElement());
					}
					itemMap.put(itemSet.getItemId(), itemSet);
				}
				recordEditorInformationDTO.getTableForm().setTableItemMap(itemMap);
				tableFormDto.setTableItemMap(itemMap);
			}
			param.setTableFormDto(tableFormDto);
			List<TableItemDTO> listKey = new ArrayList<TableItemDTO>();
			for (Iterator<TableItemDTO> iterator = recordEditorInformationDTO.getTableForm().getTableItemMap().values()
					.iterator(); iterator.hasNext();) {
				TableItemDTO itemDto = (TableItemDTO) iterator.next();
				if (itemDto.isUpdateKey()) {
					listKey.add(itemDto);
				}
			}
			if (listKey.size() > 0) {
				// ListKey > 0
				final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
				SortedMap<Integer, SelectConditionItem> listConditions = new TreeMap<Integer, SelectConditionItem>();
				for (int i = 0; i < listKey.size(); i++) {
					TableItemDTO col = listKey.get(i);
					for (ColumnAttributeItemDTO item : attributeItems) {
						if (col.getItemId().equals(item.getColumnId())) {
							SelectConditionItem condition = new SelectConditionItem();

							if (i == 0 || (i > 0 && i < listKey.size() - 1)) {
								if (listKey.size() > 1) {
									condition.setLogicalOperator(SqlWhereTableLogicalOperator.and);
								}
							}
							if (listKey.size() > 0) {
								condition.setComparisonOperator(SqlWhereTableComparisonOperator.equal);
							} else {
								condition.setComparisonOperator(SqlWhereTableComparisonOperator.isNull);
							}
							condition.setColumnId(col.getItemId());
							condition.setColumnTypeName(col.getItemId());
							condition.setValue(item.getColumnData());
							condition.setJDBCMetaDataType(recordEditorInformationDTO.getTableDef()
									.getDefinitionOfColumnMap().get(col.getItemId()).getJDBCMetaDataType());
							listConditions.put(i, condition);
						}

					}
				}
				RecordSearchConditionDTO addCondition = new RecordSearchConditionDTO();
				addCondition.setConnectDefinitionId(connectDefinisionId);
				addCondition.setTableId(tableId);
				addCondition.getConditions().putAll(listConditions);
				addCondition.setTypeOfRetrieval(TypeOfRetrieval.STRICTNESS);
				// RDBの該当テーブルに対して、上記の項目に対して画面の値をセットし、件数を取得する
				int countSQL = recordFromDatabaseLogic.getCountRecord(addCondition,
						recordEditorInformationDTO.getDbConnectInfomationDTO(),
						recordEditorInformationDTO.getTableForm());
				// データ操作(登録)画面とデータ操作(複写)画面----------------------------------------------------------------------------------------
				if (div == UpdateDivision.insert || div == UpdateDivision.copy) {
					if (countSQL == 0)
					// 上記エラーでない場合、RDBへINSERTを行う
					{
						param.setColumnMap(columnMap);
						final RecordAdditionProcessingToDatabaseLogic logicAdd = new RecordAdditionProcessingToDatabaseLogic();
						try {
							logicAdd.execute(param);
						} catch (ApplicationDomainLogicException e) {
							resultModel.setStatus(false);
							logger.error(e.getMessage(), e);
							error = new MessageInfo(e.getMessage(), MessageType.ERROR, messageService);
							resultModel.getMessageInfo().add(error);
							return resultModel;
						}

					} else {
						// 該当テーブルにおいてXMLで「tableForm->item」のisUpdatekeyがtrueの場合、その項目をWHERE条件としてセットしRDBへSELECTを行う
						// 結果が「0」以外の場合、「既にデータが登録されているか、XXXテーブルのキー設定が不正です。」のエラーメッセージを出力し、処理を終了する
						String[] args = { tableFormDto.getTableFormLabel() };
						error = new MessageInfo("FRM0200.add.E1-001", MessageType.ERROR, args, messageService);
						resultModel.getMessageInfo().add(error);
						resultModel.setStatus(false);
						return resultModel;
					}
				}
				// データ操作(編集)画面----------------------------------------------------------------------------------------
				if (div == UpdateDivision.update) {
					if (countSQL == 1)
					// 上記エラーでない場合、該当テーブルにおいてXMLで「tableForm->item」のisUpdatekeyがtrueの場合、その項目をWHERE条件としてセットしRDBへUPDATEを行う
					{
						param.setColumnMap(columnMap);
						final RecordUpdateProcessingOfDatabaseLogic logicUpdate = new RecordUpdateProcessingOfDatabaseLogic();
						try {
							logicUpdate.execute(param);
						} catch (ApplicationDomainLogicException e) {
							resultModel.setStatus(false);
							logger.error(e.getMessage(), e);
							error = new MessageInfo(e.getMessage(), MessageType.ERROR, messageService);
							resultModel.getMessageInfo().add(error);
							return resultModel;
						}

					} else {
						// 該当テーブルにおいてXMLで「tableForm->item」のisUpdatekeyがtrueの場合、その項目をWHERE条件としてセットしRDBへSELECTを行う
						// 結果が「1」以外の場合、「XXXテーブルのキー設定が不正です。」のエラーメッセージを出力し、処理を終了する
						resultModel.setStatus(false);
						String[] args = { tableFormDto.getTableFormLabel() };
						error = new MessageInfo("FRM0200.add.E1-002", MessageType.ERROR, args, messageService);
						resultModel.getMessageInfo().add(error);
						return resultModel;
					}
				}
			} else {
				// 該当テーブルにおいてXMLで「tableForm->item」のisUpdatekeyがtrueの項目が1つもない場合、
				// 「XXXテーブルのキー設定が不正です。」のエラーメッセージを出力し、処理を終了する
				String[] args = { tableFormDto.getTableFormLabel() };
				resultModel.setStatus(false);
				error = new MessageInfo("FRM0200.add.E1-002", MessageType.ERROR, args, messageService);
				resultModel.getMessageInfo().add(error);
				return resultModel;
			}
		}
		if (div == UpdateDivision.insert || div == UpdateDivision.copy) {
			error = new MessageInfo("FRM0200.add.S1-001", MessageType.SUCCESS, messageService);
			resultModel.getMessageInfo().add(error);
			return resultModel;
		} else {
			error = new MessageInfo("FRM0200.edit.S1-001", MessageType.SUCCESS, messageService);
			resultModel.getMessageInfo().add(error);
			return resultModel;
		}
	}

	/**
	 * @author LUONG THI THANH TRUC
	 * @version 6.0 Mar 31, 2017 保存して、検索画面に戻るボタン押下のイベントハンドラ
	 *          対象データを登録・更新し、編集対象レコード検索画面要素へ遷移します。
	 * @return
	 */
	@Override
	public FRM0200DataResultModel doOnceSaveDataTable(FRM0200DataParam model) throws ApplicationDomainLogicException {
		FRM0200DataResultModel resultModel = new FRM0200DataResultModel();
		resultModel.setStatus(true);
		MessageInfo error = new MessageInfo();
		RecordEditorInformationDTO recordEditorInformationDTO = new RecordEditorInformationDTO();
		final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
		TableFormDTO tableFormDTO;
		try {
			tableFormDTO = logic.getTableFormDTO(model.getConnectDefinisionId(), model.getTableId());
			model.setTableLabel(tableFormDTO.getTableFormLabel());

			ColumnPrimaryKeyItem columnPrimaryKeyItem = new ColumnPrimaryKeyItem();
			if (model.getType().equals(UpdateDivision.insert.getKey())) {
				columnPrimaryKeyItem.setUpdateDivision(UpdateDivision.insert.getKey());
			} else if (model.getType().equals(UpdateDivision.update.getKey())) {
				columnPrimaryKeyItem.setUpdateDivision(UpdateDivision.update.getKey());
			} else {
				columnPrimaryKeyItem.setUpdateDivision(UpdateDivision.copy.getKey());
			}
			columnPrimaryKeyItem.setTableId(model.getTableId());
			final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			recordEditorInformationDTO = recordFromDatabaseLogic.getRecordEditorInformation(
					model.getConnectDefinisionId(), tableFormDTO, model.getUserInfo().getId());
			FRM0200DataResultModel resultCheckColumnData = checkColumnData(model.getColumnAttributeItems(),
					model.getConnectDefinisionId(), model.getTableId(), recordEditorInformationDTO,
					model.getUserInfo());
			List<ColumnAttributeItemDTO> columnAttributeItems = new ArrayList<ColumnAttributeItemDTO>();
			for (ColumnAttributeItemDTO item : model.getColumnAttributeItems()) {
				ColumnAttributeItemDTO columnAttribute = new ColumnAttributeItemDTO();
				if (recordEditorInformationDTO.getDbConnectInfomationDTO().getDatabaseTypeConnectionDestination()
						.getKey().equals(DatabaseTypeConnectionDestination.Oracle.getKey())) {
					if (tableFormDTO.getTableItemMap().get(item.getColumnId()).getHtmlElement().getKey()
							.equals(DefinedHtmlElement.INPUT_DATE.getKey())
							|| tableFormDTO.getTableItemMap().get(item.getColumnId()).getHtmlElement().getKey()
									.equals(DefinedHtmlElement.INPUT_DATETIME.getKey())
							|| tableFormDTO.getTableItemMap().get(item.getColumnId()).getHtmlElement().getKey()
									.equals(DefinedHtmlElement.INPUT_TIME.getKey()))

					{
						columnAttribute.setColumnId(item.getColumnId());
						if (!StringUtils.isEmpty(item.getColumnData())) {
							if (tableFormDTO.getTableItemMap().keySet().contains(item.getColumnId())) {
								if (tableFormDTO.getTableItemMap().get(item.getColumnId()).getHtmlElement().getKey()
										.equals(DefinedHtmlElement.INPUT_DATE.getKey())) {
									columnAttribute.setColumnData(
											item.getColumnData().concat(DateUtils.TIMESTAMP_ZERO_FORMAT));
								}
								if (tableFormDTO.getTableItemMap().get(item.getColumnId()).getHtmlElement().getKey()
										.equals(DefinedHtmlElement.INPUT_DATETIME.getKey())) {
									columnAttribute.setColumnData(item.getColumnData().concat(DateUtils.ZERO_FORMAT));
								}
								if (tableFormDTO.getTableItemMap().get(item.getColumnId()).getHtmlElement().getKey()
										.equals(DefinedHtmlElement.INPUT_TIME.getKey())) {
									DateFormat dateFormat = new SimpleDateFormat(DateUtils.DATE_FORMAT);
									Date date = new Date();
									columnAttribute.setColumnData(dateFormat.format(date).toString()
											.concat(" " + item.getColumnData() + DateUtils.ZERO_FORMAT));
								}
							}

						} else {
							columnAttribute.setColumnData(item.getColumnData());
						}
					} else {
						columnAttribute.setColumnId(item.getColumnId());
						columnAttribute.setColumnData(item.getColumnData());
					}
					columnAttributeItems.add(columnAttribute);
				}
			}
			
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			try {
				Class<?> cls = Class.forName(String.format("%s.Ext_%s%s", "jp.co.systemexe.dbu.dbace.validator",
						model.getTableId().replace('.', '_'), "Validator"));
				Method meth = null;
				Map<String, String> map = new HashMap<String, String>();

				try {
					meth = cls.getMethod("validate", new Class[] { Map.class });
					for (ColumnAttributeItemDTO item : columnAttributeItems) {
						map.put(item.getColumnId(), item.getColumnData());
					}
				} catch (Exception e) {
					getLogger().debug(e.getMessage(), e);
					e.printStackTrace();
				}

				try {
					meth.invoke(cls.newInstance(), new Object[] { map });
				} catch (IllegalArgumentException e) {
					// TODO 閾ｪ蜍慕函謌舌＆繧後◆ catch 繝悶Ο繝�繧ｯ
					e.printStackTrace();
					getLogger().debug(e.getMessage(), e);
				} catch (IllegalAccessException e) {
					// TODO 閾ｪ蜍慕函謌舌＆繧後◆ catch 繝悶Ο繝�繧ｯ
					e.printStackTrace();
					getLogger().debug(e.getMessage(), e);
				} catch (InvocationTargetException e) {
					if (e.getCause() instanceof ApplicationDomainLogicException) {
						error = new MessageInfo(e.getCause().getMessage(), MessageType.ERROR);
						resultModel.getMessageInfo().add(error);
						resultModel.setStatus(false);
						return resultModel;
						//throw (ApplicationDomainLogicException) e.getCause();
					}
					// TODO 閾ｪ蜍慕函謌舌＆繧後◆ catch 繝悶Ο繝�繧ｯ
					e.printStackTrace();
					getLogger().debug(e.getMessage(), e);
				} catch (InstantiationException e) {
					// TODO 閾ｪ蜍慕函謌舌＆繧後◆ catch 繝悶Ο繝�繧ｯ
					e.printStackTrace();
					getLogger().debug(e.getMessage(), e);
				}
			} catch (ClassNotFoundException e) {
				getLogger().debug(e.getMessage(), e);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

			if (resultCheckColumnData.isStatus()) {
				if (recordEditorInformationDTO.getDbConnectInfomationDTO().getDatabaseTypeConnectionDestination()
						.getKey().equals(DatabaseTypeConnectionDestination.Oracle.getKey())) {
					FRM0200DataResultModel doInsertData = save(columnAttributeItems, model.getConnectDefinisionId(),
							model.getTableId(), recordEditorInformationDTO, columnPrimaryKeyItem, model.getUserInfo());
					resultModel.setStatus(doInsertData.isStatus());
					resultModel.setMessageInfo(doInsertData.getMessageInfo());

				} else {
					FRM0200DataResultModel doInsertData = save(model.getColumnAttributeItems(),
							model.getConnectDefinisionId(), model.getTableId(), recordEditorInformationDTO,
							columnPrimaryKeyItem, model.getUserInfo());
					resultModel.setStatus(doInsertData.isStatus());
					resultModel.setMessageInfo(doInsertData.getMessageInfo());
				}
			} else {
				resultModel.setMessageInfo(resultCheckColumnData.getMessageInfo());
				resultModel.setStatus(false);
				return resultModel;
			}
		} catch (final ApplicationDomainLogicException e) {
			error = new MessageInfo(e.getMessage(), MessageType.ERROR, messageService);
			resultModel.getMessageInfo().add(error);
			resultModel.setStatus(false);
			return resultModel;
		}
		return resultModel;
	}

	@Override
	public FileImportResultDTO importFile(String connectDefinisionId, String tableId, String fileUploadPath,
			String characterEncodingType, boolean skipErrors, boolean overwriteData, UserInfo userInfo)
			throws ApplicationDomainLogicException {
		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		RecordEditorInformationDTO dto = null;
		InputStream is = null;
		final File uploadFile = new File(fileUploadPath);
		try {
			dto = logic.getRecordEditorInformation(connectDefinisionId, tableId, userInfo.getId());
			final UploadFileType fileType = UploadFileType
					.extensionOf(fileUploadPath.substring(fileUploadPath.lastIndexOf(".") + 1));
			is = new FileInputStream(uploadFile);
			final FileImportInformationDTO importDTO = new FileImportInformationDTO();
			importDTO.setFileEncode(characterEncodingType);
			importDTO.setUploadFileType(fileType);
			importDTO.setIgnoreError(skipErrors);
			importDTO.setSuperscribeUpdate(overwriteData);
			importDTO.setRecordEditorInformationDTO(dto);
			final ImportFromFileToTableLogic importLogic = new ImportFromFileToTableLogic();
			/*insert data to database*/
			final String filePath = importLogic.imports(connectDefinisionId, importDTO, is, userInfo);
			int index = filePath.lastIndexOf("\\");
			String fileNameResult = filePath.substring(index + 1);
			final AcquisitionOfFileImportResultLogic logicResult = new AcquisitionOfFileImportResultLogic();
			FileImportResultDTO fileImportResultDTO = logicResult.getFileImportResultDAO(fileNameResult);
			List<ResultMessageItem> resultMessageItems = new ArrayList<ResultMessageItem>();
			for (Integer rowCount : fileImportResultDTO.getErrorMessage().keySet()) {
				final ResultMessageItem item = new ResultMessageItem();
				item.setRowCount(rowCount);
				item.setMessage(fileImportResultDTO.getErrorMessage().get(rowCount));
				resultMessageItems.add(item);
			}
			fileImportResultDTO.setResultMessageItems(resultMessageItems);
			return fileImportResultDTO;
		} catch (final ApplicationDomainLogicException e) {
			logger.error(e.getMessage());
			throw new ApplicationDomainLogicException(e.getMessage());
		} catch (IOException e) {
			// MI-E-0128=インポートファイルの読み込みに失敗しました。
			final String message = MessageUtils.getMessage("MI-E-0128");
			logger.error(message);
		} catch (final OutOfMemoryError e) {
			// MI-E-0149=取込むデータ件数が多すぎます。データ件数を絞り込んでください。
			final String message = MessageUtils.getMessage("MI-E-0149");
			logger.error(message);
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (final IOException e) {
					logger.warn(e.toString());
				}
			}
			if (!uploadFile.delete()) {
				final String args[] = { fileUploadPath };
				logger.warn(MessageUtils.getMessage("MI-W-0002", args));
			}
		}
		return null;
	}

	/**
	 * @param connectDefinitionId
	 * @param tableFormMultiTableId
	 * @return
	 * @throws DAOException
	 */
	public TableFormDto getTableMulti(String connectDefinitionId, String tableFormMultiTableId) throws DAOException {
		AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
		try {
			TableFormDAO tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
			TableFormDto dto = new TableFormDto();
			dto.setId(tableFormMultiTableId);
			TableForm tableForm = tableFormDAO.getTargetTableFormMulti(connectDefinitionId, dto);
			return new TableFormDto(tableForm);
		} catch (ApplicationDomainLogicException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@Override
	public FileImportResultDTO importFileMultiTable(String connectDefinisionId, String tableId, String fileUploadPath,
			String characterEncodingType, boolean skipErrors, boolean overwriteData, UserInfo userInfo)
			throws ApplicationDomainLogicException {
		FileImportResultDTO fileImportResultDTO = new FileImportResultDTO();
		List<ResultMessageItem> resultMessageItems = new ArrayList<ResultMessageItem>();
		final UploadFileType fileType = UploadFileType
				.extensionOf(fileUploadPath.substring(fileUploadPath.lastIndexOf(".") + 1));
		InputStream is = null;
		final File uploadFile = new File(fileUploadPath);
		try {
			is = new FileInputStream(uploadFile);
			final FileImportInformationDTO importDTO = new FileImportInformationDTO();
			importDTO.setFileEncode(characterEncodingType);
			importDTO.setUploadFileType(fileType);
			importDTO.setIgnoreError(skipErrors);
			importDTO.setSuperscribeUpdate(overwriteData);
			// importDTO.setRecordEditorInformationDTO(dto);
			//import data to database
			final ImportFromFileToTableLogic importLogic = new ImportFromFileToTableLogic();
			final String filePath = importLogic.importsMultiTable(connectDefinisionId, tableId, importDTO, is, userInfo);
			int index = filePath.lastIndexOf("\\");
			String fileNameResult = filePath.substring(index + 1);
			final AcquisitionOfFileImportResultLogic logicResult = new AcquisitionOfFileImportResultLogic();
			FileImportResultDTO fileImportResult = logicResult.getFileImportResultDAO(fileNameResult);
			List<ResultMessageItem> resultMessageItemsDTO = new ArrayList<ResultMessageItem>();
			for (Integer rowCount : fileImportResult.getErrorMessage().keySet()) {
				final ResultMessageItem item = new ResultMessageItem();
				item.setRowCount(rowCount);
				item.setMessage(fileImportResult.getErrorMessage().get(rowCount));
				resultMessageItemsDTO.add(item);
			}
			fileImportResult.setResultMessageItems(resultMessageItemsDTO);
			fileImportResultDTO.setTotalCount(fileImportResult.getTotalCount());
			fileImportResultDTO.setValidateErrorCount(fileImportResult.getValidateErrorCount());
			fileImportResultDTO.setInsertSuccessCount(fileImportResult.getInsertSuccessCount());
			fileImportResultDTO.setInsertErrorCount(fileImportResult.getInsertErrorCount());
			fileImportResultDTO.setUpdateSuccessCount(fileImportResult.getUpdateSuccessCount());
			fileImportResultDTO.setUpdateErrorCount(fileImportResult.getUpdateErrorCount());
			resultMessageItems.addAll(fileImportResult.getResultMessageItems());
			fileImportResultDTO.setResultMessageItems(resultMessageItems);
		} catch (final ApplicationDomainLogicException e) {
			logger.error(e.getMessage());
			throw new ApplicationDomainLogicException(e.getMessage());
		} catch (IOException e) {
			// MI-E-0128=インポートファイルの読み込みに失敗しました。
			final String message = MessageUtils.getMessage("MI-E-0128");
			logger.error(message);
		} catch (final OutOfMemoryError e) {
			// MI-E-0149=取込むデータ件数が多すぎます。データ件数を絞り込んでください。
			final String message = MessageUtils.getMessage("MI-E-0149");
			logger.error(message);
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (final IOException e) {
					logger.warn(e.toString());
				}
			}
			if (!uploadFile.delete()) {
				final String args[] = { fileUploadPath };
				logger.warn(MessageUtils.getMessage("MI-W-0002", args));
			}
		}
		return fileImportResultDTO;
	}
	
	private TableItemDTO getTableItemDTOByKeyFromMap(
			final Map<String, TableItemDTO> itemsMap, 
			final String key) {
		for(Map.Entry<String, TableItemDTO> item : itemsMap.entrySet()){
			final String itemKey = item.getKey();
			final TableItemDTO itemValue = item.getValue();
			if(key.equalsIgnoreCase(itemKey)){
				return itemValue;
			}
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.RecordService#getDbConnectInfomationDTO(java.lang.String)
	 */
	@Override
	public DbConnectInfomationDTO getDbConnectInfomationDTO(final String connectionId) 
			throws ApplicationDomainLogicException{
		final RetrievalProcessingOfRecordFromDatabaseLogic recordFromDatabaseLogic;
		recordFromDatabaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		return recordFromDatabaseLogic.getDbConnectInfomation(connectionId);
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.RecordService#getRecordSearchConditionDTO(java.lang.String)
	 */
	@Override
	public RecordSearchConditionDTO getRecordSearchConditionDTO(final FRM0200SearchParam searchParam) {
		final RecordSearchConditionDTO result = new RecordSearchConditionDTO();
		result.setConnectDefinitionId(searchParam.getConnectDefinisionId());
		result.setTableId(searchParam.getTableId());
		result.setTopIndex(0);
		result.setRecordCount(SystemProperties.getSearchMaxRecordCount());
		result.setTypeOfRetrieval(TypeOfRetrieval.STRICTNESS);
		result.setOrderAsc(searchParam.isOrderDesc() == false);		
		return result;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.RecordService#getTableFormDTO(jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200SearchParam)
	 */
	@Override
	public TableFormDTO getTableFormDTO(final FRM0200SearchParam searchParam) 
			throws ApplicationDomainLogicException {
		final String connectionId = searchParam.getConnectDefinisionId();
		final String tableId = searchParam.getTableId();
		//get table info from repository
		final TableNameListIsAcquiredFromRepositoryLogic logic;
		logic = new TableNameListIsAcquiredFromRepositoryLogic();
		return logic.getTableFormDTO(connectionId, tableId);
	}

}
