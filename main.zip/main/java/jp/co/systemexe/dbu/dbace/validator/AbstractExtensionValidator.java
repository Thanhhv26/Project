package jp.co.systemexe.dbu.dbace.validator;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

abstract class  AbstractExtensionValidator {

	public abstract void validate(final Map<String, String> data) throws ApplicationDomainLogicException;
}
