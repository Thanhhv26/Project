/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.dto;
import java.util.List;

import lombok.Data;
@Data
public class SelectConnectListDTO {
	List<String> connectDefinitionIds;
}
