/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;

/**
 * DB 接続情報 DTO。
 * <p>
 * データベースへの接続情報を保持する DTO です。
 * </p><p>
 * 本アイテムはリポジトリの定義に従って定義されています。
 * </p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class DbConnectInfomationDTO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
     * 接続先サーバーID
     * <p>
     * 接続先サーバーのサーバー名 or IPアドレス
     * </p>
     */
    private String serverId;

    /**
     * 接続サービスのポート番号。
     */
    private String portId;
    private String databaseId;
    private String databaseLabel;
    private String userId;
    private String password;

    /**
     * インスタンス名(SQL Serverのみ)
     */
    private String instanceName;

    /**
     * 接続データベースベンダー種類
     */
    private DatabaseTypeConnectionDestination databaseTypeConnectionDestination;

    /**
     * データベースＵＲＬをユーザが直に指定しいるか否か
     */
    private boolean useDatabaseUrl;

    /**
     * データベースＵＲＬ
     */
    private String databaseUrl;

    /**
     * databaseId を戻します。
     *
     * @return String
     */
    public String getDatabaseId() {
        return databaseId;
    }

    /**
     * databaseId を設定します。
     *
     * @param String databaseId
     */
    public void setDatabaseId(String databaseId) {
        this.databaseId = databaseId;
    }

    /**
     * password を戻します。
     *
     * @return String
     */
    public String getPassword() {
        return password;
    }

    /**
     * password を設定します。
     *
     * @param String password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * serverId を戻します。
     *
     * @return String
     */
    public String getServerId() {
        return serverId;
    }

    /**
     * serverId を設定します。
     *
     * @param String serverId
     */
    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    /**
     * userId を戻します。
     *
     * @return String
     */
    public String getUserId() {
        return userId;
    }

    /**
     * userId を設定します。
     *
     * @param String userId
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * port を戻します。
     *
     * @return String
     */
    public String getPortId() {
        return portId;
    }

    /**
     * port を設定します。
     *
     * @param String port
     */
    public void setPortId(String port) {
        this.portId = port;
    }

    /**
     * databaseUrl を戻します。
     *
     * @return String
     */
    public String getDatabaseUrl() {
        return databaseUrl;
    }

    /**
     * databaseUrl を設定します。
     *
     * @param String databaseUrl
     */
    public void setDatabaseUrl(String databaseUrl) {
        this.databaseUrl = databaseUrl;
    }

    /**
     * useDatabaseUrl を戻します。
     *
     * @return boolean
     */
    public boolean isUseDatabaseUrl() {
        return useDatabaseUrl;
    }

    /**
     * useDatabaseUrl を設定します。
     *
     * @param boolean useDatabaseUrl
     */
    public void setUseDatabaseUrl(boolean useDatabaseUrl) {
        this.useDatabaseUrl = useDatabaseUrl;
    }

    /**
     * databaseTypeConnectionDestination を戻します。
     *
     * @return DatabaseTypeConnectionDestination
     */
    public DatabaseTypeConnectionDestination getDatabaseTypeConnectionDestination() {
        return databaseTypeConnectionDestination;
    }

    /**
     * databaseTypeConnectionDestination を設定します。
     *
     * @param DatabaseTypeConnectionDestination databaseTypeConnectionDestination
     */
    public void setDatabaseTypeConnectionDestination(
            DatabaseTypeConnectionDestination databaseTypeConnectionDestination) {
        this.databaseTypeConnectionDestination = databaseTypeConnectionDestination;
    }

	/**
	 * instanceName を戻します。
	 *
	 * @return String
	 */
	public String getInstanceName() {
		return instanceName;
	}

	/**
	 * instanceName を設定します。
	 *
	 * @param String instanceName
	 */
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

	public String getDatabaseLabel() {
		return databaseLabel;
	}

	public void setDatabaseLabel(String databaseLabel) {
		this.databaseLabel = databaseLabel;
	}

}
