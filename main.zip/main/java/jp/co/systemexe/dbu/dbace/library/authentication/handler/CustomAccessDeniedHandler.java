package jp.co.systemexe.dbu.dbace.library.authentication.handler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.csrf.CsrfException;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

public class CustomAccessDeniedHandler implements AccessDeniedHandler {
	private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	private final RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
	private String errorPage401;
	private String errorPage403;

	public CustomAccessDeniedHandler() {
	}

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException, ServletException {
		// You can redirect to error page
		logger.error(request.getContextPath(), accessDeniedException);
		/*if (accessDeniedException instanceof CsrfException) {
			redirectStrategy.sendRedirect(request, response, errorPage401);
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
		} else {
			redirectStrategy.sendRedirect(request, response, errorPage403);
			response.setStatus(HttpStatus.FORBIDDEN.value());
		}*/
		redirectStrategy.sendRedirect(request, response, errorPage401);
	}

	/**
	 * @return the errorPage401
	 */
	public String getErrorPage401() {
		return errorPage401;
	}

	/**
	 * @param errorPage401
	 *            the errorPage401 to set
	 */
	public void setErrorPage401(String errorPage401) {
		this.errorPage401 = errorPage401;
	}

	/**
	 * @return the errorPage403
	 */
	public String getErrorPage403() {
		return errorPage403;
	}

	/**
	 * @param errorPage403
	 *            the errorPage403 to set
	 */
	public void setErrorPage403(String errorPage403) {
		this.errorPage403 = errorPage403;
	}

}
