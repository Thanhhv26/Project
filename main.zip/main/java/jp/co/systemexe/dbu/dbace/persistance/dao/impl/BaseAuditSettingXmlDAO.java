/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.io.FileNotFoundException;
import java.io.InputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.BaseDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.xml.AuditSettingXml;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.auditsetting.AuditSetting;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.auditsetting.ObjectFactory;

/**
 * 監査ログ設定情報XML専用の DAO 実装用基底抽象クラスです。
 * <p>
 * 本アプリケーションでは、XML ファイルへのアクセスに JAXB を使用しています。</p>
 *
 * @author	EXE 島田 雄一郎
 * @version 0.0.0
 */
public abstract class BaseAuditSettingXmlDAO extends BaseDAO {

    /**
     * XML のエンティティクラスを配置したパッケージ。
     */
    private static final String ENTITY_PACKAGE = "jp.co.systemexe.dbu.dbace.persistance.xml.entity.auditSetting";

    /**
     * XML に出力するロケーション。
     */
    protected static final String SCHEMA_LOCATION = "http://www.system-exe.co.jp/dbu/dbace/Schema auditSetting.xsd";

    /**
     * userExclusiveControlXml を保持します。
     */
    private AuditSettingXml auditSettingXml;

    /**
     * XML ファイルのルート要素「auditSetting」を保持します。
     */
    private AuditSetting auditSetting;

    /**
     * 専用のオブジェクトファクトリの保持。
     */
    private ObjectFactory objectFactory = new ObjectFactory();

    /**
     * auditSettingXml を戻します。
     *
     * @return AuditSettingXml
     */
    public AuditSettingXml getAuditSettingXml() {
        return auditSettingXml;
    }

    /**
     * auditSettingXml を設定します。
     *
     * @param AuditSettingXml
     */
    public void setAuditSettingXml(AuditSettingXml auditSettingXml) {
        this.auditSettingXml = auditSettingXml;
    }

    /**
     * auditSetting を戻します。
     * <p>
     * プログラマが意識するリポジトリの実体です。</p>
     *
     * @return AuditSetting
     */
    protected AuditSetting getAuditSetting() {
        return auditSetting;
    }

    /**
     * オブジェクトファクトリを戻します。
     * <p>
     * アプリケーションリポジトリ内のオブジェクト定義を保持する専用のオブジェクト
     * ファクトリ参照を戻します。</p>
     *
     * @return {@link ObjectFactory}
     */
    protected ObjectFactory getObjectFactory() {
        return objectFactory;
    }

    /**
     * 監査ログ設定XMLを更新する。
     *
     * @throws DAOException
     */
    protected void update() throws DAOException {
        final Marshaller m = createMarshaller();
        try {
            m.marshal(auditSetting, auditSettingXml.getOutputStream());
        } catch (final JAXBException e) {
        	// MI-E-0065=監査ログ設定XMLファイルの出力に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0065");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } catch (final FileNotFoundException e) {
        	// MI-F-0003=監査ログ設定XMLファイルが存在しません。
            final String message = MessageUtils.getMessage("MI-F-0003");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * 初期化処理。
     * <p>
     * アプリケーションリポジトリデータの読み込みを行い、DAO の初期化処理を実行
     * します。</p>
     *
     * @throws DAOException
     */
    public void init() throws DAOException {
        final Unmarshaller um = createUnmarshaller();
        try {
            final InputStream stream = this.auditSettingXml.getInputStream();
            this.auditSetting = (AuditSetting)um.unmarshal(stream);
        } catch (final JAXBException e) {
        	// MI-E-0066=監査ログ設定XMLファイルの読込に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0066");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } catch (final FileNotFoundException e) {
        	// MI-F-0003=監査ログ設定XMLファイルが存在しません。
            final String message = MessageUtils.getMessage("MI-F-0003");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * BaseRepositoryXmlDAO の生成。
     * <p>コンストラクタ。</p>
     */
    public BaseAuditSettingXmlDAO() {
        return;
    }

    /**
     * Unmarshaller を生成して戻す。
     * <p>
     * Unmarshaller は XML ファイルの読み込みに使用するオブジェクトです。</p>
     * <p>
     * アプリケーションリポジトリ XML ファイルのスキーマ定義を保持した
     * Unmarshaller を生成して戻します。</p>
     *
     * @return
     * @throws DAOException
     */
    private final Unmarshaller createUnmarshaller() throws DAOException {
        final JAXBContext context;
        try {
        	ObjectFactory objectFactory = new ObjectFactory();
            context = JAXBContext.newInstance(objectFactory.getClass().getPackage().getName());
        } catch (final JAXBException e) {
        	// MI-F-0001={0} クラスが存在しません。
        	final String args[] = {ENTITY_PACKAGE};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        final Unmarshaller ret;
        try {
            ret = context.createUnmarshaller();
        } catch (final JAXBException e) {
        	// MI-E-0066=監査ログ設定XMLファイルの読込に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0066");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }

    /**
     * Marshaller を生成して戻す。
     * <p>
     * Marshaller は、XML への書き込みに使用するオブジェクトです。</p>
     * <p>
     * アプリケーションリポジトリ XML ファイルのスキーマ定義を保持した
     * Marshaller を生成して戻します。</p>
     *
     * @return
     * @throws DAOException
     */
    private final Marshaller createMarshaller() throws DAOException {
        final JAXBContext context;
        try {
        	ObjectFactory objectFactory = new ObjectFactory();
            context = JAXBContext.newInstance(objectFactory.getClass().getPackage().getName());
        } catch (final JAXBException e) {
        	// MI-F-0001={0} クラスが存在しません。
        	final String args[] = {ENTITY_PACKAGE};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        final Marshaller ret;
        try {
            ret = context.createMarshaller();
            ret.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            ret.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            ret.setProperty(Marshaller.JAXB_SCHEMA_LOCATION, SCHEMA_LOCATION);
        } catch (final JAXBException e) {
        	// MI-E-0066=監査ログ設定XMLファイルの読込に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0066");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }
}
