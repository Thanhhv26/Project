/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;

/**
 * アプリケーションリポジトリ。
 * <p>
 * アプリケーションリポジトリファイルをラップした Singleton クラスです。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public final class AppRepository {

    /**
     * インスタンス。
     */
    private static AppRepository instance;

    /**
     * リポジトリファイル。
     */
    private File file;

    /**
     * リポジトリファイルのファイルパスを変更します。
     */
    public void changeAppRepositoryFile() {
        synchronized (AppRepository.class) {
	        this.setFile(SystemProperties.getAppRepositoryFile());
        }
    }
    
    /**
     * このクラスのインスタンスを返します。
     * 
     * @return
     */
    public static AppRepository getInstance() {
        if (instance == null) {
            synchronized (AppRepository.class) {
                if (instance == null) {
                    instance = new AppRepository();
                }
            }
        }
        return instance;
    }

    /**
     * inputStream を戻します。
     * 
     * @return InputStream
     */
    public final InputStream getInputStream() throws FileNotFoundException {
        return new FileInputStream(this.getFile());
    }

    /**
     * outputStream を戻します。
     * 
     * @return OutputStream
     * @exception FileNotFoundException
     */
    public OutputStream getOutputStream() throws FileNotFoundException {
        return new FileOutputStream(this.getFile());
    }

    /**
     * AppRepository の生成。
     * <p>デフォルトコンストラクタ隠蔽。</p>
     */
    private AppRepository() {
        this.setFile(SystemProperties.getAppRepositoryFile());
    }

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}
}
