/**
 * Copyright(C) 2008 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.SortedMap;

import jp.co.systemexe.dbu.dbace.persistance.dao.BaseDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * テーブルデータファイル出力の基底抽象クラス。
 *
 * <p>
 * 本プロジェクトにおいて テーブルデータファイル出力 を実装する際には、原則本クラスを継承しなければいけません。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public abstract class BaseOutputsToFileWithTableDataDAO extends BaseDAO {

	/**
	 *
	 */
	private OutputStream outputStream = null;

	/**
	 *
	 */
	private String filePath = null;

	/**
	 *
	 * @return
	 */
	public String getFilePath() {
		return filePath;
	}

	/**
	 * ファイルに出力したレコード件数を返します。
	 *
	 * @return 出力レコード数
	 */
	public abstract int getOutputRecordCount();

	/**
	 * outputStream を戻します。
	 *
	 * @return OutputStream
	 */
	public OutputStream getOutputStream() {
		return outputStream;
	}

	/**
	 * ファイル出力するファイルパスを設定します。
	 *
	 * @param filePath
	 */
	public void setOutputFilePath(final String filePath) throws DAOException {
		try {
			this.filePath = filePath;
			this.outputStream = new FileOutputStream(filePath);
		} catch (FileNotFoundException e) {
			throw new DAOException(e.getMessage(), e);
		}
	}

	/**
	 *
	 */
	public void close() {
		if (this.outputStream != null) {
			try {
				this.outputStream.close();
			} catch (IOException e) {
				getLogger().warn(e.getMessage());
			}
		}
	}

	/**
	 * ファイル出力を行います。
	 *
	 * @param tableId
	 *            テーブル名
	 * @param def
	 *            項目表示定義 DTO
	 * @param dto
	 *            レコード検索結果 DTO
	 * @param outputStream
	 */
	public abstract void outputFile(
			final String tableId, 
			final SortedMap<Integer, TableItemDTO> columnId,
			final Map<String, String> columnData,
			final String dbType) throws DAOException;

	/**
	 *
	 * @throws DAOException
	 */
	public abstract void write() throws DAOException;

	/**
	 *
	 * @return
	 * @throws DAOException
	 */
	public abstract boolean checkFileSize() throws DAOException;

}
