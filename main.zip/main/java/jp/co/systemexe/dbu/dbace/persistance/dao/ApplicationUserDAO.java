/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationUserDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.web.user.model.UserInformation;

/**
 * アプリケーションユーザー 情報 DAO 用のインターフェースクラス。
 * <p>
 * アプリケーションユーザー情報の入出力インターフェースの定義です。</p>
 * <p>
 * このユーザーは本アプリケーション内で定義される独自のユーザーであり、対象と
 * する DB ユーザーとは直接には関係しません。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @author EXE 六本木 圭
 * @author EXE 相田 一英
 * @author EXE 鈴木 伸祐
 * @version 0.0.0
 */
public interface ApplicationUserDAO {
    /**
     * ユーザー認証を行います。
     * <p>
     * 接続定義 ID、ユーザー ID、パスワードの組み合わせでユーザーの認証を行い
     * ます。
     * </p><p>
     * 認証時にはパスワード文字列はフラットのまま渡します。
     * </p>
     *
     * @param userId ユーザー ID
     * @param password パスワード
     * @return true : 正規ユーザー / false : 非正規ユーザー
     */
    public boolean certify(
    		final String userId,
    		final String password) throws DAOException ;

    /**
     * アプリケーションユーザー情報 DTO を戻します。
     * <p>
     * 現状、ユーザーパスワードも復号して戻す仕様になっていますが、本来は
     * 好ましくありません。将来的に再設計する必要があります。
     * </p>
     *
     * @param userId ユーザー ID
     * @return ApplicationUserDTO
     * @throws DAOException
     */
    public ApplicationUserDTO getApplicationUserDTO(final String userId)
            throws DAOException;

    /**
     * ユーザー名の一覧マップを戻します。
     * <p>
     * ユーザー ID、ユーザー名の一覧を設定した Map を戻します。</p>
     *
     * @return Map&lt;ユーザー ID, ユーザー名&gt;
     * @throws DAOException
     */
    public Map<String, String> getUserNameMap()
            throws DAOException;

    /**
     * ユーザー情報の一覧マップを戻します。
     * <p>
     * ユーザー ID、ユーザー名、ユーザー権限の一覧を設定した Map を戻します。
     * ユーザー登録がない場合は DAOException をスローします。</p>
     *
     * @return Map&lt;ユーザー ID, UserInformation&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#getUserInformationMap()
     */
    public Map<String, UserInformation> getUserInformationMap()
            throws DAOException;
    /**
     * パスワード文字列の暗号化を行います。
     * <p>
     * パスワード文字列を暗号化して文字列を返します。</p>
     *
     * @param String 対象パスワード文字列
     * @return String 暗号化済みパスワード文字列
     * @throws DAOException
     */
    public String getEncryptionPassword(final String password)
            throws DAOException;

    /**
     * パスワードを保存します。
     *
     * @param dto ユーザー情報 DTO
     * @throws DAOException
     */
    public void savePassword(final ApplicationUserDTO dto) throws DAOException;

    /**
     * username, パスワードを保存します。
     *
     * @param dto ユーザー情報 DTO
     * @throws DAOException
     */
    public void saveUsernamePassword(final ApplicationUserDTO dto) throws DAOException;

    /**
     * ユーザー情報を保存します。
     * <p>
     * 接続定義 ID、ユーザー IDの組み合わせでアプリケーションユーザー情報を保存
     * します。既存の場合は更新を、未登録の場合は新規追加を行います。</p>
     *
     * @param dto ユーザー情報 DTO
     * @throws DAOException
     */
	// MOD 外部認証連携 機能追加 ↓
	public void save(//final UserInfo userInfo,
			final ApplicationUserDTO dto,
			final UpdateDivision updateDivision)
			throws DAOException;
	// MOD 外部認証連携 機能追加 ↑
    /**
     * ユーザー情報を削除します。
     * <p>
     * ユーザー IDのアプリケーションユーザー情報を削除
     * します。</p>
     *
     * @param userId ユーザー ID
     * @throws DAOException
     */
    public void remove(final String userId)
            throws DAOException;

    public String openSesame();

}
