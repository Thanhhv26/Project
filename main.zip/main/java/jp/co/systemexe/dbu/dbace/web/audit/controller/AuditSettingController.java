/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.audit.controller;

import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.domain.service.AuditSettingService;
import jp.co.systemexe.dbu.dbace.web.audit.dto.FRM0530ResultDto;
import jp.co.systemexe.dbu.dbace.web.audit.json.FRM0530Param;
import jp.co.systemexe.dbu.dbace.web.audit.model.FRM0530ResultModel;
import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;

@RestController
@RequestMapping(value = "/system/audit")
public class AuditSettingController extends AbstractController {

	/***/
	private static final long serialVersionUID = 1L;

	@Autowired
	AuditSettingService auditSettingService;

	/**
	 * Index page
	 *
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index() throws Exception {
		return new ModelAndView(PageConst.SCREEN_AUDIT);
	}

	/**
	 * load auditsetting
	 * @param param
	 * @return FRM0530ResultModel
	 */
	@RequestMapping(value = "/init", method = { RequestMethod.POST })
	public FRM0530ResultModel init(@RequestBody FRM0530Param param) throws Exception {
		FRM0530ResultModel model = new FRM0530ResultModel();
		FRM0530ResultDto dto = auditSettingService.initialize();

		model.setBeforeAuditSettingDTO(dto.getBeforeAuditSettingDTO());
		model.setAuditCategoryItems(dto.getAuditCategoryItems());
		model.setAuditLogFileUnitItems(dto.getAuditLogFileUnitItems());
		model.setAuditLogFileSize(dto.getAuditLogFileSize());
		model.setAuditLogFileUnit(dto.getAuditLogFileUnit());
		model.setAuditLogFileRotation(dto.getAuditLogFileRotation());
		model.setAuditLogFileOutput(dto.getAuditLogFileOutput());

		model.setMessageInfoList(dto.getMessageInfoList());

		return model;
	}

	/**
	 * save auditsetting
	 * @param param
	 * @return FRM0530ResultModel
	 */
	@RequestMapping(value = "/save", method = { RequestMethod.POST })
	public FRM0530ResultModel save(@RequestBody FRM0530Param param) throws Exception {
		FRM0530ResultModel model = new FRM0530ResultModel();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		MessageInfo messageInfo = new MessageInfo();

		//#auditLogFileSize
		if(StringUtils.isBlank(param.getAuditLogFileSize()) 
				|| StringUtils.isEmpty(param.getAuditLogFileSize())){
			messageInfo = new MessageInfo("FRM0220.auditlog.auditLogFileSize.empty", MessageType.ERROR, "", messageService);//frm0530.auditSetting.auditLogFileRotation
			messageInfo.setIdError("#auditLogFileSize");
			messageInfoList.add(messageInfo);
		}else if(!this.isNumeric(param.getAuditLogFileSize()) 
				|| !isInteger(param.getAuditLogFileSize())
				|| Integer.valueOf(param.getAuditLogFileSize()) > 99999
				|| Integer.valueOf(param.getAuditLogFileSize()) < 1){
			messageInfo = new MessageInfo("FRM0220.auditLogFileSize.0.to.99999", MessageType.ERROR, "", messageService);//frm0530.auditSetting.auditLogFileSize
			messageInfo.setIdError("#auditLogFileSize");
			messageInfoList.add(messageInfo);
//			messageInfo = new MessageInfo("FRM0220.auditlog.auditLogFileSize.not.integer", MessageType.ERROR, "", messageService);//frm0530.auditSetting.auditLogFileRotation
//			messageInfo.setIdError("#auditLogFileSize");
//			messageInfoList.add(messageInfo);
		}
		//#auditLogFileRotation
		if(StringUtils.isEmpty(param.getAuditLogFileRotation()) 
				|| StringUtils.isBlank(param.getAuditLogFileRotation())){
			messageInfo = new MessageInfo("FRM0220.auditlog.auditLogFileRotation.empty", MessageType.ERROR, "", messageService);//frm0530.auditSetting.auditLogFileSize
			messageInfo.setIdError("#auditLogFileRotation");
			messageInfoList.add(messageInfo);
		}else if(!this.isNumeric(param.getAuditLogFileRotation()) 
				|| !isInteger(param.getAuditLogFileRotation())
				|| Integer.valueOf(param.getAuditLogFileRotation()) > 999
				|| Integer.valueOf(param.getAuditLogFileRotation()) < 0){
			messageInfo = new MessageInfo("FRM0220.auditLogFileRotation.0.to.999", MessageType.ERROR, "", messageService);//frm0530.auditSetting.auditLogFileSize
			messageInfo.setIdError("#auditLogFileRotation");
			messageInfoList.add(messageInfo);
//			messageInfo = new MessageInfo("FRM0220.auditlog.auditLogFileRotation.not.integer", MessageType.ERROR, "", messageService);//frm0530.auditSetting.auditLogFileSize
//			messageInfo.setIdError("#auditLogFileRotation");
//			messageInfoList.add(messageInfo);
		}
		
		if(messageInfoList.size() > 0){
			model.setMessageInfoList(messageInfoList);
			return model;
		}

		param.setUserInfo(getUserInfo());
		FRM0530ResultDto dto = auditSettingService.doOnceSave(param);
		model.setMessageInfoList(dto.getMessageInfoList());

		return model;
	}

	public boolean isNumeric(String str)
	{
		if(StringUtils.isBlank(str) || StringUtils.isEmpty(str)){
			return false;
		}
		NumberFormat formatter = NumberFormat.getInstance();
		ParsePosition pos = new ParsePosition(0);
		formatter.parse(str, pos);
		return str.length() == pos.getIndex();
	}
	
	public boolean isInteger(String s) {
	    return isInteger(s,10);
	}

	public boolean isInteger(String s, int radix) {
	    if(s.isEmpty()) return false;
	    for(int i = 0; i < s.length(); i++) {
	        if(i == 0 && s.charAt(i) == '-') {
	            if(s.length() == 1) return false;
	            else continue;
	        }
	        if(Character.digit(s.charAt(i),radix) < 0) return false;
	    }
	    return true;
	}

}
