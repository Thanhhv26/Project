package jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.poi.util.TempFile;
import org.apache.poi.xssf.model.SharedStringsTable;

public class GZIPSheetDataWriterCus extends SheetDataWriterCus {

	public GZIPSheetDataWriterCus() throws IOException {
		super();
	}

	/**
	 * @param sharedStringsTable
	 *            the shared strings table, or null if inline text is used
	 */
	public GZIPSheetDataWriterCus(SharedStringsTable sharedStringsTable) throws IOException {
		super(sharedStringsTable);
	}

	/**
	 * @return temp file to write sheet data
	 */
	@Override
	public File createTempFile() throws IOException {
		return TempFile.createTempFile("poi-sxssf-sheet-xml", ".gz");
	}

	/**
	 * @return a wrapped instance of GZIPOutputStream
	 */
	@Override
	public Writer createWriter(File fd) throws IOException {
		return new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(fd)), "UTF-8");
	}

	/**
	 * @return a GZIPInputStream stream to read the compressed temp file
	 */
	@Override
	public InputStream getWorksheetXMLInputStream() throws IOException {
		File fd = getTempFile();
		return new GZIPInputStream(new FileInputStream(fd));
	}
}
