/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.ItemRestriction;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.ColsDto.ColDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.OperationDto;

/**
 * 各カラムに対応したテーブル項目情報 DTO。
 * <p>
 * 各カラムに対応したテーブル項目（テーブルアイテム）情報を保持する DTO です。
 * 対象項目の画面上での設定や入力値に関する特殊な制約等の情報を保持します。
 * </p><p>
 * 本アイテムはリポジトリの定義に従って定義されています。
 * </p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class TableItemDTO {

    /**
     * テーブルアイテム ID。
     * <p>テーブルのカラム名に一致しています。</p>
     */
    private String tableId;

    /**
     * テーブルアイテム ID。
     * <p>テーブルのカラム名に一致しています。</p>
     */
    private String itemId;

    /**
     * テーブルアイテムラベル。
     * <p>画面表示用の仮名です。</p>
     */
    private String itemLabel;

    /**
     * テーブルアイテム並び順。
     * <p>カラム名の画面表示順です。</p>
     */
    private int sortIndex;

    /**
     * 画面構成上の HTML 要素指定。
     */
    private DefinedHtmlElement htmlElement;

    /**
     * プルダウンリスト等選択要素用の入力値候補マップ。
     */
    private SelectableItem[] selectableItems;

    /**
     * プルダウンリスト等選択要素用のリスト取得用 SQL。
     */
    private String sqlString;

    /**
     * アプリケーション独自定義の入力値制約マップ。
     */
    private Map<ItemRestriction, Boolean> ItemRestrictions = new HashMap<ItemRestriction, Boolean>();

    /**
     * アプリケーション独自定義の入力値制約マップ。
     */
    private Map<String, ColDto> cols = new HashMap<String, ColDto>();

    /**
     *
     */
    private OperationDto operations = new OperationDto();

    /**
     * 入力既定値。
     */
    private String defaultValue;

    /**
     * 画面表示用の項目説明。
     */
    private String explanation;

    /**
     * 一覧表示に表示するか否か。
     */
    private Boolean preview = true;

    /**
     * 登録・編集時に表示するか否か。
     */
    private boolean displayrecordedit = true;

    /**
     * 一覧表示おきかえ？
     */
    private boolean displaynamepreview = false;

    /**
     * 更新可能な項目か否か。
     */
    private boolean editing;

    /**
     * 更新処理の際のキー項目か否か。
     */
    private boolean updateKey;

    /**
     * 検索キーか否か。
     */
    private boolean selectKey;

    /**
     * カラムに対する、関連項目があるか否か。
     * <p>
     * プルダウンデータの場合に関連項目があるか否かを返します。
     * </p>
     */
    private boolean relatedSelectItems;

    private boolean primaryKey;
    private boolean unique;
    private boolean foreignKey;
    private String dataType;
    private String dataLength;
    private String dataUnit;
    private String parametersSql;

    public String getParametersSql() {
		return parametersSql;
	}

	public void setParametersSql(String parametersSql) {
		this.parametersSql = parametersSql;
	}

	private boolean isRoot = true;

    /**
     * 入力既定値を戻します。
     *
     * @return String
     */
    public String getDefaultValue() {
        return defaultValue;
    }

    /**
     * 入力既定値を設定します。
     *
     * @param String defaultValue
     */
    public void setDefaultValue(final String defaultValue) {
        this.defaultValue = defaultValue;
    }

    /**
     * 更新可能な項目か否かを戻します。
     *
     * @return boolean
     */
    public boolean canEditing() {
        return editing;
    }

    /**
     * 更新可能な項目か否かを設定します。
     *
     * @param boolean editing
     */
    public void setEditing(boolean editing) {
        this.editing = editing;
    }

    /**
     * 画面表示用の項目説明を戻します。
     *
     * @return String
     */
    public String getExplanation() {
        return explanation;
    }

    /**
     * 画面表示用の項目説明を設定します。
     *
     * @param String explanation
     */
    public void setExplanation(final String explanation) {
        this.explanation = explanation;
    }

    /**
     * 画面構成上の HTML 要素指定を戻します。
     *
     * @return DefinedHtmlElement
     */
    public DefinedHtmlElement getHtmlElement() {
        return htmlElement;
    }

    /**
     * 画面構成上の HTML 要素指定を設定します。
     *
     * @param DefinedHtmlElement htmlElement
     */
    public void setHtmlElement(final DefinedHtmlElement htmlElement) {
        this.htmlElement = htmlElement;
    }

    /**
     * プルダウンリスト等選択要素用の入力値候補マップを戻します。
     * <p>
     * HTML 要素がリスト系の場合の入力値候補のMap<K,V>を戻します。</p>
     *
     * @return SelectOneMenuItem[]
     */
    public SelectableItem[] getSelectableItems() {
        return selectableItems;
    }

    /**
     * sqlString を戻します。
     *
     * @return String
     */
    public String getSqlString() {
        return sqlString;
    }

    /**
     * sqlString を設定します。
     *
     * @param String sqlString
     */
    public void setSqlString(String sqlString) {
        this.sqlString = sqlString;
    }

    /**
     * テーブルアイテム ID を戻します。
     *
     * @return String
     */
    public String getItemId() {
        return itemId;
    }

    /**
     * テーブルアイテム ID を設定します。
     *
     * @param String itemId
     */
    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    /**
     * テーブルアイテムラベルを戻します。
     *
     * @return String
     */
    public String getItemLabel() {
        return itemLabel;
    }

    /**
     * テーブルアイテムラベルを設定します。
     *
     * @param String itemLabel
     */
    public void setItemLabel(final String itemLabel) {
        this.itemLabel = itemLabel;
    }

    /**
     * アプリケーション独自定義の入力値制約マップを戻します。
     *
     * @return Map<ItemRestriction,Boolean>
     */
    public Map<ItemRestriction, Boolean> getItemRestrictions() {
        return ItemRestrictions;
    }

    /**
     * 一覧表示に表示するか否かを戻します。
     *
     * @return boolean
     */
    public Boolean canPreview() {
        return preview;
    }

    /**
     * 一覧表示に表示するか否かを設定します。
     *
     * @param boolean preview
     */
    public void setPreview(Boolean preview) {
        this.preview = preview;
    }

    /**
     * 一覧表示に表示するか否かを戻します。
     * bao-anh: added method GET for json response. The method canPreview is missing in json response
     * @return boolean
     */
    public Boolean getPreview() {
        return preview;
    }

    /**
     * 登録・編集時に表示するか否かを戻します。
     *
     * @return boolean
     */
    public boolean canDisplayRecordEdit() {
        return displayrecordedit;
    }

    /**
     * 登録・編集時に表示するか否かを設定します。
     *
     * @param boolean preview
     */
    public void setDisplayRecordEdit(boolean displayrecordedit) {
        this.displayrecordedit = displayrecordedit;
    }

    /**
     * 表示置き換えするか否かを戻します。
     *
     * @return boolean
     */
    public boolean canDisplayNamePreview() {
        return displaynamepreview;
    }

    /**
     * 表示置き換えするか否かを設定します。
     *
     * @param boolean preview
     */
    public void setDisplayNamePreview(boolean displaynamepreview) {
        this.displaynamepreview = displaynamepreview;
    }

    /**
     * 検索キーか否かを戻します。
     *
     * @return boolean
     */
    public boolean isSelectKey() {
        return selectKey;
    }

    /**
     * 検索キーか否かを設定します。
     *
     * @param boolean selectKey
     */
    public void setSelectKey(boolean selectKey) {
        this.selectKey = selectKey;
    }

    /**
     * @return
     */
    public boolean getPrimaryKey() {
        return primaryKey;
    }
    /**
     * @param value
     */
    public void setPrimaryKey(boolean value) {
        this.primaryKey = value;
    }
    /**
     * @return
     */
    public boolean getUnique() {
        return unique;
    }
    /**
     * @param value
     */
    public void setUnique(boolean value) {
        this.unique = value;
    }
    /**
     * @return
     */
    public boolean getForeignKey() {
        return foreignKey;
    }
    /**
     * @param value
     */
    public void setForeignKey(boolean value) {
        this.foreignKey = value;
    }
    /**
     * @return
     */
    public String getDataType() {
        return dataType;
    }
    /**
     * @param value
     */
    public void setDataType(String value) {
        this.dataType = value;
    }
    /**
     * @return
     */
    public String getDataLength() {
        return dataLength;
    }
    /**
     * @param value
     */
    public void setDataLength(String value) {
        this.dataLength = value;
    }
    /**
     * @return
     */
    public String getDataUnit() {
        return dataUnit;
    }
    /**
     * @param value
     */
    public void setDataUnit(String value) {
        this.dataUnit = value;
    }

    /**
     * 更新処理の際のキー項目か否かを戻します。
     *
     * @return boolean
     */
    public boolean isUpdateKey() {
        return updateKey;
    }

    /**
     * 更新処理の際のキー項目か否かを設定します。
     *
     * @param boolean updateKey
     */
    public void setUpdateKey(boolean updateKey) {
        this.updateKey = updateKey;
    }

    /**
     * sortIndex を戻します。
     *
     * @return int
     */
    public int getSortIndex() {
        return sortIndex;
    }

    /**
     * sortIndex を設定します。
     *
     * @param int sortIndex
     */
    public void setSortIndex(int sortIndex) {
        this.sortIndex = sortIndex;
    }

    /**
     * relatedSelectItems を戻します。
     *
     * @return boolean
     */
    public boolean isRelatedSelectItems() {
        return relatedSelectItems;
    }

    /**
     * relatedSelectItems を設定します。
     *
     * @param boolean relatedSelectItems
     */
    public void setRelatedSelectItems(boolean relatedSelectItems) {
        this.relatedSelectItems = relatedSelectItems;
    }

    /**
     * selectableItems を設定します。
     *
     * @param SelectOneMenuItem[] selectableItems
     */
    public void setSelectableItems(SelectableItem[] item) {
        this.selectableItems = item;
    }

	/**
	 * @return the cols
	 */
	public Map<String, ColDto> getCols() {
		return cols;
	}

	/**
	 * @param cols the cols to set
	 */
	public void setCols(Map<String, ColDto> cols) {
		this.cols = cols;
	}

	/**
	 * @return the operations
	 */
	public OperationDto getOperations() {
		return operations;
	}

	/**
	 * @param operations the operations to set
	 */
	public void setOperations(OperationDto operations) {
		this.operations = operations;
	}

	/**
	 * @return the tableId
	 */
	public String getTableId() {
		return tableId;
	}

	/**
	 * @param tableId the tableId to set
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}

	/**
	 * In case multi-table, if this has childs then return true, the childs return false
	 * @return the isRoot
	 */
	public boolean isRoot() {
		return isRoot;
	}

	/**
	 * In case multi-table, if this has childs then set isRoot = true, the childs set isRoot = false
	 * @param isRoot the isRoot to set
	 */
	public void setRoot(boolean isRoot) {
		this.isRoot = isRoot;
	}
}
