/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationRelationDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Relation;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationInformation;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
public class PreservationOfAppRelationLogic extends BaseApplicationDomainLogic {

    /**
     * @param applicationRelationDTO
     * @param updateDivision
     * @param userInfo
     * @throws ApplicationDomainLogicException
     */
    public void save(ApplicationRelationDTO applicationRelationDTO,
    		final UpdateDivision updateDivision//,
    		//final UserInfo userInfo
    		)
            throws ApplicationDomainLogicException {

        final ApplicationRelationDAO dao = createApplicationRelationDAO();
//        AuditStatus status = AuditStatus.failure;
        try {
			dao.save(/*userInfo,*/applicationRelationDTO, updateDivision);
//            status = AuditStatus.success;
        } catch (final DAOException e) {
//            status = AuditStatus.failure;
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        } finally {

        }
    }

    /**
     * @param relationID
     * @return
     * @throws ApplicationDomainLogicException
     */
    public Boolean isRelationIDRepetition(final String relationName)
    		throws ApplicationDomainLogicException {
        try {
            final ApplicationRelationDAO dao = createApplicationRelationDAO();
            final Map<String, String> relationMap = dao.getRelationNameMap();
            return relationMap.containsValue(relationName);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e);
        }
    }

    /**
     * @return
     * @throws ApplicationDomainLogicException
     */
    public Map<String, RelationInformation> getRelationInformationMap()
            throws ApplicationDomainLogicException {
        try {
            final ApplicationRelationDAO dao = createApplicationRelationDAO();
            return dao.getRelationInformationMap();
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * @return
     * @throws ApplicationDomainLogicException
     */
    public ApplicationRelationDTO getApplicationRelationDTO(final String relationId)
            throws ApplicationDomainLogicException {
        try {
        	final ApplicationRelationDAO dao = createApplicationRelationDAO();
            return dao.getApplicationRelationDTO(relationId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
    /**
	 * is Deleted Relation
	 * @return true : exist /false : not exist
	 */
	public boolean checkRelationExist(final String relationId) throws ApplicationDomainLogicException {
		final ApplicationRelationDAO dao = createApplicationRelationDAO();
        try {
			return dao.checkRelationExist(relationId);
		} catch (DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}
	}

    /**
     * リレーション情報を削除します。
     * <p>
     * リレーション IDのアプリケーションリレーション情報を削除
     * します。</p>
     *
     * @param userId リレーション ID
     * @throws DAOException
     */
    public void remove(final String relationId) throws ApplicationDomainLogicException {
    	try {
        	final ApplicationRelationDAO dao = createApplicationRelationDAO();
            dao.remove(relationId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * Remove relation by connectionId
     * ■XML削除対象の追加
     * relation_infoの中でtable.connectidが、削除するDB接続情報と同じ場合、対象の「relation」を削除
     * @return
     * @throws ApplicationDomainLogicException
     * @author bao-anh
     */
    public void removeRelationsByConnectionId(final String connectionId) throws ApplicationDomainLogicException {
    	if(StringUtils.isEmpty(connectionId)){
    		return;
    	}
        try {
        	final ApplicationRelationDAO dao = createApplicationRelationDAO();
        	final List<Relation> relations = dao.getRelations();
        	List<String> relationIDs = new ArrayList<String>();
        	for(Relation item : relations){
        		Relation.Tables tables = item.getTables();
        		Relation.Tables.Table firstTable = tables.getTable().get(0);
        		if(firstTable.getConnectid().equals(connectionId)){
        			relationIDs.add(item.getId());
        		}
        	}
        	for(String item : relationIDs){
        		dao.remove(item);
        	}
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        } catch (final Exception e){
        	e.printStackTrace();
        }
    }

    /**
     * PreservationOfAppRelationLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public PreservationOfAppRelationLogic() {
        return;
    }

    /**
     * @return
     * @throws ApplicationDomainLogicException
     */
    private ApplicationRelationDAO createApplicationRelationDAO() throws ApplicationDomainLogicException {
        try {
            return (ApplicationRelationDAO)createDAO("ApplicationRelationDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
