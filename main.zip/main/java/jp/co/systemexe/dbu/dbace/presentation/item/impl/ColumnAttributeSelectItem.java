/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;

/**
 * 編集対象レコードのカラム属性がプルダウンリストの場合の表示用アイテム。
 * <p>
 * </p>
 *
 * @author	EXE 島田 雄一郎
 * @version 0.0.0
 */
public class ColumnAttributeSelectItem implements SelectOneMenuItem, Serializable {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 216543160569652614L;
    
    /**
     * 編集対象レコードのカラム属性がプルダウンリスト名称。
     * <p>ユーザーが定義する接続定義に付けた表示用名称です。</p>
     */
    private String label;
    /**
     * 編集対象レコードのカラム属性がプルダウンリスト ID。
     * <p>システム内部で扱われる ID です。</p>
     */
    private String value;

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getLabel()
     */
    public String getLabel() {
        return label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getValue()
     */
    public String getValue() {
        return value;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setLabel(java.lang.String)
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setValue(int)
     */
    public void setValue(String value) {
        this.value = value;
    }
}
