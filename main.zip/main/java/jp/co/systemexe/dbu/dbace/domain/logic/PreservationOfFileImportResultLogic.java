/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseFileImportResultDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.FileImportResultDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportResultDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * データ一括インポートにおける、エラーメッセージ情報の保存ロジック。
 * <p>
 * エラーメッセージ情報をファイルに保存します。</p>
 *
 * @author	EXE 島田 雄一郎
 * @version 0.0.0
 */
public class PreservationOfFileImportResultLogic extends BaseApplicationDomainLogic {
    /**
     * データ一括インポートにおける、エラーメッセージ情報を保存します。
     * 
     * @param 
     * @return filePath ファイルパス
     * @throws ApplicationDomainLogicException
     */
    public String save(final FileImportResultDTO dto)
            throws ApplicationDomainLogicException {
        final BaseFileImportResultDAO fileImportResultDAO
	    	= new FileImportResultDAO();
        try {
        	return fileImportResultDAO.outputFile(dto);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e);
        }
    }

    /**
     * PreservationOfDataImportErrorMessageLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public PreservationOfFileImportResultLogic() {
        return;
    }
}
