package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.presentation.FileOutputTableData;

/**
 * ダウンロードクラスを指定
 *
 * @author  Phung-tien
 * @version 0.0.0
 */
public class DaoNameConverter {

	private static final String USE_CUSTOM_WRITER = "1";
	private static final String USE_XSSF = "2";

	public static String getClassName(FileOutputTableData fileType) {
		String className = fileType.getClassName();
		if (fileType == FileOutputTableData.EXCEL) {
			String downLoadMode = SystemProperties.getDownLoadMode();
			if (USE_CUSTOM_WRITER.equals(downLoadMode)) {
				className = OutputsToExcelUseCustomWriterWithTableDataDAO.class.getSimpleName();
			} else if (USE_XSSF.equals(downLoadMode)) {
				className = OutputsToExcelWithTableDataDAO.class.getSimpleName();
			} else {
				className = OutputsToExcelUseSXSSFWriterWithTableDataDAO.class.getSimpleName();
			}
		}

		return className;
	}
}
