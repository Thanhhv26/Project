/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

/**
 * 検索種別定義 enum。
 * <p>
 * 検索種別を定義した列挙体です。一致検索、曖昧検索等の種類の定義です。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public enum TypeOfRetrieval {
    /**
     * 曖昧検索。
     */
    VAGUENESS, /**
     * 一致検索。
     */
    STRICTNESS,
    /**
     * 無制限。
     */
    UNRESTRICTED

}
