/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.Iterator;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseDbTransactionAbstractDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.InputDto;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordEditInputDto;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSaveConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * データベースのレコード更新ロジック。
 * <p>
 * </p>
 *
 * @author EXE 相田 一英
 * @version 0.0.0
 */
public class RecordAddUpdateProcessingOfDatabaseLogic extends BaseDbTransactionAbstractDomainLogic {
	public RecordAddUpdateProcessingOfDatabaseLogic() {
	}

	/**
	 * 指定されたテーブルのレコードを更新します。
	 * <p>
	 * DB から最新のテーブル定義を取得し、それに併せて更新処理を実行します。<br />
	 * 特に自動インクリメントフィールドを検出した場合、更新対象から自動的に除外 します。
	 * </p>
	 * <p>
	 * また、リポジトリ内の定義に従い、更新キーマップを作成します。これは リポジトリ内で、主キーとは独立して定義された更新キー情報をもとに、更新
	 * 条件を自動的に組み立てる機能です。<br />
	 * この機能により、本メソッドは主キーが存在しないようなテーブルに対しても 更新処理を実行する事が出来ます。
	 * </p>
	 *
	 * @param connectDefinitionId
	 *            接続定義 ID
	 * @param tableId
	 *            テーブル ID（テーブル名）
	 * @param records
	 *            レコード保持コレクション
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @throws ApplicationDomainLogicException
	 */
	@Override
	protected void doBusinessLogic(final InputDto inputdto, final DatabaseTableDAO databaseTableDAO)
			throws ApplicationDomainLogicException, DAOException {
		RecordEditInputDto inputDto = (RecordEditInputDto) inputdto;
		for (Object element : inputDto.getListTableFormDTO().keySet()) {
			String key = (String) element;
			if (inputDto.getListTableFormDTO().get(key).status == false) {
				final RecordSaveConditionDTO dto = new RecordSaveConditionDTO();
				dto.setConnectDefinitionId(inputDto.getConnectDefinitionId());
				dto.setTableId(inputDto.getListTableFormDTO().get(key).getTableFormDTO().getTableFormId());
				final Map<String, String> filteredRecords = filterAutoIncrementColumn(
						inputDto.getListTableFormDTO().get(key).listItem,
						inputDto.getListTableFormDTO().get(key).recordEditorDTO.getTableDef().getDefinitionOfColumnMap());
				// Insert Data
				if (inputDto.getListTableFormDTO().get(key).countRecord == 0) {
					try {
						databaseTableDAO.doInsert(filteredRecords, dto,
								inputDto.getListTableFormDTO().get(key).recordEditorDTO.getTableDef(),
								inputDto.getListTableFormDTO().get(key).tableFormDTO.getTableItemMap(),
								inputDto.getListTableFormDTO().get(key).recordEditorDTO.getDbConnectInfomationDTO()
										.getDatabaseId(),
								inputDto.getUserInfo());
					} catch (Exception e) {
						String[] args = { inputDto.getListTableFormDTO().get(key).tableFormDTO.getTableFormLabel() };
						throw new ApplicationDomainLogicException(MessageUtils.getMessage("FRM0200.add.E1-003", args));
					}


				}
				// Update Data
				else if (inputDto.getListTableFormDTO().get(key).countRecord == 1) {
					for (final Iterator<String> ite = inputDto.getListTableFormDTO().get(key).recordEditorDTO
							.getTableForm().getUpdateKeyList().iterator(); ite.hasNext();) {
						final String key1 = ite.next();
						dto.getConditions().put(key1, inputDto.getListTableFormDTO().get(key).listItem.get(key1));
					}
					try {
						databaseTableDAO.doUpdate(filteredRecords, dto,
								inputDto.getListTableFormDTO().get(key).recordEditorDTO.getTableDef(),
								inputDto.getListTableFormDTO().get(key).recordEditorDTO.getTableForm().getTableItemMap(),
								inputDto.getListTableFormDTO().get(key).recordEditorDTO.getDbConnectInfomationDTO()
										.getDatabaseId(),
								inputDto.getUserInfo());
					} catch (Exception e) {
						String[] args = { inputDto.getListTableFormDTO().get(key).recordEditorDTO.getTableForm().getTableFormLabel() };
						throw new ApplicationDomainLogicException(MessageUtils.getMessage("FRM0200.update.E1-003", args));
					}
				}
				// Delete Data
				else {
					final RetrievalProcessingOfRecordFromDatabaseLogic recordLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
					TableDefinitionDTO tableDefinitionDTO = recordLogic.getTableDefinitionDTO(
							inputDto.getConnectDefinitionId(), dto.getTableId(), inputDto.getUserInfo().getId());
					try {
						databaseTableDAO.doDelete(inputDto.getListTableFormDTO().get(key).getRecordSearchConditionDTO(),
								tableDefinitionDTO, dto.getTableId(), inputDto.getUserInfo());
					} catch (Exception e) {
						String[] args = { inputDto.getListTableFormDTO().get(key).tableFormDTO.getTableFormLabel() };
						throw new ApplicationDomainLogicException(MessageUtils.getMessage("FRM0200.del.E1-003", args));
					}

				}
			}
		}

	}
}
