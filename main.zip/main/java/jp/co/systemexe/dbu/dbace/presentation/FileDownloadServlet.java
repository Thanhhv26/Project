/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ファイルダウンロードサーブレット。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
@Deprecated
public class FileDownloadServlet extends BaseHttpServlet {

    /**
	 * <code>serialVersionUID</code> のコメント。
	 */
	private static final long serialVersionUID = 1L;

	/**
     * ファイルのダウンロードを行います。
     *
     * @param HttpServletRequest
     * @param HttpServletResponse
     * @exception ServletException
     * @exception IOException
     */
    @Override
    protected void service(
            final HttpServletRequest request,
            final HttpServletResponse response)
            throws ServletException, IOException {

        // TODO ダウンロードサーブレット実装
        //      　１．リクエストパラメータより、検索条件の取得。
        //      　２．BLOBファイルの検索処理。
        //      　３．ContentType、Headerの設定。
        //      　４．ストリーム出力。
        //      　５．後処理
        // パラメータは接続定義ID、テーブルID、からラムIDかな～

        // TODO 以下スタブ
        final String fileName = "reference.txt";
        response.setContentType("text/plain");
        response.setHeader("Content-Disposition","attachment;filename=\"" + fileName +"\"");

        final File file = new File("C:\\katrina1\\work\\" + fileName);
        InputStream is = null;

        try {
            is = new BufferedInputStream(new FileInputStream(file));

            response.setContentLength((int)file.length());


            final OutputStream os = response.getOutputStream();
            byte[] byteBuf = new byte[4096];
            int read = 0;
            while ((read = is.read(byteBuf)) != -1) {
                os.write(byteBuf, 0, read);
            }
        } catch (FileNotFoundException fileNotFoundException) {
            // TODO 例外処理
            fileNotFoundException.printStackTrace();
        } catch (IOException exception) {
            // TODO 例外処理
            exception.printStackTrace();
        } finally {
            if (is != null) {
                is.close();
            }
        }
    }
}
