/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.jdbc;

import java.sql.DatabaseMetaData;
import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.web.common.AppConst;

/**
 * JDBC メタデータ型の定義 enum。
 * <p>
 * この列挙体は java.sql.Types のラッパーです。</p>
 * <p>
 * SQL データ型と JDBC データ型、Java データ型とのマッピングに関しては
 * <a href="http://sdc.sun.co.jp/java/docs/j2se/1.4/ja/docs/ja/guide/jdbc/getstart/mapping.html">
 * 参考資料</p>をご確認下さい。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 * @see java.sql.Types
 */
public enum JDBCMetaDataType {
    BIT(java.sql.Types.BIT, "ビット（true/false）", AppConst.NULL_ONLY),
    TINYINT(java.sql.Types.TINYINT, "TINYINT（0_255）", AppConst.NULL_ONLY),
    SMALLINT(java.sql.Types.SMALLINT, "SMALLINT（-32768_32767）", AppConst.NULL_ONLY),
    INTEGER(java.sql.Types.INTEGER, "整数（-2147483648_2147483647）", AppConst.NULL_ONLY),
    BIGINT(java.sql.Types.BIGINT, "長整数（-9223372036854775808_9223372036854775807）", AppConst.NULL_ONLY),
    FLOAT(java.sql.Types.FLOAT, "倍精度浮動小数点（n.15桁）", AppConst.NULL_ONLY),
    REAL(java.sql.Types.REAL, "単精度浮動小数点（n.7桁）", AppConst.NULL_ONLY),
    DOUBLE(java.sql.Types.DOUBLE, "倍精度浮動小数点（n.15桁）", AppConst.NULL_ONLY),
    NUMERIC(java.sql.Types.NUMERIC, "固定精度10進数", AppConst.NULL_ONLY),
    DECIMAL(java.sql.Types.DECIMAL, "固定精度10進数", AppConst.NULL_ONLY),
    CHAR(java.sql.Types.CHAR, "固定長文字列", AppConst.NULL_FIXED),
    VARCHAR(java.sql.Types.VARCHAR, "可変長文字列", AppConst.NULL_VARIABLE),
    NCHAR(java.sql.Types.NCHAR, "固定長文字列", AppConst.NULL_FIXED),
    NVARCHAR(java.sql.Types.NVARCHAR, "可変長文字列", AppConst.NULL_VARIABLE),
    LONGVARCHAR(java.sql.Types.LONGVARCHAR, "長い可変長文字列", AppConst.NULL_VARIABLE),
    DATE(java.sql.Types.DATE, "日付（yyyy/MM/dd）", AppConst.NULL_ONLY),
    TIME(java.sql.Types.TIME, "時刻（hh:mm:ss）", AppConst.NULL_ONLY),
    TIMESTAMP(java.sql.Types.TIMESTAMP, "タイムスタンプ（yyyy/MM/dd HH:mm:ss.SSS）", AppConst.NULL_ONLY),
    BINARY(java.sql.Types.BINARY, "固定長バイナリ値", AppConst.NULL_ONLY),
    VARBINARY(java.sql.Types.VARBINARY, "可変長バイナリ値", AppConst.NULL_ONLY),
    LONGVARBINARY(java.sql.Types.LONGVARBINARY, "大きな可変長バイナリ値", AppConst.NULL_ONLY),
    NULL(java.sql.Types.NULL, "null パラメータ", AppConst.NULL_ONLY),
    OTHER(java.sql.Types.OTHER, "その他", AppConst.NULL_ONLY),
    JAVA_OBJECT(java.sql.Types.JAVA_OBJECT, "", AppConst.NULL_ONLY),
    DISTINCT(java.sql.Types.DISTINCT, "DISTINCT", AppConst.NULL_ONLY),
    STRUCT(java.sql.Types.STRUCT, "構造化", AppConst.NULL_ONLY),
    ARRAY(java.sql.Types.ARRAY, "配列", AppConst.NULL_ONLY),
    BLOB(java.sql.Types.BLOB, "Binary Large Object", AppConst.NULL_ONLY),
    CLOB(java.sql.Types.CLOB, "Character Large Object", AppConst.NULL_ONLY),
    REF(java.sql.Types.REF, "構造化型参照", AppConst.NULL_ONLY);

    private static Map<Integer, JDBCMetaDataType> map;
    static {
        map = new HashMap<Integer, JDBCMetaDataType>();
        for (final JDBCMetaDataType buff : values()) {
            map.put(buff.getDataType(), buff);
        }
    }

    /**
     * データタイプ数値に応じて定義インスタンスを検索して戻します。
     * <p>
     * JDBC DatabaseMetaData の DATA_TYPE 列の値に応じて定義インスタンスを戻し
     * ます。
     * </p><p>
     * 未定義の値の場合は OTHER を戻します。</p>
     * 
     * @param dataType JDBC DatabaseMetaData DATA_TYPE 列の数値
     * @return JDBCMetaDataType
     * @see DatabaseMetaData
     */
    public static JDBCMetaDataType dataTypeOf(final int dataType) {
        if (map.containsKey(dataType)) {
            return map.get(dataType);
        } else {
            return OTHER;
        }
    }

    /**
     * JDBC データタイプを示す数値。
     */
    private final int dataType;
    /**
     * データタイプの説明。
     */
    private final String explanation;
    
    /**
     * ※今回の対応では、文字列の型のみ1(可変長)または,2(固定長)にする
     * NULL_ONLY = 0 : where条件：is null/ is not null だけ（シングルクォーテーションと比較しない）
     * NULL_VARIABLE = 1 : is null/ is not null または シングルクォーテーションと比較
     * NULL_FIXED = 2 : is null/ is not null または 「項目をTRIM した結果」とシングルクォーテーション　比較
     */
    private final Integer searchStringFlag;

    /**
     * JDBC データタイプを示す数値を戻します。
     * 
     * @return int
     */
    public int getDataType() {
        return dataType;
    }

    /**
     * データタイプの説明を戻します。
     * 
     * @return String
     */
    public String getExplanation() {
        return explanation;
    }
    
    /**
     * @return searchStringFlag
     */
    public Integer getSearchStringFlag() {
        return searchStringFlag;
    }

    private JDBCMetaDataType(final int dataType, final String explanation, final Integer searchStringFlag) {
        this.dataType = dataType;
        this.explanation = explanation;
        this.searchStringFlag = searchStringFlag;
    }
	
}
