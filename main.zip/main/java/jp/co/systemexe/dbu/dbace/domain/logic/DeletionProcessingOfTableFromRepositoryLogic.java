/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * リポジトリからのテーブル情報の削除処理。
 * <p>
 * アプリケーションリポジトリからテーブル情報を削除します。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class DeletionProcessingOfTableFromRepositoryLogic
        extends BaseApplicationDomainLogic {

    /**
     * リポジトリからテーブル情報を削除する。
     * <p>
     * アプリケーションリポジトリからテーブル情報を削除します。</p>
     * 
     * @param connectDefinitionId
     * @param tableId
     * @throws ApplicationDomainLogicException
     */
    public void delete(final String connectDefinitionId, final String tableId)
            throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        try {
            dao.remove(connectDefinitionId, tableId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * DeletionProcessingOfTableFromRepositoryLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public DeletionProcessingOfTableFromRepositoryLogic() {
        return;
    }

    /**
     * テーブルフォーム DAO を生成して戻す。
     * 
     * @return TableFormDAO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDAO createTableFormDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
