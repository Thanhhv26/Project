/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import jp.co.systemexe.dbu.dbace.domain.BaseDbAccessApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.DbConnectDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * データベースからテーブル名一覧を取得するロジック。
 * <p>
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class TableNameListIsAcquiredFromDatabaseLogic
        extends BaseDbAccessApplicationDomainLogic {

    /**
     * データベース内のテーブル一覧を取得してリストに設定して戻します。
     * <p>
     * 取得する一覧は「スキーマ名.テーブル名」の一覧です。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param condition 検索条件
     * @param connectionUserLabel 接続ユーザー表示名
     * @return List&lt;スキーマ名.テーブル名&gt;
     * @throws ApplicationDomainLogicException
     */
//    public List<String> getTableNameList(
//            final String connectDefinitionId,
//            final String condition,
//            final String connectionUserLabel)
//            throws ApplicationDomainLogicException {
//        final List<String> list = getTableNameList(connectDefinitionId, connectionUserLabel);
//        final List<String> ret = new ArrayList<String>();
//        for (final Iterator<String> ite = list.iterator(); ite.hasNext();) {
//            final String name = ite.next();
//            if (name.matches(".*\\Q" + condition + "\\E.*")) {
//                ret.add(name);
//            }
//        }
//        return ret;
//    }

    /**
     * データベース内のテーブル一覧を取得してリストに設定して戻します。
     * <p>
     * 取得する一覧は「スキーマ名.テーブル名」の一覧です。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param connectionUserLabel 接続ユーザー表示名
     * @return List&lt;スキーマ名.テーブル名&gt;
     * @throws ApplicationDomainLogicException
     */
    public List<String> getTableNameList(
            final String connectDefinitionId,
            String condition,
            final String connectionUserLabel)
            throws ApplicationDomainLogicException {
        final AcquisitionOfConnectDefinitionLogic connectDefinitionLogic
            = new AcquisitionOfConnectDefinitionLogic();
        final DbConnectDefinitionDTO connectDefinitionDTO
            = connectDefinitionLogic.getConnectDefinitionDTO(connectDefinitionId);
        final DatabaseSchemaDAO dao = createDatabaseSchemaDAO(
                                        connectDefinitionDTO.getDatabaseTypeConnectionDestination());
        try {
            dao.connect(getDbConnectInfomation(connectDefinitionId));
        } catch (final DAOException e) {
            try {
                dao.close();
            } catch (final DAOException ex) {
                getLogger().warn(ex);
            }
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        final List<String> ret;
        try {
            ret = dao.getTableNameList(condition);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        } finally {
            try {
                dao.close();
            } catch (final DAOException e) {
                getLogger().warn(e);
            }
        }
        return ret;
    }

    /**
     * TableNameListIsAcquiredFromDatabaseLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public TableNameListIsAcquiredFromDatabaseLogic() {
        return;
    }
}
