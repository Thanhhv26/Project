/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic.definition;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;

/**
 * JDBC メタデータ型と HTML 要素の関係性定義 enum。
 * <p>
 * JDBC メタデータ型と、画面上でどう表現するかを示す HTML 要素の関係性を定義した
 * 列挙体です。<br />
 * また「編集可能か否か」の定義も併せて保持しています。即ち、本列挙体で「編集
 * 不可」と定義されているデータ型には、本アプリケーションは原則対応していません。
 * </p><p>
 * 本アプリケーションで対応していないデータ型を含むテーブルを編集するためには、
 * 別途カスタムアプリケーションを開発する必要があります。
 * </p><p>
 * 参考 :
 * <a herf="http://sdc.sun.co.jp/java/docs/j2se/1.4/ja/docs/ja/guide/jdbc/getstart/mapping.html">
 * 「SQL と Java の型のマッピング」</a>
 * </p>
 * 
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public enum RelationOfJdbcAndHtml {

    // TODO 以下「編集不可」定義のデータ型に関しては、徐々に対応範囲を拡張する...
    // TODO 対応のためには DAO 内でのデータ変換処理を実装する必要がある。読込、更新両方...

    /**
     * 配列型。
     * <p>対応していません。</p>
     */
    ARRAY_DEF(JDBCMetaDataType.ARRAY, DefinedHtmlElement.SPAN, false),
    BIGINT_DEF(JDBCMetaDataType.BIGINT, DefinedHtmlElement.INPUT_TEXT, true),
    BINARY_DEF(JDBCMetaDataType.BINARY, DefinedHtmlElement.SPAN, false),
    BIT_DEF(JDBCMetaDataType.BIT, DefinedHtmlElement.SPAN, false),
//    BLOB_DEF(JDBCMetaDataType.BLOB, DefinedHtmlElement.INPUT_FILE, true),
    BLOB_DEF(JDBCMetaDataType.BLOB, DefinedHtmlElement.SPAN, false),
    CHAR_DEF(JDBCMetaDataType.CHAR, DefinedHtmlElement.INPUT_TEXT, true),
    NCHAR_DEF(JDBCMetaDataType.NCHAR, DefinedHtmlElement.INPUT_TEXT, true),
    CLOB_DEF(JDBCMetaDataType.CLOB, DefinedHtmlElement.SPAN, false),
    DATE_DEF(JDBCMetaDataType.DATE, DefinedHtmlElement.INPUT_DATE, true),
    DECIMAL_DEF(JDBCMetaDataType.DECIMAL, DefinedHtmlElement.INPUT_TEXT, true),
    /**
     * 弁別型。
     * <p>対応していません。今後もユーザー定義型には対応出来ません。</p>
     */
    DISTINCT_DEF(JDBCMetaDataType.DISTINCT, DefinedHtmlElement.SPAN, false),
    DOUBLE_DEF(JDBCMetaDataType.DOUBLE, DefinedHtmlElement.INPUT_TEXT, true),
    FLOAT_DEF(JDBCMetaDataType.FLOAT, DefinedHtmlElement.INPUT_TEXT, true),
    INTEGER_DEF(JDBCMetaDataType.INTEGER, DefinedHtmlElement.INPUT_TEXT, true),
    /**
     * JAVA OBJECT 型。
     * <p>対応していません。</p>
     */
    JAVA_OBJECT_DEF(JDBCMetaDataType.JAVA_OBJECT, DefinedHtmlElement.SPAN,
            false),
    /**
     * LONGVARBINARY 型。
     * <p>原則ファイルデータの扱いとします。</p>
     */
//    LONGVARBINARY_DEF(JDBCMetaDataType.LONGVARBINARY,
//            DefinedHtmlElement.INPUT_FILE, true),
    LONGVARBINARY_DEF(JDBCMetaDataType.LONGVARBINARY,
        DefinedHtmlElement.SPAN, false),
    /**
     * LONGVARCHAR 型。
     * <p>原則ファイルデータの扱いとします。</p>
     */
//    LONGVARCHAR_DEF(JDBCMetaDataType.LONGVARCHAR,
//            DefinedHtmlElement.INPUT_FILE, true),
    LONGVARCHAR_DEF(JDBCMetaDataType.LONGVARCHAR, DefinedHtmlElement.INPUT_TEXT, true),
    /**
     * null パラメータ。
     * <p>原則無視します。</p>
     */
    NULL_DEF(JDBCMetaDataType.NULL, DefinedHtmlElement.SPAN, false),
    NUMERIC_DEF(JDBCMetaDataType.NUMERIC, DefinedHtmlElement.INPUT_TEXT, true),
    /**
     * その他の型。
     * <p>原則無視します。</p>
     */
    OTHER_DEF(JDBCMetaDataType.OTHER, DefinedHtmlElement.SPAN, false),
    REAL_DEF(JDBCMetaDataType.REAL, DefinedHtmlElement.INPUT_TEXT, true),
    /**
     * 参照型。
     * <p>対応していません。</p>
     */
    REF_DEF(JDBCMetaDataType.REF, DefinedHtmlElement.SPAN, false),
    SMALLINT_DEF(JDBCMetaDataType.SMALLINT, DefinedHtmlElement.INPUT_TEXT, true),
    /**
     * STRUCT 型。
     * <p>対応していません。</p>
     */
    STRUCT_DEF(JDBCMetaDataType.STRUCT, DefinedHtmlElement.SPAN, false),
    TIME_DEF(JDBCMetaDataType.TIME, DefinedHtmlElement.INPUT_TIME, true),
    TIMESTAMP_DEF(JDBCMetaDataType.TIMESTAMP, DefinedHtmlElement.INPUT_TIMESTAMP,
            true),
    TINYINT_DEF(JDBCMetaDataType.TINYINT, DefinedHtmlElement.INPUT_TEXT, true),
    /**
     * VARBINARY 型。
     * <p>原則ファイルデータの扱いとします。</p>
     */
//  VARBINARY_DEF(JDBCMetaDataType.VARBINARY, DefinedHtmlElement.INPUT_FILE,
//  true),
    VARBINARY_DEF(JDBCMetaDataType.VARBINARY, DefinedHtmlElement.SPAN,false),
    VARCHAR_DEF(JDBCMetaDataType.VARCHAR, DefinedHtmlElement.INPUT_TEXT, true),
    NVARCHAR_DEF(JDBCMetaDataType.NVARCHAR, DefinedHtmlElement.INPUT_TEXT, true);

    private static Map<JDBCMetaDataType, RelationOfJdbcAndHtml> map;
    static {
        map = new HashMap<JDBCMetaDataType, RelationOfJdbcAndHtml>();
        for (final RelationOfJdbcAndHtml buff : values()) {
            map.put(buff.getJdbc(), buff);
        }
    }

    /**
     * JDBC メタデータ型から定義を検索して戻します。
     * 
     * @param type
     * @return
     */
    public static RelationOfJdbcAndHtml metaDataTypeOf(
            final JDBCMetaDataType type) {
        if (map.containsKey(type)) {
            return map.get(type);
        } else {
        	// MI-F-0004=JDBCデータタイプのマッピングに失敗しました。JDBCデータタイプ {0} は存在しません。
        	final String args[] = {type.toString()};
            throw new IllegalArgumentException(MessageUtils.getMessage("MI-F-0004", args));
        }
    }

    /**
     * JDBC メタデータ型。
     */
    private final JDBCMetaDataType jdbc;

    /**
     * HTML タイプ。
     */
    private final DefinedHtmlElement html;

    /**
     * 対応しているか否か。
     */
    private final boolean correspond;

    /**
     * 対応しているか否かを戻します。
     * 
     * @return boolean
     */
    public boolean isCorrespond() {
        return correspond;
    }

    /**
     * html を戻します。
     * 
     * @return DefinedHtmlElement
     */
    public DefinedHtmlElement getHtml() {
        return html;
    }

    /**
     * jdbc を戻します。
     * 
     * @return JDBCMetaDataType
     */
    public JDBCMetaDataType getJdbc() {
        return jdbc;
    }

    /**
     * RelationOfJdbcAndHtml の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param jdbc
     * @param html
     * @param correspond
     */
    private RelationOfJdbcAndHtml(final JDBCMetaDataType jdbc,
            final DefinedHtmlElement html, final boolean editing) {
        this.jdbc = jdbc;
        this.html = html;
        this.correspond = editing;
    }
}
