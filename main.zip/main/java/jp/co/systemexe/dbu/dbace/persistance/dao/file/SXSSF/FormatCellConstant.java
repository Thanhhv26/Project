package jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF;

/**
 * @author van-thanh
 *
 */
public class FormatCellConstant {

	public static String CHARACTER = "Character";
	public static String NUMERIC = "Numeric";
	public static String DATE = "Date";
	public static String DATE_TIME = "DateTime";

}
