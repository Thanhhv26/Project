/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
public class ApplicationRuntimeException extends RuntimeException implements IUtilException {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	private static final long serialVersionUID = 1L;
	private long errCode = -1;

	/**
	 * Constructor.
	 */
	public ApplicationRuntimeException() {
		super();
	}

	/**
	 * Constructor.
	 */
	public ApplicationRuntimeException(String message) {
		super(message);
		logger.error(message);
	}

	/**
	 * Constructor.
	 */
	public ApplicationRuntimeException(Throwable cause) {
		super(cause);
		logger.error(cause.getMessage(), cause);
	}

	/**
	 * Constructor.
	 */
	public ApplicationRuntimeException(String message, Throwable cause) {
		super(message, cause);
		logger.error(message, cause);
	}

	/**
	 * Constructor.
	 */
	public ApplicationRuntimeException(long errCode, String message) {
		super(message);
		logger.error(message);
		this.setErrCode(errCode);
	}

	/**
	 * Constructor.
	 */
	public ApplicationRuntimeException(long errCode, Throwable cause) {
		super(cause);
		logger.error(cause.getMessage(), cause);
		this.setErrCode(errCode);
	}

	/**
	 * Constructor.
	 */
	public ApplicationRuntimeException(long errCode, String message, Throwable cause) {
		super(message, cause);
		logger.error(message, cause);
		this.setErrCode(errCode);
	}

	public long getErrCode() {
		return errCode;
	}
	private void setErrCode(long errCode) {
		this.errCode = errCode;
	}
}
