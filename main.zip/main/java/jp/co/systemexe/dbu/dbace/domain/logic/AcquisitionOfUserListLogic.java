/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectItem;
import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;
import jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.web.user.model.UserInformation;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * ユーザー一覧情報の取得ロジック。
 * <p>
 * </p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class AcquisitionOfUserListLogic extends BaseApplicationDomainLogic {

    /**
     * プルダウンリスト表示用の一覧リストを戻す。
     * <p>
     * 接続定義要素に登録されたユーザーの一覧を取得してリストに設定して戻します。
     * ユーザーが一件も登録されていない場合は例外をスローします。
     * </p>
     *
     * @return List&lt;IdSelectable&gt;
     * @throws ApplicationDomainLogicException
     */
    public List<IdSelectable> getIdSelectableList()
            throws ApplicationDomainLogicException {
        final ApplicationUserDAO dao = createApplicationUserDAO();
        final Map<String, String> map;
        try {
            map = dao.getUserNameMap();
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        final List<IdSelectable> ret = new ArrayList<IdSelectable>();
        for (final Iterator<String> ite = map.keySet().iterator(); ite
            .hasNext();) {
            final String key = ite.next();
            ret.add(new IdSelectItem(key, map.get(key)));
        }
        return ret;
    }

    /**
     * プルダウンリスト表示用の一覧リストを戻す。
     * <p>
     * 接続定義要素に登録されたユーザーの一覧を取得してリストに設定して戻します。
     * ユーザーが一件も登録されていない場合は例外をスローします。
     * </p>
     *
     * @return List&lt;IdSelectable&gt;
     * @throws ApplicationDomainLogicException
     */
    public Map<String, UserInformation> getUserInformationMap()
            throws ApplicationDomainLogicException {
        try {
            final ApplicationUserDAO dao = createApplicationUserDAO();
            return dao.getUserInformationMap();
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * AcquisitionOfUserListLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public AcquisitionOfUserListLogic() {
        return;
    }

    /**
     * アプリケーションユーザー DAO を生成して戻す。
     *
     * @return ApplicationUserDAO
     * @throws ApplicationDomainLogicException
     */
    private ApplicationUserDAO createApplicationUserDAO()
            throws ApplicationDomainLogicException {
        try {
            return (ApplicationUserDAO)createDAO("ApplicationUserDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
