package jp.co.systemexe.dbu.dbace.web.common;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.util.StringUtils;

import jp.co.systemexe.dbu.dbace.library.util.SpringContextHelper;

/**
 * Application utilities
 *
 * @author long-hai
 *
 */
public final class ApplicationUtils implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;
	/** logger */
    protected static Logger logger = LoggerFactory.getLogger(ApplicationUtils.class);

	/**
	 * Gets the message source bundle
	 *
	 * @return the message source bundle
	 */
	private static MessageSource getMessageSource() {
		return SpringContextHelper.findBean(MessageSource.class);
	}

	/**
	 * Get message content from properties file based on system's locale
	 *
	 * @param messageKey
	 * @return
	 */
	public static String getMessage(String messageKey, Object... args) {
		return getMessage(messageKey, args, messageKey);
	}
	/**
	 * Get message content from properties file based on system's locale
	 *
	 * @param messageKey
	 * @return
	 */
	public static String getMessage(String messageKey, Object[] args, String defmessage) {
		return getMessage(messageKey, args, defmessage, LocaleContextHolder.getLocale());
	}
	/**
	 * Get message content from properties file based on locale
	 *
	 * @param messageKey message key
	 * @param args message arguments
	 * @param defmessage default message while not found
	 * @param locale message locale
	 *
	 * @return message content or default message
	 */
	public static String getMessage(String messageKey, Object[] args, String defmessage, Locale locale) {
		// checks parameters
		if (!StringUtils.hasText(messageKey)) return defmessage;
		// parses message source bane
		MessageSource msgSrc = getMessageSource();
		// if not in job
		try {
			locale = (locale == null ? Locale.getDefault() : locale);
			logger.debug(MessageFormat.format(
					"Get message from bundle with key [{0}] and locale [{1}]",
					(messageKey == null ? "NULL" : messageKey),
					(locale == null ? "NULL" : locale.getDisplayLanguage())));
			return msgSrc.getMessage(messageKey, args, locale);
		}
		catch (NoSuchMessageException e) {
			logger.error(e.getMessage(), e);
			return defmessage;
		}
		catch (Throwable e) {
			logger.error(e.getMessage(), e);
			return defmessage;
		}
	}

	public static String getLocaleLang() {
		Locale locale = LocaleContextHolder.getLocale();
		locale = (locale == null ? Locale.ENGLISH : locale);
		return locale.getLanguage();
	}
	public static boolean isEnglish() {
		return "en".equalsIgnoreCase(getLocaleLang());
	}
	public static boolean isJapanese() {
		return "jp".equalsIgnoreCase(getLocaleLang());
	}
	public static boolean isVietnamese() {
		return "vi".equalsIgnoreCase(getLocaleLang());
	}
	public static String chooseByLocale(String viVal, String enVal, String jpVal) {
		String sVal = (StringUtils.hasText(viVal) ? viVal : StringUtils.hasText(enVal) ? enVal : jpVal);
		return (isVietnamese() && StringUtils.hasText(viVal) ? viVal
				: isEnglish() && StringUtils.hasText(enVal) ? enVal
						: isJapanese() && StringUtils.hasText(jpVal) ? jpVal
								: sVal);
	}
}
