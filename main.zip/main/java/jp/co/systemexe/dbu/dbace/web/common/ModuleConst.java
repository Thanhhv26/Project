package jp.co.systemexe.dbu.dbace.web.common;

/**
 * The module code constants
 *
 * @author THANH-TRUC
 *
 */
public abstract class ModuleConst {
	/**
	 * Common HOME modules
	 */
	public static final String CMN_HOME = "C0900";
	/**
	 * 個人プロファイル
	 */
	public static final String PERSONAL_PROFILE = "FRM0600";
	/**
	 * システム管理
	 */
	public static final String EXTERNAL_AUTHENTICATION = "FRM0510";	//ユーザー外部認証設定
	public static final String ENVIRONMENT = "FRM0520";	//環境設定
	public static final String AUDIT = "FRM0530";	//監査ログ設定
	/**
	 * ユーザー管理
	 */
	public static final String USER_SEARCH = "FRM0400";	//検索
	public static final String USER_ADD = "FRM0401";	//新規登録
	public static final String USER_EDIT = "FRM0402";	//編集
	public static final String USER_DELETE = "FRM0403";	//削除
	/**
	 * Database
	 */
	public static final String DB_SEARCH = "FRM0500";	//DB接続設定
	/**
	 * DBオブジェクト設定
	 */
	public static final String OBJECT_SETTING = "FRM0300";
	/**
	 * 項目カスタマイズ
	 */
	public static final String OBJECT_ITEM = "FRM0310";	//項目カスタマイズ
	public static final String OBJECT_RELATION = "FRM0320";	//リレーション設定
	public static final String OBJECT_DATAMANIPULATION = "FRM0330";	//画面作成

	/**
	 * データ操作
	 */
	public static final String RECORD_EXPLORER = "FRM0200";	//検索
	public static final String RECORD_EXPLORER_ALL_TABLE = "FRM0201";	//検索
	public static final String RECORD_ADD = "FRM0210";	//新規作成
	public static final String RECORD_EDIT = "FRM0220";	//編集
	public static final String RECORD_COPY = "FRM0230";	//編集
	public static final String RECORD_VIEW = "FRM0240";	//編集
	public static final String RECORD_DELETE = "FRM0250";	//削除
	public static final String RECORD_DOWNLOAD = "FRM0260";	//削除
	public static final String RECORD_UPLOAD = "FRM0270";	//削除

	/**
	 * Common SOCKET modules
	 */
	public static final String CMN_SOCK = "C0300";
	public static final String CMN_SOCK_WS = "C0400";
	public static final String CMN_SOCK_CHAT = "C0500";
	public static final String CMN_SOCK_USERS_ONLINE = "C0600";
	/**
	 * Common security modules
	 */
	public static final String CMN_SEC_TOKEN = "C0700";
	public static final String CMN_SEC_USERNAME = "C0800";

	/**
	 * Common DASHBOARD modules
	 */
	public static final String CMN_DASHBOARD = "C1000";
	public static final String CMN_DASHBOARD_MASTER = "C1001";
	public static final String CMN_DASHBOARD_HR = "C1002";
	public static final String CMN_DASHBOARD_ACCOUNTING = "C1003";
	public static final String CMN_DASHBOARD_SALARY = "C1004";

	/**
	 * Common TASK TODAY/NEXT modules (current user info)
	 */
	public static final String CMN_TASK_TODAY = "C1100";
	public static final String CMN_TASK_NEXT = "C1101";

}
