/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.config;

import java.io.File;

/**
 * システムディレクトリ定義列挙体。
 * <p>
 * 本アプリケーションが動作する上で、リソースが配置される固定ディレクトリ位置を
 * 定義した列挙体です。
 * </p><p>
 * 実行環境の自己構築に対応するため、ディレクトリ生成メソッド等を実装しています。
 * </p>
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public enum SystemDirectories {
    /**
     * ワークディレクトリ（作業用ディレクトリ）定義。
     */
    WORK_DIR("../work");

    private final String path;

    /**
     * path を戻します。
     * <p>ディレクトリパスの表記揺れを解消するため、一度ファイルオブジェクトを
     * 生成し、補正された path 文字列を戻します。</p>
     * 
     * @return String
     */
    public final String getPath() {
        return new File(this.path).getPath();
    }

    /**
     * File オブジェクトを戻す。
     * 
     * @return File
     */
    public File getFileObject() {
        return new File(this.path);
    }

    /**
     * ディレクトリの有無を確認し、無ければ作成する。
     * 
     * @return false : 有ったので何もしない / true : 無かったので作成
     */
    public boolean makeDir() {
        final File dir = getFileObject();
        if (dir.exists() == false) {
            dir.mkdir();
            return true;
        }
        return false;
    }

    /**
     * SystemDirectories の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param path ディレクトリパス。
     */
    private SystemDirectories(final String path) {
        this.path = path;
    }
}
