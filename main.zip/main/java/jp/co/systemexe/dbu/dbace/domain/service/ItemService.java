/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service;

import java.util.List;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectConnectListDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectItemDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectItemDTOSave;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectTablesDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SortColumnEditorDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SortDataEditorDTO;
import jp.co.systemexe.dbu.dbace.web.item.model.FRM0310ResultModel;

/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 jan 18, 2017
 */
public interface ItemService {
	/**
	 *
	 * @param EnvironmentDto
	 * @return
	 * @throws ApplicationRuntimeException
	 */
	public List<IdSelectable> doInitialize(UserAuthority userAuthority) throws ApplicationRuntimeException;

	public FRM0310ResultModel searchTable(SelectConnectListDTO search) throws ApplicationRuntimeException;
	public FRM0310ResultModel searchColumn(SelectTablesDTO search, String userInfo) throws ApplicationRuntimeException;
	public FRM0310ResultModel doEditItem(SelectItemDTO search) throws ApplicationRuntimeException;
	public FRM0310ResultModel doOnceDefaultValue(SelectItemDTO search, UserInfo userInfo) throws ApplicationRuntimeException;
	public FRM0310ResultModel doOnceAddRestrictionItem(SelectItemDTO search, UserInfo userInfo) throws ApplicationRuntimeException;
	public FRM0310ResultModel doOnceDelitationRestrictionItem(SelectItemDTO search, UserInfo userInfo) throws ApplicationRuntimeException;
	public FRM0310ResultModel doOnceSqlCheck(SelectItemDTO search, UserInfo userInfo) throws ApplicationRuntimeException;
	public FRM0310ResultModel doOnceSave(SelectItemDTOSave search, UserInfo userInfo) throws ApplicationRuntimeException;
	public FRM0310ResultModel loadSortData(SelectTablesDTO selectTablesDTO) throws ApplicationRuntimeException;
	public FRM0310ResultModel updateSortData(SortDataEditorDTO sortDataEditorDTO, UserInfo userInfo);

	public FRM0310ResultModel loadSortColumn(SelectTablesDTO selectTablesDTO) throws ApplicationRuntimeException;
	public FRM0310ResultModel updateSortColumn(SortColumnEditorDTO sortColumnEditorDTO, UserInfo userInfo);
	public boolean isMultiTable(String connectDefinisionId, String tableFormId) throws  ApplicationDomainLogicException;
}
