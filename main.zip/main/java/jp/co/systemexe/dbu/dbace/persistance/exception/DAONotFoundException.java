/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.exception;

import jp.co.systemexe.dbu.dbace.common.exception.SystemException;

/**
 * DAO 未登録例外。
 * <p>
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class DAONotFoundException extends SystemException {
    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 970154049870043403L;

    /**
     * DAONotFoundException の生成。
     * <p>コンストラクタ。</p>
     *
     * @param message
     * @param te
     */
    public DAONotFoundException(final String message, final Throwable te) {
        super(message, te);
    }

    /**
     * DAONotFoundException の生成。
     * <p>コンストラクタ。</p>
     *
     * @param te
     */
    public DAONotFoundException(final Throwable te) {
        super(te);
    }
}
