/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.logger;

import org.apache.log4j.Logger;

/**
 * AuditLog 用のロガーオブジェクト。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class AuditLogger implements jp.co.systemexe.dbu.dbace.common.logger.Logger {
    private final Logger logger;

    /**
     * ロガーを返します。
     * 
     * @return
     */
    public Logger getLogger() {
        return logger;
    }
    
    /**
     * SimpleLogger の生成。
     * 
     * @param className 呼び出し元クラス名。
     */
    public AuditLogger(final String className) {
        logger = Logger.getLogger(className);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object)
     */
    @Deprecated
    public void fatal(final Object obj) {
//        log.fatal(obj);
        return;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object, java.lang.Throwable)
     */
    @Deprecated
    public void fatal(Object obj, Throwable te) {
//        log.fatal(obj, te);
        return;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object)
     */
    @Deprecated
    public void error(final Object obj) {
//        log.error(obj);
        return;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object, java.lang.Throwable)
     */
    @Deprecated
    public void error(Object obj, Throwable te) {
//        log.error(obj, te);
        return;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object)
     */
    @Deprecated
    public void warn(final Object obj) {
//        log.warn(obj);
        return;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object, java.lang.Throwable)
     */
    @Deprecated
    public void warn(Object obj, Throwable te) {
//        log.warn(obj, te);
        return;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object)
     */
    public void info(final Object obj) {
        logger.info(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object, java.lang.Throwable)
     */
    @Deprecated
    public void info(Object obj, Throwable te) {
//        log.info(obj, te);
        return;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object)
     */
    @Deprecated
    public void debug(final Object obj) {
//        log.debug(obj);
        return;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object, java.lang.Throwable)
     */
    @Deprecated
    public void debug(Object obj, Throwable te) {
//        log.debug(obj, te);
        return;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#isDebugEnabled()
     */
    public boolean isDebugEnabled() {
        return false;
    }
}
