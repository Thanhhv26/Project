/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.xml.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * 項目表示用定義済み HTML 要素 enum。
 * <p>
 * テーブルアイテムを画面に表示する際に指定できる HTML 要素種類を定義した列挙体
 * です。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public enum DefinedHtmlElement {
    /**
     * テキストボックス。
     */
    INPUT_TEXT("input_text", "テキストフィールド"),
    /**
     * テキストボックス（日付型）。
     */
    INPUT_DATE("input_date", "日付型(YYYY/MM/DD)"),
    /**
     * テキストボックス（日付時刻型）。
     */
    INPUT_DATETIME("input_datetime", "日付時刻型(YYYY/MM/DD hh:mm:ss)"),
    /**
     * テキストボックス（タイムスタンプ型）。
     */
    INPUT_TIMESTAMP("input_timestamp", "タイムスタンプ型(YYYY/MM/DD hh:mm:ss.sss)"),
    /**
     * テキストボックス（時刻型）。
     */
    INPUT_TIME("input_time", "時刻型(hh:mm:ss)"),
//    /**
//     * パスワード入力欄。
//     */
//    INPUT_PASSWORD("input_password", "パスワード"),
//    /**
//     * チェックボックス。
//     */
//    INPUT_CHECKBOX("input_checkbox", "チェックボックス"),
    /**
     * ラジオボタン。
     */
    INPUT_RADIO("input_radio", "ラジオボタン"),
    // TODO ファイル処理は７月以降に対応予定
//    /**
//     * ファイル。
//     * <p>画像を除くバイナリ項目は原則このタイプとなります。</p>
//     */
//    INPUT_FILE("input_file", "ファイル"),
//    /**
//     * 画像データ。
//     */
//    INPUT_IMAGE("input_image", "画像"),
    /**
     * 複数行テキスト。
     */
    TEXTAREA("textarea", "テキストエリア"),
    /**
     * プルダウンリスト。
     * <p>サイズ指定を行わない select 要素です。</p>
     */
    SELECT("select", "プルダウンリスト"),
//    /**
//     * リストボックス。
//     * <p>サイズ指定を行った select 要素です。</p>
//     */
//    SELECT_SIZE("select_size", "リストボックス"),
    /**
     * 非編集ラベル。
     */
    SPAN("span", "表示のみ");

    private static Map<String, DefinedHtmlElement> map;
    static {
        map = new HashMap<String, DefinedHtmlElement>();
        for (final DefinedHtmlElement buff : values()) {
            map.put(buff.getKey(), buff);
        }
    }

    /**
     * キー値に対応した定義インスタンスを検索して戻す。
     * <p>
     * 未定義キーだった場合、強制的に span を戻します。</p>
     * 
     * @param key
     * @return DefinedHtmlElement
     */
    public static DefinedHtmlElement keyOf(final String key) {
        if (map.containsKey(key)) {
            return map.get(key);
        } else {
            return SPAN;
        }
    }

    private final String key;
    private final String label;

    /**
     * key を戻します。
     * 
     * @return String
     */
    public String getKey() {
        return key;
    }

    /**
     * label を戻します。
     * 
     * @return String
     */
    public String getLabel() {
        return label;
    }

    private DefinedHtmlElement(final String key, final String label) {
        this.key = key;
        this.label = label;
    }
}
