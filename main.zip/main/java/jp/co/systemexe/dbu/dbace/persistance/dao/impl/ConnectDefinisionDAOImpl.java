/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.util.SecurePwdBlowfishUtils;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfAppRelationLogic;
import jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.DAOFactory;
import jp.co.systemexe.dbu.dbace.persistance.dto.ConnectDefinisionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.DbConnect;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.DbConnect.Database;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.DbConnect.DatabaseUrl;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.DbConnect.Port;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.DbConnect.Server;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.DbConnect.User;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.ConnectDefinision;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForms;
import jp.co.systemexe.dbu.dbace.web.connect.dto.ConnectDto;

/**
 * 接続定義情報 DAO。
 * <p>
 * リポジトリに対する接続定義情報 DAO です。
 * </p>
 *
 * @author EXE 相田 一英
 * @version 0.0.0
 */
public class ConnectDefinisionDAOImpl extends BaseRepositoryXmlDAO implements ConnectDefinisionDAO {

	/**
	 * 接続定義名の一覧を取得して戻します。
	 *
	 * @return Map&lt;接続定義 ID, 接続定義ラベル&gt;
	 * @throws DAOException
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO#getConnectDefinisionNameMap()
	 */
	public Map<String, String> getConnectDefinisionNameMap() throws DAOException {
		final Map<String, String> ret = new HashMap<String, String>();
		for (final Iterator<ConnectDefinision> ite = getRepository().getConnectDefinision().iterator(); ite
				.hasNext();) {
			final ConnectDefinision def = ite.next();
			ret.put(def.getId(), def.getLabel());
		}
		return ret;
	}

	/**
	 * 接続定義情報 DTO を戻す。
	 * <p>
	 * リポジトリから接続定義情報 DTO を取得して戻します。ID に該当する DTO が 存在しない場合は null を戻します。
	 * </p>
	 *
	 * @return ConnectDefinisionDTO
	 * @throws DAOException
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO#getConnectDefinisionDTO(java.lang.String)
	 */
	public ConnectDefinisionDTO getConnectDefinisionDTO(final String connectDefinitionId) throws DAOException {
		for (final Iterator<ConnectDefinision> ite = getRepository().getConnectDefinision().iterator(); ite
				.hasNext();) {
			final ConnectDefinision def = ite.next();
			if (def.getId().equals(connectDefinitionId)) {
				final ConnectDefinisionDTO ret = new ConnectDefinisionDTO();
				ret.setConnectDefinisionId(def.getId());
				ret.setConnectDefinisionLabel(def.getLabel());
				return ret;
			}
		}
		return null;
	}

	/**
	 * 接続定義情報 DTO を戻す。
	 * <p>
	 * リポジトリから接続定義情報 DTO を取得して戻します。ID に該当する DTO が 存在しない場合は null を戻します。
	 * </p>
	 *
	 * @return ConnectDefinisionDTO
	 * @throws DAOException
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO#getConnectDefinisionDTO(java.lang.String)
	 */
	public ConnectDefinisionDTO getConnectDefinisionDTOByLable(final String connectDefinitionId) throws DAOException {
		for (final Iterator<ConnectDefinision> ite = getRepository().getConnectDefinision().iterator(); ite
				.hasNext();) {
			final ConnectDefinision def = ite.next();
			if (def.getLabel().equals(connectDefinitionId)) {
				final ConnectDefinisionDTO ret = new ConnectDefinisionDTO();
				ret.setConnectDefinisionId(def.getId());
				ret.setConnectDefinisionLabel(def.getLabel());
				return ret;
			}
		}
		return null;
	}

	/**
	 * 接続定義情報を保存します。
	 * <p>
	 * 接続定義情報 DTO の内容をリポジトリに保存します。既存の場合はラベル等の 更新を、新規の場合は新しい接続定義情報要素を作成（新規追加）します。
	 * </p>
	 *
	 * @param dto
	 *            ConnectDefinisionDTO
	 * @throws DAOException
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO#save(jp.co.systemexe.dbu.dbace.persistance.dto.ConnectDefinisionDTO)
	 */
	public void save(final ConnectDefinisionDTO dto) throws DAOException {
		for (final Iterator<ConnectDefinision> ite = getRepository().getConnectDefinision().iterator(); ite
				.hasNext();) {
			final ConnectDefinision def = ite.next();
			if (def.getId().equals(dto.getConnectDefinisionId())) {
				def.setLabel(dto.getConnectDefinisionLabel());
				update();
				return;
			}
		}
		final ConnectDefinision def = getObjectFactory().createRepositoryConnectDefinision();
		def.setId(dto.getConnectDefinisionId());
		def.setLabel(dto.getConnectDefinisionLabel());
		getRepository().getConnectDefinision().add(def);
		update();
	}

	/**
	 * 接続定義情報を削除します。
	 * <p>
	 * 接続定義情報をリポジトリから完全に削除します。
	 * </p>
	 *
	 * @param connectDefinitionId
	 * @throws DAOException
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO#remove(java.lang.String)
	 */
	public void remove(final String connectDefinitionId) throws DAOException {
		for (final Iterator<ConnectDefinision> ite = getRepository().getConnectDefinision().iterator(); ite
				.hasNext();) {
			final ConnectDefinision def = ite.next();
			if (def.getId().equals(connectDefinitionId)) {
				ite.remove();
				break;
			}
		}

		update();

		// ■XML削除対象の追加
		//・relation_infoの中でtable.connectidが、削除するDB接続情報と同じ場合、対象の「relation」を削除
		PreservationOfAppRelationLogic relationLogic = new PreservationOfAppRelationLogic();
		try {
			relationLogic.removeRelationsByConnectionId(connectDefinitionId);
		} catch (ApplicationDomainLogicException e) {
			// TODO Auto-generated catch block
			throw new DAOException(e);
		}


	}

	/**
	 * ConnectDefinisionDAOImpl の生成。
	 * <p>
	 * コンストラクタ。
	 * </p>
	 *
	 * @throws DAOException
	 */
	public ConnectDefinisionDAOImpl() throws DAOException {
		super();
	}

	/**
	 *
	 *
	 */
	@Override
	public Map<String, ConnectDto> getAllConnectDefinisions() {
		final Map<String, ConnectDto> ret = new HashMap<String, ConnectDto>();
		for (final Iterator<ConnectDefinision> ite = getRepository().getConnectDefinision().iterator(); ite
				.hasNext();) {
			final ConnectDefinision def = ite.next();
			ConnectDto connectDto = new ConnectDto();
			connectDto.setConnectDefinition(def.getId());
			connectDto.setConnectDefinitionName(def.getLabel());
			connectDto.setTemplateDatabaseUrl(def.getDbConnect().getDatabaseTypeConnectionDestination());
			connectDto.setPort(def.getDbConnect().getPort().getValue());
			connectDto.setServerId(def.getDbConnect().getServer().getId());
			connectDto.setInstanceName(def.getDbConnect().getInstanceName());
			connectDto.setUseDatabaseUrl(def.getDbConnect().getDatabaseUrl().isUse());
			connectDto.setDatabaseId(def.getDbConnect().getDatabase().getId());
			connectDto.setDatabaseUrl(def.getDbConnect().getDatabaseUrl().getUrl());
			connectDto.setPid(def.getDbConnect().getUser().getId());
			connectDto.setPassword(def.getDbConnect().getPassword());

			ret.put(def.getId(), connectDto);
		}
		return ret;
	}

	@Override
	public int insert(ConnectDto newConnectDto) throws DAOException {
		final ConnectDefinision def = getObjectFactory().createRepositoryConnectDefinision();
		def.setDbConnect(new DbConnect());
		def.setTableForms(new TableForms());
		def.getDbConnect().setDatabase(new Database());
		def.getDbConnect().setPort(new Port());
		def.getDbConnect().setServer(new Server());
		def.getDbConnect().setDatabaseUrl(new DatabaseUrl());
		def.getDbConnect().setUser(new User());

		def.setId(newConnectDto.getConnectDefinition());
		def.setLabel(newConnectDto.getConnectDefinitionName());

		def.getDbConnect().setInstanceName(newConnectDto.getInstanceName());
		def.getDbConnect().setDatabaseTypeConnectionDestination(newConnectDto.getTemplateDatabaseUrl());

		SecurePwdBlowfishUtils securePwdBlowfishUtils = new SecurePwdBlowfishUtils();
		def.getDbConnect().setPassword(securePwdBlowfishUtils.encrypt(newConnectDto.getPassword(), openSesame()));

		def.getDbConnect().getPort().setId("");
		def.getDbConnect().getPort().setValue(newConnectDto.getPort());

		def.getDbConnect().getServer().setId(newConnectDto.getServerId());
		def.getDbConnect().getServer().setLabel("");

		if (newConnectDto.getUseDatabaseUrl() == null ? Boolean.FALSE : newConnectDto.getUseDatabaseUrl()) {
			def.getDbConnect().getDatabaseUrl().setUrl(newConnectDto.getDatabaseUrl());
			def.getDbConnect().getServer().setId("");
			def.getDbConnect().getServer().setLabel("");
			def.getDbConnect().getPort().setId("");
			def.getDbConnect().getPort().setValue("");
			def.getDbConnect().getDatabase().setId("");
			def.getDbConnect().getDatabase().setLabel("");
			def.getDbConnect().setInstanceName("");
		} else {
			def.getDbConnect().getDatabaseUrl().setUrl("");
		}
		def.getDbConnect().getDatabaseUrl()
				.setUse(newConnectDto.getUseDatabaseUrl() == null ? Boolean.FALSE : newConnectDto.getUseDatabaseUrl());

		def.getDbConnect().getUser().setId(newConnectDto.getPid());
		def.getDbConnect().getUser().setLabel("");

		def.getDbConnect().getDatabase().setId(newConnectDto.getDatabaseId());
		def.getDbConnect().getDatabase().setLabel("");

		getRepository().getConnectDefinision().add(def);
		update();
		return 1;
	}

	@Override
	public int update(ConnectDto connectDto) throws DAOException {
		for (final Iterator<ConnectDefinision> ite = getRepository().getConnectDefinision().iterator(); ite
				.hasNext();) {
			final ConnectDefinision def = ite.next();
			if (def.getId().equals(connectDto.getConnectDefinition())) {
				def.setLabel(connectDto.getConnectDefinitionName());

				def.getDbConnect().setInstanceName(connectDto.getInstanceName());
				def.getDbConnect().setDatabaseTypeConnectionDestination(connectDto.getTemplateDatabaseUrl());

				SecurePwdBlowfishUtils securePwdBlowfishUtils = new SecurePwdBlowfishUtils();
				if (!def.getDbConnect().getPassword().equals(connectDto.getPassword())) {
					def.getDbConnect().setPassword(securePwdBlowfishUtils.encrypt(connectDto.getPassword(), openSesame()));
				}

				def.getDbConnect().getPort().setId("");
				def.getDbConnect().getPort().setValue(connectDto.getPort());

				def.getDbConnect().getServer().setId(connectDto.getServerId());
				def.getDbConnect().getServer().setLabel("");

				if (connectDto.getUseDatabaseUrl() == null ? Boolean.FALSE : connectDto.getUseDatabaseUrl()) {
					def.getDbConnect().getDatabaseUrl().setUrl(connectDto.getDatabaseUrl());
					def.getDbConnect().getServer().setId("");
					def.getDbConnect().getServer().setLabel("");
					def.getDbConnect().getPort().setId("");
					def.getDbConnect().getPort().setValue("");
					def.getDbConnect().getDatabase().setId("");
					def.getDbConnect().getDatabase().setLabel("");
					def.getDbConnect().setInstanceName("");
				} else {
					def.getDbConnect().getDatabaseUrl().setUrl("");
					def.getDbConnect().getDatabase().setId(connectDto.getDatabaseId());
					def.getDbConnect().getDatabase().setLabel("");
				}
				def.getDbConnect().getDatabaseUrl().setUse(
						connectDto.getUseDatabaseUrl() == null ? Boolean.FALSE : connectDto.getUseDatabaseUrl());

				def.getDbConnect().getUser().setId(connectDto.getPid());
				def.getDbConnect().getUser().setLabel("");

				update();
				return 1;
			}
		}

		return 0;
	}

	@Override
	public void testConnect(ConnectDto newConnectDto) throws DAOException {
		BaseDatabaseDAO dao = (BaseDatabaseDAO) DAOFactory.createDAO("DatabaseSchemaDAO",
				DatabaseTypeConnectionDestination.keyOf(newConnectDto.getTemplateDatabaseUrl()));
		SecurePwdBlowfishUtils securePwdBlowfishUtils = new SecurePwdBlowfishUtils();
		DbConnectInfomationDTO dto = new DbConnectInfomationDTO();
		dto.setDatabaseId(newConnectDto.getDatabaseId());
		dto.setDatabaseTypeConnectionDestination(DatabaseTypeConnectionDestination.keyOf(newConnectDto.getTemplateDatabaseUrl()));
		dto.setDatabaseUrl(newConnectDto.getDatabaseUrl());
		dto.setInstanceName(newConnectDto.getInstanceName());
		dto.setPassword(securePwdBlowfishUtils.decrypt(newConnectDto.getPassword(), openSesame()));
		if(dto.getPassword() == null && newConnectDto.getPassword() != null){
			dto.setPassword(newConnectDto.getPassword());
		}

		dto.setPortId(newConnectDto.getPort());
		dto.setServerId(newConnectDto.getServerId());
		dto.setUseDatabaseUrl(newConnectDto.getUseDatabaseUrl());
		dto.setUserId(newConnectDto.getPid());
		dao.testConnect(dto);
	}

	@Override
	public List<Repository.ConnectDefinision> getAllConnectDefinisionsList() {
		List<Repository.ConnectDefinision> ret = new ArrayList<Repository.ConnectDefinision>();
		for (final Iterator<ConnectDefinision> ite = getRepository().getConnectDefinision().iterator(); ite
				.hasNext();) {
			final ConnectDefinision def = ite.next();
			ret.add(def);
		}
		return ret;
	}

}
