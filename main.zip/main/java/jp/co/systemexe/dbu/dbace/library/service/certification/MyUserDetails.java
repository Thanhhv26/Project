/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.service.certification;
import java.util.Collection;
import java.util.List;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
public class MyUserDetails implements UserDetails{

	private static final long serialVersionUID = 1L;
	private String userid;
	private String username;
    private String password;
    private List<GrantedAuthority> authorities;
    private UserInfoDTO userInfoDTO;
    private UserInfo userInfo;
    /**
	 * 外部認証
	 */
	private String extAuth;
	private String clientIpAddress;
	private String serverName;

    public MyUserDetails(String userid,String username, String password, List<GrantedAuthority> authorities){
    	this.setUserid(userid);
         this.username = username;
         this.password = password;
         this.authorities = authorities;
    }
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
         return authorities;
    }
    @Override
    public String getPassword() {
         return password;
    }
    @Override
    public String getUsername() {
         return username;
    }
	public void setUserName(String username) {
		this.username = username;
	}
    @Override
    public boolean isAccountNonExpired() {
         return true;
    }
    @Override
    public boolean isAccountNonLocked() {
         return true;
    }
    @Override
    public boolean isCredentialsNonExpired() {
         return true;
    }
    @Override
    public boolean isEnabled() {
         return true;
    }
	public UserInfoDTO getUserInfoDTO() {
		return userInfoDTO;
	}
	public void setUserInfoDTO(UserInfoDTO userInfoDTO) {
		this.userInfoDTO = userInfoDTO;
	}
	public String getExtAuth() {
		return extAuth;
	}
	public void setExtAuth(String extAuth) {
		this.extAuth = extAuth;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	/**
	 * @return the clientIpAddress
	 */
	public String getClientIpAddress() {
		return clientIpAddress;
	}
	/**
	 * @param clientIpAddress the clientIpAddress to set
	 */
	public void setClientIpAddress(String clientIpAddress) {
		this.clientIpAddress = clientIpAddress;
	}
	/**
	 * @return the serverName
	 */
	public String getServerName() {
		return serverName;
	}
	/**
	 * @param serverName the serverName to set
	 */
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	/**
	 * @return the userInfo
	 */
	public UserInfo getUserInfo() {
		return userInfo;
	}
	/**
	 * @param userInfo the userInfo to set
	 */
	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

}
