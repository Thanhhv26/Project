/**
 * Copyright(C) 2008 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import jp.co.systemexe.dbu.dbace.persistance.dao.BaseDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportResultDTO;

/**
 * データ一括インポートにおける、エラーメッセージ情報ファイル入出力の基底抽象クラス。
 * 
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public abstract class BaseFileImportResultDAO extends BaseDAO {
    /**
     * ファイル出力を行います。
     *
     * @param dto
     * @return fileName ファイル名
     * @param outputStream
     */
    public abstract String outputFile(
            final FileImportResultDTO dto)
            throws DAOException;

    /**
     * ファイルを読み込みます。
     *
     * @param fileName
     */
    public abstract FileImportResultDTO inputFile(
            final String fileName)
            throws DAOException;

    /**
     * ファイルを削除します。
     *
     * @param fileName
     */
    public abstract void deleteFile(
            final String fileName)
            throws DAOException;

}
