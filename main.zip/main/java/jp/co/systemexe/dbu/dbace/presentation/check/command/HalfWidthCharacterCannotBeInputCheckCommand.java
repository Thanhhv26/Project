/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.ItemRestriction;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;

/**
 * 半角文字入力不可チェック。
 * <p>
 * 半角数値、半角カナ、半角英語、半角記号の入力を禁じる項目用の
 * チェックコマンドです。<br />
 * つまり、全角文字のみで入力する必要がある場合のチェックです。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class HalfWidthCharacterCannotBeInputCheckCommand extends BaseLogicalCheckCommand {

    /**
     * コントロールコード及び半角英字数字を定義した正規表現文字列。
     */
//	private static final String REGEX = ".*[ -~｡-ﾟ]+.*";
	private static final String REGEX = ".*[\\w\\sｧ-ﾝﾞﾟ､｡ｰ!-~]+.*";

    /**
     * Jisx0201CannotBeInputCheckCommand の生成。
     * <p>コンストラクタ。</p>
     */
    public HalfWidthCharacterCannotBeInputCheckCommand() {
        return;
    }

    /**
     * 検査を実行します。
     * <p>
	 * 半角数値、半角カナ、半角英語、半角記号、いわゆる「半角文字」を検出したら警告を設定します。<br />
     * 「半角文字」とは、いわゆる ASCII に含まれる符号と、日本語の半角カタカナの
     * 事です。
     * </p>
     *
     * @param columnId カラム名
     * @param messages 論理チェック結果メッセージ保持 DTO
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#check(java.lang.String, java.lang.String, jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO)
     */
    @Override
    public void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
  		final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap) {
        final String value = messages.getCorrectedValue(columnId);
        if (value == null || value.equals("")) {
            return;
        }

        // TODO 半角 --> 全角補正は面倒なので後ほど改めて実装...

        if (value.matches(REGEX)) {
        	//MI-E-0105={0}に半角文字は入力できません。
        	String columnLabel = tableItemMap.get(columnId).getItemLabel();
        	final String args[]={columnLabel};
            messages.getMessages(columnId).add(MessageUtils.getMessage("MI-E-0105",args));
        }
    }

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * このクラスが検査対象とする条件は、
     * <ol>
     *  <li>リポジトリの入力値制約に JISX0201_CANNOT_BE_INPUT 制約が存在する場合。</li>
     * </ol>
     * </p>
     *
     * @param columnId
     * @return true : 検査担当 / false : 担当ではない
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#isMyTask(java.lang.String)
     */
    @Override
    protected boolean isMyTask(final String columnId) {
        final TableItemDTO item = getDisplayDef().getItemDefinitions().get(
            columnId);
        if (item.getItemRestrictions().containsKey(
            ItemRestriction.JISX0201_CANNOT_BE_INPUT)) {
            return true;
        }
        return false;
    }
}
