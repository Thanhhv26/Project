/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;

/**
 * テーブルのデータベース内定義情報を戻します。
 * <p>
 * データベースから最新のテーブル・カラム定義情報を取得し保持するための DTO
 * です。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class TableDefinitionDTO {
    /**
     * ロガーインスタンスを保持します。
     */
    private final Logger logger;

    /**
     * テーブル ID。
     * <p>テーブル名と等価です。前方がスキーマ名で修飾されています。</p>
     */
    private String tableId;

    /**
     * VIEWか否か
     */
    private boolean isView;

    /**
     * カラム名マップ。
     * <p>SortedMap&lt;インデックス番号, カラム名&gt;</p>
     */
    private SortedMap<Integer, String> columnNames = new TreeMap<Integer, String>();

    /**
     * データベースカラム定義保持マップ。
     */
    private Map<String, DefinitionOfColumn> definitionOfColumnMap = new HashMap<String, DefinitionOfColumn>();

    /**
     * カラム名マップを戻します。
     * <p>
     * このマップのインデックス番号がカラムの並び順になります。</p>
     *
     * @return SortedMap&lt;インデックス番号, カラム名&gt;
     */
    public SortedMap<Integer, String> getColumnNames() {
        return columnNames;
    }

    /**
     * データベースカラム定義保持マップを戻します。
     *
     * @return Map<String,DefinitionOfColumn>
     */
    public Map<String, DefinitionOfColumn> getDefinitionOfColumnMap() {
        return definitionOfColumnMap;
    }

    /**
     * tableId を戻します。
     *
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * TableDefinitionDTO の生成。
     * <p>
     * コンストラクタ。テーブル名の初期化を行います。</p>
     *
     * @param tableId テーブル ID（スキーマ名.テーブル名）
     */
    public TableDefinitionDTO(final String tableId) {
        this.tableId = tableId;
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
    }

    /**
     * isView を戻します。
     *
     * @return boolean
     */
    public boolean isView() {
        return isView;
    }

    /**
     * isView を設定します。
     *
     * @param boolean isView
     */
    public void setView(boolean isView) {
        this.isView = isView;
    }

	/**
	 * クラスが保持しているプロパティ情報をログ出力します。
	 */
	public void outputDebugLog() {
		outputDebugLog(0);
	}

	/**
	 * クラスが保持しているプロパティ情報をログ出力します。
	 */
	public void outputDebugLog(final int index) {
		if (logger.isDebugEnabled()) {
			final String indexString = LoggerUtils.getIndexString(index);
			logger.debug(indexString + "TableDefinitionDTO ---------- DEBUG START");
			logger.debug(indexString + "　Table ID:" + tableId);
			logger.debug(indexString + "　Is View:" + isView);

			for (final Integer sortIndex : columnNames.keySet()) {
				final String columnId = columnNames.get(sortIndex);
				logger.debug(indexString + "　Column ID:" + columnId);
				logger.debug(indexString + "　　Index:" + index);

				final DefinitionOfColumn def = definitionOfColumnMap.get(columnId);
				def.outputDebugLog(index + 2);
			}

			logger.debug("　TableDefinitionDTO ---------- DEBUG END");
		}
	}
}
