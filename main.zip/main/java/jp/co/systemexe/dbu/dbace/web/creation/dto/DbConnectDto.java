/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.DbConnect;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

@Data
public class DbConnectDto {
    private DbConnectDto.Server server;
    private DbConnectDto.Port port;
    private String databaseTypeConnectionDestination;
    private DbConnectDto.Database database;
    private DbConnectDto.User user;
    private String password;
    private String instanceName;
    private DbConnectDto.DatabaseUrl databaseUrl;
    
    public DbConnectDto(){
    	
    }
    
    public DbConnectDto(DbConnectDto dbConnectDto){
    	if(dbConnectDto == null){
    		return;
    	}
    	this.setServer(dbConnectDto.getServer());
    	this.setPort(dbConnectDto.getPort());
    	this.setDatabaseTypeConnectionDestination(dbConnectDto.getDatabaseTypeConnectionDestination());
    	this.setDatabase(dbConnectDto.getDatabase());
    	this.setUser(dbConnectDto.getUser());
    	this.setPassword(dbConnectDto.getPassword());
    	this.setInstanceName(dbConnectDto.getInstanceName());
    	this.setDatabaseUrl(dbConnectDto.getDatabaseUrl());
    }
    
    public DbConnectDto(DbConnect dbConnect){
    	if(dbConnect == null){
    		return;
    	}
    	this.setServer(new DbConnectDto.Server(dbConnect.getServer()));
    	this.setPort(new DbConnectDto.Port(dbConnect.getPort()));
    	this.setDatabaseTypeConnectionDestination(dbConnect.getDatabaseTypeConnectionDestination());
    	this.setDatabase(new DbConnectDto.Database(dbConnect.getDatabase()));
    	this.setUser(new DbConnectDto.User(dbConnect.getUser()));
    	this.setPassword(dbConnect.getPassword());
    	this.setInstanceName(dbConnect.getInstanceName());
    	this.setDatabaseUrl(new DbConnectDto.DatabaseUrl(dbConnect.getDatabaseUrl()));
    }
    
    @Data
    public static class Server {
    	private String id;
    	private String label;
        
        public Server(){ 
        	
        }
        
        public Server(DbConnect.Server server){
        	this.setId(server == null ? null : server.getId());
        	this.setLabel(server == null ? null : server.getLabel());
        }
        
        public Server(DbConnectDto.Server server){
        	this.setId(server == null ? null : server.getId());
        	this.setLabel(server == null ? null : server.getLabel());
        }
    }
    
    @Data
    public static class Port {
    	private String id;
    	private String value;
        
        public Port(){
        	
        }
        
        public Port(DbConnect.Port port){
        	this.setId(port == null ? null : port.getId());
        	this.setValue(port == null ? null : port.getValue());
        }
        
        public Port(DbConnectDto.Port port){
        	this.setId(port == null ? null : port.getId());
        	this.setValue(port == null ? null : port.getValue());
        }
    }
    
    @Data
    public static class Database {
    	private String id;
    	private String label;
        
        public Database(){
        	
        }
        
        public Database(DbConnect.Database database){
        	this.setId(database == null ? null : database.getId());
        	this.setLabel(database == null ? null : database.getLabel());
        }
        
        public Database(DbConnectDto.Database database){
        	this.setId(database == null ? null : database.getId());
        	this.setLabel(database == null ? null : database.getLabel());
        }
    }
    
    @Data
    public static class User {
    	private String id;
    	private String label;
        
        public User(){ 
        	
        }
        
        public User(DbConnect.User user){
        	this.setId(user == null ? null : user.getId());
        	this.setLabel(user == null ? null : user.getLabel());
        }
        
        public User(DbConnectDto.User user){
        	this.setId(user == null ? null : user.getId());
        	this.setLabel(user == null ? null : user.getLabel());
        }
    }
    
    @Data
    public static class DatabaseUrl {
    	private Boolean use;
    	private String url;
        
        public DatabaseUrl(){ 
        	
        }
        
        public DatabaseUrl(DbConnect.DatabaseUrl databaseUrl){
        	this.setUse(databaseUrl == null ? null : databaseUrl.isUse());
        	this.setUrl(databaseUrl == null ? null : databaseUrl.getUrl());
        }
        
        public DatabaseUrl(DbConnectDto.DatabaseUrl databaseUrl){
        	this.setUse(databaseUrl == null ? null : databaseUrl.getUse());
        	this.setUrl(databaseUrl == null ? null : databaseUrl.getUrl());
        }
    }
}
