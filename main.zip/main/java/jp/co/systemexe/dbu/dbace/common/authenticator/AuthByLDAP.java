/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.authenticator;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.presentation.AdLdapServerType;
import jp.co.systemexe.dbu.dbace.presentation.LdapUserServerIdentify;

/**
 * AuthByLDAP クラス
 *
 * @version 5.0.0_0
 */
public class AuthByLDAP {
	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	private String authServerId;
	private String authServerType;
	private String authServerPort;
	private String authDomain;
	private String authServerUserIdentify;
	private String authServerProtocol;
	private String authServerSecurity;
	private String authServerTimeout;
	private String username;
	private String password;

	public AuthByLDAP() {
		super();
	}

	/**
	 * getHost
	 *
	 * @param ssl
	 * @return String
	 */
	private String getHost(boolean ssl) {
		return (ssl ? "ldaps://" : "ldap://") + this.getAuthServerId() + ":" + this.getAuthServerPort();
	}

	/**
	 * isSSLProtocol
	 *
	 * @return boolean
	 */
	private boolean isSSLProtocol() {
		return this.getAuthServerProtocol().equalsIgnoreCase("true");
	}

	/**
	 * getFullUserPath
	 *
	 * @return List
	 * @throws ApplicationDomainLogicException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<String> getFullUserPath() throws ApplicationDomainLogicException {
		List<String> listPath = new ArrayList<String>();
		try {
			Hashtable env = new Hashtable();
			// Contextはjavax.namingパッケージにあるインターフェース
			// と定義されている。ここではJNDIプロバイダに使用するクラスを指定している。
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			// ディレクトリサービスに使用するホストとポート番号を指定する。
			env.put(Context.PROVIDER_URL, this.getHost(this.isSSLProtocol()));
			// ディレクトリコンテキストへの参照を取得する。
			DirContext ctx = new InitialDirContext(env);
			// 検索のスコープを指定する。
			SearchControls constraints = new SearchControls();
			constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
			// 実際の検索を実行する。検索ベース、フィルタ、検索のスコープを含む制約を与える。
			NamingEnumeration<?> results = ctx.search(this.getAuthDomain(), this.getFilter(), constraints);
			// 検索の結果をたどってみる
			while (results != null && results.hasMore()) {
				String userFullPath = StringUtils.EMPTY;
				SearchResult sr = (SearchResult) results.next();
				String dn = sr.getName();
				userFullPath += dn + "," + this.getAuthDomain();
				if (userFullPath.startsWith(this.getUsername())) {
					listPath.add(userFullPath);
				}
			}
		} catch (Exception e) {
			logger.error(e);
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}
		return listPath;
	}

	/**
	 * Connect to LDAP server
	 * 
	 * @throws ApplicationDomainLogicException
	 */
	public boolean connect() throws ApplicationException {
		Hashtable<String, Object> env = new Hashtable<String, Object>();
		// JNDIライブラリを使う
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		try {
			if (this.isSSLProtocol()) {
				env.put(Context.SECURITY_PROTOCOL, "ssl");
				// SSL -> SECURITY_AUTHENTICATION must be EXTERNAL
				env.put(Context.SECURITY_AUTHENTICATION, ExtAuthSecProtocol.EXTERNAL.getValue());
				env.put(Context.PROVIDER_URL, this.getHost(this.isSSLProtocol()));
			} else {
				// Default is simple
				env.put(Context.SECURITY_AUTHENTICATION, this.getAuthServerSecurity());
				env.put(Context.PROVIDER_URL, this.getHost(this.isSSLProtocol()));
			}
			env.put("com.sun.jndi.ldap.read.timeout", this.getAuthServerTimeout());
			env.put(Context.SECURITY_CREDENTIALS, this.getPassword());
			if (AdLdapServerType.AD.getKey().equalsIgnoreCase(this.getAuthServerType())) {
				env.put(Context.SECURITY_PRINCIPAL, this.getUsername() + "@" + this.getAuthDomain());
				this.ping(env);
				return true;
			} else if (AdLdapServerType.LDAP.getKey().equalsIgnoreCase(this.getAuthServerType())) {
				List<String> paths = this.getFullUserPath();
				for (String userPath : paths) {
					env.put(Context.SECURITY_PRINCIPAL, userPath);
					this.ping(env);
				}
				return true;
			}
		} catch (ApplicationDomainLogicException e) {
			logger.error(e);
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}
		return false;
	}

	/**
	 *
	 *
	 * @param env
	 * @return
	 * @throws ApplicationException
	 */
	private void ping(Hashtable<String, Object> env) throws ApplicationException {
		LdapContext ctx = null;
		try {
			ctx = new InitialLdapContext(env, null);
		} catch (NamingException ex) {
			logger.error("=== LDAP Connection: FAILED ===\n" + ex.getMessage());
			throw new ApplicationDomainLogicException(ex.getMessage(), ex);
		} finally {
			try {
				if (ctx != null) {
					ctx.close();
				}
			} catch (Exception ex) {
				logger.error(ex.getMessage());
			}
		}
	}

	/**
	 * authServerId を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerId() {
		return authServerId;
	}

	/**
	 * authServerId を設定します。
	 *
	 * @param String
	 *            authServerId
	 */
	public void setAuthServerId(String authServerId) {
		this.authServerId = authServerId;
	}

	/**
	 * authServerPort を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerPort() {
		return authServerPort;
	}

	/**
	 * authServerPort を設定します。
	 *
	 * @param String
	 *            authServerPort
	 */
	public void setAuthServerPort(String authServerPort) {
		this.authServerPort = authServerPort;
	}

	/**
	 * authDomain を戻します。
	 *
	 * @return String
	 */
	public String getAuthDomain() {
		return authDomain;
	}

	/**
	 * authDomain を設定します。
	 *
	 * @param String
	 *            authDomain
	 */
	public void setAuthDomain(String authDomain) {
		this.authDomain = authDomain;
	}

	/**
	 * authServerProtocol を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerProtocol() {
		return authServerProtocol;
	}

	/**
	 * authServerProtocol を設定します。
	 *
	 * @param String
	 *            authServerProtocol
	 */
	public void setAuthServerProtocol(String authServerProtocol) {
		this.authServerProtocol = authServerProtocol;
	}

	/**
	 * authServerSecurity を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerSecurity() {
		return authServerSecurity;
	}

	/**
	 * authServerSecurity を設定します。
	 *
	 * @param String
	 *            authServerSecurity
	 */
	public void setAuthServerSecurity(String authServerSecurity) {
		this.authServerSecurity = authServerSecurity;
	}

	/**
	 * authServerTimeout を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerTimeout() {
		return authServerTimeout;
	}

	/**
	 * authServerTimeout を設定します。
	 *
	 * @param String
	 *            authServerTimeout
	 */
	public void setAuthServerTimeout(String authServerTimeout) {
		this.authServerTimeout = authServerTimeout;
	}

	/**
	 * getFilter
	 *
	 * @return String
	 */
	private String getFilter() {
		return "(" + this.getUsername() + ")";
	}

	/**
	 * username を戻します。
	 *
	 * @return String
	 */
	private String getUsername() {
		final AdLdapServerType serverType = AdLdapServerType.keyOf(authServerType);
		if (AdLdapServerType.AD.equals(serverType)) {
			return username;
		}
		if (LdapUserServerIdentify.cn.getKey().equalsIgnoreCase(this.getAuthServerUserIdentify())) {
			return LdapUserServerIdentify.cn.getKey().concat("=").concat(this.username);
		} else if (LdapUserServerIdentify.uid.getKey().equalsIgnoreCase(this.getAuthServerUserIdentify())) {
			return LdapUserServerIdentify.uid.getKey().concat("=").concat(this.username);
		} else {
			return username;
		}
	}

	/**
	 * username を設定します。
	 *
	 * @param String
	 *            username
	 */
	public void setUsername(String username) {
		this.username = username;
	}

	/**
	 * password を戻します。
	 *
	 * @return String
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * password を設定します。
	 *
	 * @param String
	 *            password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * authServerUserIdentify を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerUserIdentify() {
		return authServerUserIdentify;
	}

	/**
	 * authServerUserIdentify を設定します。
	 *
	 * @param String
	 *            authServerUserIdentify
	 */
	public void setAuthServerUserIdentify(String authServerUserIdentify) {
		this.authServerUserIdentify = authServerUserIdentify;
	}

	/**
	 * authServerType を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerType() {
		return authServerType;
	}

	/**
	 * authServerType を設定します。
	 *
	 * @param String
	 *            authServerType
	 */
	public void setAuthServerType(String authServerType) {
		this.authServerType = authServerType;
	}
}
