/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author bao-anh
 *
 */

@Data
public class SelectTargetedColumnSearchCondition {
	/**
	 * 1ページの最大値
	 */
	public final static int MAX_ITEM_COUNT = 500;

	UserInfo userInfo;

	private String isWindowClose = "false";
	public String getIsWindowClose() {
		return isWindowClose;
	}
	public void setIsWindowClose(String isWindowClose) {
		this.isWindowClose = isWindowClose;
	}


	private String searchCondition;
	private String currentConnectDefinisionId;
	private String currentTableId;
	private String currentColumnId;

	private List<SelectableItem> columnContentsItems;
	private String value;
	private String label;
    private Integer columnContentsIndex;
    private boolean display;
    private Integer pageIndex;

    /**
     * 現在の表示件数
     */
    private int nowViewableRecordCount;

    /**
     * レコード検索結果件数 プロパティ
     */
    private int resultRowCount;


	/**
	 *
	 */
	private List<MessageInfo> messageInfo;

	/**
	 *
	 */
	public SelectTargetedColumnSearchCondition() {
		messageInfo = new ArrayList<MessageInfo>();
	}
}
