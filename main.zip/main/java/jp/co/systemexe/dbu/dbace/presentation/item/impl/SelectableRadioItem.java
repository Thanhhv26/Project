/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneRadioItem;

/**
 * （JavaDoc）。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class SelectableRadioItem implements SelectOneRadioItem {
    private String label;
    private String value;

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneRadioItem#getLabel()
     */
    public String getLabel() {
        return label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneRadioItem#getValue()
     */
    public String getValue() {
        return value;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneRadioItem#setLabel(java.lang.String)
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneRadioItem#setValue(java.lang.String)
     */
    public void setValue(String value) {
        this.value = value;
    }
}
