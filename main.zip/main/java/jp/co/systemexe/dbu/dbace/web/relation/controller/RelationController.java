/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.relation.controller;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.dto.IdSelectTableLabeExtendConnectDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfTableLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.DeletionProcessingOfTableFromRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfAppRelationLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.TableNameListIsAcquiredFromRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.service.CreationService;
import jp.co.systemexe.dbu.dbace.library.service.certification.MyUserDetails;
import jp.co.systemexe.dbu.dbace.library.util.Constants;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.web.common.AppConst;
import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;
import jp.co.systemexe.dbu.dbace.web.creation.dto.RelationsDto.RelationDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.creation.json.FRM0330JsonSearch;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationCreateColumnNameDefDTO;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationCreateInfoDTO;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationDTO;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationDeleteDTO;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationInformation;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationMessageInfo;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationMessageResult;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationScreenDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.GetTableDependenceDatabaseDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SearchCriteria;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SelectTablesDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.TableConnectRelationDTO;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;
import jp.co.systemexe.dbu.dbace.web.user.dto.PageInfo;

/**
 * リポジトリ情報構築画面要素ページクラス。
 * <p>
 * リポジトリ情報設定クラスです。リポジトリへのテーブルの追加登録、
 * 登録の削除を行います。
 * </p><p>
 * 登録の際には、データベース内のテーブルメタデータを元に、リポジトリ内の画面
 * 項目定義情報の初期化を行います。<br />
 * 具体的には各項目の HTML 要素型やプライマリキー属性の付加などの初期値割り振り
 * を行います。
 * </p>
 *
 * @author tu-lenh
 * @version 0.0.0
 */
@RestController
@RequestMapping(value = "/data")
public class RelationController extends AbstractController {
	private static final long serialVersionUID = 1L;

	@Autowired
	CreationService creationService;
	/**
	 * get info page
	 * @return view
	 */
	@RequestMapping(value = "/relation/getInfoPage", method = { RequestMethod.POST })
	public PageInfo getInfoPage() throws Exception {
		return new PageInfo();
	}

	@RequestMapping(value="/relation",method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index(Model model) throws Exception {
		ModelAndView mv = new ModelAndView(PageConst.SCREEN_OBJECT_RELATION);
		//model.addAttribute("connectDefinitionIdItems", initDataForTestConnectDefinitionIdItems());
		return mv;
	}

	@RequestMapping(value = "/relation/getsearchresult",method = RequestMethod.POST )
	 public @ResponseBody RelationMessageResult doOnceValueTableSearch(@RequestBody SearchCriteria search) {
		RelationMessageResult result = new RelationMessageResult();
//		String nullPointerException = null;
//		nullPointerException.length();

		try{
			search.setUserAuthority(getUserAuthority());
			result = getDataForSearchRelation(search);

			OutputAuditLog.writeRelationLog(
					getUserInfo(), //userInfo
					AuditStatus.success,
					"",//databaseName
					"",
					AuditEventKind.SEARCH,
					String.valueOf(result.getRelations().size()));
		}catch(Exception e){
			OutputAuditLog.writeRelationLog(
					getUserInfo(), //userInfo
					AuditStatus.failure,
					"",//databaseName
					"",
					AuditEventKind.SEARCH,
					"");
		}
		return result;
	 }

	@RequestMapping(value = "/relation/getlistobject",method = RequestMethod.POST )
	 public @ResponseBody List<IdSelectTableLabeExtendConnectDTO> doGetListObject(@RequestBody SearchCriteria search) throws Exception {
			return iniDataFormRepositoryListObject(search);
	 }

	@RequestMapping(value = "/relation/getDataColumn",method = RequestMethod.POST )
	 public @ResponseBody Map<String, RecordEditorInformationDTO> doGetDataColumn(@RequestBody TableConnectRelationDTO search) {
		 	Map<String, RecordEditorInformationDTO> tableDefinitions = new HashMap<String, RecordEditorInformationDTO>();
		 	GetTableDependenceDatabaseDTO tableConnect1 = search.getTableConnect1();
			GetTableDependenceDatabaseDTO tableConnect2 = search.getTableConnect2();
			RecordEditorInformationDTO table1 =getInfoTable(tableConnect1);
			RecordEditorInformationDTO table2 =getInfoTable(tableConnect2);
			tableDefinitions.put("table1", table1);
			tableDefinitions.put("table2", table2);
			return tableDefinitions;
	 }

	@RequestMapping(value = "/relation/getDataColumnEdit",method = RequestMethod.POST )
	 public @ResponseBody Map<String, RecordEditorInformationDTO> doGetDataColumnEdit(@RequestBody TableConnectRelationDTO search) {
			AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		 	Map<String, RecordEditorInformationDTO> tableDefinitions = new HashMap<String, RecordEditorInformationDTO>();
		 	GetTableDependenceDatabaseDTO tableConnect1 = search.getTableConnect1();
			GetTableDependenceDatabaseDTO tableConnect2 = search.getTableConnect2();
			RecordEditorInformationDTO table1 =getInfoTable(tableConnect1);
			RecordEditorInformationDTO table2 =getInfoTable(tableConnect2);
			tableDefinitions.put("table1", table1);
			tableDefinitions.put("table2", table2);

			final PreservationOfAppRelationLogic logicRelation = new PreservationOfAppRelationLogic();
			RecordEditorInformationDTO relation = new RecordEditorInformationDTO();
			String relationId = search.getId();
			ApplicationRelationDTO relationDTO = new ApplicationRelationDTO();
			try {
				relationDTO = logicRelation.getApplicationRelationDTO(relationId);
				relation.setRelation(relationDTO);
				tableDefinitions.put("relation", relation);

				//view
				if(AppConst.ACTION_VIEW.equals(search.getAction())){
					OutputAuditLog.writeRelationLog(
							getUserInfo(), //userInfo
							AuditStatus.success,
							logic.getConnectionByID(tableConnect1.getConnectDefinitionId()).getLabel(),//databaseName
							relationDTO.getRelationLabel(),
							AuditEventKind.REFERENCE,
							String.valueOf(1));
				}
			} catch (ApplicationDomainLogicException e) {
				//view
				if(AppConst.ACTION_VIEW.equals(search.getAction())){
					try {
						OutputAuditLog.writeRelationLog(
								getUserInfo(), //userInfo
								AuditStatus.failure,
								logic.getConnectionByID(tableConnect1.getConnectDefinitionId()).getLabel(),//databaseName
								relationDTO.getRelationLabel(),
								AuditEventKind.REFERENCE,
								"");
					} catch (ApplicationDomainLogicException e1) {
						getLogger().error(e1);
					}
				}

				getLogger().error(e);
			}
			return tableDefinitions;
	 }

	/**
	 * @param tableconnect
	 * @return
	 */
	public RecordEditorInformationDTO getInfoTable(GetTableDependenceDatabaseDTO tableConnect) {
		final RecordEditorInformationDTO dto = new RecordEditorInformationDTO();
		String selectedConnectDefinisionId = tableConnect.getConnectDefinitionId();
		String tableId = tableConnect.getTableId();
	    try {
			final AcquisitionOfTableLogic tableLogic = new AcquisitionOfTableLogic();
			TableFormDTO tableFormDTO = tableLogic.getTableFormDTO(selectedConnectDefinisionId, tableId);
			Map<String, TableItemDTO> tableItemSortedMap = getTableItemMapSorted(tableFormDTO);
			tableFormDTO.setTableItemMap(tableItemSortedMap);
			 dto.setTableForm(tableFormDTO);
			 return dto;
	    } catch (final ApplicationDomainLogicException e) {
	        //addPageMessage(e.getMessage());
	        return null;
	    }
	}

	/**
	 * @param tableFormDTO
	 * @return
	 */
	private Map<String, TableItemDTO> getTableItemMapSorted(TableFormDTO tableFormDTO) {
		List<TableItemDTO> tableItemList=new ArrayList<>(tableFormDTO.getTableItemMap().values());
		Collections.sort(tableItemList, new Comparator<TableItemDTO>() {
			  @Override
			  public int compare(final TableItemDTO o1, final TableItemDTO o2) {
			    return o1.getSortIndex() > o2.getSortIndex() ? 1:-1;
			  }
			});
		Map<String, TableItemDTO> tableItemSortedMap = new LinkedHashMap<String, TableItemDTO>();
		for (TableItemDTO item : tableItemList){
			tableItemSortedMap.put(item.getItemId(),item);
		}
		return tableItemSortedMap;
	}

	@RequestMapping(value = "/relation/getlistobjecttype",method = RequestMethod.POST )
	 public @ResponseBody List<IdSelectTableLabeExtendConnectDTO> doGetListObjectType(@RequestBody GetTableDependenceDatabaseDTO search) throws Exception {
		return iniDataFormRepositoryListObjectType(search);
	 }

	@RequestMapping(value="/relation/objectcreaterelation",method = { RequestMethod.GET, RequestMethod.POST })
	public String index(@RequestBody SelectTablesDTO selectTablesDTO,Model model, HttpServletRequest req) throws Exception {
		//Convert Java object to JSON
		ObjectMapper mapper = new ObjectMapper();
		String objectToJson = mapper.writeValueAsString(selectTablesDTO);
		model.addAttribute("selectTablesDTO", objectToJson);
		return objectToJson;
	}

	/**
     * 新しいRelation ID を生成して戻します。
     *
     * @return relation ID
     */
    public String generateRelationId() {
        final SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmssZ");
        return sdf.format(new Date());
    }

    /**
	 * is Deleted Object
	 * @return true : exist /false : not exist
	 */
	public boolean isDeletedObject(String connectDefinitionId,String tableId) throws Exception {
		// check object exist
		TableFormDto check = creationService.getTableFormDtoByID(connectDefinitionId,tableId, getUserAuthority());
		// if check === null => check.getId() is error and
		// =>ApplicationDomainLogicException
		if (check == null) {
			return false;
		}
		return true;
	}

	@RequestMapping(value = "/relation/createrelation",method = RequestMethod.POST )
	 public @ResponseBody RelationMessageInfo doCreateRelation(@RequestBody RelationCreateInfoDTO relationCreateInfoDTO) throws Exception{
		AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		RelationMessageInfo resultModel = new RelationMessageInfo();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		MessageInfo error = new MessageInfo();

		//is Deleted Master Object
		String tableMaster = relationCreateInfoDTO.getSchema() + "." + relationCreateInfoDTO.getTable();
		if (!isDeletedObject(relationCreateInfoDTO.getConnectDefinitionId(),tableMaster)) {
			final String args[]={relationCreateInfoDTO.getTableLabel()};
			error = new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args);
			messageInfoList.add(error);
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}

		//is Deleted Detail Object
		String tableDetail = relationCreateInfoDTO.getSchemaR() + "." + relationCreateInfoDTO.getTableR();
		if (!isDeletedObject(relationCreateInfoDTO.getConnectDefinitionId(),tableDetail)) {
			final String args[]={relationCreateInfoDTO.getTableRLabel()};
			error = new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args);
			messageInfoList.add(error);
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}

		if(StringUtils.isEmpty(relationCreateInfoDTO.getRelationName())){
			//MI-E-0330=リレーション名を入力してください
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0330", messageService);
			error.setIdError("#conditionOfTableNameRelationAdd");
			messageInfoList.add(error);
		}
		if(StringUtils.isEmpty(relationCreateInfoDTO.getJoinType())){
			//MI-E-0330=結合方法を選択してください
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0331", messageService);
			error.setIdError("#joinAdd");
			messageInfoList.add(error);
		}
		boolean flag = isInsertRelationValidate(relationCreateInfoDTO.getRelationName());
		if(!flag) {
			// MI-E-0101_1=入力されたリレーション名 は、既に使用されています
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0101_1", messageService);
			error.setIdError("#conditionOfTableNameRelationAdd");
			messageInfoList.add(error);
		}
		if(relationCreateInfoDTO.getColJoinsAddLength().equals("0")){
			error = new MessageInfo("", MessageType.ERROR, "relation.select.column.join", messageService);
			error.setIdError("#colJoinsAdd");
			messageInfoList.add(error);
			resultModel.setMessageInfo(messageInfoList);
		}
		if (messageInfoList.size() > 0) {
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		final PreservationOfAppRelationLogic logicRelation = new PreservationOfAppRelationLogic();
		ApplicationRelationDTO applicationRelationDTO = new ApplicationRelationDTO();
		try {
			applicationRelationDTO.setRelationId(generateRelationId());//YYMMDDHHSSMMZ
			applicationRelationDTO.setRelationLabel(relationCreateInfoDTO.getRelationName());
			applicationRelationDTO.setRelationType(relationCreateInfoDTO.getJoinType());
			//list table
			List<TableDTO> tables = new ArrayList<TableDTO>();
			//master
			TableDTO tableMasterDTO = new TableDTO();
			tableMasterDTO.setConnectid(relationCreateInfoDTO.getConnectDefinitionId());
			tableMasterDTO.setType(AppConst.RELATION_TABLE_MASTER);
			tableMasterDTO.setTableid(relationCreateInfoDTO.getSchema() + "." + relationCreateInfoDTO.getTable());
			tables.add(tableMasterDTO);
			//detail
			TableDTO tableDetailDTO = new TableDTO();
			tableDetailDTO.setConnectid(relationCreateInfoDTO.getConnectDefinitionIdR());
			tableDetailDTO.setType(AppConst.RELATION_TABLE_DETAIL);
			tableDetailDTO.setTableid(relationCreateInfoDTO.getSchemaR() + "." + relationCreateInfoDTO.getTableR());
			tables.add(tableDetailDTO);
			applicationRelationDTO.setTables(tables);
			//list item
			List<ItemDTO> items = new ArrayList<ItemDTO>();
			for(RelationCreateColumnNameDefDTO relationColumnDTO:relationCreateInfoDTO.getColumnNameDefList()){
				ItemDTO itemDTO = new ItemDTO();
				itemDTO.setMaster(relationColumnDTO.getColumnName());
				itemDTO.setDetail(relationColumnDTO.getColumnNameR());
				items.add(itemDTO);
			}
			applicationRelationDTO.setItems(items);
			UpdateDivision updateDivision = UpdateDivision.insert;
			logicRelation.save(applicationRelationDTO, updateDivision/*, getUserInfo()*/);
			//リレーションを登録しました
			String msgSuccess = MessageUtils.getMessage("relation.insert.success");
			Map<String,String> successMap= new HashMap<String,String>();
			resultModel.setStatus(Constants.CONST_STATUS_OK);
			successMap.put("relation", msgSuccess);
			resultModel.setSuccessMap(successMap);
			OutputAuditLog.writeRelationLog(
					getUserInfo(), //userInfo
					AuditStatus.success,
					logic.getConnectionByID(relationCreateInfoDTO.getConnectDefinitionId()).getLabel(),//databaseName
					applicationRelationDTO.getRelationLabel(),
					AuditEventKind.INSERT,
					String.valueOf(1));
			new MessageInfo("relation.insert.success", MessageType.SUCCESS, messageService);
			return resultModel;
        } catch (final ApplicationDomainLogicException e) {
        	try {
				OutputAuditLog.writeRelationLog(
						getUserInfo(), //userInfo
						AuditStatus.failure,
						logic.getConnectionByID(relationCreateInfoDTO.getConnectDefinitionId()).getLabel(),//databaseName
						applicationRelationDTO.getRelationLabel(),
						AuditEventKind.INSERT,
						"");
			} catch (ApplicationDomainLogicException e1) {
				new MessageInfo(e1, MessageType.ERROR);
			}
        	new MessageInfo(e, MessageType.ERROR);
        }
		return null;
	 }

	@RequestMapping(value = "/relation/editrelation",method = RequestMethod.POST )
	 public @ResponseBody RelationMessageInfo doEditRelation(@RequestBody RelationCreateInfoDTO relationCreateInfoDTO) throws Exception {
		AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		RelationMessageInfo resultModel = new RelationMessageInfo();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		MessageInfo error = new MessageInfo();
		// check relation exist
		final PreservationOfAppRelationLogic logicRel = new PreservationOfAppRelationLogic();
		if (!logicRel.checkRelationExist(relationCreateInfoDTO.getRelationId())) {
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0117", messageService);
			messageInfoList.add(error);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		//is Deleted Master Object
		String tableMaster = relationCreateInfoDTO.getSchema() + "." + relationCreateInfoDTO.getTable();
		if (!isDeletedObject(relationCreateInfoDTO.getConnectDefinitionId(),tableMaster)) {
			final String args[]={relationCreateInfoDTO.getTableLabel()};
			error = new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args);
			messageInfoList.add(error);
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}

		//is Deleted Detail Object
		String tableDetail = relationCreateInfoDTO.getSchemaR() + "." + relationCreateInfoDTO.getTableR();
		if (!isDeletedObject(relationCreateInfoDTO.getConnectDefinitionId(),tableDetail)) {
			final String args[]={relationCreateInfoDTO.getTableRLabel()};
			error = new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args);
			messageInfoList.add(error);
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		if(StringUtils.isEmpty(relationCreateInfoDTO.getRelationName())){
			//MI-E-0330=リレーション名を入力してください
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0330", messageService);
			error.setIdError("#conditionOfTableNameRelationEdit");
			messageInfoList.add(error);
		}
		if(StringUtils.isEmpty(relationCreateInfoDTO.getJoinType())){
			//MI-E-0330=結合方法を選択してください
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0331", messageService);
			error.setIdError("#joinEdit");
			messageInfoList.add(error);
		}
		boolean flag = isEditRelationValidate(relationCreateInfoDTO);
		if(!flag) {
			// MI-E-0101_1=入力されたリレーション名 は、既に使用されています
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0101_1", messageService);
			error.setIdError("#conditionOfTableNameRelationEdit");
			messageInfoList.add(error);
		}
		if(relationCreateInfoDTO.getColJoinsAddLength().equals("0")){
			error = new MessageInfo("", MessageType.ERROR, "relation.select.column.join", messageService);
			error.setIdError("#colJoinsEdit");
			messageInfoList.add(error);
			resultModel.setMessageInfo(messageInfoList);
		}
		if (messageInfoList.size() > 0) {
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		final PreservationOfAppRelationLogic logicRelation = new PreservationOfAppRelationLogic();
		ApplicationRelationDTO applicationRelationDTO = new ApplicationRelationDTO();
		try {
			applicationRelationDTO.setRelationId(relationCreateInfoDTO.getRelationId());
			applicationRelationDTO.setRelationLabel(relationCreateInfoDTO.getRelationName());
			applicationRelationDTO.setRelationType(relationCreateInfoDTO.getJoinType());
			//list table
			List<TableDTO> tables = new ArrayList<TableDTO>();
			//master
			TableDTO tableMasterDTO = new TableDTO();
			tableMasterDTO.setConnectid(relationCreateInfoDTO.getConnectDefinitionId());
			tableMasterDTO.setType(AppConst.RELATION_TABLE_MASTER);
			tableMasterDTO.setTableid(relationCreateInfoDTO.getSchema() + "." + relationCreateInfoDTO.getTable());
			tables.add(tableMasterDTO);
			//detail
			TableDTO tableDetailDTO = new TableDTO();
			tableDetailDTO.setConnectid(relationCreateInfoDTO.getConnectDefinitionIdR());
			tableDetailDTO.setType(AppConst.RELATION_TABLE_DETAIL);
			tableDetailDTO.setTableid(relationCreateInfoDTO.getSchemaR() + "." + relationCreateInfoDTO.getTableR());
			tables.add(tableDetailDTO);
			applicationRelationDTO.setTables(tables);
			//list item
			List<ItemDTO> items = new ArrayList<ItemDTO>();
			for(RelationCreateColumnNameDefDTO relationColumnDTO:relationCreateInfoDTO.getColumnNameDefList()){
				ItemDTO itemDTO = new ItemDTO();
				itemDTO.setMaster(relationColumnDTO.getColumnName());
				itemDTO.setDetail(relationColumnDTO.getColumnNameR());
				items.add(itemDTO);
			}
			applicationRelationDTO.setItems(items);
			UpdateDivision updateDivision = UpdateDivision.update;
			logicRelation.save(applicationRelationDTO, updateDivision/*, getUserInfo()*/);
			//リレーション設定を編集しました
			String msgSuccess = MessageUtils.getMessage("relation.edit.success");
			Map<String,String> successMap= new HashMap<String,String>();
			resultModel.setStatus(Constants.CONST_STATUS_OK);
			successMap.put("relation", msgSuccess);
			resultModel.setSuccessMap(successMap);
			OutputAuditLog.writeRelationLog(
					getUserInfo(), //userInfo
					AuditStatus.success,
					logic.getConnectionByID(relationCreateInfoDTO.getConnectDefinitionId()).getLabel(),//databaseName
					applicationRelationDTO.getRelationLabel(),
					AuditEventKind.UPDATE,
					String.valueOf(1));
			new MessageInfo("relation.edit.success", MessageType.SUCCESS, messageService);
			return resultModel;
       } catch (final ApplicationDomainLogicException e) {
    	   try {
			OutputAuditLog.writeRelationLog(
					   getUserInfo(), //userInfo
						AuditStatus.failure,
						logic.getConnectionByID(relationCreateInfoDTO.getConnectDefinitionId()).getLabel(),//databaseName
						applicationRelationDTO.getRelationLabel(),
						AuditEventKind.UPDATE,
						"");
		} catch (ApplicationDomainLogicException e1) {
			new MessageInfo(e1, MessageType.ERROR);
		}
    	   new MessageInfo(e, MessageType.ERROR);
       }
		return null;
	 }

	@RequestMapping(value = "/relation/copyrelation",method = RequestMethod.POST )
	 public @ResponseBody RelationMessageInfo doCopyRelation(@RequestBody RelationCreateInfoDTO relationCreateInfoDTO) throws Exception {
		AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		//check validate
		RelationMessageInfo resultModel = new RelationMessageInfo();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		MessageInfo error = new MessageInfo();
		//is Deleted Master Object
		String tableMaster = relationCreateInfoDTO.getSchema() + "." + relationCreateInfoDTO.getTable();
		if (!isDeletedObject(relationCreateInfoDTO.getConnectDefinitionId(),tableMaster)) {
			final String args[]={relationCreateInfoDTO.getTableLabel()};
			error = new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args);
			messageInfoList.add(error);
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}

		//is Deleted Detail Object
		String tableDetail = relationCreateInfoDTO.getSchemaR() + "." + relationCreateInfoDTO.getTableR();
		if (!isDeletedObject(relationCreateInfoDTO.getConnectDefinitionId(),tableDetail)) {
			final String args[]={relationCreateInfoDTO.getTableRLabel()};
			error = new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args);
			messageInfoList.add(error);
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		// check relation exist
		final PreservationOfAppRelationLogic logicRel = new PreservationOfAppRelationLogic();
		if (!logicRel.checkRelationExist(relationCreateInfoDTO.getRelationId())) {
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0117", messageService);
			messageInfoList.add(error);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		if(StringUtils.isEmpty(relationCreateInfoDTO.getRelationName())){
			//MI-E-0330=リレーション名を入力してください
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0330", messageService);
			error.setIdError("#conditionOfTableNameRelationCopy");
			messageInfoList.add(error);
		}
		if(StringUtils.isEmpty(relationCreateInfoDTO.getJoinType())){
			//MI-E-0330=結合方法を選択してください
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0331", messageService);
			error.setIdError("#joinCopy");
			messageInfoList.add(error);
		}
		boolean flag = isInsertRelationValidate(relationCreateInfoDTO.getRelationName());
		if(!flag) {
			// MI-E-0101_1=入力されたリレーション名 は、既に使用されています
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0101_1", messageService);
			error.setIdError("#conditionOfTableNameRelationCopy");
			messageInfoList.add(error);
		}
		if(relationCreateInfoDTO.getColJoinsAddLength().equals("0")){
			error = new MessageInfo("", MessageType.ERROR, "relation.select.column.join", messageService);
			error.setIdError("#colJoinsCopy");
			messageInfoList.add(error);
			resultModel.setMessageInfo(messageInfoList);
		}
		if (messageInfoList.size() > 0) {
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		final PreservationOfAppRelationLogic logicRelation = new PreservationOfAppRelationLogic();
			ApplicationRelationDTO applicationRelationDTO = new ApplicationRelationDTO();
		try {
			applicationRelationDTO.setRelationId(generateRelationId());//YYMMDDHHSSMMZ
			applicationRelationDTO.setRelationLabel(relationCreateInfoDTO.getRelationName());
			applicationRelationDTO.setRelationType(relationCreateInfoDTO.getJoinType());

			//list table
			List<TableDTO> tables = new ArrayList<TableDTO>();
			//master
			TableDTO tableMasterDTO = new TableDTO();
			tableMasterDTO.setConnectid(relationCreateInfoDTO.getConnectDefinitionId());
			tableMasterDTO.setType(AppConst.RELATION_TABLE_MASTER);
			tableMasterDTO.setTableid(relationCreateInfoDTO.getSchema() + "." + relationCreateInfoDTO.getTable());
			tables.add(tableMasterDTO);
			//detail
			TableDTO tableDetailDTO = new TableDTO();
			tableDetailDTO.setConnectid(relationCreateInfoDTO.getConnectDefinitionIdR());
			tableDetailDTO.setType(AppConst.RELATION_TABLE_DETAIL);
			tableDetailDTO.setTableid(relationCreateInfoDTO.getSchemaR() + "." + relationCreateInfoDTO.getTableR());
			tables.add(tableDetailDTO);

			applicationRelationDTO.setTables(tables);

			//list item
			List<ItemDTO> items = new ArrayList<ItemDTO>();
			for(RelationCreateColumnNameDefDTO relationColumnDTO:relationCreateInfoDTO.getColumnNameDefList()){
				ItemDTO itemDTO = new ItemDTO();
				itemDTO.setMaster(relationColumnDTO.getColumnName());
				itemDTO.setDetail(relationColumnDTO.getColumnNameR());
				items.add(itemDTO);
			}
			applicationRelationDTO.setItems(items);

			UpdateDivision updateDivision = UpdateDivision.copy;
			logicRelation.save(applicationRelationDTO, updateDivision/*, getUserInfo()*/);

			//リレーションを複写しました
			String msgSuccess = MessageUtils.getMessage("relation.copy.success");
			Map<String,String> successMap= new HashMap<String,String>();
			resultModel.setStatus(Constants.CONST_STATUS_OK);
			successMap.put("relation", msgSuccess);
			resultModel.setSuccessMap(successMap);

			OutputAuditLog.writeRelationLog(
					getUserInfo(), //userInfo
					AuditStatus.success,
					logic.getConnectionByID(relationCreateInfoDTO.getConnectDefinitionId()).getLabel(),//databaseName
					applicationRelationDTO.getRelationLabel(),
					AuditEventKind.INSERT,
					String.valueOf(1));
			new MessageInfo("relation.copy.success", MessageType.SUCCESS, messageService);
			return resultModel;
       } catch (final ApplicationDomainLogicException e) {
    	   try {
			OutputAuditLog.writeRelationLog(
					   getUserInfo(), //userInfo
						AuditStatus.failure,
						logic.getConnectionByID(relationCreateInfoDTO.getConnectDefinitionId()).getLabel(),//databaseName
						applicationRelationDTO.getRelationLabel(),
						AuditEventKind.INSERT,
						"");
		} catch (ApplicationDomainLogicException e1) {
			new MessageInfo(e1, MessageType.ERROR);
		}
    	   new MessageInfo(e, MessageType.ERROR);
       }
		return null;
	 }

	/**
	 * is Deleted Relation
	 * @return true/false
	 */
	@RequestMapping(value = "/relation/isDeletedRelation", method = { RequestMethod.POST })
	public boolean isDeletedRelation(@RequestBody RelationDeleteDTO param) throws Exception {
		// check relation exist
		final PreservationOfAppRelationLogic logic = new PreservationOfAppRelationLogic();
		return logic.checkRelationExist(param.getRelationId());
	}

	@RequestMapping(value = "/relation/delrelation",method = RequestMethod.POST )
	 public @ResponseBody RelationMessageInfo doDelRelation(@RequestBody RelationDeleteDTO relationDeleteDTO) throws Exception {
		AcquisitionOfConnectDefinitionListLogic logic1 = new AcquisitionOfConnectDefinitionListLogic();
		//check validate
		RelationMessageInfo resultModel = new RelationMessageInfo();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		MessageInfo error = new MessageInfo();
		// check relation exist
		final PreservationOfAppRelationLogic logicRel = new PreservationOfAppRelationLogic();
		if (!logicRel.checkRelationExist(relationDeleteDTO.getRelationId())) {
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0117", messageService);
			messageInfoList.add(error);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		//check validate
		RelationMessageInfo relMssInfo = new RelationMessageInfo();
		final PreservationOfAppRelationLogic logicRelation = new PreservationOfAppRelationLogic();
		try {
			logicRelation.remove(relationDeleteDTO.getRelationId());
			if (relationDeleteDTO.getNames() != null) {
				for (RelationScreenDTO relationScreenDTO : relationDeleteDTO.getNames()) {
					String connectDefinisionId = relationScreenDTO.getConnectDefinitionId();
					String tableFormIdTypeMultiTable = relationScreenDTO.getTableFormMultiTableId();
					final DeletionProcessingOfTableFromRepositoryLogic logic = new DeletionProcessingOfTableFromRepositoryLogic();
					logic.delete(connectDefinisionId,tableFormIdTypeMultiTable);
				}
			}
			//リレーション設定を削除しました
			String msgSuccess = MessageUtils.getMessage("relation.delete.success");
			Map<String,String> successMap= new HashMap<String,String>();
			relMssInfo.setStatus(Constants.CONST_STATUS_OK);
			successMap.put("relation", msgSuccess);
			relMssInfo.setSuccessMap(successMap);
			OutputAuditLog.writeRelationLog(
					getUserInfo(), //userInfo
					AuditStatus.success,
					logic1.getConnectionByID(relationDeleteDTO.getConnectid()).getLabel(),//databaseName
					relationDeleteDTO.getRelationName(),
					AuditEventKind.DELETE,
					String.valueOf(1));
			new MessageInfo("relation.delete.success", MessageType.SUCCESS, messageService);
			return relMssInfo;
      } catch (final ApplicationDomainLogicException e) {
    	  try {
			OutputAuditLog.writeRelationLog(
						getUserInfo(), //userInfo
						AuditStatus.failure,
						logic1.getConnectionByID(relationDeleteDTO.getConnectid()).getLabel(),//databaseName
						relationDeleteDTO.getRelationName(),
						AuditEventKind.DELETE,
						"");
		} catch (ApplicationDomainLogicException e1) {
			new MessageInfo(e1, MessageType.ERROR);
		}
    	  new MessageInfo(e, MessageType.ERROR);
      }
		return null;
	 }

	/**
	 * @param connectDefinitionId
	 * @param tableFormMultiTableId
	 * @return
	 * @throws DAOException
	 */
	public TableFormDto getTableMulti(String connectDefinitionId, String tableFormMultiTableId) throws DAOException {
		AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
		try {
			TableFormDAO tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
			TableFormDto dto = new TableFormDto();
			dto.setId(tableFormMultiTableId);
			TableForm tableForm = tableFormDAO.getTargetTableFormMulti(connectDefinitionId, dto);
			return new TableFormDto(tableForm);
		} catch (ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
		return null;
	}


	/**
	 * @param relationName
	 * @return
	 */
	private boolean isInsertRelationValidate(String relationName) {
		final PreservationOfAppRelationLogic logic = new PreservationOfAppRelationLogic();
		try {
			if (logic.isRelationIDRepetition(relationName)) {
				// MI-E-0101_1=入力されたリレーション名 は、既に使用されています
				return false;
			}
		} catch (final ApplicationDomainLogicException e) {
			getLogger().error(e);
			return false;
		}
		return true;
	}

	private boolean isEditRelationValidate(RelationCreateInfoDTO relationCreateInfoDTO)  {
		final PreservationOfAppRelationLogic logic = new PreservationOfAppRelationLogic();
		try {
			Map<String, RelationInformation> relationMap = logic.getRelationInformationMap();
            String relLabel = relationMap.get(relationCreateInfoDTO.getRelationId()).getLabel();
            String relationName = relationCreateInfoDTO.getRelationName();
			if (!relationName.equals(relLabel) && logic.isRelationIDRepetition(relationName)) {
				// MI-E-0101_1=入力されたリレーション名 は、既に使用されています
				return false;
			}
		} catch (final ApplicationDomainLogicException e) {
			new MessageInfo(e, MessageType.ERROR);
			return false;
		}
		return true;
	}


	/**
	 * @param search
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private List<IdSelectTableLabeExtendConnectDTO> iniDataFormRepositoryListObject(SearchCriteria search) throws ApplicationDomainLogicException {
		final TableNameListIsAcquiredFromRepositoryLogic repository = new TableNameListIsAcquiredFromRepositoryLogic();
		//リポジトリXML上に登録されているテーブル一覧を取得
		 try {
			 	MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				List<IdSelectTableLabeExtendConnectDTO> repList = repository.getAllTableNameListNotExistMulti(myUserDetails.getUserInfoDTO());
					//sort by TableName
				  Collections.sort(repList, new Comparator<IdSelectTableLabeExtendConnectDTO>() {
				    @Override public int compare(final IdSelectTableLabeExtendConnectDTO o1, final IdSelectTableLabeExtendConnectDTO o2) {
				      return o1.getTableConnectLabel().compareTo(o2.getTableConnectLabel());
				    }
				  });
				return repList;
         } catch (final ApplicationDomainLogicException e) {
             throw new ApplicationDomainLogicException(e);
         }
	}

	/**
	 * @param search
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private List<IdSelectTableLabeExtendConnectDTO> iniDataFormRepositoryListObjectType(GetTableDependenceDatabaseDTO search) throws Exception {
		final TableNameListIsAcquiredFromRepositoryLogic repository = new TableNameListIsAcquiredFromRepositoryLogic();
		//リポジトリXML上に登録されているテーブル一覧を取得
		 try {
				List<IdSelectTableLabeExtendConnectDTO> repList = repository.getAllTableNameConnectTypeList(search,search.getConnectDefinitionId());
				//sort by TableName
				  Collections.sort(repList, new Comparator<IdSelectTableLabeExtendConnectDTO>() {
				    @Override public int compare(final IdSelectTableLabeExtendConnectDTO o1, final IdSelectTableLabeExtendConnectDTO o2) {
				      return o1.getTableConnectLabel().compareTo(o2.getTableConnectLabel());
				    }
				  });
				return repList;
         } catch (final ApplicationDomainLogicException e) {
             throw new ApplicationDomainLogicException(e);
         }
	}

	/**
	 * @param search
	 * @return
	 */
	private RelationMessageResult getDataForSearchRelation(SearchCriteria search) {
		RelationMessageResult result = new RelationMessageResult();
		// 最終的に一覧に使用するリスト
		final List<RelationDTO> itemList = new ArrayList<RelationDTO>();
		RelationDTO item;
//		if(search.getConditionOfTableName()==null){
//			search.setConditionOfTableName("");
//		}
		final PreservationOfAppRelationLogic logic = new PreservationOfAppRelationLogic();
		final Map<String, RelationInformation> relationInformationMap;
		try {
			relationInformationMap = logic.getRelationInformationMap();
		} catch (final ApplicationDomainLogicException e) {
//			addPageMessage(e.getMessage());
			result.setStatus(Constants.CONST_STATUS_NG);
			result.setMessage(e.getMessage());
			return result;
		}
		String searchRelation = search.getConditionOfTableName();
		List<RelationInformation> relationInformationItems = new ArrayList<RelationInformation>();
		for (final String id : relationInformationMap.keySet()) {
			final RelationInformation info = relationInformationMap.get(id);
			if (StringUtils.isEmpty(searchRelation)
						|| info.getLabel().toLowerCase().contains(searchRelation.toLowerCase())
						|| info.getTables().get(0).getTableid().toLowerCase().contains(searchRelation.toLowerCase())
						|| info.getTables().get(1).getTableid().toLowerCase().contains(searchRelation.toLowerCase())
						) {
				info.setConnectid(info.getTables().get(0).getConnectid());
				relationInformationItems.add(info);
			}
		}

		if (search.getUserAuthority().isSystemAdministrator()) {
			for (RelationInformation relationInformation : relationInformationItems) {
				item = new RelationDTO();
				item.setConnectid(relationInformation.getConnectid());
				item.setId(relationInformation.getId());
				item.setRelationName(relationInformation.getLabel());
				item.setObjectId1(relationInformation.getTables().get(0).getTableid());
				item.setObjectName1(relationInformation.getTables().get(0).getTablelabel());
				item.setJoinName(relationInformation.getType());
				item.setObjectId2(relationInformation.getTables().get(1).getTableid());
				item.setObjectName2(relationInformation.getTables().get(1).getTablelabel());
				item.setDatabaseTypeConnectionDestination(relationInformation.getTables().get(0).getDatabaseTypeConnectionDestination());
				itemList.add(item);
			}
		} else {
			for (ConnectDefinisionAuthority connectDefinisionAuthority : search.getUserAuthority().getConnectDefinisionAuthoritys()) {
				String connectDefinisionId = connectDefinisionAuthority.getConnectDefinisionId();
				for (RelationInformation relationInformation : relationInformationItems) {
					if (relationInformation.getConnectid().equals(connectDefinisionId)) {
						item = new RelationDTO();
						item.setConnectid(relationInformation.getConnectid());
						item.setId(relationInformation.getId());
						item.setRelationName(relationInformation.getLabel());
						item.setObjectId1(relationInformation.getTables().get(0).getTableid());
						item.setObjectName1(relationInformation.getTables().get(0).getTablelabel());
						item.setJoinName(relationInformation.getType());
						item.setObjectId2(relationInformation.getTables().get(1).getTableid());
						item.setObjectName2(relationInformation.getTables().get(1).getTablelabel());
						item.setDatabaseTypeConnectionDestination(relationInformation.getTables().get(0).getDatabaseTypeConnectionDestination());
						itemList.add(item);
					}
				}
			}
		}

		if (itemList.size() == 0) {
			String message = MessageUtils.getMessage("MI-E-0154");
			result.setStatus(Constants.CONST_STATUS_OK);
			result.setMessage(message);
			result.setRelations(new ArrayList<RelationDTO>());
			return result;
		}

		result.setStatus(Constants.CONST_STATUS_OK);
//		result.setMessage(message);

		//sort by RelationName
		  Collections.sort(itemList, new Comparator<RelationDTO>() {
		    @Override public int compare(final RelationDTO o1, final RelationDTO o2) {
		      return o1.getRelationName().compareTo(o2.getRelationName());
		    }
		  });

		result.setRelations(itemList);
		return result;
	}

	@RequestMapping(value = "/relation/getcreationscreen",method = RequestMethod.POST )
	 public @ResponseBody RelationMessageInfo getCreationScreen(@RequestBody RelationCreateInfoDTO relationCreateInfoDTO) {
		RelationMessageInfo resultModel = new RelationMessageInfo();
		FRM0330JsonSearch search = new FRM0330JsonSearch();
		/*search.setUserAuthority(getUserAuthority());*/
		search.setUserAuthority(getUserAuthority());
		Map<String, TableFormDto> tableFormDtoMap = creationService.getAllTableMulti(search);
		List<RelationScreenDTO> relationScreenDTOList = getCreationScreenUsingRelaion(tableFormDtoMap,relationCreateInfoDTO.getRelationId());
		resultModel.setRelationScreenDTOList(relationScreenDTOList);
		resultModel.setStatus(Constants.CONST_STATUS_OK);
		return resultModel;
	 }

	/**
	 * @param tableFormMultiMap
	 * @param relationId
	 * @return
	 */
	private List<RelationScreenDTO> getCreationScreenUsingRelaion(Map<String, TableFormDto> tableFormMultiMap,String relationId) {
		List<RelationScreenDTO> relationScreenDTOList  = new ArrayList<>();
		for (String  connectLabel : tableFormMultiMap.keySet()) {
			TableFormDto tableFormMultiDto= tableFormMultiMap.get(connectLabel);
			for( RelationDto relationDto:tableFormMultiDto.getRelationsDto().getRelationDtoList()){
				if(relationId.equals(relationDto.getId())){
					RelationScreenDTO relationScreenDTO = new RelationScreenDTO(tableFormMultiDto.getConnectionId(),tableFormMultiDto.getId(),tableFormMultiDto.getLabel());
					relationScreenDTOList.add(relationScreenDTO);
					break;
				}
			}
		}
		return relationScreenDTOList;
	}
}
