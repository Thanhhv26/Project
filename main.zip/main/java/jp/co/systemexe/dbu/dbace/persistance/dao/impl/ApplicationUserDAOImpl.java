/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.common.authenticator.AuthByLDAP;
import jp.co.systemexe.dbu.dbace.common.authenticator.ExtAuthValue;
import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.util.BlowfishUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationUserDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.GeneralUserOperationAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Authority;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Authority.AuthConnectDefinisions;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Authority.AuthConnectDefinisions.AuthConnectDefinision;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Authority.AuthConnectDefinisions.AuthConnectDefinision.Auth;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.LoginUser;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.LoginUsers;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.web.user.model.UserInformation;

/**
 * アプリケーションユーザー情報 DAO。
 * <p>
 * アプリケーションユーザー情報 にアクセスする DAO の実装クラスになります。</p>
 *
 * @author EXE 島田 雄一郎
 * @author EXE ウォン フェイ
 * @author EXE 鈴木 伸祐
 * @author EXE 六本木 圭
 * @author EXE 相田 一英
 * @version 0.0.0
 */
public class ApplicationUserDAOImpl extends BaseRepositoryXmlDAO
        implements ApplicationUserDAO {

	private static final String EX_AUTHENTICATE_ON = ExtAuthValue.ON.getValue();//ADD 外部認証連携 機能追加

	/**
     * ユーザー認証を行います。
     * <p>
     * ユーザー ID、パスワードの組み合わせでユーザーの認証を行います。
     * </p><p>
     * 認証時にはパスワードがフラットで送られてきます。この仕様は安全上好ましく
     * ありません。将来的に何らかの対策を検討する必要があります。
     * </p>
     *
     * @param userId ユーザー ID
     * @param password パスワード
     * @return true : 正規ユーザー / false : 非正規ユーザー
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#certify(java.lang.String, java.lang.String)
     */
	// MOD 外部認証連携 機能追加 ↓
    public boolean certify(
    		final String userId,
    		final String password) throws DAOException {

        final LoginUser user = searchUser(userId);
        if (user == null) {
        	// MI-E-0016=ユーザー情報の取得に失敗しました。
            getLogger().error(
            	MessageUtils.getMessage("MI-E-0016"));
            return false;
        }
        try {
        	// ADD 外部認証連携 機能追加　↓
			if (!userId.equals("admin")) {
				if (isExAuthentication()) {
					// 又は外部認証ON
					// 外部認証
					return verifyExAuthentication(userId, password);
				}
			}
			// adminユーザー | 又は外部認証OFF
			// check xml normaly
        	//ADD 外部認証連携 機能追加　↑
            if (user.getPassword().equals(
                BlowfishUtils.encrypt2b64(openSesame(), password))) {
                return true;
            } else {
                return false;
            }
        } catch (final Exception e) {
        	// MI-F-0009=パスワードの暗号化に失敗しました。
            final String message = MessageUtils.getMessage("MI-F-0009");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
    }
    // MOD 外部認証連携 機能追加↑

    /**
     * アプリケーションユーザー情報 DTO を戻します。
     * <p>
     * 現状、ユーザーパスワードも復号して戻す仕様になっていますが、本来は
     * 好ましくありません。将来的に再設計する必要があります。</p>
     *
     * @param userId ユーザー ID
     * @return ApplicationUserDTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#getApplicationUserDTO(java.lang.String)
     */
    public ApplicationUserDTO getApplicationUserDTO(final String userId)
            throws DAOException {
        final ApplicationUserDTO ret = new ApplicationUserDTO();
        final LoginUser user = searchUser(userId);
        if (user == null) {
        	// MI-E-0053=ユーザーが存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0053"));
        }
        ret.setUserId(user.getId());
        ret.setUserLabel(user.getLabel());
        try {
            ret.setPassword(BlowfishUtils.decrypt4b64(openSesame(), user
                .getPassword()));
        } catch (final Exception e) {
        	// MI-F-0010=パスワードの複合化に失敗しました。
            final String message = MessageUtils.getMessage("MI-F-0010");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }

        final UserAuthority userAuthority = new UserAuthority();
        final Authority autority = user.getAuthority();
        userAuthority.setSystemAdministrator(autority.isSystemAdministrator());

        final AuthConnectDefinisions defs = autority.getAuthConnectDefinisions();
        final List<ConnectDefinisionAuthority>
        	authoritys = new ArrayList<ConnectDefinisionAuthority>();
        for (final AuthConnectDefinision def : defs.getAuthConnectDefinision()) {
        	final ConnectDefinisionAuthority
        		connectDefinisionAuthority = new ConnectDefinisionAuthority();
        	connectDefinisionAuthority.setConnectDefinisionId(def.getId());

        	final List<GeneralUserOperationAuthority> auths
        		= new ArrayList<GeneralUserOperationAuthority>();
        	for (final Auth auth : def.getAuth()) {
        		auths.add(GeneralUserOperationAuthority.idOf(auth.getId()));
        	}
        	connectDefinisionAuthority.setOperationAuthority(auths);
        	authoritys.add(connectDefinisionAuthority);
        }
        userAuthority.setConnectDefinisionAuthoritys(authoritys);
        ret.setAuthority(userAuthority);

        return ret;
    }

    /**
     * ユーザー名の一覧マップを戻します。
     * <p>
     * ユーザー ID、ユーザー名の一覧を設定した Map を戻します。
     * ユーザー登録がない場合は DAOException をスローします。</p>
     *
     * @return Map&lt;ユーザー ID, ユーザー名&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#getUserNameMap()
     */
    public Map<String, String> getUserNameMap()
            throws DAOException {
        final Map<String, String> ret = new HashMap<String, String>();
        final LoginUsers users = getLoginUsers();
        if (users == null || users.getLoginUser() == null) {
        	// MI-E-0053=ユーザーが存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0053"));
        }

        for (LoginUser user : users.getLoginUser()) {
            ret.put(user.getId(), user.getLabel());
        }
        return ret;
    }

    /**
     * ユーザー情報の一覧マップを戻します。
     * <p>
     * ユーザー ID、ユーザー名、ユーザー権限の一覧を設定した Map を戻します。
     * ユーザー登録がない場合は DAOException をスローします。</p>
     *
     * @return Map&lt;ユーザー ID, UserInformation&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#getUserInformationMap()
     */
    public Map<String, UserInformation> getUserInformationMap()
            throws DAOException {
        final Map<String, UserInformation> ret
        	= new TreeMap<String, UserInformation>();
        final LoginUsers users = getLoginUsers();
        if (users == null || users.getLoginUser() == null) {
        	// MI-E-0053=ユーザーが存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0053"));
        }

        for (LoginUser user : users.getLoginUser()) {
        	final UserInformation info = new UserInformation();
        	info.setUserId(user.getId());
        	info.setUserLabel(user.getLabel());
        	info.setUserAuthority(
        			user.getAuthority().isSystemAdministrator() ? "システム管理者" : "一般ユーザー");
            ret.put(user.getId(), info);
        }
        return ret;
    }

    /**
     * パスワード文字列の暗号化を行います。
     * <p>
     * パスワード文字列を暗号化して文字列を返します。</p>
     *
     * @param String 対象パスワード文字列
     * @return String 暗号化済みパスワード文字列
     * @throws DAOException
     */
    public String getEncryptionPassword(final String password)
            throws DAOException {
        final String ret;

        try {
            ret = BlowfishUtils.encrypt2b64(openSesame(), password);
        } catch (final Exception e) {
        	// MI-F-0010=パスワードの複合化に失敗しました。
            final String message = MessageUtils.getMessage("MI-F-0010");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }

    /**
     * パスワードの保存します。
     *
     * @param dto
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#savePassword(jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationUserDTO)
     */
    public void savePassword(final ApplicationUserDTO dto) throws DAOException {
    	final LoginUsers users = getLoginUsers();

    	final LoginUser user = searchUser(users, dto.getUserId());
    	user.setPassword(dto.getPassword());

        try {
            update();
        } catch (final DAOException e) {
        	throw e;
        }
    }

    /**
     * Username, パスワードの保存します。
     *
     * @param dto
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#savePassword(jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationUserDTO)
     */
    public void saveUsernamePassword(final ApplicationUserDTO dto) throws DAOException {
    	final LoginUsers users = getLoginUsers();

    	final LoginUser user = searchUser(users, dto.getUserId());
    	user.setLabel(dto.getUserLabel());
    	user.setPassword(dto.getPassword());

        try {
            update();
        } catch (final DAOException e) {
        	throw e;
        }
    }

//    /**
//     * Usernameの保存します。
//     *
//     * @param dto
//     * @throws DAOException
//     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#savePassword(jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationUserDTO)
//     */
//    public void saveUsername(final ApplicationUserDTO dto) throws DAOException {
//    	final LoginUsers users = getLoginUsers();
//
//    	final LoginUser user = searchUser(users, dto.getUserId());
//    	user.setLabel(dto.getUserLabel());
//        try {
//            update();
//        } catch (final DAOException e) {
//        	throw e;
//        }
//    }

    /**
     * ユーザー情報を保存します。
     * <p>
     * 既存の場合は更新を、未登録の場合は新規追加を行います。
     * </p><p>
     * パスワードの暗号化はプレゼンテーション層内で実行されます。ただし、
     * パスワード文字列が空で指定された場合はユーザー ID を暗号化して保存します。
     * </p>
     *
     * @param dto
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#save(jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationUserDTO)
     */
    public void save(
    		//final UserInfo userInfo,
    		final ApplicationUserDTO dto,
    		final UpdateDivision updateDivision)
    		throws DAOException {
    	final LoginUsers users = getLoginUsers();

    	final LoginUser buff = searchUser(users, dto.getUserId());
    	final LoginUser user;
    	if (buff == null) {
    		user = getObjectFactory().createLoginUser();
    		users.getLoginUser().add(user);
    	} else {
    		user = buff;
    	}

        user.setId(dto.getUserId());
        user.setLabel(dto.getUserLabel());
		// MOD 外部認証連携 機能追加 ↓
		if (SystemProperties.getExtAuth().equals(ExtAuthValue.OFF.getValue()) || dto.getUserId().equals("admin")) {
			if (dto.getPassword() == null || dto.getPassword().equals("")) {
				try {
					user.setPassword(BlowfishUtils.encrypt2b64(openSesame(), dto.getUserId()));
				} catch (final Exception e) {
					// MI-F-0009=パスワードの暗号化に失敗しました。
					final String message = MessageUtils.getMessage("MI-F-0009");
					getLogger().fatal(message, e);
					throw new DAOException(e);
				}
			} else {
				user.setPassword(dto.getPassword());
			}
		} else {
			user.setPassword("");
		}
		// MOD 外部認証連携 機能追加 ↑
        final Authority authority;
        final Authority buffAuth = user.getAuthority();
        if (buffAuth == null) {
        	authority = getObjectFactory().createAuthority();
        	user.setAuthority(authority);
        } else {
        	authority = buffAuth;
        }

        final UserAuthority userAuthority = dto.getAuthority();
        authority.setSystemAdministrator(userAuthority.isSystemAdministrator());

        final AuthConnectDefinisions buffAuthConnectDefinisions
        	= authority.getAuthConnectDefinisions();
        final AuthConnectDefinisions authConnectDefinisions;
        if (buffAuthConnectDefinisions == null) {
        	authConnectDefinisions
        		= getObjectFactory().createAuthorityAuthConnectDefinisions();
        	authority.setAuthConnectDefinisions(authConnectDefinisions);
        } else {
        	authConnectDefinisions = buffAuthConnectDefinisions;
            authConnectDefinisions.getAuthConnectDefinision().clear();
        }

        for (final ConnectDefinisionAuthority defAuthority
        		: userAuthority.getConnectDefinisionAuthoritys()) {
        	final AuthConnectDefinision authConnectDefinision
        		= getObjectFactory().createAuthorityAuthConnectDefinisionsAuthConnectDefinision();
        	authConnectDefinision.setId(defAuthority.getConnectDefinisionId());
            authConnectDefinision.getAuth().clear();

        	for (final GeneralUserOperationAuthority operationAuthority
        			: defAuthority.getOperationAuthority()) {
        		final Auth auth =
        			getObjectFactory().createAuthorityAuthConnectDefinisionsAuthConnectDefinisionAuth();
        		auth.setId(operationAuthority.getId());
            	authConnectDefinision.getAuth().add(auth);
        	}
            authConnectDefinisions.getAuthConnectDefinision().add(authConnectDefinision);
        }

        try {
            update();
        } catch (final DAOException e) {
        	throw e;
        }
    }

    /**
     * ユーザー情報を削除します。
     *
     * @param userId ユーザー ID
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO#remove(java.lang.String)
     */
    public void remove(final String userId)
            throws DAOException {
    	final LoginUsers users = getLoginUsers();

    	if (users == null || users.getLoginUser() == null) {
        	// MI-E-0053=ユーザーが存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0053"));
        }

    	final List<LoginUser> list = users.getLoginUser();
        for (final Iterator<LoginUser> ite = list.iterator(); ite.hasNext();) {
            final LoginUser user = ite.next();
        	if (user.getId().equals(userId)) {
            	ite.remove();
                update();
                return;
        	}
        }
    }

    /**
     * ApplicationUserDAOImpl の生成。
     * <p>
     * コンストラクタ。</p>
     *
     * @throws DAOException
     */
    public ApplicationUserDAOImpl() {
        super();
    }

    /**
     * ユーザー ID からユーザー要素を検索して戻す。
     * <p>
     * リポジトリXMLに含まれるユーザー要素オブジェクトを検索して参照を戻します。<br />
     * ユーザーが発見出来ない場合は null を戻します。</p>
     *
     * @param userId
     * @return LoginUser
     */
    private LoginUser searchUser(final String userId) throws DAOException {
    	final LoginUsers users = getLoginUsers();
    	for (final LoginUser user : users.getLoginUser()) {
    		if (user.getId().equals(userId)) {
    			return user;
    		}
    	}
    	return null;
    }

    /**
     * ユーザー情報、ユーザー ID からユーザー要素を検索して戻す。
     * <p>
     * ユーザー情報に含まれるユーザー要素オブジェクトを検索して参照を戻します。<br />
     * ユーザーが発見出来ない場合は null を戻します。</p>
     *
     * @param userId
     * @return LoginUser
     */
    private LoginUser searchUser(
    		final LoginUsers users,
    		final String userId) throws DAOException {
    	for (final LoginUser user : users.getLoginUser()) {
    		if (user.getId().equals(userId)) {
    			return user;
    		}
    	}
    	return null;
    }

    // ADD 外部認証連携 機能追加　↓
    /**
     *
     * Is ex-authentication or not
     * true: ExtAuth = ON
     * false: ExtAuth != ON
     *
     * @return
     */
	private boolean isExAuthentication() {
		String status = SystemProperties.getExtAuth();
		if (status.equals(EX_AUTHENTICATE_ON)) {
			return true;
		}
		return false;
	}

	/**
	 *
	 * Verify user on server.
	 * true: success
	 * false: fail
	 *
	 * @param username
	 * @param password
	 * @return
	 */
	private boolean verifyExAuthentication(String username, String password) {
		boolean result = false;
		try {
			AuthByLDAP authByLDAP = new AuthByLDAP();
			authByLDAP.setAuthServerType(SystemProperties.getAuthServerType());
			authByLDAP.setAuthServerId(SystemProperties.getAuthServerId());
			authByLDAP.setAuthServerPort(String.valueOf(SystemProperties.getAuthServerPort()));
			authByLDAP.setAuthDomain(SystemProperties.getAuthServerBaseDomain());
			authByLDAP.setAuthServerProtocol(SystemProperties.getAuthServerProtocol());
			authByLDAP.setAuthServerSecurity(SystemProperties.getAuthServerSecurity());
			authByLDAP.setAuthServerTimeout(String.valueOf(SystemProperties.getAuthServerTimeout()));
			authByLDAP.setAuthServerUserIdentify(SystemProperties.getAuthServerUserIdentify());
			authByLDAP.setUsername(username);
			authByLDAP.setPassword(password);
			result = authByLDAP.connect();
		} catch(ApplicationException e) {
			getLogger().error(e.getMessage());
			return false;
		}
		return result;
	}
	//ADD 外部認証連携 機能追加　↑
}
