/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.audit.dto;

import java.util.List;

import jp.co.systemexe.dbu.dbace.library.dto.BaseDto;
import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author van-thanh
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0530ResultDto extends BaseDto {

	private static final long serialVersionUID = 1L;
	AuditSettingDTO beforeAuditSettingDTO;
    AuditCategoryItem[] auditCategoryItems;
    List<SelectOneMenuItem> auditLogFileUnitItems;
    String auditLogFileSize;
    String auditLogFileUnit;
    String auditLogFileRotation;
    String auditLogFileOutput;    
    
    List<MessageInfo> messageInfoList;

}
