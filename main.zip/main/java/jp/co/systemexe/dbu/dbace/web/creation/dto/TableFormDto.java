/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

@Data
public class TableFormDto {
	/*XmlAttribute*/
	private String id;
	private String label;
	private Boolean orderdesc;
	private String type;
	private String discription;
	private Boolean enable;
	
	/*XmlElement*/
	private SortDto sortDto;
	private List<ItemDto> itemDtoList;
	private TablesDto tablesDto;
	private RelationsDto relationsDto;
	private OptionalDto optionalDto;
	
	/*Dummy*/
	private String connectionId;
	private String connectionLabel;

	public TableFormDto() {

	}

	/**
	 * new TableFormDto by TableForm
	 * @param tableForm
	 */
	public TableFormDto(TableForm tableForm) {
		if (tableForm == null) {
			return;
		}
		this.setId(tableForm.getId());
		this.setLabel(tableForm.getLabel());
		this.setOrderdesc(tableForm.getOrderdesc());
		this.setType(tableForm.getType());
		this.setDiscription(tableForm.getDiscription());
		this.setEnable(tableForm.getEnable());
		/*setSortTableFormDto(tableForm.getSort());*/
		this.setSortDto(new SortDto(tableForm.getSort())); 
		this.setItemDtoList(tableForm.getItem());
		this.setTablesDto(new TablesDto(tableForm.getTables()));
		this.setRelationsDto(new RelationsDto(tableForm.getRelations()));
		this.setOptionalDto(new OptionalDto(tableForm.getOptional()));
	}
	
	/**
	 * 1. new ArrayList<ItemDto>()
	 * 2. sort by SortIndex
	 * @return itemDtoList
	 */
	public List<ItemDto> getItemDtoList() {
        if (itemDtoList == null) {
        	itemDtoList = new ArrayList<ItemDto>();
        }else{
        	Collections.sort(itemDtoList, new Comparator<ItemDto>() {
    		  @Override public int compare(final ItemDto o1, final ItemDto o2) {
    		    return o1.getSortIndex() == o2.getSortIndex() ? 0 : o1.getSortIndex() > o2.getSortIndex() ? 1 : -1;
    		  }
    		});
        }
        return itemDtoList;
    }
	
	public void setItemDtoList(List<Item> Items){
		if(Items != null){
			List<ItemDto> ItemDtos = new ArrayList<ItemDto>();
			for(Item item : Items){
				ItemDto itemDto = new ItemDto(item);
				ItemDtos.add(itemDto);
			}
			this.itemDtoList = ItemDtos;
		}
	}

	public Boolean isOrderdesc() {
		return orderdesc;
	}

	public void isOrderdesc(Boolean orderdesc) {
		this.orderdesc = orderdesc;
	}

	public Boolean isEnable() {
		return enable;
	}

	public void isEnable(Boolean enable) {
		this.enable = enable;
	}

}
