/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import java.util.HashMap;
import java.util.Map;

/**
 * DB(XML)更新処理区分 enum。
 * <p>
 * GUI 画面遷移の際に、共通編集画面に対してどの編集モードで動作すべきかを指示
 * するための定義値です。いわゆる（操作処理区分）
 * </p>
 * 
 * @author EXE 島田 雄一郎
 * @author EXE 鈴木 伸祐
 * @author EXE 相田 一英
 * @version 0.0.0
 */
public enum UpdateDivision {

    insert("insert", "登録"),
    update("update", "更新"),
    delete("delete", "削除"),
    reference("reference", "参照"),
    copy("copy", "複写新規");

    /**
     * 更新処理区分を&lt;編集モードkey,編集モード区分Enum&gt;マップに生成し保持します。
     * <p>スタティックイニシャライザーにてMapに設定。</p>
     */
    private static Map<String, UpdateDivision> map;
    static {
        map = new HashMap<String, UpdateDivision>();
        for (final UpdateDivision buff : values()) {
            map.put(buff.getKey(), buff);
        }
    }

    /**
     * 更新処理区分を key に、更新処理区分 Enum を取得します。
     * 
     * @param key
     * @return 更新処理区分 Enum
     */
    public static UpdateDivision keyOf(final String key) {
        if (map.containsKey(key)) {
            return map.get(key);
        } else {
            return null;
        }
    }

    /**
     * 更新処理区分の Key を保持します。
     */
    private final String key;

    /**
     * 更新処理区分の label を保持します。
     */
    private final String label;

    /**
     * 更新処理区分の key を戻します。
     * 
     * @return String
     */
    public String getKey() {
        return key;
    }

    /**
     * 更新処理区分の label を戻します。
     * 
     * @return String
     */
    public String getLabel() {
        return label;
    }

    /**
     * UpdateDivision の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param 更新処理ID
     * @param 更新処理表示名
     */
    private UpdateDivision(final String id, final String label) {
        this.key = id;
        this.label = label;
    }
}
