package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.jdbc.DataTypeDBMappingWithJDBC;
import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.jdbc.WebResultSetFacade;
import jp.co.systemexe.dbu.dbace.common.sql.SqlJoinTableLogicalOperator;
import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableComparisonOperator;
import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableLogicalOperator;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectSqlCondition;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SimpleSqlCondition;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.TableIdDefinition;
import jp.co.systemexe.dbu.dbace.persistance.dao.message.OracleMessageWrapper;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.web.common.AppConst;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.ColsDto.ColDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;

/**
 * （JavaDoc）。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public abstract class MySQLDatabaseTableDAO extends BaseDatabaseTableDAO {
    /**
     * 項目名と値を単純に「=」で接続した Where 句文字列を作成して戻す。
     * <p>
     * 先頭に ' where ' も修飾して戻します。</p>
     * <p>
     * 条件指定が無い場合は空文字を戻します。</p>
     *
     * @param wheresMap
     * @return
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseDatabaseDAO#createSelectWheresClause(java.util.SortedMap)
     */
    @Override
    protected String createSelectWheresClause(SortedMap<Integer, SelectConditionItem> wheresMap) {
        if (wheresMap.size() <= 0) {
            return "";
        } else {
            final StringBuffer wheres = new StringBuffer();
            for (final Integer index : wheresMap.keySet()) {
                final SelectConditionItem item = wheresMap.get(index);
                
                if (item.getComparisonOperator() == SqlWhereTableComparisonOperator.isNull
                		|| item.getComparisonOperator() == SqlWhereTableComparisonOperator.isNotNull) { 
                	String operator = (item.getComparisonOperator() == SqlWhereTableComparisonOperator.isNull) ? "=" : "<>";
                	if(AppConst.NULL_ONLY.equals(item.getJDBCMetaDataType().getSearchStringFlag())){
//                    	NULL_ONLY = 0 : where条件：is null/ is not null だけ（シングルクォーテーションと比較しない）
                		wheres.append(" (`");
                        wheres.append(item.getColumnId());
                        wheres.append("`");
                        wheres.append(" ");
                        wheres.append(item.getComparisonOperator().getComparisonOperator());
                        wheres.append(" ");
                	} else if(AppConst.NULL_VARIABLE.equals(item.getJDBCMetaDataType().getSearchStringFlag())){
//                    	NULL_VARIABLE = 1 : is null/ is not null または シングルクォーテーションと比較
                		wheres.append(" (IFNULL(CHAR_LENGTH(`");
                        wheres.append(item.getColumnId());
                        wheres.append("`), 0)");
                        wheres.append(" ");
                        wheres.append(operator);
                        wheres.append("0");
                	} else if(AppConst.NULL_FIXED.equals(item.getJDBCMetaDataType().getSearchStringFlag())){
//                    	NULL_FIXED = 2 : is null/ is not null または 「項目をTRIM した結果」とシングルクォーテーション　比較
                		wheres.append(" (IFNULL(CHAR_LENGTH(TRIM(`");
                        wheres.append(item.getColumnId());
                        wheres.append("`)), 0)");
                        wheres.append(" ");
                        wheres.append(operator);
                        wheres.append("0");
                	}
                	wheres.append(") ");
                } else {
                    wheres.append(" `");
                    wheres.append(item.getColumnId());
                    wheres.append("`");
                    wheres.append(" ");
                    wheres.append(item.getComparisonOperator().getComparisonOperator());
                    wheres.append(" ");

                    if (StringUtils.isNotEmpty(item.getValue())) {
                        if (isJDBCMetaDataTypeToNumber(item.getJDBCMetaDataType())) {
                            wheres.append(item.getValue());
                        } else if (isJDBCMetaDataTypeToDate(item.getJDBCMetaDataType())) {
                        	// MySQLのTIMESTAMP型のエーラを修正　↓
                        	//wheres.append(String.format("CAST('%s' AS %s)", item.getValue(), item.getColumnTypeName()));
                        	if (item.getJDBCMetaDataType() == JDBCMetaDataType.TIMESTAMP) {
                        		wheres.append(String.format("CAST('%s' AS %s)", item.getValue(), "DATETIME"));// TIMESTAMPをDATETIMEに変更
                        	} else {
                        		wheres.append(String.format("CAST('%s' AS %s)", item.getValue(), item.getColumnTypeName()));
                        	}
                        	// MySQLのTIMESTAMP型のエーラを修正　↑
                        } else {
                            wheres.append("'");

                            //条件に含まれるシングルクォーテーションを2重化する。
                            final String condition = item.getValue().replace("'", "''");

                            //演算子がパターンマッチングである場合に、条件にワイルドカードの役割を担うメタ文字%を付加する。
                            wheres.append(getPatternMatchCondition(item.getComparisonOperator(), condition));
                            wheres.append("'");

                            wheres.append(" ");
                        }
                        wheres.append(" ");
                    }
                }
                if(index <= wheresMap.size() && item.getLogicalOperator() != null){
                	wheres.append(item.getLogicalOperator().getLogicalOperator());
                }
            }
            return " where ".concat(wheres.toString().replaceAll("\"", "`"));
        }
    }

    @Override
	protected String createSimpleWheresString(SimpleSqlCondition condition) {
        final Map<String, String> wheresMap = condition.getWheresMap();
        if (wheresMap.size() <= 0) {
            return "";
        } else {
            final StringBuffer wheres = new StringBuffer();
            for (final Iterator<String> ite = wheresMap.keySet().iterator(); ite
                    .hasNext();) {
                final String name = ite.next();
                final String columnname = String.format("`%s`", name);
                final String singleQuart = additionSingleQuart(condition.getJdbcMetaDataMap().get(name));
                final String value = wheresMap.get(name);
                if (wheres.length() <= 0) {
                    if (value.equals("")) {
                        wheres.append("(");
                        if (singleQuart.endsWith("'")) {
                            wheres.append(columnname);
                            wheres.append(" = ");
                            wheres.append(singleQuart);
                            wheres.append(value.replace("'", "''"));
                            wheres.append(singleQuart);
                            wheres.append(" or ");
                        }
                        wheres.append(columnname);
                        wheres.append(" is null ");
                        wheres.append(")");
                    } else {
                        wheres.append(columnname);
                        wheres.append(" = ");
                        wheres.append(singleQuart);
                        wheres.append(value.replace("'", "''"));
                        wheres.append(singleQuart);
                    }
                } else {
                    wheres.append(" and ");
                    if (value.equals("")) {
                        wheres.append("(");
                        if (singleQuart.endsWith("'")) {
                            wheres.append(columnname);
                            wheres.append(" = ");
                            wheres.append(singleQuart);
                            wheres.append(value.replace("'", "''"));
                            wheres.append(singleQuart);
                            wheres.append(" or ");
                        }
                        wheres.append(columnname);
                        wheres.append(" is null ");
                        wheres.append(")");
                    } else {
                        wheres.append(columnname);
                        wheres.append(" = ");
                        wheres.append(singleQuart);
                        wheres.append(value.replace("'", "''"));
                        wheres.append(singleQuart);
                    }
                }
            }
            return " where ".concat(wheres.toString());
        }
	}

//    @Override
//	protected String ignoreNullColumns(List<String> colList) {
//		final StringBuffer columnsBuff = new StringBuffer();
//		final StringBuffer bracketsBuff = new StringBuffer();
//		String dbFunc = "IFNULL";
//		int index = 0;
//		for (String name : colList) {
//			if (columnsBuff.length() > 0) {
//				columnsBuff.append(", ");
//			}
//
//			columnsBuff.append(dbFunc);
//			columnsBuff.append("(");
//			columnsBuff.append(name);
//
//			if(index >= colList.size() - 1){
//				columnsBuff.append(", ");
//				columnsBuff.append("null");
//			}
//
//			bracketsBuff.append(")");
//			index++;
//		}
//		columnsBuff.append(bracketsBuff);
//		return columnsBuff.toString();
//	}
    
    @Override
    protected String ignoreNullColumns(final List<String> columns, final String columnType) {
    	final int lastIndex = columns.size() - 1;
    	final String lastColumn = columns.get(lastIndex);
    	String temp = ignoreNullColumns(lastColumn, columnType);
    	for(int i = columns.size() - 2; i >= 0; i--){
    		String tempi = ignoreNullColumns(columns.get(i), columnType);
    		temp = tempi.replace(" NULL", String.format(" %s ", temp));
    	}
		return temp;
	}
    
    private String ignoreNullColumns(final String column, final String columnType) {
    	final String databaseType = DatabaseTypeConnectionDestination.MySQL.getKey();
    	final String dataTypeDatabase = columnType;
    	final DataTypeDBMappingWithJDBC dataType;
    	dataType= DataTypeDBMappingWithJDBC.getByDataTypeDatabase(databaseType, dataTypeDatabase);
    	final JDBCMetaDataType jdbc = JDBCMetaDataType.dataTypeOf(dataType.getDataType());
    	final int columnNullType = jdbc.getSearchStringFlag();
    	
    	String temp = "";
    	if(AppConst.NULL_ONLY.equals(columnNullType)){
    	    temp += String.format("(IFNULL(%s, NULL))", column);
    	}else if(AppConst.NULL_VARIABLE.equals(columnNullType)) {
    		temp = "(CASE WHEN ";
    	    temp += String.format("(IFNULL(CHAR_LENGTH(%s), 0) = 0) ", column);
    	    temp += "THEN NULL ";
    	    temp += String.format("ELSE %s ", column);
    	    temp += "END) ";
    	}else if(AppConst.NULL_FIXED.equals(columnNullType)) {
    		temp = "(CASE WHEN ";
    	    temp += String.format("(IFNULL(CHAR_LENGTH(TRIM(%s)), 0) = 0) ", column);
    	    temp += "THEN NULL ";
    	    temp += String.format("ELSE %s ", column);
    	    temp += "END) ";
    	}
	    return temp;
    }

//	/**
//     * 選択条件 VO を生成し値を設定して戻す。
//     *
//     * @param dto
//     * @param form
//     * @return SelectSqlCondition
//     */
//    protected SelectSqlCondition createSelectSqlCondition(
//            final RecordSearchConditionDTO dto, final TableFormDTO form) {
//        final SelectSqlCondition ret = new SelectSqlCondition();
//        ret.setTableId(dto.getTableId());
//        ret.setType(form.getType());
//        for (final Iterator<String> ite = form.getTableItemMap().keySet()
//            .iterator(); ite.hasNext();) {
//            ret.addValues(ite.next(), null);
//        }
//
//        for (final Integer index : dto.getConditions().keySet()) {
//            final SelectConditionItem buff = dto.getConditions().get(index);
//            ret.addWheres(index, buff);
//        }
//
//        for (final Iterator<Integer> ite = form.getSortConditionMap().keySet()
//            .iterator(); ite.hasNext();) {
//            final int index = ite.next();
//            ret.addOrders(index, form.getSortConditionMap().get(index));
//        }
//
//		for (final Iterator<String> ite = form.getRelationMap().keySet().iterator(); ite.hasNext();) {
//			final String id = ite.next();
//			ret.addRelation(id, form.getRelationMap().get(id));
//		}
//
//		for (final Iterator<String> ite = form.getTableItemMap().keySet().iterator(); ite.hasNext();) {
//			final String id = ite.next();
//			ret.addColumn(id, form.getTableItemMap().get(id));
//		}
//
//		ret.setTablesMap(form.getTableMap());
//
//        ret.setOrderAsc(dto.isOrderAsc());
//        return ret;
//    }

	@Override
	protected String rowCount(SelectSqlCondition condition) throws DAOException {
        /*TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
        final String where = createSelectWheresClause(condition.getWheresMap());
        final String query = "select "
                + "COUNT(*)"
                + " from "
                + String.format("`%s`.`%s`",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + where;

        getLogger().debug(query);
    	setSearchCondition(where.replace(" where ", ""));

        return query;*/
        
        final String where = this.createWheresClause(condition.getType(), condition.getTableId(), condition.getColumnsMap(), condition.getWheresMap());
        final String query = "select "
                + "COUNT(*)"
                + " from "
                + this.createFromClause(condition)
                + " " + createJoinsClause(condition.getJoinsMap()) + " "
                + where;

        getLogger().debug(query);
        setSearchCondition(where.replace(" where ", ""));
        
        return query;
	}

	@Override
	protected String rowCountLike(SelectSqlCondition condition) throws DAOException {
        /*TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
        final String where = createSelectWheresClause(condition.getWheresMap());
        final String query = "select "
                + "COUNT(*)"
                + " from "
                + String.format("`%s`.`%s`",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + where;

        getLogger().debug(query);
    	setSearchCondition(where.replace(" where ", ""));

        return query;*/
		TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
        final String where = createWheresClause(condition.getType(), condition.getTableId(), condition.getColumnsMap(), condition.getWheresMap());
        final String query = "select "
                + "COUNT(*)"
                + " from "
                + String.format("`%s`.`%s`",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + where;

        getLogger().debug(query);
        setSearchCondition(where.replace(" where ", ""));

        return query;
	}

    /**
     * MySQLのレコードを抽出した結果セットを戻します。
     * <p>
     * 複数カラムに対する一致条件のみのシンプルな条件で結果セットを取得し参照を
     * 戻します。</p>
     * <p>
     * 本メソッドを使用した場合は、クライアント側で結果セットの close 後、
     * getPreparedStatement の参照を経由し PreparedStatement も close しなければ
     * なりません。</p>
     *
     * @param condition
     * @param isForwardOnly
     * @return WebResultSetFacade 結果セットラッパー
     * @throws DAOException
     */
//	@Override
//	protected WebResultSetFacade select(
//			final SelectSqlCondition condition,
//			final boolean isForwardOnly)
//					throws DAOException {
//		String columns = this.createSelectClause(condition.getType(), condition.getTableId(),
//        		condition.getValuesMap(),
//        		condition.getColumnsMap());
//
//        final String where = this.createWheresClause(condition.getType(), condition.getTableId(),
//        		condition.getColumnsMap(),
//        		condition.getWheresMap());
//        String query = "select "
//                + columns.toString()
//                + " from "
//                + this.createFromClause(condition)
//                + " " + this.createJoinsClause(condition.getJoinsMap()) + " "
//                + where
//                + this.createOrdersClause(condition.getType(),
//                		condition.getTableId(),
//                		condition.getColumnsMap(),
//                		condition.getOrdersMap(),
//                		condition.isOrderAsc());
//
//        setSearchCondition(where.replace(" where ", ""));
//        getLogger().debug("select sql:" + query);
//        query = query.replaceAll("\"", "`");
//        try {
//        	if (isForwardOnly) {
//        		this.setPreparedStatement(getPreparedStatementForwardOnly(query));
//        	} else {
//        		this.setPreparedStatement(getPreparedStatement(query));
//        	}
//        	return new WebResultSetFacade(this.getPreparedStatement().executeQuery());
//        } catch (final SQLException e) {
//            try {
//                if (this.getPreparedStatement() != null) {
//                    this.getPreparedStatement().close();
//                    this.setPreparedStatement(null);
//                }
//            } catch (final SQLException ex) {
//                getLogger().warn(ex);
//            }
//        	// MI-E-0021=データベースのカーソルの取得に失敗しました。({0})
//            final String message
//	        	= OracleMessageWrapper.getWrapMessage(
//					e.getErrorCode(),
//					e.getMessage(),
//					"MI-E-0021");
//            getLogger().error(message, e);
//            throw new DAOException(message, e);
//        }
//	}

	@Override
	protected void update(SimpleSqlCondition condition, String databaseId, UserInfo userInfo) throws DAOException {
        TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
        final StringBuffer columns = new StringBuffer();
        for (final String name : condition.getValuesMap().keySet()) {
        	String aliasName = "";
        	for(Map.Entry<String, String> aliasEntry:condition.getAliasNameMap().entrySet()){
        		if (aliasEntry.getValue().equals(name)){
        			aliasName = aliasEntry.getKey();
        		}
        	}
        	final Boolean isVirtualColumn = condition.getVirtualColumns().get(name);
        	if (isVirtualColumn != null
        			&& isVirtualColumn) {
        		continue;
        	}
        	String columnname = String.format("`%s` as `%s`", name, aliasName);
            if (columns.length() <= 0) {
                columns.append(columnname);
            } else {
                columns.append(", ");
                columns.append(columnname);
            }
        }
        final String where = createSimpleWheresString(condition);
        final String query = "select " + columns.toString() + " from "
        + String.format("`%s`.`%s`",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + where;

        getLogger().debug(query);

    	setPreparedStatement(getPreparedStatement(query));

        final WebResultSetFacade facade;
        try {
            facade = new WebResultSetFacade(getPreparedStatement()
                .executeQuery());
        } catch (final SQLException e) {
        	// MI-E-0079=レコードの更新に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0079");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        boolean isSuccess = true;
        try {
            facade.first();
            facade.updateMap(condition);
            facade.updateRow();
            isSuccess = true;
        } catch (final SQLException e) {
            isSuccess = false;
        	getLogger().error(e.getErrorCode() + "," + e.getSQLState() + "," + e.getLocalizedMessage());
        	// MI-E-0079=レコードの更新に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0079");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } catch (final DAOException e) {
            isSuccess = false;
            throw e;
        } finally {
        	final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
            try {
				OutputAuditLog.writeExcuteUpdateLog(
						AuditEventKind.UPDATE,
						userInfo,
						connectDefinitionListLogic.getConnectionByID(condition.getConnectDefinitionId()).getLabel(),
						connectDefinitionListLogic.getTableForm(condition.getConnectDefinitionId(), condition.getTableId()).getLabel(),
						isSuccess ? AuditStatus.success : AuditStatus.failure,
						condition.getValuesMap(),
						where.replace(" where ", ""),
						isSuccess ? "1" : "0");
			} catch (ApplicationDomainLogicException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

            facade.close();
        }
	}

	@Override
	protected int delete(SimpleSqlCondition condition, String databaseId, UserInfo userInfo) throws DAOException {
        TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
    	final String where = createSimpleWheresString(condition);
        final String query = "delete from "
                + String.format("`%s`.`%s`",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + where;

        getLogger().debug(query);
        int rowAffected = 0;
        boolean isSuccess = true;
        PreparedStatement statement = null;
        try {
        	statement = getConnectionManager()
                .getConnection().prepareStatement(query);
        	rowAffected = statement.executeUpdate();
            isSuccess = true;
        } catch (final SQLException e) {
            isSuccess = false;

        	// MI-E-0081=レコードの削除に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0081");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
        	final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
            try {
				OutputAuditLog.writeExcuteUpdateLog(
						AuditEventKind.DELETE,
						userInfo,
						connectDefinitionListLogic.getConnectionByID(condition.getConnectDefinitionId()).getLabel(),
						connectDefinitionListLogic.getTableForm(condition.getConnectDefinitionId(), condition.getTableId()).getLabel(),
						isSuccess ? AuditStatus.success : AuditStatus.failure,
						condition.getValuesMap(),
						where.replace(" where ", ""),
						isSuccess ? "1" : "0");
			} catch (ApplicationDomainLogicException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

            if (statement != null) {
            	try {
            		statement.close();
            	} catch (final SQLException e) {
            		getLogger().warn(e);
            	}
            }
        }
        return rowAffected;
	}

	@Override
	protected void insert(SimpleSqlCondition condition, String databaseId, UserInfo userInfo) throws DAOException {
        final StringBuffer columns = new StringBuffer();
        TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());

        for (final String name : condition.getValuesMap().keySet()) {
        	final Boolean isVirtualColumn = condition.getVirtualColumns().get(name);
        	if (isVirtualColumn != null
        			&& isVirtualColumn) {
        		continue;
        	}
        	String columnname = String.format("`%s`", name);
            if (columns.length() <= 0) {
                columns.append(columnname);
            } else {
                columns.append(", ");
                columns.append(columnname);
            }
        }
        final String query = "select " + columns.toString() + " from "
                + String.format("`%s`.`%s`",tableiddefinition.getSchem(), tableiddefinition.getTable())
                + createSimpleWheresString(condition);

        getLogger().debug(query);

    	setPreparedStatement(getPreparedStatement(query));

        WebResultSetFacade facade = null;
        boolean isSuccess = true;
        try {
            facade = new WebResultSetFacade(getPreparedStatement()
                .executeQuery());
            facade.moveToInsertRow();
            facade.insertMap(condition);
            facade.insertRow();
            isSuccess = true;
        } catch (final SQLException e) {
            isSuccess = false;

            // MI-E-0097=レコードの登録に失敗しました。({0})
            final String message
	        	= OracleMessageWrapper.getWrapMessage(
					e.getErrorCode(),
					e.getMessage(),
					"MI-E-0097");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } catch (final DAOException e) {
            isSuccess = false;

            throw e;
        } finally {
        	final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
            try {
				OutputAuditLog.writeExcuteUpdateLog(
						AuditEventKind.INSERT,
						userInfo,
						connectDefinitionListLogic.getConnectionByID(condition.getConnectDefinitionId()).getLabel(),
						connectDefinitionListLogic.getTableForm(condition.getConnectDefinitionId(), condition.getTableId()).getLabel(),
						isSuccess ? AuditStatus.success : AuditStatus.failure,
						condition.getValuesMap(),
						"",
						isSuccess ? "1" : "0");
			} catch (ApplicationDomainLogicException e) {
				throw new DAOException(e);
			}

        	if (facade != null) {
        		facade.close();
        	}
            try {
                if (getPreparedStatement() != null) {
                	getPreparedStatement().close();
                	setPreparedStatement(null);
                }
            } catch (final SQLException ex) {
                getLogger().warn(ex);
            }
        }
	}

	@Override
	protected String createOrdersClause(SortedMap<Integer, String> ordersMap, boolean asc) {
        if (ordersMap.size() <= 0) {
            return "";
        } else {
            final StringBuffer orders = new StringBuffer();
            for (final Iterator<String> ite = ordersMap.values().iterator(); ite
                .hasNext();) {
                final String name = String.format("`%s`",ite.next());
                if (orders.length() <= 0) {
                	orders.append(name);
	            } else {
	                orders.append(",");
	                orders.append(name);
	            }
                orders.append(( asc ? " asc" : " desc" ));
            }
            return " order by " + orders.toString();
        }
	}

    /**
     * 選択条件 VO を生成し値を設定して戻す。
     *
     * @param dto
     * @param form
     * @return SelectSqlCondition
     */
    protected SelectSqlCondition createSelectSqlConditionTab(
            final RecordSearchConditionDTO dto, final TableFormDTO form,
            final TableDto table) {
        final SelectSqlCondition ret = new SelectSqlCondition();
        ret.setTableId(dto.getTableId());
        ret.setType(form.getType());
        for (final Iterator<String> ite = form.getTableItemMap().keySet()
            .iterator(); ite.hasNext();) {
            ret.addValues(ite.next(), null);
        }

        for (final Integer index : dto.getConditions().keySet()) {
            final SelectConditionItem buff = dto.getConditions().get(index);
            ret.addWheres(index, buff);
        }

        for (final Iterator<Integer> ite = form.getSortConditionMap().keySet()
            .iterator(); ite.hasNext();) {
            final int index = ite.next();
            ret.addOrders(index, form.getSortConditionMap().get(index));
        }

		for (final Iterator<String> ite = form.getRelationMap().keySet().iterator(); ite.hasNext();) {
			final String id = ite.next();
			ret.addRelation(id, form.getRelationMap().get(id));
		}

		for (final Iterator<String> ite = form.getTableItemMap().keySet().iterator(); ite.hasNext();) {
			final String id = ite.next();
			ret.addColumn(id, form.getTableItemMap().get(id));
		}

		ret.setTablesMap(form.getTableMap());

        ret.setOrderAsc(dto.isOrderAsc());
        return ret;
    }

    /**
     * @param dto
     * @param table
     * @return
     */
    protected SelectSqlCondition createSelectSqlConditionTab(
            final RecordSearchConditionDTO dto,
            final TableDto table) {
        final SelectSqlCondition ret = new SelectSqlCondition();
        ret.setTableId(table.getId());

        for (final Integer index : dto.getConditions().keySet()) {
            final SelectConditionItem buff = dto.getConditions().get(index);
            ret.addWheres(index, buff);
        }


        return ret;
    }
    
    /**
     * @param type
     * @param mTableId
     * @param columnsMap
     * @param wheresMap
     * @return
     */
    private String createWheresClause(
    		String type, 
    		String mTableId, 
    		Map<String, TableItemDTO> columnsMap,
			SortedMap<Integer, SelectConditionItem> wheresMap) {
	   	if (!isMultiTable(type)) {
	   		return createSelectWheresClause(wheresMap);
	   	}else{
	   		return createWheresClauseForMultiTable(mTableId, columnsMap, wheresMap);
	   	}
	}
    
    /**
     * @param mTableId
     * @param columnsMap
     * @param wheresMap
     * @return
     */
    private String createWheresClauseForMultiTable(
    		String mTableId, 
    		Map<String, TableItemDTO> columnsMap,
			SortedMap<Integer, SelectConditionItem> wheresMap) {
    	if (wheresMap.size() <= 0) {
            return "";
        } else {
            final StringBuffer wheres = new StringBuffer();
            for (final Integer index : wheresMap.keySet()) {
                final SelectConditionItem item = wheresMap.get(index);
                if(columnsMap.containsKey(item.getColumnId())){
                	SortedMap<Integer, SelectConditionItem> subWheresMap = new TreeMap<Integer, SelectConditionItem>();
                	TableItemDTO tableItem = columnsMap.get(item.getColumnId());
                	if(tableItem.getCols() != null && tableItem.getCols().size() > 0){
                		SqlWhereTableLogicalOperator subLogicalOperator = SqlWhereTableLogicalOperator.blank;
                		for (Iterator<String> iterator = tableItem.getCols().keySet().iterator(); iterator.hasNext();) {
	    					String listNo = (String) iterator.next();
	    					ColDto colDto = tableItem.getCols().get(listNo);
	    					SelectConditionItem itemCond = new SelectConditionItem();
	    					itemCond.setColumnId(colDto.getItemID());
	    					itemCond.setTableId(colDto.getTableID());
	    					itemCond.setColumnTypeName(item.getColumnTypeName());
	    					itemCond.setComparisonOperator(item.getComparisonOperator());
	    					itemCond.setJDBCMetaDataType(item.getJDBCMetaDataType());
	    					itemCond.setLogicalOperator(subLogicalOperator);
	    					itemCond.setValue(item.getValue());
	    					subWheresMap.put(new Integer(listNo), itemCond);
	//            			「item->operationのselectがfalse」の場合、「item->cols->colのListNoが1」の「TableID.ItemID」をセットする
	//    					 Only get first item
	            			if(tableItem.getOperations() != null && !tableItem.getOperations().isSelect()){
	            				break;
	            			}else{
	            				if(iterator.hasNext()){
	            					if(SqlWhereTableComparisonOperator.isNull.equals(item.getComparisonOperator())
	            							|| SqlWhereTableComparisonOperator.isNotNull.equals(item.getComparisonOperator())){
	            						itemCond.setLogicalOperator(SqlWhereTableLogicalOperator.and);
	            					}else{
	            						itemCond.setLogicalOperator(SqlWhereTableLogicalOperator.or);
	            					}

	            				}else{
	            					itemCond.setLogicalOperator(subLogicalOperator);
	            				}


	            			}
	//            			「item->operationのselectがtrue」の場合、「item->cols->colのListNo」の順に[NULLを回避する関数]を使い「TableID.ItemID」をセットする
	    				}
                		if (tableItem.getOperations()!=null && tableItem.getOperations().isSelect() && subWheresMap.size() > 0) {
                			String subWheres = createNVLOrIsNullInWhere(mTableId,tableItem,item);
							if (subWheres.replaceAll(" ", "").toLowerCase().startsWith("where")) {
								subWheres = subWheres.replaceFirst("where", "");
							}
							wheres.append(" (");
							wheres.append(subWheres);
							wheres.append(") ");
							wheres.append(item.getLogicalOperator().getLogicalOperator());
						} else if (subWheresMap.size() > 0) {
							String subWheres = createSelectWheresClause(subWheresMap);
							if (subWheres.replaceAll(" ", "").toLowerCase().startsWith("where")) {
								subWheres = subWheres.replaceFirst("where", "");
							}
							wheres.append(" (");
							wheres.append(subWheres);
							wheres.append(") ");
							wheres.append(item.getLogicalOperator().getLogicalOperator());
						}
                	}else{
                		item.setTableId(mTableId);
    					subWheresMap.put(new Integer(0), item);
    					String subWheres = createSelectWheresClause(subWheresMap);
    					if(subWheres.replaceAll(" ", "").toLowerCase().startsWith("where")){
        					subWheres = subWheres.replaceFirst("where", "");
        				}
    					wheres.append(subWheres);
                	}
                }

            }
            if(wheres.toString().equals("")){
            	return " ";
            }

            return " where ".concat(wheres.toString());
        }
	}
    
    /**
     * @param condition
     * @return
     */
    private String createFromClause(final SelectSqlCondition condition) {
    	TableIdDefinition tableiddefinition = new TableIdDefinition(condition.getTableId());
    	if (StringUtils.isNotBlank(condition.getType())) {//is multi table
    		String mTableId = getTableMasterId(condition.getJoinsMap());

    		if(condition.getJoinsMap() == null || condition.getJoinsMap().size() == 0){
    			mTableId = condition.getTablesMap().keySet().iterator().next();
    		}

    		tableiddefinition = new TableIdDefinition(mTableId);
    	}
    	return String.format("`%s`.`%s`", tableiddefinition.getSchem(), tableiddefinition.getTable());
	}
    
    /**
     * @param relationsMap
     * @return
     */
    private String createJoinsClause(final SortedMap<String, ApplicationRelationDTO> relationsMap){
    	String join = " ";
    	if(relationsMap == null || relationsMap.size() == 0) return join;
    	String rootTableId = null;
    	List<String> tablesJoinedList = new ArrayList<String>();

		for (Iterator<ApplicationRelationDTO> iterator = relationsMap.values().iterator(); iterator.hasNext();) {
			ApplicationRelationDTO relation = (ApplicationRelationDTO) iterator.next();
			getLogger().info(relation.getRelationLabel());
			String type = relation.getRelationType().toLowerCase().replaceAll(" ", "");
			String mMasterId = "";
			String mDetailId = "";
			for (Iterator<TableDTO> tableIterator = relation.getTables().iterator(); tableIterator.hasNext();) {
				TableDTO relationTable = (TableDTO) tableIterator.next();
				TableIdDefinition tableIdDefinition = new TableIdDefinition(relationTable.getTableid());
				String tableId = String.format("`%s`.`%s`", tableIdDefinition.getSchem(),
						tableIdDefinition.getTable());
				if (relationTable.getType().equals(AppConst.RELATION_TABLE_MASTER)) {
					mMasterId = tableId;
				} else {
					mDetailId = tableId;
				}
			}

			// Set first mMasterId of table in relations is FROM
			if(rootTableId == null){
				rootTableId = mMasterId;
				tablesJoinedList.add(rootTableId);
			}

			if(rootTableId != mMasterId){
				if(!tablesJoinedList.contains(mMasterId)){
					join += " " + SqlJoinTableLogicalOperator.valueOf(type).getLogicalOperator() + " " + mMasterId;
					tablesJoinedList.add(mMasterId);
				}
			}
			if(rootTableId != mDetailId){
				if(!tablesJoinedList.contains(mDetailId)){
					join += " " + SqlJoinTableLogicalOperator.valueOf(type).getLogicalOperator() + " " + mDetailId;
					tablesJoinedList.add(mDetailId);
				}
			}

			join += " " + SqlJoinTableLogicalOperator.on.getLogicalOperator() + " ";
			String cond = " ";
			for (Iterator<ItemDTO> itemIterator = relation.getItems().iterator(); itemIterator.hasNext();) {
				ItemDTO relationItem = (ItemDTO) itemIterator.next();
				join += cond;
				join += mDetailId + "." + String.format("`%s`", relationItem.getDetail()) + " = " + mMasterId
						+ "." + String.format("`%s`", relationItem.getMaster());
				cond = " " + SqlWhereTableLogicalOperator.and.getLogicalOperator() + " ";
			}
		}
    	join = join.replace("  ", " ");
    	return join;
    }
    
    /**
     * @param relationsMap
     * @return
     */
    private String getTableMasterId(SortedMap<String, ApplicationRelationDTO> relationsMap){
    	if(relationsMap != null && relationsMap.size() > 0){
    		for (Iterator<ApplicationRelationDTO> iterator = relationsMap.values().iterator(); iterator.hasNext();) {
    			ApplicationRelationDTO relation = (ApplicationRelationDTO) iterator.next();
				for (Iterator<TableDTO> tableIterator = relation.getTables().iterator(); tableIterator.hasNext();) {
					TableDTO relationTable = (TableDTO) tableIterator.next();
					if(relationTable.getType().equals(AppConst.RELATION_TABLE_MASTER)){
						return relationTable.getTableid();
					}

				}
			}
    	}
    	return "";
    }
    
    /**
     * @param type
     * @param mTableId
     * @param valuesMap
     * @param columnsMap
     * @return
     */
//    private String createSelectClause(final String type, final String mTableId,
//			final Map<String, String> valuesMap,
//			final Map<String, TableItemDTO> columnsMap) {
//		if(!isMultiTable(type)){
//			final StringBuffer columns = new StringBuffer();
//			for (final Iterator<String> ite = valuesMap.keySet().iterator(); ite.hasNext();) {
//				final String name = String.format("`%s`", ite.next());
//				if (columns.length() <= 0) {
//					columns.append(name);
//				} else {
//					columns.append(", ");
//					columns.append(name);
//				}
//			}
//			return columns.toString();
//		}else{
//			return createSelectClauseForMultiTable(mTableId, columnsMap);
//		}
//	}
    
    /**
     * @param mTableId
     * @param columnsMap
     * @return
     */
//    private String createSelectClauseForMultiTable(final String mTableId, final Map<String, TableItemDTO> columnsMap) {
//		if (columnsMap == null || columnsMap.size() <= 0)
//			return "";
//		final StringBuffer columns = new StringBuffer();
//		for (final Iterator<TableItemDTO> ite = columnsMap.values().iterator(); ite.hasNext();) {
//			TableItemDTO tableItem = ite.next();
//			if (tableItem.isRoot()) {
//				// 「item->operationのselectがfalse」の場合、「item->cols->colのListNoが1」の「TableID.ItemID」をセットする
//				if (tableItem.getOperations() != null && !tableItem.getOperations().isSelect()) {
//					if (tableItem.getCols() != null && tableItem.getCols().size() > 0) {
//						for (Iterator<String> iterator = tableItem.getCols().keySet().iterator(); iterator.hasNext();) {
//							String listNo = (String) iterator.next();
//							ColDto colDto = tableItem.getCols().get(listNo);
//							String name = formatColumnMultiTable(colDto.getTableID(), colDto.getItemID());
//							name += " AS " + tableItem.getItemId();
//							if (columns.length() <= 0) {
//								columns.append(name);
//							} else {
//								columns.append(", ");
//								columns.append(name);
//							}
//							break;
//						}
//					} else {
//						final String name = formatColumnMultiTable(tableItem.getTableId(), tableItem.getItemId());
//						if (columns.length() <= 0) {
//							columns.append(name);
//						} else {
//							columns.append(", ");
//							columns.append(name);
//						}
//					}
//				}
//				// 「item->operationのselectがtrue」の場合、「item->cols->colのListNo」の順に[NULLを回避する関数]を使い「TableID.ItemID」をセットする
//				if (tableItem.getOperations() != null && tableItem.getOperations().isSelect()) {
//					List<String> colList = new ArrayList<String>();
//					if (tableItem.getCols() != null && tableItem.getCols().size() > 0) {
//						for (Iterator<String> iterator = tableItem.getCols().keySet().iterator(); iterator.hasNext();) {
//							String listNo = (String) iterator.next();
//							ColDto colDto = tableItem.getCols().get(listNo);
//							final String name = formatColumnMultiTable(colDto.getTableID(), colDto.getItemID());
//							colList.add(name);
//						}
//
//						if (colList.size() > 0) {
//							String name = ignoreNullColumns(colList);
//							if (null != name && !"".equals(name)) {
//								name += " AS " + tableItem.getItemId();
//								if (columns.length() <= 0) {
//									columns.append(name);
//								} else {
//									columns.append(", ");
//									columns.append(name);
//								}
//							}
//						}
//					} else {
//						final String name = formatColumnMultiTable(mTableId, tableItem.getItemId());
//						if (columns.length() <= 0) {
//							columns.append(name);
//						} else {
//							columns.append(", ");
//							columns.append(name);
//						}
//					}
//
//				}
//			}
//		}
//		return columns.toString();
//	}
    
    /**
     * @param type
     * @param tableId
     * @param columnsMap
     * @param ordersMap
     * @param isOrderAsc
     * @return
     */
//    private String createOrdersClause(final String type, final String tableId,
//			final Map<String, TableItemDTO> columnsMap, final SortedMap<Integer, String> ordersMap,
//			final Boolean isOrderAsc) {
//		if (!isMultiTable(type)) {
//			return createOrdersClause(ordersMap, isOrderAsc);
//		} else {
//			return createOrdersClauseForMultiTable(tableId, columnsMap, ordersMap, isOrderAsc);
//		}
//	}
    
    /**
     * @param tableId
     * @param columnsMap
     * @param ordersMap
     * @param isOrderAsc
     * @return
     */
//    private String createOrdersClauseForMultiTable(final String tableId, final Map<String, TableItemDTO> columnsMap,
//			final SortedMap<Integer, String> ordersMap, final Boolean isOrderAsc) {
//		if (ordersMap.size() <= 0)
//			return "";
//		final StringBuffer orders = new StringBuffer();
//		for (final Iterator<String> ite = ordersMap.values().iterator(); ite.hasNext();) {
//			String columnId = ite.next();
//			if (columnsMap.containsKey(columnId) && columnsMap.get(columnId).getCols() != null
//					&& columnsMap.get(columnId).getCols().size() > 0) {
//				TableItemDTO tableItem = columnsMap.get(columnId);
//				if (tableItem.getCols() != null && tableItem.getCols().size() > 0) {
//					List<String> colList = new ArrayList<String>();
//					for (Iterator<String> iterator = tableItem.getCols().keySet().iterator(); iterator.hasNext();) {
//						String listNo = (String) iterator.next();
//						ColDto colDto = tableItem.getCols().get(listNo);
//						final String name = formatColumnMultiTable(colDto.getTableID(), colDto.getItemID());
//						colList.add(name);
//					}
//					if (colList.size() > 0) {
//						final String name = ignoreNullColumns(colList);
//						if (orders.length() <= 0) {
//							orders.append(name);
//						} else {
//							orders.append(", ");
//							orders.append(name);
//						}
//						orders.append((isOrderAsc ? " asc" : " desc"));
//					}
//				}
//			} else {
//				final String name = formatColumnMultiTable(tableId, columnId);
//				if (orders.length() <= 0) {
//					orders.append(name);
//				} else {
//					orders.append(",");
//					orders.append(name);
//				}
//				orders.append((isOrderAsc ? " asc" : " desc"));
//			}
//		}
//		return " order by " + orders.toString();
//	}
    
    /**
     * @param tableId
     * @param itemId
     * @return
     */
//    private String formatColumnMultiTable(String tableId, String itemId){
//    	TableIdDefinition tableIdDefinition = new TableIdDefinition(tableId);
//    	return String.format("`%s`.`%s`.`%s`",tableIdDefinition.getSchem(), tableIdDefinition.getTable(), itemId);
//    }

}
