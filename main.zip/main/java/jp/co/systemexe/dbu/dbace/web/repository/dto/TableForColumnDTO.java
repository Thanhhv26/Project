/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import lombok.Data;
@Data
public class TableForColumnDTO {
	// テーブル１
	String table1;
	// テーブル２
	String table2;
}
