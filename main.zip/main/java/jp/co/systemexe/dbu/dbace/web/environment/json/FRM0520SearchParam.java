/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.environment.json;

import jp.co.systemexe.dbu.dbace.web.environment.dto.EnvironmentDto;
import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 jan 18, 2017
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0520SearchParam {
	private EnvironmentDto searchData;
}
