/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.presentation;

/**
 * リスト要素用 ID 選択インターフェース。
 * <p>
 * HTML select 要素の保持値定義用インターフェース。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public interface IdSelectable {

    /**
     * id 値を戻す。
     * 
     * @return String
     */
    public abstract String getId();

    /**
     * 表示値を戻す。
     * 
     * @return String
     */
    public abstract String getLabel();

}
