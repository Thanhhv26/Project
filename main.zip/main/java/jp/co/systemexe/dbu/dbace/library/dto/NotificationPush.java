/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.dto;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jp.co.systemexe.dbu.dbace.common.util.DateUtils;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class NotificationPush extends BaseDto {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private Timestamp time;
	private String message;

	public enum NotificationType {
		None,
		Success,
		Info,
		Warning,
		Error,
		Wait,
	}
	@JsonIgnore
	private NotificationType messageType = NotificationType.None;
	public int getType() {
		int type = 0;
		if (this.getMessageType() != null) {
			type = this.getMessageType().ordinal();
		}
		return type;
	}

	public NotificationPush(String message) {
		this(NotificationType.None, message);
	}
	public NotificationPush(NotificationType msgType, String message) {
		this.setMessageType(msgType == null ? NotificationType.None : msgType);
		this.setMessage(message);
		this.setTime(DateUtils.getCurrentTimestamp());
	}
}
