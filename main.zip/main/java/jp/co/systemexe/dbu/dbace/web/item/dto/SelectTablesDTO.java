/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.dto;
import lombok.Data;
@Data
public class SelectTablesDTO {
	String connectDefinitionId;
	// テーブル名の選択一覧
	String tableId;
	String tableLabel;
}
