/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.audit.model;

import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.web.audit.dto.AuditCategoryItem;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author van-thanh
 */

@Data
public class FRM0530ResultModel {
	
    AuditSettingDTO beforeAuditSettingDTO;
    AuditCategoryItem[] auditCategoryItems;
    List<SelectOneMenuItem> auditLogFileUnitItems;
    String auditLogFileSize;
    String auditLogFileUnit;
    String auditLogFileRotation;
    String auditLogFileOutput;    
    
    List<MessageInfo> messageInfoList;
	
}
