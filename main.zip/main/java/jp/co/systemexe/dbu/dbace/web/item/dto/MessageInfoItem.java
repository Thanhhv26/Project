/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.dto;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author van-thanh
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class MessageInfoItem {
	//class
	private static final String  warningCls = "alert alert-warning fade in alert-dismissable error ";
	private static final String  errorCls = "fontError error alert alert-danger ";
	private static final String  successCls = "alert alert-success fade in alert-dismissable ";
	private static final String  infoCls = "alert alert-info fade in alert-dismissable error ";
	//icon
	private static final String  warningIcon = "glyphicon glyphicon-warning-sign ";
	private static final String  errorIcon = "glyphicon glyphicon-remove-sign ";
	private static final String  successIcon = "glyphicon glyphicon-ok ";
	private static final String  infoIcon = "glyphicon glyphicon-info-sign ";
	//class error input, select, ...
	private final String  clsError = "cls-errors ";

	public enum MessageType{
		WARNING,
		ERROR,
		SUCCESS,
		INFO
	}

	/** Logger. **/
	//protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	private String id;
	private String errorCode;
	private String errorString;
	private String addClass;
	private String removeClass;
	private String icon;
	private String idError;
	private String messageType;


	public MessageInfoItem(){

	}

	public MessageInfoItem(final String _errorString, final MessageType _errorType){
		this.setErrorCode("");
		this.setErrorString(_errorString);
		this.setRemoveClass(warningCls + errorCls + successCls + infoCls);
		if(_errorType != null){
			setClassAndIconByType(_errorType);
		}
	}

	public MessageInfoItem(final String _errorCode, final MessageType _errorType, MessageService messageService){
		this.setErrorString(messageService.getMessage(_errorCode));
		//this.setErrorCode(_errorCode + "=");
		this.setRemoveClass(warningCls + errorCls + successCls + infoCls);
		if(_errorType != null){
			setClassAndIconByType(_errorType);
		}
	}

	public MessageInfoItem(final String _errorCode, final MessageType _errorType, final String[] args, MessageService messageService){
		String msg = MessageUtils.getMessageNotMessageId(_errorCode, getMessageByListCode(args, messageService));
		this.setErrorString(msg);
		//this.setErrorCode(_errorCode + "=");
		this.setRemoveClass(warningCls + errorCls + successCls + infoCls);
		if(_errorType != null){
			setClassAndIconByType(_errorType);
		}
	}

	public MessageInfoItem(final String _errorCode, final MessageType _errorType, final String _controlCode, MessageService messageService){
		String control = messageService.getMessage(_controlCode);
		String msg = messageService.getMessage(_errorCode);
		this.setErrorString(control + msg);
		//this.setErrorCode(_errorCode + "=");
		this.setRemoveClass(warningCls + errorCls + successCls + infoCls);
		if(_errorType != null){
			setClassAndIconByType(_errorType);
		}
	}

	public MessageInfoItem(final String _id,final String _errorCode, final MessageType _errorType, MessageService messageService, final String... args){
		//String control = messageService.getMessage(_controlCode);
		String msg = messageService.getMessage(_errorCode, args);
		this.setId(_id);
		this.setErrorString(msg);
		//this.setErrorCode(_errorCode + "=");
		this.setRemoveClass(warningCls + errorCls + successCls + infoCls);
		if(_errorType != null){
			setClassAndIconByType(_errorType);
		}
	}

	public MessageInfoItem(final String _id,final String _errorCode, final MessageType _errorType, MessageService messageService){
		//String control = messageService.getMessage(_controlCode);
		String msg = messageService.getMessage(_errorCode);
		this.setId(_id);
		this.setErrorString(msg);
		//this.setErrorCode(_errorCode + "=");
		this.setRemoveClass(warningCls + errorCls + successCls + infoCls);
		if(_errorType != null){
			setClassAndIconByType(_errorType);
		}
	}

	public MessageInfoItem(final ApplicationException e, final MessageType _errorType) {
        //getLogger().error(e.getLocalizedMessage(), e);
        //this.setErrorCode("message.UidNotFound=");
        this.setErrorString(e.getLocalizedMessage());
        this.setRemoveClass(warningCls + errorCls + successCls + infoCls);
        if(_errorType != null){
        	setClassAndIconByType(_errorType);
		}
    }

	public MessageInfoItem(final Exception e, final MessageType _errorType) {
        //getLogger().error(e.getLocalizedMessage(), e);
        //this.setErrorCode("message.UidNotFound=");
        this.setErrorString(e.getLocalizedMessage());
        this.setRemoveClass(warningCls + errorCls + successCls + infoCls);
        if(_errorType != null){
        	setClassAndIconByType(_errorType);
		}
    }

	private void setClassAndIconByType(MessageType type){
		switch(type){
			case WARNING:
				this.setAddClass(warningCls);
				this.setIcon(warningIcon);
				this.setMessageType(String.valueOf(type));
				break;
			case ERROR:
				this.setAddClass(errorCls);
				this.setIcon(errorIcon);
				this.setMessageType(String.valueOf(type));
				break;
			case SUCCESS:
				this.setAddClass(successCls);
				this.setIcon(successIcon);
				this.setMessageType(String.valueOf(type));
				break;
			case INFO:
				this.setAddClass(infoCls);
				this.setIcon(infoIcon);
				this.setMessageType(String.valueOf(type));
				break;
		}
	}

	private String[] getMessageByListCode(final String[] args, MessageService messageService){
		String temp = "";
		if(args != null && args.length > 0){
			for(int i = 0; i < args.length; i++){
				if(temp.length() > 0){
					temp += messageService.getMessage("msg.semicolons");
					temp += messageService.getMessage(args[i]);
				}else{
					temp += messageService.getMessage(args[i]);
				}
			}
		}
		return new String[]{temp};
	}

}
