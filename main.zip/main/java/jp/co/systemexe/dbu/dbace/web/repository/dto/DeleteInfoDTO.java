/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;

import java.util.List;

import lombok.Data;

/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class DeleteInfoDTO {
	private SelectTablesRegister selectTablesRegister;
	private List<RelationScreenForDeleteDTO> relationScreens;
}