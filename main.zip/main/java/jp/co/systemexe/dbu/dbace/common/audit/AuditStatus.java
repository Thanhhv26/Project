/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.audit;

/**
 * 監査が成功したか否か 列挙体。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum AuditStatus {
    /**
     * 成功
     */
    success("SUCCESS"),
    /**
     * 失敗
     */
    failure("FAILURE");

    private String auditStatusName;
    public String getAuditStatusName() {
        return auditStatusName;
    }
    
    private AuditStatus(final String auditStatusName) {
        this.auditStatusName = auditStatusName;
    }
}
