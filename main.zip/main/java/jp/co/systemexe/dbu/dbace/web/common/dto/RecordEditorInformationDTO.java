/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.web.common.dto;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;

/**
 * レコード更新用のリポジトリ情報を保持するDTOです。
 * <p>
 * 以下の情報を保持します。<br />
 * テーブルのデータベース内定義情報(TableDefinitionDTO)<br />
 * テーブル個々に対応した画面設定（テーブルフォーム）情報(TableFormDTO)<br />
 * DB 接続情報(DbConnectInfomationDTO)
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class RecordEditorInformationDTO implements Serializable {
	/**
	 * <code>serialVersionUID</code> のコメント。
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	private ApplicationRelationDTO relation;

    /**
     * テーブルのデータベース内定義情報
     */
    private TableDefinitionDTO tableDef;

    /**
     * テーブル個々に対応した画面設定（テーブルフォーム）情報
     */
    private TableFormDTO tableForm;

    /**
     * DB 接続情報
     */
    private DbConnectInfomationDTO dbConnectInfomationDTO;

    /**
     * dbConnectInfomationDTO を戻します。
     *
     * @return DbConnectInfomationDTO
     */
    public DbConnectInfomationDTO getDbConnectInfomationDTO() {
        return dbConnectInfomationDTO;
    }

    /**
     * dbConnectInfomationDTO を設定します。
     *
     * @param DbConnectInfomationDTO dbConnectInfomationDTO
     */
    public void setDbConnectInfomationDTO(
            DbConnectInfomationDTO dbConnectInfomationDTO) {
        this.dbConnectInfomationDTO = dbConnectInfomationDTO;
    }

    /**
     * tableDef を戻します。
     *
     * @return TableDefinitionDTO
     */
    public TableDefinitionDTO getTableDef() {
        return tableDef;
    }

    /**
     * tableDef を設定します。
     *
     * @param TableDefinitionDTO tableDef
     */
    public void setTableDef(TableDefinitionDTO tableDef) {
        this.tableDef = tableDef;
    }

    /**
     * tableForm を戻します。
     *
     * @return TableFormDTO
     */
    public TableFormDTO getTableForm() {
        return tableForm;
    }

    /**
     * tableForm を設定します。
     *
     * @param TableFormDTO tableForm
     */
    public void setTableForm(TableFormDTO tableForm) {
        this.tableForm = tableForm;
    }

	/**
	 * @return the relation
	 */
	public ApplicationRelationDTO getRelation() {
		return relation;
	}

	/**
	 * @param relation the relation to set
	 */
	public void setRelation(ApplicationRelationDTO relation) {
		this.relation = relation;
	}
}
