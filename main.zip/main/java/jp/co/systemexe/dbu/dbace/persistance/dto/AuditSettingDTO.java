/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 監査ログ設定情報を保持する DTO クラスです。
 * <p>
 * 監査ログ設定情報を保持する DTO です。
 * </p>
 * <p>
 * 監査カテゴリ、ファイルローテーションサイズ、ファイルローテーションサイズ単位、監査ログ出力先を保持します。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class AuditSettingDTO implements Serializable {

	/**
     * serialVersionUID。
     */
    private static final long serialVersionUID = 1L;

    /**
     * 監査カテゴリ
     */
    private Map<Integer, String> categoryMap = new LinkedHashMap<Integer, String>();

    /**
     * ファイルローテーションサイズ
     */
    private long fileSize;

    /**
     * ファイルローテーションサイズ単位
     */
    private int fileRotation;

    /**
     * ファイルローテーションサイズ単位
     */
    private String fileUnit;

    /**
     * 監査ログ出力先
     */
    private String filePath;

    /**
     * filePath を戻します。
     *
     * @return String
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * filePath を設定します。
     *
     * @param String filePath
     */
    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    /**
     * fileRotation を戻します。
     *
     * @return int
     */
    public int getFileRotation() {
        return fileRotation;
    }

    /**
     * fileRotation を設定します。
     *
     * @param int fileRotation
     */
    public void setFileRotation(int fileRotation) {
        this.fileRotation = fileRotation;
    }

    /**
     * fileSize を戻します。
     *
     * @return long
     */
    public long getFileSize() {
        return fileSize;
    }

    /**
     * fileSize を設定します。
     *
     * @param long fileSize
     */
    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    /**
     * fileUnit を戻します。
     *
     * @return String
     */
    public String getFileUnit() {
        return fileUnit;
    }

    /**
     * fileUnit を設定します。
     *
     * @param String fileUnit
     */
    public void setFileUnit(String fileUnit) {
        this.fileUnit = fileUnit;
    }

    /**
     * categoryMap を戻します。
     *
     * @return Map<Integer,String>
     */
    public Map<Integer, String> getCategoryMap() {
        return categoryMap;
    }
}
