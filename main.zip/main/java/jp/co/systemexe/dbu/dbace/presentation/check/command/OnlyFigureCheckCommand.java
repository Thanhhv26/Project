/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;

/**
 * 数字及び＋/－符号のみ入力チェック。
 * <p>
 * データベース内で、対象カラムが数値系フィールドだった場合に必ず働く入力値検査
 * です。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class OnlyFigureCheckCommand extends BaseLogicalCheckCommand {

    /**
     * 対象データ型・警告メッセージ用キャプション定義マップ。
     */
    private final static Map<JDBCMetaDataType, String> targetMap;
    static {
        targetMap = new HashMap<JDBCMetaDataType, String>();
        targetMap.put(JDBCMetaDataType.TINYINT, "TINYINT ");
        targetMap.put(JDBCMetaDataType.SMALLINT, "SMALLINT ");
        targetMap.put(JDBCMetaDataType.INTEGER, "整数");
        targetMap.put(JDBCMetaDataType.BIGINT, "長整数");
        targetMap.put(JDBCMetaDataType.FLOAT, "倍精度浮動小数点");
        targetMap.put(JDBCMetaDataType.REAL, "単精度浮動小数点");
        targetMap.put(JDBCMetaDataType.DOUBLE, "倍精度浮動小数点");
        targetMap.put(JDBCMetaDataType.NUMERIC, "固定精度10進数");
        targetMap.put(JDBCMetaDataType.DECIMAL, "固定精度10進数");
    }

    /**
     * 「数字と＋/－符号のみ」の定義正規表現文字列。
     * <p></p>
     */
    private static final String REGEX = "[^0-9０-９\\+\\-＋－.．]+";

    /**
     * OnlyFigureCheckCommand の生成。
     * <p>コンストラクタ。</p>
     */
    public OnlyFigureCheckCommand() {
        return;
    }

    /**
     * 検査を実行します。
     * <p>
     * 大文字・小文字・全角・半角を問わず数字及び＋/－符号、及び小数点以外の文字
     * を検出した場合、警告を設定した上で、対象文字を除外した補正値を設定します。
     * </p><p>
     * null または空文字だった場合は検査を行いません。</p>
     *
     * @param columnId カラム名
     * @param messages 論理チェック結果メッセージ保持 DTO
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#check(java.lang.String, jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO)
     */
    @Override
    public void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
    		final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap) {
        final String value = messages.getCorrectedValue(columnId);
        if (value == null || value.equals("")) {
            return;
        }
        if (value.matches(REGEX)) {
            final DefinitionOfColumn def = getDisplayDef()
                .getDefinitionOfColumns().get(columnId);
            // MI-E-0070={0}(数値型)に＋－記号及びに、小数点以外の文字が入力されました。
            String columnLabel = tableItemMap.get(columnId).getItemLabel();
            final String args[]={columnLabel};
            messages.getMessages(columnId).add(MessageUtils.getMessage("MI-E-0070",args));
            messages.setCorrectedValue(columnId, value.replaceAll(REGEX, ""));
        }

    }

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * このクラスが検査対象とする条件は、DB 内のデータ型が以下のいずれかの型で
     * ある事です。
     * <ol>
     *  <li>TINYINT</li>
     *  <li>SMALLINT</li>
     *  <li>INTEGER</li>
     *  <li>BIGINT</li>
     *  <li>FLOAT</li>
     *  <li>REAL</li>
     *  <li>DOUBLE</li>
     *  <li>NUMERIC</li>
     *  <li>DECIMAL</li>
     * </ol>
     * </p>
     *
     * @param columnId カラム ID（＝カラム名）
     * @return true : 検査担当 / false : 担当ではない
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#isMyTask(java.lang.String)
     */
    @Override
    protected boolean isMyTask(final String columnId) {
        final DefinitionOfColumn def = getDisplayDef().getDefinitionOfColumns()
            .get(columnId);
        if (targetMap.containsKey(def.getJDBCMetaDataType())) {
            return true;
        } else {
            return false;
        }
    }
}
