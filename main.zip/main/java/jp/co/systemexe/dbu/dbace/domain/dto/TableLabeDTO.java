/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

/**
 * テーブル名 DTO。
 * <p>
 * テーブルID、テーブル名を保持する DTO です。
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class TableLabeDTO {
    /**
     * テーブルID
     */
    private String id;
    
    /**
     * テーブル名
     */
    private String label;
    
    private String type;

    /**
     * id を戻します。
     * 
     * @return String
     */
    public String getId() {
        return id;
    }

    /**
     * id を設定します。
     *
     * @param String id 
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * label を戻します。
     * 
     * @return String
     */
    public String getLabel() {
        return label;
    }

    /**
     * label を設定します。
     *
     * @param String label 
     */
    public void setLabel(String label) {
        this.label = label;
    }

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
