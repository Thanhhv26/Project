/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
public class ItemDTO {

    private String master;
    private String masterLabel;

    private String detail;
    private String detailLabel;

	/**
	 * master を戻します。
	 *
	 * @return String
	 */
	public String getMaster() {
		return master;
	}

	/**
	 * master を設定します。
	 *
	 * @param String master
	 */
	public void setMaster(String master) {
		this.master = master;
	}

	/**
	 * detail を戻します。
	 *
	 * @return String
	 */
	public String getDetail() {
		return detail;
	}

	/**
	 * detail を設定します。
	 *
	 * @param String detail
	 */
	public void setDetail(String detail) {
		this.detail = detail;
	}

	/**
	 * @return the masterLabel
	 */
	public String getMasterLabel() {
		return masterLabel;
	}

	/**
	 * @param masterLabel the masterLabel to set
	 */
	public void setMasterLabel(String masterLabel) {
		this.masterLabel = masterLabel;
	}

	/**
	 * @return the detailLabel
	 */
	public String getDetailLabel() {
		return detailLabel;
	}

	/**
	 * @param detailLabel the detailLabel to set
	 */
	public void setDetailLabel(String detailLabel) {
		this.detailLabel = detailLabel;
	}

}
