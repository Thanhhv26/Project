/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectManyCheckboxItem;


/**
 * 一般ユーザー操作権限チェックボックスアイテム。
 * <p>
 * いわゆる １チェックボックス に対応する DTO です。</p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 島田 雄一郎
 * @version 0.0.0
 */
public class OperationAuthoritysItem implements SelectManyCheckboxItem, Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * 操作権限表示名を保持します。
     * <p>
     * 一般ユーザーの操作権限チェックボックスに使用される表示プロパティです。</p>
     */
    private String label;
    
    /**
     * 操作権限 ID を保持します。
     * <p>
     * 一般ユーザーの操作権限チェックボックスの id 識別にて使用される、
     *  ID プロパティです。</p>
     */
    private String value;

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getLabel()
     */
    public String getLabel() {
        return label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getValue()
     */
    public String getValue() {
        return value;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setLabel(java.lang.String)
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setValue(int)
     */
    public void setValue(String value) {
        this.value = value;
    }
}
