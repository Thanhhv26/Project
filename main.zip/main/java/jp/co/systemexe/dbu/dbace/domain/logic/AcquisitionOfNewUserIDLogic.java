/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 新規ユーザーID を生成するクラス。
 * <p>一意のIDを生成します。</p>
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class AcquisitionOfNewUserIDLogic {

    /**
     * 新しいユーザ ID を生成して戻します。
     * 
     * @return 接続定義 ID
     */
    public String generateUserId() {
        final SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmssZ");
        return sdf.format(new Date());
    }
    
    /**
     * AcquisitionOfNewUserIDLogic.java の生成。
     * <p>コンストラクタ。</p>
     * 
     */
    public AcquisitionOfNewUserIDLogic() {
        super();
    }

}
