/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.definition.RelationOfJdbcAndHtml;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;

/**
 * リポジトリとデータベースのカラムが変更されているか否かを返します。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic
	extends BaseApplicationDomainLogic {

    /**
     * リポジトリとデータベースのカラムが変更されているか否かを返します。
     *
     * @param connectDefinision 接続定義ID
     * @param tableIdList リポジトリとデータベースのカラムが変更されているかチェックするテーブルIDのリスト
     * @param userId ログインユーザID
     * @return 変更されている場合はtrue、変更されていない場合はfalse
     */
	public Map<String, Boolean> isDifferenceMap(
			final String connectDefinisionId,
			final List<String> tableIdList,
			final String userId)
			throws ApplicationDomainLogicException {
        final RetrievalProcessingOfRecordFromDatabaseLogic logic
        	= new RetrievalProcessingOfRecordFromDatabaseLogic();
		final Map<String, RecordEditorInformationDTO> map
			 = logic.getRecordEditorInformationMap(
					 connectDefinisionId,
					 tableIdList,
					 userId);

		final Map<String, Boolean> ret
			= new HashMap<String, Boolean>();

		for (final String tableId : tableIdList) {
			final RecordEditorInformationDTO dto
				= map.get(tableId);
			ret.put(
				tableId,
				isDifference(
					dto.getTableForm().getTableItemMap(),
					dto.getTableDef().getDefinitionOfColumnMap()));
		}

		return ret;
	}

    /**
     * リポジトリとデータベースのカラムが変更されているか否かを返します。
     *
     * @param dto
     * @return 変更されている場合はtrue、変更されていない場合はfalse
     */
	public boolean isDifference(
			final String connectDefinisionId,
			final String tableId,
			final String userId)
			throws ApplicationDomainLogicException {
        final RetrievalProcessingOfRecordFromDatabaseLogic logic
        	= new RetrievalProcessingOfRecordFromDatabaseLogic();
		final RecordEditorInformationDTO dto
			 = logic.getRecordEditorInformation(
					 connectDefinisionId,
					 tableId,
					 userId);
		return isDifference(
				dto.getTableForm().getTableItemMap(),
				dto.getTableDef().getDefinitionOfColumnMap());
	}

    /**
     * リポジトリとデータベースのカラムが変更されているか否かを返します。
     *
     * @param dto
     * @return 変更されている場合はtrue、変更されていない場合はfalse
     */
	public boolean isDifference(final ColumnDisplayDefinitionDTO dto) {
        return isDifference(dto.getItemDefinitions(), dto.getDefinitionOfColumns());
	}

    /**
     * リポジトリとデータベースのカラムが変更されているか否かを返します。
     *
     * @param dto
     * @return 変更されている場合はtrue、変更されていない場合はfalse
     * @throws ApplicationDomainLogicException
     */
	public boolean isDifference(String connectDefinisionId, String tableId, final ColumnDisplayDefinitionDTO dto) throws ApplicationDomainLogicException {
        return isDifference(connectDefinisionId, tableId, dto.getItemDefinitions(), dto.getDefinitionOfColumns());
	}

    /**
     * リポジトリとデータベースのカラムが変更されているか否かを返します。
     * <p>
     * 以下の場合に、リポジトリとデータベースのカラムが変更されていると判定します。
     * <ol>
     *   <li>リポジトリとデータベースのカラムの数が違う場合</li>
     *   <li>リポジトリにカラムが存在する、データベースにカラムが存在しない場合</li>
     *   <li>リポジトリにカラムが存在しない、データベースにカラムが存在する場合</li>
     * </ol>
     * </p>
     *
     * @param itemDefinitions
     * @param definitionOfColumns
     * @return 変更されている場合はtrue、変更されていない場合はfalse
     */
	public boolean isDifference(
	        final Map<String, TableItemDTO> itemDefinitions,
	        final Map<String, DefinitionOfColumn> definitionOfColumns) {

        if (itemDefinitions.size() != definitionOfColumns.size()) {
            return true;
        }

        for (final String columnName : itemDefinitions.keySet()) {
            if (definitionOfColumns.get(columnName) == null) {
                return true;
            }
        }

        for (final String columnName : definitionOfColumns.keySet()) {
            if (itemDefinitions.get(columnName) == null) {
                return true;
            }
        }

        for (final String columnName : definitionOfColumns.keySet()) {
			DefinitionOfColumn defCol = definitionOfColumns.get(columnName);
			TableItemDTO itemDTO = itemDefinitions.get(columnName);
			if (isChangeColumnAttribute(itemDTO, defCol)) {
				return true;
			}
		}
        return false;
	}

	/**
     * リポジトリとデータベースのカラムが変更されているか否かを返します。
     * <p>
     * 以下の場合に、リポジトリとデータベースのカラムが変更されていると判定します。
     * <ol>
     *   <li>リポジトリとデータベースのカラムの数が違う場合</li>
     *   <li>リポジトリにカラムが存在する、データベースにカラムが存在しない場合</li>
     *   <li>リポジトリにカラムが存在しない、データベースにカラムが存在する場合</li>
     * </ol>
     * </p>
     *
     * @param itemDefinitions
     * @param definitionOfColumns
     * @return 変更されている場合はtrue、変更されていない場合はfalse
	 * @throws ApplicationDomainLogicException
     */
	public boolean isDifference(final String connectDefinisionId, final String tableId,
	        final Map<String, TableItemDTO> itemDefinitions,
	        final Map<String, DefinitionOfColumn> definitionOfColumns) throws ApplicationDomainLogicException {
		final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();


//        for (final String columnName : definitionOfColumns.keySet()) {
//			DefinitionOfColumn defCol = definitionOfColumns.get(columnName);
////			TableFormDTO tableFormDTO = logic.getTableFormDTO(connectDefinisionId, defCol.getTableId());
//			TableItemDTO itemDTO = itemDefinitions.get(columnName);
//			if(!itemDTO.isRoot()){
//				String columnTypeNameDB = defCol.getColumnTypeName();
//				String dataTypeXML = itemDTO.getDataType();
//				//DBの項目の型変更
//				if (!columnTypeNameDB.equalsIgnoreCase(dataTypeXML)) {
//					return true;
//				}
//				//DBの項目にPK追加
//				boolean isPrimaryKeyDb = defCol.isPrimaryKey();
//				boolean isPrimaryKeyXml = itemDTO.getPrimaryKey();
//				if (isPrimaryKeyDb == true && isPrimaryKeyDb != isPrimaryKeyXml) {
//					return true;
//				}
//			}
//		}
        return false;
	}

	/**
	 * @param itemDTO
	 * @param defCol
	 * @return
	 */
	public boolean isChangeColumnAttribute(final TableItemDTO itemDTO, final DefinitionOfColumn defCol) {
		//DBの項目の型変更
		String columnTypeNameDB = defCol.getColumnTypeName();
		String dataTypeXML = itemDTO.getDataType();
		if (!columnTypeNameDB.equalsIgnoreCase(dataTypeXML)) {
			return true;
		}
		//dataUnit
		String dataUnitDb = defCol.getDataUnit();
		String dataUnitXml = itemDTO.getDataUnit();
		if ((dataUnitDb != null || dataUnitXml != null) && (dataUnitDb != null && !dataUnitDb.equalsIgnoreCase(dataUnitXml))) {
			return true;
		}
		boolean isPrimaryKeyDb = defCol.isPrimaryKey();
		boolean isPrimaryKeyXml = itemDTO.getPrimaryKey();
		//DBの項目にPK追加
		if (isPrimaryKeyDb == true && isPrimaryKeyDb != isPrimaryKeyXml) {
			return true;
		}
		//DBの項目にPK削除
		if (isPrimaryKeyDb == false && isPrimaryKeyXml == true) {
			return true;
		}
		//サイズ
		String dataLengthDb = makeSizeColumnTypeLabel(defCol);
		String dataLength = itemDTO.getDataLength();
		//Oracle , SQL Server
		if ("FLOAT".equals(defCol.getColumnTypeName()) || "float".equals(defCol.getColumnTypeName())) {

		} else if (!dataLengthDb.equals(dataLength)) {
			return true;
		}
		return false;
	}

	 /**
		 * 精度或いは桁数注釈の作成。
		 * <p>
		 * 精度、或いは最大桁数の定義が存在しない場合は空文字を戻します。
		 * </p>
		 *
		 * @param def
		 * @return ret 精度或いは桁数注釈
		 */
		private String makeSizeColumnTypeLabel(final DefinitionOfColumn def) {
			final String ret;
			// アプリケーション非対応
			if (!RelationOfJdbcAndHtml.metaDataTypeOf(def.getJDBCMetaDataType()).isCorrespond()) {
				return "";

				// 数値型
			} else if (isJDBCMetaDataTypeIsNumeric(def.getJDBCMetaDataType())) {
				// ORACLEの場合、NUMBERで桁数指定されていない場合は getPrecision が 0 を返す。
				// そして、10gの場合は getScale が -127 (9iは0)を返す。。。（謎
				if (def.getDefinitionOfNumericalValue().getPrecision() == 0) {
					ret = "(38,0)";
				} else {
					ret = "(" + def.getDefinitionOfNumericalValue().getPrecision() + ","
							+ def.getDefinitionOfNumericalValue().getScale() + ")";
				}

				// 日付型
			} else if (isJDBCMetaDataTypeIsDate(def.getJDBCMetaDataType())) {
				ret = "";
				// 文字列型 or バイナリ型
			} else {
				if (def.getColumnDisplayMaxSize() > 0) {
					ret = "(" + def.getColumnDisplayMaxSize() + ")";
				} else {
					ret = "";
				}
			}
			return ret;
		}

    /**
	 * 引数のJDBCMetaDataTypeが数値型が否かを返します。
	 *
	 * @param type
	 * @return
	 */
	private boolean isJDBCMetaDataTypeIsNumeric(final JDBCMetaDataType type) {
		if (type == JDBCMetaDataType.TINYINT || type == JDBCMetaDataType.SMALLINT || type == JDBCMetaDataType.INTEGER
				|| type == JDBCMetaDataType.BIGINT || type == JDBCMetaDataType.FLOAT || type == JDBCMetaDataType.REAL
				|| type == JDBCMetaDataType.DOUBLE || type == JDBCMetaDataType.NUMERIC
				|| type == JDBCMetaDataType.DECIMAL) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 引数のJDBCMetaDataTypeが日付型が否かを返します。
	 *
	 * @param type
	 * @return
	 */
	private boolean isJDBCMetaDataTypeIsDate(final JDBCMetaDataType type) {
		if (type == JDBCMetaDataType.DATE || type == JDBCMetaDataType.TIME || type == JDBCMetaDataType.TIMESTAMP) {
			return true;
		} else {
			return false;
		}
	}

}
