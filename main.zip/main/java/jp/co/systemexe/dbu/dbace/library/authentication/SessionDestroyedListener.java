/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.authentication;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.session.SessionDestroyedEvent;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import jp.co.systemexe.dbu.dbace.library.service.certification.MyUserDetails;
import jp.co.systemexe.dbu.dbace.library.util.BeanUtils;

@Component
public class SessionDestroyedListener implements ApplicationListener<SessionDestroyedEvent> {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	/*
	 * (Non-Javadoc)
	 *
	 * @see
	 * org.springframework.context.ApplicationListener#onApplicationEvent(org.
	 * springframework.context.ApplicationEvent)
	 */
	@Override
	public void onApplicationEvent(SessionDestroyedEvent event) {
		List<SecurityContext> securityContexts = event.getSecurityContexts();
		if (!CollectionUtils.isEmpty(securityContexts)) {
			for (SecurityContext securityContext : securityContexts) {
				Authentication authentication = securityContext.getAuthentication();
				MyUserDetails user = (authentication != null
						? BeanUtils.safeType(authentication.getPrincipal(), MyUserDetails.class) : null);
				if (user != null) {
					logger.info("BI APPLICATION [Session of user {} destroyed]", user.getUsername());
				}
			}
		}
	}
}
