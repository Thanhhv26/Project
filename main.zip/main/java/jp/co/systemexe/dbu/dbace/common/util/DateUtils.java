/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.util;

import java.io.Serializable;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.util.Assert;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.exception.CheckException;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;

/**
 *
 * To process the date type
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
public class DateUtils implements Serializable {

	public static String DATE_FORMAT = "yyy/MM/dd";
	public static String TIME_ZERO_FORMAT = " 00:00:00";
	public static String TIMESTAMP_ZERO_FORMAT = " 00:00:00.000";
	public static String ZERO_FORMAT = ".000";
	public static final Logger logger = LoggerFactory.getLogger(DateUtils.class.getName());

//	public static Date getCurrentDate() {
//		Calendar cl = Calendar.getInstance();
//		cl.set(Calendar.HOUR_OF_DAY, 0);
//		cl.set(Calendar.MINUTE, 0);
//		cl.set(Calendar.SECOND, 0);
//		cl.set(Calendar.MILLISECOND, 0);
//		return cl.getTime();
//	}

	public static Date parseToDate(String dateString, String pattern) throws ApplicationException {
		DateFormat df = new SimpleDateFormat(pattern);
		Date date;
		try {
			date = df.parse(dateString);
			return date;
		} catch (ParseException e) {
			e.printStackTrace();
			throw new CheckException(e.getMessage(), e);
		}
	}

	/**
	 * Get string format date value refer formatType
	 *
	 * @param dateData string data in resultset
	 * @param formatType
	 * @return String formated date
	 */
	// MOD　DBエースOracle日付対応　↓
	public static String formatDateToString(String dateData, DefinedHtmlElement formatType) {
		String valueDsp = "";
		if(StringUtils.isEmpty(dateData)) {
			return valueDsp;
		} else if(isTimeInputFormat(dateData)) {
			return dateData;
		}
		SimpleDateFormat sdf = null;
		if (DefinedHtmlElement.INPUT_DATE == formatType) {
			sdf = new SimpleDateFormat("yyyy/MM/dd");
		} else if (DefinedHtmlElement.INPUT_DATETIME == formatType) {
			sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		} else if (DefinedHtmlElement.INPUT_TIMESTAMP == formatType) {
			sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
		}
		try {
			if (DefinedHtmlElement.INPUT_TIME == formatType) {
				sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
				Date parsed = sdf.parse(dateData);
				valueDsp = DateFormatUtils.format(parsed.getTime(), "HH:mm:ss");
			} else {
				// DBエースPostgres日付対応　2016/07/27　↓
				if(isDateInputFormat(dateData) && DefinedHtmlElement.INPUT_DATETIME == formatType) {
					dateData = dateData + TIME_ZERO_FORMAT;
				} else if(isDateInputFormat(dateData) && DefinedHtmlElement.INPUT_TIMESTAMP == formatType) {
					dateData = dateData + TIMESTAMP_ZERO_FORMAT;
				}
				// DBエースPostgres日付対応　2016/07/27　↑
				Date parsed = sdf.parse(dateData);
				valueDsp = DateFormatUtils.format(parsed, sdf.toPattern());
			}
		} catch (ParseException e) {
			return dateData;
		}
		return valueDsp;
	}
	// MOD　DBエースOracle日付対応　↑

	/**
	 *
	 * @param value
	 * @return
	 */
	public static boolean isDateInputFormat(String value) {
		if (value.matches("^\\d{4}/\\d{2}/\\d{2}$")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 *
	 * @param value
	 * @return
	 */
	public static boolean isTimeInputFormat(String value) {
		if (value.matches("^\\d{2}:\\d{2}:\\d{2}$") || value.matches("^\\d{2}:\\d{2}:\\d{2}\\.\\d{3}$")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 *
	 * @param value
	 * @return
	 */
	public static boolean isTimeMiliFormat(String value) {
		if (value.matches("^\\d{2}:\\d{2}:\\d{2}\\.\\d{3}$")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

//	/**
//	 * SLF4J
//	 */
//	protected transient static final Logger logger = LoggerFactory.getLogger(DateUtils.class);

	/**
	 * The {@link Calendar} instance for calculating date time
	 */
	private static Calendar CALENDAR = Calendar.getInstance();
	public static String CONST_TIME_STAMP_PATTERN = "yyyy/MM/dd HH:mm";
	public static String CONST_TIME_FORMAT = "yyyy/MM/dd";

	/**
	 * Convert String to Timestamp with format
	 *
	 * @param strDate
	 * @param format
	 * @return
	 */
	public static java.sql.Timestamp toTimestamp(String strDate, String format) {
		if (StringUtils.isEmpty(strDate))
			return null;
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			Date parsedDate = dateFormat.parse(strDate);
			return new java.sql.Timestamp(parsedDate.getTime());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static java.sql.Timestamp toTimestamp(Date dt) {
		Assert.notNull(dt, "The dates parameter must be not null");
		return new Timestamp(dt.getTime());
	}

	public static java.sql.Date toSqlDate(Date dt) {
		Assert.notNull(dt, "The dates parameter must be not null");
		return new java.sql.Date(dt.getTime());
	}

	public static java.sql.Time toSqlTime(Date dt) {
		Assert.notNull(dt, "The dates parameter must be not null");
		return new java.sql.Time(dt.getTime());
	}

	/**
	 * 今年を取得する。
	 *
	 * @return current year
	 */
	public static int getCurrentYear() {
		return get(new Date(), Calendar.YEAR);
	}

	/**
	 * 今年月日を取得する。
	 *
	 * @return
	 */
	public static Timestamp getCurrentTimestamp() {
		return toTimestamp(new Date());
	}

	public static Timestamp getTimestamp(int year, int month, int day) {
		try {
			Calendar calendar = CALENDAR;
			synchronized (calendar) {
				calendar.set(Calendar.YEAR, year);
				calendar.set(Calendar.MONTH, month - 1);
				calendar.set(Calendar.DAY_OF_MONTH, day);
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				return toTimestamp(calendar.getTime());
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	public static Timestamp getTimestamp(int year, int month, int day, int hourOfDay, int minute, int second, int milli) {
		try {
			Calendar calendar = CALENDAR;
			synchronized (calendar) {
				calendar.set(Calendar.YEAR, year);
				calendar.set(Calendar.MONTH, month - 1);
				calendar.set(Calendar.DAY_OF_MONTH, day);
				calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
				calendar.set(Calendar.MINUTE, minute);
				calendar.set(Calendar.SECOND, second);
				calendar.set(Calendar.MILLISECOND, milli);
				return toTimestamp(calendar.getTime());
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	public static java.sql.Date getCurrentDate() {
		return toSqlDate(new Date());
	}

	public static Time getCurrentTime() {
		return toSqlTime(new Date());
	}

	/**
	 * Checks the specified date <code>d</code> whether is equals/greater than the first date <code>d1</code> and
	 * equals/less than the second date <code>d2</code> (d1 <= d <= d2) base on compare kind.<br/>
	 *
	 * @param d
	 *            the {@link Date} to check
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @param what
	 *            specifies compare by what kind:<br/>
	 *            - {@link Calendar#YEAR}: compare base on year<br/>
	 *            - {@link Calendar#MONTH}: compare base on year and month<br/>
	 *            - {@link Calendar#DATE}: compare base on year/month and date<br/>
	 *            - {@link Calendar#HOUR} or {@link Calendar#HOUR_OF_DAY}: compare base on year/month/date and hour<br/>
	 *            - {@link Calendar#MINUTE}: compare base on year/month/date/hour and minute<br/>
	 *            - {@link Calendar#SECOND}: compare base on year/month/date/hour/minute and second<br/>
	 *            - {@link Calendar#MILLISECOND}: compare base on whole date (to miliseconds)
	 * @return
	 * @exception throw
	 *                {@link NullPointerException} if one of two dates is null;<br/>
	 *                throw {@link IllegalArgumentException} if the specified comparision kind <code>what</code> is not
	 *                supported
	 */
	public static boolean between(Date d, Date d1, Date d2, int what) {
		return (0 <= compareTo(d1, d, what) && 0 <= compareTo(d, d2, what));
	}

	/**
	 * Compares two specified date (compare to every milisecond)
	 *
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @param what
	 *            specifies compare by what kind:<br/>
	 *            - {@link Calendar#YEAR}: compare base on year<br/>
	 *            - {@link Calendar#MONTH}: compare base on year and month<br/>
	 *            - {@link Calendar#DATE}: compare base on year/month and date<br/>
	 *            - {@link Calendar#HOUR} or {@link Calendar#HOUR_OF_DAY}: compare base on year/month/date and hour<br/>
	 *            - {@link Calendar#MINUTE}: compare base on year/month/date/hour and minute<br/>
	 *            - {@link Calendar#SECOND}: compare base on year/month/date/hour/minute and second<br/>
	 *            - {@link Calendar#MILLISECOND}: compare base on whole date (to miliseconds)
	 * @return 0 if two date are equals by the comparision kind<br/>
	 *         1 if the second date <code>d2</code> are greater than the first date <code>d1</code> (<code>d2</code>
	 *         &gt; <code>d1</code>) by the comparision kind<br/>
	 *         -1 if the second date <code>d2</code> are less than the first date <code>d1</code> (<code>d2</code> &lt;
	 *         <code>d1</code>) by the comparision kind<br/>
	 * @exception throw
	 *                {@link NullPointerException} if one of two dates is null;<br/>
	 *                throw {@link IllegalArgumentException} if the specified comparision kind <code>what</code> is not
	 *                supported
	 */
	public static boolean equals(Date d1, Date d2, int what) {
		if ((d1 == null && d2 != null) || (d1 != null && d2 == null))
			return false;
		return (compareTo(d1, d2, what) == 0);
	}

	public static int compareTo(Date d1, Date d2, int what) {
		Assert.notNull(d1, "The dates parameter must be not null");
		Assert.notNull(d2, "The dates parameter must be not null");
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			switch (what) {
			// compares year
			case Calendar.YEAR: {
				calendar.setTime(d1);
				int y1 = calendar.get(what);
				calendar.setTime(d2);
				int y2 = calendar.get(what);
				if (y1 == y2)
					return 0;
				else if (y1 < y2)
					return 1;
				else
					return -1;
			}
			// compares year and month
			case Calendar.MONTH: {
				int compareYear = compareTo(d1, d2, Calendar.YEAR);
				if (compareYear != 0)
					return compareYear;
				calendar.setTime(d1);
				int m1 = calendar.get(what);
				calendar.setTime(d2);
				int m2 = calendar.get(what);
				if (m1 == m2)
					return 0;
				else if (m1 < m2)
					return 1;
				else
					return -1;
			}
			// compares year, month and date
			case Calendar.DATE: {
				int compareMonth = compareTo(d1, d2, Calendar.MONTH);
				if (compareMonth != 0)
					return compareMonth;
				calendar.setTime(d1);
				int date1 = calendar.get(what);
				calendar.setTime(d2);
				int date2 = calendar.get(what);
				if (date1 == date2)
					return 0;
				else if (date1 < date2)
					return 1;
				else
					return -1;
			}
			// compares year, month, date and hour
			case Calendar.HOUR:
			case Calendar.HOUR_OF_DAY: {
				int compareDate = compareTo(d1, d2, Calendar.DATE);
				if (compareDate != 0)
					return compareDate;
				calendar.setTime(d1);
				int h1 = calendar.get(Calendar.HOUR_OF_DAY);
				calendar.setTime(d2);
				int h2 = calendar.get(Calendar.HOUR_OF_DAY);
				if (h1 == h2)
					return 0;
				else if (h1 < h2)
					return 1;
				else
					return -1;
			}
			// compares year, month, date, hour and minute
			case Calendar.MINUTE: {
				int compareHour = compareTo(d1, d2, Calendar.HOUR);
				if (compareHour != 0)
					return compareHour;
				calendar.setTime(d1);
				int mi1 = calendar.get(what);
				calendar.setTime(d2);
				int mi2 = calendar.get(what);
				if (mi1 == mi2)
					return 0;
				else if (mi1 < mi2)
					return 1;
				else
					return -1;
			}
			// compares year, month, date, hour, minute and second
			case Calendar.SECOND: {
				int compareMinute = compareTo(d1, d2, Calendar.MINUTE);
				if (compareMinute != 0)
					return compareMinute;
				calendar.setTime(d1);
				int sec1 = calendar.get(what);
				calendar.setTime(d2);
				int sec2 = calendar.get(what);
				if (sec1 == sec2)
					return 0;
				else if (sec1 < sec2)
					return 1;
				else
					return -1;
			}
			// compares year, month, date, hour, minute, second and
			// millisecond
			case Calendar.MILLISECOND: {
				int compareSecond = compareTo(d1, d2, Calendar.SECOND);
				if (compareSecond != 0)
					return compareSecond;
				calendar.setTime(d1);
				int mili1 = calendar.get(what);
				calendar.setTime(d2);
				int mili2 = calendar.get(what);
				if (mili1 == mili2)
					return 0;
				else if (mili1 < mili2)
					return 1;
				else
					return -1;
			}
			// invalid parameter
			default: {
				throw new IllegalArgumentException("what");
			}
			}
		}
	}

	/**
	 * Compares two specified date (compare to every milisecond)
	 *
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @param what
	 *            specifies compare by what kind:<br/>
	 *            - {@link Calendar#YEAR}: compare base on year<br/>
	 *            - {@link Calendar#MONTH}: compare base on year and month<br/>
	 *            - {@link Calendar#DATE}: compare base on year/month and date<br/>
	 *            - {@link Calendar#HOUR} or {@link Calendar#HOUR_OF_DAY}: compare base on year/month/date and hour<br/>
	 *            - {@link Calendar#MINUTE}: compare base on year/month/date/hour and minute<br/>
	 *            - {@link Calendar#SECOND}: compare base on year/month/date/hour/minute and second<br/>
	 *            - {@link Calendar#MILLISECOND}: compare base on whole date (to miliseconds)
	 * @return 0 if two date are equals by the comparision kind<br/>
	 *         1 if the second date <code>d2</code> are greater than the first date <code>d1</code> (<code>d2</code>
	 *         &gt; <code>d1</code>) by the comparision kind<br/>
	 *         -1 if the second date <code>d2</code> are less than the first date <code>d1</code> (<code>d2</code> &lt;
	 *         <code>d1</code>) by the comparision kind<br/>
	 * @exception throw
	 *                {@link NullPointerException} if one of two dates is null;<br/>
	 *                throw {@link IllegalArgumentException} if the specified comparision kind <code>what</code> is not
	 *                supported
	 */
	public static int compareTo(String d1, String fmt1, String d2, String fmt2, int what) {
		return compareTo(toTimestamp(d1, fmt1), toTimestamp(d2, fmt2), what);
	}

	/**
	 * Compares two specified date (compare to every milisecond)
	 *
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @param what
	 *            specifies compare by what kind:<br/>
	 *            - {@link Calendar#YEAR}: compare base on year<br/>
	 *            - {@link Calendar#MONTH}: compare base on year and month<br/>
	 *            - {@link Calendar#DATE}: compare base on year/month and date<br/>
	 *            - {@link Calendar#HOUR} or {@link Calendar#HOUR_OF_DAY}: compare base on year/month/date and hour<br/>
	 *            - {@link Calendar#MINUTE}: compare base on year/month/date/hour and minute<br/>
	 *            - {@link Calendar#SECOND}: compare base on year/month/date/hour/minute and second<br/>
	 *            - {@link Calendar#MILLISECOND}: compare base on whole date (to miliseconds)
	 * @return 0 if two date are equals by the comparision kind<br/>
	 *         1 if the second date <code>d2</code> are greater than the first date <code>d1</code> (<code>d2</code>
	 *         &gt; <code>d1</code>) by the comparision kind<br/>
	 *         -1 if the second date <code>d2</code> are less than the first date <code>d1</code> (<code>d2</code> &lt;
	 *         <code>d1</code>) by the comparision kind<br/>
	 * @exception throw
	 *                {@link NullPointerException} if one of two dates is null;<br/>
	 *                throw {@link IllegalArgumentException} if the specified comparision kind <code>what</code> is not
	 *                supported
	 */
	public static int compareTo(String d1, String d2, int what) {
		return compareTo(d1, CONST_TIME_STAMP_PATTERN, d2, CONST_TIME_STAMP_PATTERN, what);
	}

	/**
	 * Returns the last millisecond of the specified date.
	 *
	 * @param date
	 *            Date to calculate end of day from
	 * @return Last millisecond of <code>date</code>
	 */
	public static Date endOfDay(Date date) {
		Assert.notNull(date, "The date parameter must be not null");
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTime(date);
			calendar.set(Calendar.HOUR_OF_DAY, 23);
			calendar.set(Calendar.MILLISECOND, 999);
			calendar.set(Calendar.SECOND, 59);
			calendar.set(Calendar.MINUTE, 59);
			return calendar.getTime();
		}
	}

	/**
	 * Returns a new Date with the hours, milliseconds, seconds and minutes set to 0.
	 *
	 * @param date
	 *            Date used in calculating start of day
	 * @return Start of <code>date</code>
	 */
	public static Date startOfDay(Date date) {
		Assert.notNull(date, "The date parameter must be not null");
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTime(date);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MINUTE, 0);
			return calendar.getTime();
		}
	}

	/**
	 * Returns day in millis with the hours, milliseconds, seconds and minutes set to 0.
	 *
	 * @param date
	 *            long used in calculating start of day
	 * @return Start of <code>date</code>
	 */
	public static long startOfDayInMillis(long date) {
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(date);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MINUTE, 0);
			return calendar.getTimeInMillis();
		}
	}

	/**
	 * Returns the last millisecond of the specified date.
	 *
	 * @param date
	 *            long to calculate end of day from
	 * @return Last millisecond of <code>date</code>
	 */
	public static long endOfDayInMillis(long date) {
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(date);
			calendar.set(Calendar.HOUR_OF_DAY, 23);
			calendar.set(Calendar.MILLISECOND, 999);
			calendar.set(Calendar.SECOND, 59);
			calendar.set(Calendar.MINUTE, 59);
			return calendar.getTimeInMillis();
		}
	}

	/**
	 * Returns the day after <code>date</code>.
	 *
	 * @param date
	 *            Date used in calculating next day
	 * @return Day after <code>date</code>.
	 */
	public static Date nextDay(Date date) {
		Assert.notNull(date, "The date parameter must be not null");
		return new Date(addDaysToMillis(date.getTime(), 1));
	}

	/**
	 * Adds <code>amount</code> days to <code>time</code> and returns the resulting time.
	 *
	 * @param time
	 *            Base time
	 * @param amount
	 *            Amount of increment.
	 * @return the <var>time</var> + <var>amount</var> days
	 */
	public static long addDaysToMillis(long time, int amount) {
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(time);
			calendar.add(Calendar.DAY_OF_MONTH, amount);
			return calendar.getTimeInMillis();
		}
	}

	/**
	 * Adds <code>amount</code> days to <code>time</code> and returns the resulting time.
	 *
	 * @param time
	 *            Base time
	 * @param amount
	 *            Amount of increment.
	 * @return the <var>time</var> + <var>amount</var> days
	 */
	public static Date addDays(long time, int amount) {
		return addDate(time, Calendar.DAY_OF_MONTH, amount);
	}

	/**
	 * Adds <code>amount</code> days to <code>date</code> and returns the resulting time.
	 *
	 * @param date
	 *            Base date
	 * @param amount
	 *            Amount of increment.
	 * @return the <var>date</var> + <var>amount</var> days
	 */
	public static Date addDays(Date date, int amount) {
		Assert.notNull(date, "The date parameter must be not null");
		return addDays(date.getTime(), amount);
	}

	/**
	 * Adds <code>amount</code> months to <code>time</code> and returns the resulting time.
	 *
	 * @param time
	 *            Base time
	 * @param amount
	 *            Amount of increment.
	 * @return the <var>time</var> + <var>amount</var> months
	 */
	public static Date addMonths(long time, int amount) {
		return addDate(time, Calendar.MONTH, amount);
	}

	/**
	 * Adds <code>amount</code> days to <code>date</code> and returns the resulting time.
	 *
	 * @param date
	 *            Base date
	 * @param amount
	 *            Amount of increment.
	 * @return the <var>date</var> + <var>amount</var> days
	 */
	public static Date addMonths(Date date, int amount) {
		Assert.notNull(date, "The date parameter must be not null");
		return addMonths(date.getTime(), amount);
	}

	/**
	 * Adds <code>amount</code> days to <code>time</code> and returns the resulting time.
	 *
	 * @param time
	 *            Base time
	 * @param amount
	 *            Amount of increment.
	 * @return the <var>time</var> + <var>amount</var> days
	 */
	public static Date addBusinessDays(Date date, int amount) {
		Assert.notNull(date, "The date parameter must be not null");
		return addBusinessDays(date.getTime(), amount);
	}

	/**
	 * Adds <code>amount</code> days to <code>time</code> and returns the resulting time.
	 *
	 * @param time
	 *            Base time
	 * @param amount
	 *            Amount of increment.
	 * @return the <var>time</var> + <var>amount</var> days
	 */
	public static Date addBusinessDays(long time, int amount) {
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(time);
			while (amount > 0) {
				calendar.add(Calendar.DAY_OF_MONTH, 1);
				// if the date after adding is not weekends; then decreasing the
				// mount days
				if ((calendar.get(Calendar.DAY_OF_WEEK) != Calendar.SATURDAY)
						&& (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY)) {
					amount--;
				}
			}
			return new Date(calendar.getTimeInMillis());
		}
	}

	/**
	 * Adds <code>amount</code> days to <code>time</code> and returns the resulting time.
	 *
	 * @param time
	 *            Base time
	 * @param field
	 *            see {@link Calendar#DATE}, {@link Calendar#DAY_OF_MONTH}, etc...
	 * @param amount
	 *            Amount of increment.
	 * @return the <var>time</var> + <var>amount</var> days
	 */
	public static Date addDate(long time, int field, int amount) {
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(time);
			calendar.add(field, amount);
			return new Date(calendar.getTimeInMillis());
		}
	}

	/**
	 * Adds <code>amount</code> days to <code>time</code> and returns the resulting time.
	 *
	 * @param time
	 *            Base time
	 * @param field
	 *            see {@link Calendar#DATE}, {@link Calendar#DAY_OF_MONTH}, etc...
	 * @param amount
	 *            Amount of increment.
	 * @return the <var>time</var> + <var>amount</var> days
	 */
	public static Date addDate(Date date, int field, int amount) {
		Assert.notNull(date, "The date parameter must be not null");
		return addDate(date.getTime(), field, amount);
	}

	/**
	 * Returns the day after <code>date</code>.
	 *
	 * @param date
	 *            Date used in calculating next day
	 * @return Day after <code>date</code>.
	 */
	public static long nextDay(long date) {
		return addDaysToMillis(date, 1);
	}

	/**
	 * Returns the week after <code>date</code>.
	 *
	 * @param date
	 *            Date used in calculating next week
	 * @return week after <code>date</code>.
	 */
	public static long nextWeek(long date) {
		return addDaysToMillis(date, 7);
	}

	/**
	 * Returns the number of days difference between <code>t1</code> and <code>t2</code>.
	 *
	 * @param t1
	 *            Time 1
	 * @param t2
	 *            Time 2
	 * @param checkOverflow
	 *            indicates whether to check for overflow
	 * @return Number of days between <code>start</code> and <code>end</code>
	 */
	public static int getDaysDiff(long t1, long t2, boolean checkOverflow) {
		if (t1 > t2) {
			long tmp = t1;
			t1 = t2;
			t2 = tmp;
		}
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(t1);
			int delta = 0;
			while (calendar.getTimeInMillis() < t2) {
				calendar.add(Calendar.DAY_OF_MONTH, 1);
				delta++;
			}
			if (checkOverflow && (calendar.getTimeInMillis() > t2)) {
				delta--;
			}
			return delta;
		}
	}

	/**
	 * Returns the number of days difference between <code>t1</code> and <code>t2</code>.
	 *
	 * @param t1
	 *            Time 1
	 * @param t2
	 *            Time 2
	 * @return Number of days between <code>start</code> and <code>end</code>
	 */
	public static int getDaysDiff(long t1, long t2) {
		return getDaysDiff(t1, t2, true);
	}

	/**
	 * Check, whether the date passed in is the first day of the year.
	 *
	 * @param date
	 *            date to check in millis
	 * @return <code>true</code> if <var>date</var> corresponds to the first day of a year
	 * @see Date#getTime()
	 */
	public static boolean isFirstOfYear(long date) {
		boolean ret = false;
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(date);
			int currentYear = calendar.get(Calendar.YEAR);
			// Check yesterday
			calendar.add(Calendar.DATE, -1);
			int yesterdayYear = calendar.get(Calendar.YEAR);
			ret = (currentYear != yesterdayYear);
		}
		return ret;
	}

	/**
	 * Check, whether the date passed in is the first day of the month.
	 *
	 * @param date
	 *            date to check in millis
	 * @return <code>true</code> if <var>date</var> corresponds to the first day of a month
	 * @see Date#getTime()
	 */
	public static boolean isFirstOfMonth(long date) {
		boolean ret = false;
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(date);
			int currentMonth = calendar.get(Calendar.MONTH);
			// Check yesterday
			calendar.add(Calendar.DATE, -1);
			int yesterdayMonth = calendar.get(Calendar.MONTH);
			ret = (currentMonth != yesterdayMonth);
		}
		return ret;
	}

	/**
	 * Returns the day before <code>date</code>.
	 *
	 * @param date
	 *            Date used in calculating previous day
	 * @return Day before <code>date</code>.
	 */
	public static long previousDay(long date) {
		return addDaysToMillis(date, -1);
	}

	/**
	 * Returns the week before <code>date</code>.
	 *
	 * @param date
	 *            Date used in calculating previous week
	 * @return week before <code>date</code>.
	 */
	public static long previousWeek(long date) {
		return addDaysToMillis(date, -7);
	}

	/**
	 * Returns the first day before <code>date</code> that has the day of week matching <code>startOfWeek</code>. For
	 * example, if you want to find the previous monday relative to <code>date</code> you would call
	 * <code>getPreviousDay(date, Calendar.MONDAY)</code>.
	 *
	 * @param date
	 *            Base date
	 * @param startOfWeek
	 *            Calendar constant correspoding to start of week.
	 * @return start of week, return value will have 0 hours, 0 minutes, 0 seconds and 0 ms.
	 */
	public static long getPreviousDay(long date, int startOfWeek) {
		return getDay(date, startOfWeek, -1);
	}

	/**
	 * Returns the first day after <code>date</code> that has the day of week matching <code>startOfWeek</code>. For
	 * example, if you want to find the next monday relative to <code>date</code> you would call
	 * <code>getPreviousDay(date, Calendar.MONDAY)</code>.
	 *
	 * @param date
	 *            Base date
	 * @param startOfWeek
	 *            Calendar constant correspoding to start of week.
	 * @return start of week, return value will have 0 hours, 0 minutes, 0 seconds and 0 ms.
	 */
	public static long getNextDay(long date, int startOfWeek) {
		return getDay(date, startOfWeek, 1);
	}

	/**
	 * Gets the day by increment and start of week
	 *
	 * @param date
	 *            the date to increase
	 * @param startOfWeek
	 *            the start of week to get
	 * @param increment
	 *            the increase unit
	 * @return the date in miliseconds by increment and start of week
	 */
	private static long getDay(long date, int startOfWeek, int increment) {
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(date);
			int day = calendar.get(Calendar.DAY_OF_WEEK);
			// Normalize the view starting date to a week starting day
			while (day != startOfWeek) {
				calendar.add(Calendar.DATE, increment);
				day = calendar.get(Calendar.DAY_OF_WEEK);
			}
			return startOfDayInMillis(calendar.getTimeInMillis());
		}
	}

	/**
	 * Returns the previous month.
	 *
	 * @param date
	 *            Base date
	 * @return previous month
	 */
	public static long getPreviousMonth(long date) {
		return incrementMonth(date, -1);
	}

	/**
	 * Returns the next month.
	 *
	 * @param date
	 *            Base date
	 * @return next month
	 */
	public static long getNextMonth(long date) {
		return incrementMonth(date, 1);
	}

	/**
	 * Increases the specified date amount of months
	 *
	 * @param date
	 *            the date to increase
	 * @param increment
	 *            amount of months
	 * @return the date (in miliseconds) after increasing amount of months
	 */
	private static long incrementMonth(long date, int increment) {
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(date);
			calendar.add(Calendar.MONTH, increment);
			return calendar.getTimeInMillis();
		}
	}

	/**
	 * Returns the date corresponding to the start of the month.
	 *
	 * @param date
	 *            Base date
	 * @return Start of month.
	 */
	public static long getStartOfMonth(long date) {
		return getMonth(date, -1);
	}

	/**
	 * Returns the date corresponding to the end of the month.
	 *
	 * @param date
	 *            Base date
	 * @return End of month.
	 */
	public static long getEndOfMonth(long date) {
		return getMonth(date, 1);
	}

	/**
	 * Increases the specified date amount of months
	 *
	 * @param date
	 *            the date to increase
	 * @param increment
	 *            amount of months
	 * @return the date (in miliseconds) after increasing amount of months
	 */
	private static long getMonth(long date, int increment) {
		long result;
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(date);
			if (increment == -1) {
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				result = startOfDayInMillis(calendar.getTimeInMillis());
			} else {
				calendar.add(Calendar.MONTH, 1);
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.add(Calendar.MILLISECOND, -1);
				result = calendar.getTimeInMillis();
			}
		}
		return result;
	}

	/**
	 * Returns the day of the week.
	 *
	 * @param date
	 *            date
	 * @return day of week.
	 */
	public static int getDayOfWeek(long date) {
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTimeInMillis(date);
			return (calendar.get(Calendar.DAY_OF_WEEK));
		}
	}

	/**
	 * Returns the ActualMaximum day of the month.
	 *
	 * @param date
	 *            timestamp
	 * @return day of month.
	 */
	public static int getActualMaximum(Date date) {
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTime(date);
			return (calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		}
	}

	/**
	 * goals convert from java.util.Date date to java.sql.Date date
	 *
	 * @param date
	 * @return - a sql date or null if input parameter is null
	 */
	public static java.sql.Date toSQLDate(Date date) {
		if (date == null) {
			return null;
		} else {
			return new java.sql.Date(date.getTime());
		}
	}

	/**
	 * goals convert from java.sql.Date date to java.util.Date date
	 *
	 * @param date
	 * @return - a sql date or null if input parameter is null
	 */
	public static java.util.Date toUtilDate(java.sql.Date date) {
		if (date == null) {
			return null;
		} else {
			return new java.util.Date(date.getTime());
		}
	}

	/**
	 * Calculates the number of days between two specified {@link Date}
	 *
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @return the number of days between two specified {@link Date}
	 */
	public static int daysBetween(Date d1, Date d2) {
		return (int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
	}

	/**
	 * Calculates the number of days between two specified {@link Date}, with the start of date <i>d1</i> to the end of
	 * date <i>d2</i>
	 *
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @return the number of days between two specified {@link Date}, with the start of date <i>d1</i> to the end of
	 *         date <i>d2</i>
	 */
	public static int fullDaysBetween(Date d1, Date d2) {
		d1 = startOfDay(d1);
		d2 = endOfDay(d2);
		return daysBetween(d1, d2);
	}

	/**
	 * Formats date time
	 *
	 * @param pattern
	 *            the format pattern
	 * @param date
	 *            (java.sql.date) the date to format
	 * @return the formatted date time
	 */
	public static String formatDateTime(String pattern, java.sql.Date date) {
		Assert.notNull(date, "The date parameter must be not null");
		return formatDateTime(pattern, toUtilDate(date));
	}

	/**
	 * Formats date time
	 *
	 * @param pattern
	 *            the format pattern
	 * @param date
	 *            (java.util.date) the date to format
	 * @return the formatted date time
	 */
	public static String formatDateTime(String pattern, java.util.Date date) {
		return formatDateTime(pattern, date, null);
	}

	/**
	 * Formats date time
	 *
	 * @param pattern
	 *            the format pattern
	 * @param date
	 *            (java.util.date) the date to format
	 * @return the formatted date time
	 */
	public static String formatDateTime(String pattern, java.util.Date date, Locale locale) {
		String retDate = "";
		if (date != null) {
			locale = (locale == null ? Locale.getDefault() : locale);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, locale);
			retDate = simpleDateFormat.format(date);
		}
		return retDate;
	}

	/**
	 * Convert number of days to minutes
	 */
	public static int daysToMinutes(int days) {
		return days * 24 * 60;
	}

	/**
	 * Gets the milliseconds between 2 specified {@link Date} ( <code>d2 - d1</code>)
	 *
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @return the milliseconds between 2 specified {@link Date}
	 */
	public static long getMilliSecondsDiff(Date d1, Date d2) {
		Assert.notNull(d1, "date 1");
		Assert.notNull(d2, "date 2");
		return (d2.getTime() - d1.getTime());
	}

	/**
	 * Gets the seconds between 2 specified {@link Date}
	 *
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @return the seconds between 2 specified {@link Date}
	 */
	public static long getSecondsDiff(Date d1, Date d2) {
		return (getMilliSecondsDiff(d1, d2) / 1000);
	}

	/**
	 * Gets the minutes between 2 specified {@link Date}
	 *
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @return the minutes between 2 specified {@link Date}
	 */
	public static long getMinutesDiff(Date d1, Date d2) {
		return (getSecondsDiff(d1, d2) / 60);
	}

	/**
	 * Gets the hours between 2 specified {@link Date}
	 *
	 * @param d1
	 *            the {@link Date} 1
	 * @param d2
	 *            the {@link Date} 2
	 * @return the hours between 2 specified {@link Date}
	 */
	public static long getHoursDiff(Date d1, Date d2) {
		return (getMinutesDiff(d1, d2) / 60);
	}

	/**
	 * Gets the date after truncating the specified kinds
	 *
	 * @param dt
	 *            the {@link Date} to parse
	 * @param kinds
	 *            the kinds to truncate such as {@link Calendar#MILLISECOND}, {@link Calendar#HOUR_OF_DAY}, etc...
	 * @return the date in milliseconds with nanoseconds is truncated
	 */
	public static Date truncate(Date dt, int... kinds) {
		Assert.notNull(dt, "The date parameter must be not null");
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTime(dt);
			if (!ArrayUtils.isEmpty(kinds)) {
				for (int kind : kinds) {
					calendar.set(kind, 0);
				}
			}
			return calendar.getTime();
		}
	}

	/**
	 * Gets the date after truncating the specified kinds
	 *
	 * @param dt
	 *            the {@link Date} to parse
	 * @param kinds
	 *            the kinds to truncate such as {@link Calendar#MILLISECOND}, {@link Calendar#HOUR_OF_DAY}, etc...
	 * @return the date in milliseconds with nanoseconds is truncated
	 */
	public static long truncateInMillis(Date dt, int... kinds) {
		Assert.notNull(dt, "The date parameter must be not null");
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTime(dt);
			if (!ArrayUtils.isEmpty(kinds)) {
				for (int kind : kinds) {
					calendar.set(kind, 0);
				}
			}
			return calendar.getTimeInMillis();
		}
	}

	/**
	 * Gets a part of the specified {@link Date}
	 *
	 * @param dt
	 *            the {@link Date} to get
	 * @param what
	 *            the information to get
	 * @return a part of the specified {@link Date}
	 */
	public static int get(Date dt, int what) {
		Assert.notNull(dt, "The date parameter must be not null");
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTime(dt);
			return calendar.get(what);
		}
	}

	/**
	 * Gets a part of the specified {@link Date}
	 *
	 * @param dt
	 *            the {@link Date} to get
	 * @param what
	 *            the information to get
	 * @return a part of the specified {@link Date}
	 */
	public static int getDaysInYear(Date dt) {
		Assert.notNull(dt, "The date parameter must be not null");
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.setTime(dt);
			return calendar.getActualMaximum(Calendar.DAY_OF_YEAR);
		}
	}

	/**
	 * Gets the first date of year that is specified by date
	 *
	 * @param dt
	 *            the date to parse year
	 * @return the first date of year that is specified by date
	 */
	public static Date getStartDateOfYear(Date dt) {
		Assert.notNull(dt, "The date parameter must be not null");
		// parses year
		int year = get(dt, Calendar.YEAR);
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, 0);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			return calendar.getTime();
		}
	}

	/**
	 * Gets the first date of month that is specified by date
	 *
	 * @param dt
	 *            the date to parse month
	 * @return the first date of month that is specified by date
	 */
	public static Date getStartDateOfMonth(Date dt) {
		Assert.notNull(dt, "The date parameter must be not null");
		// parses year
		int year = get(dt, Calendar.YEAR);
		int month = get(dt, Calendar.MONTH);
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			return calendar.getTime();
		}
	}

	/**
	 * Gets the end date of year that is specified by date
	 *
	 * @param dt
	 *            the date to parse year
	 * @return the first date of year that is specified by date
	 */
	public static Date getEndDateOfYear(Date dt) {
		Assert.notNull(dt, "The date parameter must be not null");
		// parses year
		int year = get(dt, Calendar.YEAR);
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.set(Calendar.YEAR, year + 1);
			calendar.set(Calendar.MONTH, 0);
			calendar.set(Calendar.DAY_OF_MONTH, 0);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			return calendar.getTime();
		}
	}

	/**
	 * Gets the end date of month that is specified by date
	 *
	 * @param dt
	 *            the date to parse month
	 * @return the first date of month that is specified by date
	 */
	public static Date getEndDateOfMonth(Date dt) {
		Assert.notNull(dt, "The date parameter must be not null");
		// parses year
		int year = get(dt, Calendar.YEAR);
		int month = get(dt, Calendar.MONTH);
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month + 1);
			calendar.set(Calendar.DAY_OF_MONTH, 0);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			return calendar.getTime();
		}
	}

	/**
	 * Gets the first date of year that is specified by date
	 *
	 * @param dt
	 *            the date to parse year
	 * @return the first date of year that is specified by date
	 */
	public static Date getStartDateOfNextYear(Date dt) {
		Assert.notNull(dt, "The date parameter must be not null");
		// parses year
		int year = get(dt, Calendar.YEAR);
		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.set(Calendar.YEAR, (year + 1));
			calendar.set(Calendar.MONTH, 0);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			return calendar.getTime();
		}
	}

	public static Time truncatDate(Date dt) {
		Assert.notNull(dt, "The date parameter must be not null");
		// parses time
		int hour = get(dt, Calendar.HOUR_OF_DAY);
		int minute = get(dt, Calendar.MINUTE);
		int second = get(dt, Calendar.SECOND);
		int miliSecond = get(dt, Calendar.MILLISECOND);

		Calendar calendar = CALENDAR;
		synchronized (calendar) {
			calendar.set(Calendar.YEAR, 1970);
			calendar.set(Calendar.MONTH, 0);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR, hour);
			calendar.set(Calendar.MINUTE, minute);
			calendar.set(Calendar.SECOND, second);
			calendar.set(Calendar.MILLISECOND, miliSecond);
			return new java.sql.Time(calendar.getTime().getTime());
		}
	}

//	/**
//	 * Get the milliseconds of day by the specified {@link Time}
//	 *
//	 * @param time
//	 *            the time to parse
//	 *
//	 * @return the milliseconds of day
//	 */
//	public static long getLocalTimeMilli(Time time) {
//		Assert.notNull(time, "The parameter must be not null");
//		return (new LocalDateTime(time)).getMillisOfDay();
//	}

	/**
	 * Main test
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		Timestamp ts = getCurrentTimestamp();
		System.out.println(getStartDateOfMonth(ts));
		System.out.println(getEndDateOfMonth(ts));
	}
}
