/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.dto;
import java.io.Serializable;
import java.util.List;

import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneRadioItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.ColumnConditionItem;
public class columnListItemDTO implements Serializable {
    /**
	 *
	 */
	private static final long serialVersionUID = 2285519141987539001L;

	/**
     * 本アプリケーションで対応しているか否か
     */
    private boolean correspondence;

    /**
     * SelectableList を保持するか否かの Boolean を保持します。
     * <p>
     * HTML の Condition 判定 Boolean です。</p>
     */
    private boolean displaysSelectableList;

    /**
     * RestrictionList を保持するか否かの Boolean を保持します。
     * <p>
     * HTML の Condition 判定 Boolean です。</p>
     */
    private boolean displaysRestrictionList;

    /**
     * テーブルプルダウンリストより選択された、テーブル ID プロパティーを保持し
     * ます。
     */
    private String tableId;

    /**
     * テーブル Label 「仮名」プロパティを保持します。
     */
    private String tableLabel;

    /**
     * テーブルリストプロパティを保持します。
     * <p>
     * プルダウン用のテーブル一覧リストを保持します。</p>
     */
    private List<SelectOneMenuItem> tableIdItems;

    /**
     * カラムリストより選択された、カラムの ID プロパティーを保持します。
     */
    private String columnId;

    /**
     * カラム Label 「仮名」プロパティを保持します。
     */
    private String columnLabel;

    /**
     * カラム表示順
     */
    private int sortIndex;

    /**
     * HTML 要素リストより選択された HTML ID プロパティーを保持します。
     */
    private String htmlElement;

    /**
     * HTML 要素リストプルダウンプロパティを保持します。
     */
    private List<SelectOneMenuItem> htmlElementItems;

    /**
     * 編集対象レコードのカラム属性がプルダウンリスト名称。
     * <p>表示用名称「仮名」を保持するプロパティです。</p>
     */
    private String label;

    /**
     * 編集対象レコードのカラム属性がプルダウンリスト ID。
     * <p>システム内部で扱われる ID を保持するプロパティです。</p>
     */
    private String value;

    /**
     * <code>selectableListIndex</code> のコメント。
     */
    private int selectableListIndex;

    /**
     * HTML 要素に対応する、プルダウン等のリスト用のデータプロパティを保持します。
     */
    private List<SelectOneMenuItem> selectableListItems;

    /**
     * アプリケーション独自定義制約プロパティリストより選択された アプリケーショ
     * ン独自定義制約 ID プロパティーを保持します。
     */
    private String[] restrictions;

    /**
     * アプリケーション独自定義制約リストプロパティを保持します。
     * <p>
     * チェックボックス HTML 生成用。本アプリケーションにて定義されている独自定
     * 義制約を保持します。</p>
     */
    private List<SelectOneMenuItem> restrictionsItems;

    /**
     * アプリケーション独自定義制約リストプロパティを保持します。
     * <p>
     * ユーザーが選択した独自制約。「確認画面要素」表示用のリストプロパティーを
     * 保持します。</p>
     */
    private List<SelectOneMenuItem> restrictionConfirmItems;

    /**
     * 既定値プロパティを保持します。
     */
    private String defaultValue;

    /**
     * 画面表示用項目説明文プロパティを保持します。
     */
    private String explanation;

    /**
     * 一覧表示設定ラジオボタンのラジオボタンリストプロパティより選択された 一覧
     * 表示設定 プロパティー ID を保持します。
     */
    private String canPreview;

    /**
     * 一覧表示設定ラジオボタンのラジオボタン用リストプロパティ。
     */
    private List<SelectOneRadioItem> canPreviewItems;

    /**
     * 登録・編集時表示設定ラジオボタンのラジオボタンリストプロパティより選択された
     * 設定 プロパティー ID を保持します。
     */
    private String canDisplayRecordEdit;

    /**
     * 登録・編集時表示設定ラジオボタンのラジオボタン用リストプロパティ。
     */
    private List<SelectOneRadioItem> canDisplayRecordEditItems;


    /**
     * 一覧表示設定ラジオボタンのラジオボタンリストプロパティより選択された 一覧
     * 表示設定 プロパティー ID を保持します。
     */
    private String canDisplayNamePreview;

    /**
     * 一覧表示設定ラジオボタンのラジオボタン用リストプロパティ。
     */
    private List<SelectOneRadioItem> canDisplayNamePreviewItems;


    /**
     * 更新可能設定ラジオボタンのラジオボタンリストより選択された 更新可能設定
     * プロパティー ID を保持します。
     */
    private String canEditing;

    /**
     * 更新可能設定ラジオボタンのラジオボタン用リストプロパティ。
     */
    private List<SelectOneRadioItem> canEditingItems;

    /**
     * 更新処理のキー設定ラジオボタンのラジオボタンリストより選択された 更新処理
     * のキー設定 プロパティー ID を保持します。
     */
    private String isUpdateKey;

    /**
     * 更新処理のキー設定ラジオボタンのラジオボタン用リストプロパティ。
     */
    private List<SelectOneRadioItem> isUpdateKeyItems;

    /**
     * 検索キー設定ラジオボタンのラジオボタンリストより選択された 検索キー設定
     * プロパティー ID を保持します。
     */
    private String isSelectKey;

    /**
     * 検索キー設定ラジオボタンのラジオボタン用リストプロパティ。
     */
    private List<SelectOneRadioItem> isSelectKeyItems;

    /**
     * カラム条件定義画面表示用リストプロパティ。
     */
    private List<ColumnConditionItem> columnCondisionItems;

    /**
     * SQL文のプロパティを保持します。
     */
    private String sqlString;

    /**
     * DB(XML)更新処理区分
     */
    private String updateDivision;

    /**
     * キーカラムか否かプロパティ
     */
    private String keyColumn;

    /**
     * カラムの型プロパティ
     */
    private String columnType;

    /**
     * 選択された接続定義ID
     */
    private String selectedConnectDefinisionId;

    /**
     * 選択された接続定義表示名
     */
    private String selectedConnectDefinisionLabel;

    private String tableType;

    /**
     * hasSelectableList を戻します。
     *
     * @return boolean
     */
    public boolean isDisplaysSelectableList() {
        return displaysSelectableList;
    }

    /**
     * hasSelectableList を設定します。
     *
     * @param boolean hasSelectableList
     */
    public void setDisplaysSelectableList(boolean hasSelectableList) {
        this.displaysSelectableList = hasSelectableList;
    }

    /**
     * hasRestrictionList を戻します。
     *
     * @return boolean
     */
    public boolean isDisplaysRestrictionList() {
        return displaysRestrictionList;
    }

    /**
     * hasRestrictionList を設定します。
     *
     * @param boolean hasRestrictionList
     */
    public void setDisplaysRestrictionList(boolean hasRestrictionList) {
        this.displaysRestrictionList = hasRestrictionList;
    }

    /**
     * テーブルプルダウンリストより選択された、テーブル ID プロパティー を戻し
     * ます。
     *
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * テーブルプルダウンリストより選択された、テーブル ID プロパティー を設定
     * します。
     *
     * @param String tableId
     */
    public void setTableId(String tableId) {
        this.tableId = tableId;
    }

    /**
     * テーブル Label 「仮名」プロパティ を戻します。
     *
     * @return String
     */
    public String getTableLabel() {
        return tableLabel;
    }

    /**
     * テーブル Label 「仮名」プロパティ を設定します。
     *
     * @param String tableLabel
     */
    public void setTableLabel(String tableLabel) {
        this.tableLabel = tableLabel;
    }

    /**
     * テーブルリストプロパティ を戻します。
     *
     * @return List<SelectOneMenuItem>
     */
    public List<SelectOneMenuItem> getTableIdItems() {
        return tableIdItems;
    }

    /**
     * テーブルリストプロパティ を設定します。
     *
     * @param List<SelectOneMenuItem> tableIdItems
     */
    public void setTableIdItems(List<SelectOneMenuItem> tableIdItems) {
        this.tableIdItems = tableIdItems;
    }

    /**
     * カラムリストプロパティーより選択された、カラム ID プロパティー を戻します。
     *
     * @return String
     */
    public String getColumnId() {
        return columnId;
    }

    /**
     * カラムリストプロパティーより選択された、カラム ID プロパティー を設定します。
     *
     * @param String columnId
     */
    public void setColumnId(String columnId) {
        this.columnId = columnId;
    }

    /**
     * カラム Label 「仮名」」プロパティ を戻します。
     *
     * @return String
     */
    public String getColumnLabel() {
        return columnLabel;
    }

    /**
     * カラム Label 「仮名」」プロパティ を設定します。
     *
     * @param String columnLabel
     */
    public void setColumnLabel(String columnLabel) {
        this.columnLabel = columnLabel;
    }

    /**
     * HTML 要素リストより選択された HTML ID プロパティー を戻します。
     *
     * @return String
     */
    public String getHtmlElement() {
        return htmlElement;
    }

    /**
     * HTML 要素リストより選択された HTML ID プロパティー を設定します。
     *
     * @param String htmlElement
     */
    public void setHtmlElement(String htmlElement) {
        this.htmlElement = htmlElement;
    }

    /**
     * HTML 要素リストプルダウンプロパティ を戻します。
     *
     * @return List<SelectOneMenuItem>
     */
    public List<SelectOneMenuItem> getHtmlElementItems() {
        return htmlElementItems;
    }

    /**
     * HTML 要素リストプルダウンプロパティ を設定します。
     *
     * @param List<SelectOneMenuItem> htmlElementItems
     */
    public void setHtmlElementItems(List<SelectOneMenuItem> htmlElementItems) {
        this.htmlElementItems = htmlElementItems;
    }

    /**
     * HTML 要素に対応する、プルダウン等のリスト用のデータプロパティ を戻します。
     *
     * @return List<SelectOneMenuItem>
     */
    public List<SelectOneMenuItem> getSelectableListItems() {
        return selectableListItems;
    }

    /**
     * HTML 要素に対応する、プルダウン等のリスト用のデータプロパティ を設定します。
     *
     * @param SelectOneMenuItem[] selectableListItems
     */
    public void setSelectableListItems(
            List<SelectOneMenuItem> selectableListItems) {
        this.selectableListItems = selectableListItems;
    }

    /**
     * アプリケーション独自定義制約プロパティリストより選択された アプリケーショ
     * ン独自定義制約 ID プロパティー を戻します。
     *
     * @return String
     */
    public String[] getRestrictions() {
        return restrictions;
    }

    /**
     * アプリケーション独自定義制約プロパティリストより選択された アプリケーショ
     * ン独自定義制約 ID プロパティー を設定します。
     *
     * @param String restrictions
     */
    public void setRestrictions(String[] restrictions) {
        this.restrictions = restrictions;
    }

    /**
     * アプリケーション独自定義制約リストプロパティ を戻します。
     *
     * @return List<SelectOneMenuItem>
     */
    public List<SelectOneMenuItem> getRestrictionsItems() {
        return restrictionsItems;
    }

    /**
     * アプリケーション独自定義制約リストプロパティ を設定します。
     *
     * @param List<SelectOneMenuItem> restrictionsItems
     */
    public void setRestrictionsItems(List<SelectOneMenuItem> restrictionsItems) {
        this.restrictionsItems = restrictionsItems;
    }

    /**
     * 既定値プロパティ を戻します。
     *
     * @return String
     */
    public String getDefaultValue() {
        return defaultValue;
    }

    /**
     * 既定値プロパティ を設定します。
     *
     * @param String defaultValue
     */
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    /**
     * 画面表示用項目説明文プロパティ を戻します。
     *
     * @return String
     */
    public String getExplanation() {
        return explanation;
    }

    /**
     * 画面表示用項目説明文プロパティ を設定します。
     *
     * @param String explanation
     */
    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    /**
     * 一覧表示設定ラジオボタンのラジオボタンリストプロパティより選択された 一覧
     * 表示設定 プロパティー ID を戻します。
     *
     * @return String
     */
    public String getCanPreview() {
        return canPreview;
    }

    /**
     * 一覧表示設定ラジオボタンのラジオボタンリストプロパティより選択された 一覧
     * 表示設定 プロパティー ID を設定します。
     *
     * @param String canPreview
     */
    public void setCanPreview(String indication) {
        this.canPreview = indication;
    }

    /**
     * 登録・編集時表示設定ラジオボタンのラジオボタンリストプロパティより選択された
     * 設定 プロパティー ID を戻します。
     *
     * @return String
     */
    public String getCanDisplayRecordEdit() {
        return canDisplayRecordEdit;
    }

    /**
     * 登録・編集時表示設定ラジオボタンのラジオボタンリストプロパティより選択された
     * 設定 プロパティー ID を設定します。
     *
     * @param String canPreview
     */
    public void setCanDisplayRecordEdit(String indication) {
        this.canDisplayRecordEdit = indication;
    }

    /**
     * 一覧表示設定ラジオボタンのラジオボタンリストプロパティより選択された 一覧
     * 表示設定 プロパティー ID を戻します。
     *
     * @return String
     */
    public String getCanDisplayNamePreview() {
        return canDisplayNamePreview;
    }

    /**
     * 一覧表示設定ラジオボタンのラジオボタンリストプロパティより選択された 一覧
     * 表示設定 プロパティー ID を設定します。
     *
     * @param String canPreview
     */
    public void setCanDisplayNamePreview(String indication) {
        this.canDisplayNamePreview = indication;
    }

    /**
     * 更新可能設定ラジオボタンのラジオボタンリストより選択された 更新可能設定
     * プロパティー ID を戻します。
     *
     * @return String
     */
    public String getCanEditing() {
        return canEditing;
    }

    /**
     * 更新可能設定ラジオボタンのラジオボタンリストより選択された 更新可能設定
     * プロパティー ID を設定します。
     *
     * @param String canEditing
     */
    public void setCanEditing(String canEditing) {
        this.canEditing = canEditing;
    }

    /**
     * 一覧表示設定ラジオボタンのラジオボタン用リストプロパティ を戻します。
     *
     * @return List<SelectOneRadioItem>
     */
    public List<SelectOneRadioItem> getCanPreviewItems() {
        return canPreviewItems;
    }

    /**
     * 一覧表示設定ラジオボタンのラジオボタン用リストプロパティ を設定します。
     *
     * @param List<SelectOneRadioItem> canPreviewItems
     */
    public void setCanPreviewItems(List<SelectOneRadioItem> indicationItems) {
        this.canPreviewItems = indicationItems;
    }

    /**
     * 登録・編集時表示設定ラジオボタンのラジオボタン用リストプロパティ を戻します。
     *
     * @return List<SelectOneRadioItem>
     */
    public List<SelectOneRadioItem> getCanDisplayRecordEditItems() {
        return canDisplayRecordEditItems;
    }

    /**
     * 登録・編集時表示設定ラジオボタンのラジオボタン用リストプロパティ を設定します。
     *
     * @param List<SelectOneRadioItem> canPreviewItems
     */
    public void setCanDisplayRecordEditItems(List<SelectOneRadioItem> indicationItems) {
        this.canDisplayRecordEditItems = indicationItems;
    }

    /**
     * 表示置き換え設定ラジオボタンのラジオボタン用リストプロパティ を戻します。
     *
     * @return List<SelectOneRadioItem>
     */
    public List<SelectOneRadioItem> getCanDisplayNamePreviewItems() {
        return canDisplayNamePreviewItems;
    }

    /**
     * 一覧置き換え設定ラジオボタンのラジオボタン用リストプロパティ を設定します。
     *
     * @param List<SelectOneRadioItem> canPreviewItems
     */
    public void setCanDisplayNamePreviewItems(List<SelectOneRadioItem> indicationItems) {
        this.canDisplayNamePreviewItems = indicationItems;
    }

    /**
     * 更新可能設定ラジオボタンのラジオボタン用リストプロパティ を戻します。
     *
     * @return List<SelectOneRadioItem>
     */
    public List<SelectOneRadioItem> getCanEditingItems() {
        return canEditingItems;
    }

    /**
     * 更新可能設定ラジオボタンのラジオボタン用リストプロパティ を設定します。
     *
     * @param List<SelectOneRadioItem> canEditingItems
     */
    public void setCanEditingItems(List<SelectOneRadioItem> canEditingItems) {
        this.canEditingItems = canEditingItems;
    }

    /**
     * 更新処理のキー設定ラジオボタンのラジオボタンリストより選択された 更新処理
     * のキー設定 プロパティー ID を戻します。
     *
     * @return String
     */
    public String getIsUpdateKey() {
        return isUpdateKey;
    }

    /**
     * isUpd更新処理のキー設定ラジオボタンのラジオボタンリストより選択された 更新処理
     * のキー設定 プロパティー IDateKey を設定します。
     *
     * @param String isUpdateKey
     */
    public void setIsUpdateKey(String isUpdateKey) {
        this.isUpdateKey = isUpdateKey;
    }

    /**
     * 更新処理のキー設定ラジオボタンのラジオボタン用リストプロパティ を戻します。
     *
     * @return List<SelectOneRadioItem>
     */
    public List<SelectOneRadioItem> getIsUpdateKeyItems() {
        return isUpdateKeyItems;
    }

    /**
     * 更新処理のキー設定ラジオボタンのラジオボタン用リストプロパティ を設定します。
     *
     * @param List<SelectOneRadioItem> isUpdateKeyItems
     */
    public void setIsUpdateKeyItems(List<SelectOneRadioItem> isUpdateKeyItems) {
        this.isUpdateKeyItems = isUpdateKeyItems;
    }

    /**
     * 検索キー設定ラジオボタンのラジオボタンリストより選択された 検索キー設定
     * プロパティー ID を戻します。
     *
     * @return String
     */
    public String getIsSelectKey() {
        return isSelectKey;
    }

    /**
     * 検索キー設定ラジオボタンのラジオボタンリストより選択された 検索キー設定
     * プロパティー ID を設定します。
     *
     * @param String isSelectKey
     */
    public void setIsSelectKey(String isSelectKeyItem) {
        this.isSelectKey = isSelectKeyItem;
    }

    /**
     * 検索キー設定ラジオボタンのラジオボタン用リストプロパティ を戻します。
     *
     * @return List<SelectOneRadioItem>
     */
    public List<SelectOneRadioItem> getIsSelectKeyItems() {
        return isSelectKeyItems;
    }

    /**
     * 検索キー設定ラジオボタンのラジオボタン用リストプロパティ を設定します。
     *
     * @param List<SelectOneRadioItem> isSelectKeyItems
     */
    public void setIsSelectKeyItems(List<SelectOneRadioItem> isSelectKeyItems) {
        this.isSelectKeyItems = isSelectKeyItems;
    }

    /**
     * DB(XML)更新処理区分 を戻します。
     *
     * @return UpdateDivision
     */
    public String getUpdateDivision() {
        return updateDivision;
    }

    /**
     * カラム条件定義画面表示用リストプロパティ を戻します。
     *
     * @return List<ColumnConditionItem>
     */
    public List<ColumnConditionItem> getColumnCondisionItems() {
        return columnCondisionItems;
    }

    /**
     * カラム条件定義画面表示用リストプロパティ を設定します。
     *
     * @param List<ColumnConditionItem>
     */
    public void setColumnCondisionItems(
            List<ColumnConditionItem> columnCondisionItems) {
        this.columnCondisionItems = columnCondisionItems;
    }

    /**
     * SQL文のプロパティ を戻します。
     *
     * @return String
     */
    public String getSqlString() {
        return sqlString;
    }

    /**
     * SQL文のプロパティ を設定します。
     *
     * @param String sqlString
     */
    public void setSqlString(String sqlString) {
        this.sqlString = sqlString;
    }

    /**
     * DB(XML)更新処理区分 を設定します。
     * <p>
     * パラメーターを String 型で受け取ります。</p>
     *
     * @see this.setUpdateDivision(final UpdateDivision div)
     * @param UpdateDivision updateDivision
     */
    public void setUpdateDivision(String updateDivision) {
        this.updateDivision = updateDivision;
    }

    /**
     * DB(XML)更新処理区分 を設定します。
     * <p>
     * パラメーターを UpdateDivision 型で受け取ります。</p>
     *
     * @see this.setUpdateDivision(String updateDivision)
     * @param UpdateDivision updateDivision
     */
    protected void setUpdateDivision(final UpdateDivision div) {
        this.updateDivision = div.getKey();
    }

    /**
     * label を戻します。
     *
     * @return String
     */
    public String getLabel() {
        return label;
    }

    /**
     * label を設定します。
     *
     * @param String label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * value を戻します。
     *
     * @return String
     */
    public String getValue() {
        return value;
    }

    /**
     * value を設定します。
     *
     * @param String value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * selectableListIndex を戻します。
     *
     * @return int
     */
    public int getSelectableListIndex() {
        return selectableListIndex;
    }

    /**
     * selectableListIndex を設定します。
     *
     * @param int selectableListIndex
     */
    public void setSelectableListIndex(int selectableListIndex) {
        this.selectableListIndex = selectableListIndex;
    }

    /**
     * restrictionConfirmItems を戻します。
     *
     * @return List<SelectOneMenuItem>
     */
    public List<SelectOneMenuItem> getRestrictionConfirmItems() {
        return restrictionConfirmItems;
    }

    /**
     * restrictionConfirmItems を設定します。
     *
     * @param List<SelectOneMenuItem> restrictionConfirmItems
     */
    public void setRestrictionConfirmItems(
            List<SelectOneMenuItem> restrictionConfirmItems) {
        this.restrictionConfirmItems = restrictionConfirmItems;
    }

    /**
     * correspondence を戻します。
     *
     * @return boolean
     */
    public boolean isCorrespondence() {
        return correspondence;
    }

    /**
     * correspondence を設定します。
     *
     * @param boolean correspondence
     */
    public void setCorrespondence(boolean correspondence) {
        this.correspondence = correspondence;
    }

    /**
     * sortIndex を戻します。
     *
     * @return int
     */
    public int getSortIndex() {
        return sortIndex;
    }

    /**
     * sortIndex を設定します。
     *
     * @param int sortIndex
     */
    public void setSortIndex(int sortIndex) {
        this.sortIndex = sortIndex;
    }

	/**
	 * keyColumn を戻します。
	 *
	 * @return String
	 */
	public String getKeyColumn() {
		return keyColumn;
	}

	/**
	 * keyColumn を設定します。
	 *
	 * @param String keyColumn
	 */
	public void setKeyColumn(String keyColumn) {
		this.keyColumn = keyColumn;
	}

	/**
	 * columnType を戻します。
	 *
	 * @return String
	 */
	public String getColumnType() {
		return columnType;
	}

	/**
	 * columnType を設定します。
	 *
	 * @param String columnType
	 */
	public void setColumnType(String columnType) {
		this.columnType = columnType;
	}

	/**
	 * selectedConnectDefinisionId を戻します。
	 *
	 * @return String
	 */
	public String getSelectedConnectDefinisionId() {
		return selectedConnectDefinisionId;
	}

	/**
	 * selectedConnectDefinisionId を設定します。
	 *
	 * @param String selectedConnectDefinisionId
	 */
	public void setSelectedConnectDefinisionId(String selectedConnectDefinisionId) {
		this.selectedConnectDefinisionId = selectedConnectDefinisionId;
	}

	/**
	 * selectedConnectDefinisionLabel を戻します。
	 *
	 * @return String
	 */
	public String getSelectedConnectDefinisionLabel() {
		return selectedConnectDefinisionLabel;
	}

	/**
	 * selectedConnectDefinisionLabel を設定します。
	 *
	 * @param String selectedConnectDefinisionLabel
	 */
	public void setSelectedConnectDefinisionLabel(
			String selectedConnectDefinisionLabel) {
		this.selectedConnectDefinisionLabel = selectedConnectDefinisionLabel;
	}

	public String getTableType() {
		return tableType;
	}

	public void setTableType(String tableType) {
		this.tableType = tableType;
	}

	private String parametersSql;

	public String getParametersSql() {
		return parametersSql;
	}

	public void setParametersSql(String parametersSql) {
		this.parametersSql = parametersSql;
	}
}
