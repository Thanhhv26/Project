/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.DbConnectInfomationDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ConnectDefinisionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.DbConnectDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 接続定義情報の保存ロジック。
 * <p>
 * 接続定義情報をリポジトリに新規追加、或いは更新するための処理です。</p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class PreservationOfConnectDefinitionLogic
        extends BaseApplicationDomainLogic {

    /**
     * 接続定義情報をリポジトリに保存します。
     * <p>
     * 接続定義情報及びデータベース接続情報をリポジトリに保存します。</p>
     * 
     * @param dto DbConnectDefinitionDTO
     * @throws ApplicationDomainLogicException
     */
    public void save(final DbConnectDefinitionDTO dto)
            throws ApplicationDomainLogicException {

        final ConnectDefinisionDTO def = new ConnectDefinisionDTO();
        def.setConnectDefinisionId(dto.getConnectDefinitionId());
        def.setConnectDefinisionLabel(dto.getConnectDefinitionName());
        final ConnectDefinisionDAO defDao = createConnectDefinisionDAO();
        try {
            defDao.save(def);
        } catch (final DAOException e) {
//            throw new ApplicationDomainLogicException(
//                    "接続定義情報の保存に失敗しました。", e);
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

        final DbConnectInfomationDTO info = new DbConnectInfomationDTO();
        info.setServerId(dto.getServerId());
        info.setPortId(dto.getPort());
        info.setDatabaseId(dto.getDatabaseId());
        info.setUserId(dto.getPid());
        info.setPassword(dto.getPassword());
        info.setDatabaseTypeConnectionDestination(dto.getDatabaseTypeConnectionDestination());
        info.setUseDatabaseUrl(dto.isUseDatabaseUrl());
        info.setDatabaseUrl(dto.getDatabaseUrl());
        info.setInstanceName(dto.getInstanceName());
        final DbConnectInfomationDAO dbDao = createDbConnectInfomationDAO();
        try {
            dbDao.save(dto.getConnectDefinitionId(), info);
        } catch (final DAOException e) {
//            throw new ApplicationDomainLogicException(
//                    "データベース接続情報の保存に失敗しました。",
//                    e);
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * PreservationOfConnectDefinitionLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public PreservationOfConnectDefinitionLogic() {
        return;
    }

    /**
     * 接続定義情報 DAO を生成して戻す。
     * 
     * @return ConnectDefinisionDAO
     * @throws ApplicationDomainLogicException
     */
    private ConnectDefinisionDAO createConnectDefinisionDAO()
            throws ApplicationDomainLogicException {
        try {
            return (ConnectDefinisionDAO)createDAO("ConnectDefinisionDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * データベースの接続情報 DAO を生成して戻す。
     * 
     * @return DbConnectInfomationDAO
     * @throws ApplicationDomainLogicException
     */
    private DbConnectInfomationDAO createDbConnectInfomationDAO()
            throws ApplicationDomainLogicException {
        try {
            return (DbConnectInfomationDAO)createDAO("DbConnectInfomationDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

}
