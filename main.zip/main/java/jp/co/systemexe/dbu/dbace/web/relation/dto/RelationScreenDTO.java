/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.relation.dto;

import java.io.Serializable;

import lombok.Data;

/**
 * @author  tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationScreenDTO  implements Serializable {
	private static final long serialVersionUID = 1L;
	private String connectDefinitionId;
    private String tableFormMultiTableId;
    private String tableFormMultiTableLabel;

    public RelationScreenDTO(){

    }
    /**
     * @param tableFormMultiTableId
     * @param tableFormMultiTableLabel
     */
    public RelationScreenDTO(String connectDefinitionId,String tableFormMultiTableId,String tableFormMultiTableLabel){
    	this.connectDefinitionId = connectDefinitionId;
    	this.tableFormMultiTableId = tableFormMultiTableId;
    	this.tableFormMultiTableLabel = tableFormMultiTableLabel;
    }
}
