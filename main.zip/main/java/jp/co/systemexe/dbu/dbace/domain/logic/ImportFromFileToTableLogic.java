/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.util.DefaultValueAnalysis;
import jp.co.systemexe.dbu.dbace.common.util.DefaultValueAnalysis.UpdatePattern;
import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportInformationDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportResultDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.definition.RelationOfJdbcAndHtml;
import jp.co.systemexe.dbu.dbace.persistance.dao.BaseConnectionManager;
import jp.co.systemexe.dbu.dbace.persistance.dao.ConnectionManagerFactory;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.TableIdDefinition;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseInputFileDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.InputToCsvOrTsvDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.InputToExcelDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.message.OracleMessageWrapper;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;
import jp.co.systemexe.dbu.dbace.presentation.UploadFileType;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;
import jp.co.systemexe.dbu.dbace.presentation.check.LogicalCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.record.dto.StatusCountDTO;

/**
 * 指定のファイルを読み込み、テーブルへデータとインポート（登録、更新）します。
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class ImportFromFileToTableLogic {
	/**
	 * ロガーへの参照を保持します。
	 */
	private final Logger logger;

	/**
	 * エラー情報を格納する最大件数
	 */
	private static final int MAX_OUTPUT_ERROR_COUNT = 1000;

	/**
	 * データの処理件数、エラーとなった情報を保持するDTO
	 */
	private FileImportResultDTO fileImportResultDTO;

	/**
	 * 入力制約エラー件数
	 */
	private int validateErrorCount = 0;

	/**
	 * 登録成功件数
	 */
	private int insertSuccessCount = 0;

	/**
	 * 更新成功件数
	 */
	private int updateSuccessCount = 0;

	/**
	 * 登録失敗件数
	 */
	private int insertErrorCount = 0;

	/**
	 * 更新失敗件数
	 */
	private int updateErrorCount = 0;

	/**
	 * 指定のファイルを読み込み、テーブルへデータとインポート（登録、更新）します。
	 *
	 * @param dto
	 * @param stream
	 * @param connectionUserLabel
	 * @param isExcel
	 * @throws ApplicationDomainLogicException
	 */
	public String imports(final String connectDefinitionId,
			final FileImportInformationDTO importDTO,
			final InputStream stream, final UserInfo userInfo
			)
			throws ApplicationDomainLogicException {

		BaseConnectionManager manager = null;
		Connection connection = null;
		PreparedStatement selectStatment = null;
		PreparedStatement insertStatment = null;
		PreparedStatement updateStatment = null;
		BaseInputFileDAO dao = null;
		
		UploadFileType uploadFileType = importDTO.getUploadFileType();

		boolean isException = false;
		final RecordEditorInformationDTO dto = importDTO.getRecordEditorInformationDTO();
		final DbConnectInfomationDTO dbConnectInfomationDTO = dto.getDbConnectInfomationDTO();
		final TableFormDTO tableForm = dto.getTableForm();
		try {
			final TableDefinitionDTO tableDef = dto.getTableDef();

			dao = createDAO(stream, importDTO.getUploadFileType(), tableForm,
					importDTO.getFileEncode());

			final List<String> columnIdList = dao.getColumnIdList();

			final List<String> insertColumnIdList = new ArrayList<String>(columnIdList);
			final List<String> updateColumnIdList = new ArrayList<String>(columnIdList);

			manager = ConnectionManagerFactory
					.createConnectionManager(dbConnectInfomationDTO
							.getDatabaseTypeConnectionDestination());
			connection = manager.getConnection(dbConnectInfomationDTO);

			connection.setAutoCommit(false);

			RetrievalProcessingOfRecordFromDatabaseLogic rplogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			final ColumnDisplayDefinitionDTO columnDef
				= rplogic.getColumnDisplayDefinition(connectDefinitionId, tableForm.getTableFormId(), tableDef,userInfo.getId());
			for(final Entry<String, TableItemDTO> itemDef : columnDef.getItemDefinitions().entrySet()){
				final String defaultValue = itemDef.getValue().getDefaultValue();
		        final DefaultValueAnalysis compiler = new DefaultValueAnalysis(userInfo);
		        String insertReplaceData = compiler.analysis(defaultValue, UpdatePattern.INSERT, "");
		        String updateReplaceData = compiler.analysis(defaultValue, UpdatePattern.UPDATE, "");

				if (!StringUtils.isEmpty(insertReplaceData) && !columnIdList.contains(itemDef.getKey())){
					insertColumnIdList.add(itemDef.getKey());
				}
				if (!StringUtils.isEmpty(updateReplaceData) && !columnIdList.contains(itemDef.getKey())){
					updateColumnIdList.add(itemDef.getKey());
				}
			}			
			
			final List<String> updatKeyList = tableForm.getUpdateKeyList();
			final String tableId = tableForm.getTableFormId();
			final Map<String, DefinitionOfColumn> defMap = tableDef.getDefinitionOfColumnMap();
			final DatabaseTypeConnectionDestination dbType = dbConnectInfomationDTO.getDatabaseTypeConnectionDestination();
			//AutoIncrement
			changeAutoIncrement(tableId, dto.getTableDef(), dbType, connection, true);			
			//select statment
			final String selectSQL = createSelectCountSql(updatKeyList, tableId, dbType);
			selectStatment = connection.prepareStatement(selectSQL);
			//insert statment
			final String insertSQL = createInsertSql(insertColumnIdList, tableId, defMap, dbType);
			insertStatment = connection.prepareStatement(insertSQL);
			//update statment
			final String updateSQL = createUpdateSql(updateColumnIdList, updatKeyList, tableId, defMap, dbType);
			updateStatment = connection.prepareStatement(updateSQL);

			final LogicalCheckCommand logicalCheckCommand = new LogicalCheckCommand(columnDef);
			Map<String, TableItemDTO>  tableItemMap = tableForm.getTableItemMap();
			int commitCount = 0;
			int recordCount = 2; // レコード件数はヘッダの次の行(2)から始まる(
			while (dao.hasNext()) {
				final Map<String, String> columnData = dao.read(columnIdList);//key=columnId; value=data
				if (columnData.size() == 0) {
					continue;
				}
				//入力制約チェック
				final CheckMessageDTO checkMessageDTO = logicalCheckCommand.checkDataImport(dbConnectInfomationDTO, columnData,tableItemMap);
				/*check format csv or tsv data*/
				this.checkFormatCsvOrTsv(uploadFileType, columnData, checkMessageDTO);
				
				if (checkMessageDTO.hasWarning()) {
					String validateMessage = "";
			        for (final String columnId : columnDef.getColumnNames().values()){//.keySet()) {
			        	if (checkMessageDTO.hasWarning(columnId)){
			        		for (final String message : checkMessageDTO.getMessages(columnId)){
			        			validateMessage += message + System.getProperty("line.separator");
			        			final String str = MessageUtils.getMessage("MI-E-0151");
			        			if(message.equals(str)){
			        				validateMessage = message;
			        				break;
			        			}
			        		}
			        	}
			        }
	        		validateErrorCount++;
					addFileImportResultMessage(recordCount, validateMessage.replaceFirst(System.getProperty("line.separator") + "$", ""));
					recordCount++;
					if (importDTO.isIgnoreError()){
						continue;
					} else {
						break;
					}
				}
            	try{
            		Class<?> cls = Class.forName(String.format("%s.Ext_%s%s",
            				"jp.co.systemexe.dbu.dbace.validator",
            				importDTO.getRecordEditorInformationDTO().getTableForm().getTableFormId().replace('.', '_'),
            				"Validator"));
	            	Method meth = null;
	        		try {
	        			meth = cls.getMethod("validate", new Class[]{Map.class});
	        		} catch (Exception e){
	        			logger.debug(e.getMessage(),e);
	        			e.printStackTrace();
	        		}
	            	try {
	        			meth.invoke(cls.newInstance(), new Object[]{columnData});
	        		} catch (IllegalArgumentException e) {
	        			// TODO 自動生成された catch ブロック
	        			e.printStackTrace();
	            		logger.debug(e.getMessage(),e);
	        		} catch (IllegalAccessException e) {
	        			// TODO 自動生成された catch ブロック
	        			e.printStackTrace();
	            		logger.debug(e.getMessage(),e);
	        		} catch (InvocationTargetException e) {
	        			if (e.getCause() instanceof ApplicationDomainLogicException){
	        				throw (ApplicationDomainLogicException)e.getCause();
	        			}
	        			// TODO 自動生成された catch ブロック
	        			e.printStackTrace();
	            		logger.debug(e.getMessage(),e);
	        		} catch (InstantiationException e) {
	        			// TODO 自動生成された catch ブロック
	        			e.printStackTrace();
	            		logger.debug(e.getMessage(),e);
	        		}
            	} catch (ClassNotFoundException e){
            		logger.debug(e.getMessage(),e);
            	} catch (Exception e){
            		e.printStackTrace();
	        		validateErrorCount++;
					addFileImportResultMessage(recordCount, e.getMessage());
					recordCount++;
					if (importDTO.isIgnoreError()){
						continue;
					} else {
						break;
					}
            	}

				final boolean result
					= doExecuteUpdate(
						insertStatment,
						updateStatment,
						selectStatment,
						userInfo,
//						columnIdList,
						insertColumnIdList,
						updateColumnIdList,
						columnDef,
						columnData,
						tableForm,
						tableDef,
						importDTO.isIgnoreError(),
						importDTO.isSuperscribeUpdate(), recordCount);

				if (!result) {
					break;
				}

				commitCount++;
				if (commitCount == 100) {
					connection.commit();
					commitCount = 0;
				}
				recordCount++;
			}
			connection.commit();

			fileImportResultDTO.setValidateErrorCount(validateErrorCount);
			fileImportResultDTO.setInsertSuccessCount(insertSuccessCount);
			fileImportResultDTO.setInsertErrorCount(insertErrorCount);
			fileImportResultDTO.setUpdateSuccessCount(updateSuccessCount);
			fileImportResultDTO.setUpdateErrorCount(updateErrorCount);
			fileImportResultDTO.setTotalCount(validateErrorCount + insertSuccessCount
					+ insertErrorCount + updateSuccessCount + updateErrorCount);

			final PreservationOfFileImportResultLogic logic = new PreservationOfFileImportResultLogic();

			return logic.save(fileImportResultDTO);
		} catch (final DAOException e) {
			if (connection != null) {
				try {
					connection.rollback();
				} catch (final SQLException se) {
					this.logger.warn(se);
				}
			}

			isException = true;

			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} catch (final SQLException e) {
			if (connection != null) {
				try {
					connection.rollback();
				} catch (final SQLException se) {
					this.logger.warn(se);
				}
			}

			// MI-E-0032=データベースの接続に失敗しました。({0})
			final String message = OracleMessageWrapper.getWrapMessage(e
					.getErrorCode(), e.getMessage(), "MI-E-0032");
			logger.error(message, e);

			isException = true;

			throw new ApplicationDomainLogicException(message, e);
		} finally {
			if (insertStatment != null) {
				try {
					insertStatment.close();
				} catch (final SQLException e) {
					this.logger.warn(e);
				}
			}

			if (updateStatment != null) {
				try {
					updateStatment.close();
				} catch (final SQLException e) {
					this.logger.warn(e);
				}
			}

			if (connection != null) {
				try {
					changeAutoIncrement(
							tableForm.getTableFormId(),
							dto.getTableDef(),
							dbConnectInfomationDTO.getDatabaseTypeConnectionDestination(),
							connection,
							false);
				} catch (DAOException e) {
					this.logger.warn(e);
				}
				try {
					connection.commit();
				} catch (final SQLException se) {
					this.logger.warn(se);
				}
			}

			if (manager != null) {
				manager.close();
			}

			if (dao != null) {
				dao.close();
			}

			fileImportResultDTO.setValidateErrorCount(validateErrorCount);
			fileImportResultDTO.setInsertSuccessCount(insertSuccessCount);
			fileImportResultDTO.setInsertErrorCount(insertErrorCount);
			fileImportResultDTO.setUpdateSuccessCount(updateSuccessCount);
			fileImportResultDTO.setUpdateErrorCount(updateErrorCount);
			fileImportResultDTO.setTotalCount(insertSuccessCount
					+ insertErrorCount + updateSuccessCount + updateErrorCount);

			outputAuditLog(importDTO.getRecordEditorInformationDTO()
					.getDbConnectInfomationDTO().getDatabaseId(), importDTO
					.getRecordEditorInformationDTO().getTableForm()
					.getTableFormId(), userInfo, !isException, connectDefinitionId);
		}
	}


	/**
	 * @param connectDefinitionId
	 * @param tableFormMultiTableId
	 * @return
	 * @throws DAOException
	 */
	public TableFormDto getTableMulti(String connectDefinitionId, String tableFormMultiTableId) throws DAOException {
		// TODO Auto-generated method stub
		AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
		try {
			TableFormDAO tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
			TableFormDto dto = new TableFormDto();
			dto.setId(tableFormMultiTableId);
			TableForm tableForm = tableFormDAO.getTargetTableFormMulti(connectDefinitionId, dto);
			return new TableFormDto(tableForm);
		} catch (ApplicationDomainLogicException e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	/**
	 * @param connectDefinitionId
	 * @param tableId
	 * @param importDTO
	 * @param stream
	 * @param userInfo
	 * @return
	 * @throws ApplicationDomainLogicException
	 * @throws SQLException
	 * @throws DAOException
	 */
	public String importsMultiTable(
			final String connectDefinitionId,
			final String tableId,
			final FileImportInformationDTO importDTO,
			final InputStream stream, 
			final UserInfo userInfo) 
					throws ApplicationDomainLogicException {		
		int recordCount = 2; // レコード件数はヘッダの次の行(2)から始まる(
		final TableNameListIsAcquiredFromRepositoryLogic logicTable = new TableNameListIsAcquiredFromRepositoryLogic();
		TableFormDTO tableFormDTO = logicTable.getTableFormDTO(connectDefinitionId, tableId);
		BaseConnectionManager manager = null;
		Connection connection = null;
		PreparedStatement selectStatment = null;
		PreparedStatement insertStatment = null;
		PreparedStatement updateStatment = null;
		BaseInputFileDAO dao = null;
		UploadFileType uploadFileType = importDTO.getUploadFileType();
		try {
		dao = createDAO(stream, importDTO.getUploadFileType(), tableFormDTO,importDTO.getFileEncode());
		//list column in file import
		//List<String> columnList = dao.getColumnIdList();
		//check column exist in tables : column = "" -->column not exist repository
//			String column = checkColumnExistInTables(tableFormDTO,columnList);
//			if (StringUtils.isNotEmpty(column)) {
//				final String args[] = {column};
//				final String message = MessageUtils.getMessage("MI-E-0133",args);
//				logger.error(message);
//				throw new ApplicationDomainLogicException(message);
//			}
		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		final RetrievalProcessingOfRecordFromDatabaseLogic databaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		final DbConnectInfomationDTO dbConnectInfomationDTO = databaseLogic.getDbConnectInfomation(connectDefinitionId);
		manager = ConnectionManagerFactory.createConnectionManager(dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
		connection = manager.getConnection(dbConnectInfomationDTO);
		connection.setAutoCommit(false);
		// sort fill commitNo
		List<TableDto> tableDtoList = new ArrayList<>(tableFormDTO.getTableMap().values());
		Collections.sort(tableDtoList, new Comparator<TableDto>() {
			@Override
			public int compare(final TableDto o1, final TableDto o2) {
				return o1.getCommitNO().compareTo(o2.getCommitNO());
			}
		});
		Map<String,RecordEditorInformationDTO> recordEditorInformationDTOMap= new HashMap<String,RecordEditorInformationDTO>();
		for (TableDto tableDto : tableDtoList) {
			RecordEditorInformationDTO dto = logic.getRecordEditorInformation(connectDefinitionId, tableDto.getId(),userInfo.getId());
			//update label for column
			for (String columnId : dto.getTableForm().getTableItemMap().keySet()) {
				if (tableFormDTO.getTableItemMap().get(columnId) != null) {
					TableItemDTO tableItemDTO = dto.getTableForm().getTableItemMap().get(columnId);
					TableItemDTO tableItemDTOMulti = tableFormDTO.getTableItemMap().get(columnId);
					setChangeTableItemDTO(tableItemDTO, tableItemDTOMulti);
				}
			}
			recordEditorInformationDTOMap.put(tableDto.getId(), dto);
		}
		//insertStatment,updateStatment
		Map<String,List<PreparedStatement>> statmentMap = new HashMap<String,List<PreparedStatement>>();
		//columnDef
		Map<String,ColumnDisplayDefinitionDTO> columnDefMap = new HashMap<String,ColumnDisplayDefinitionDTO>();
		//columnIdMap
		Map<String,Map<String, Integer>> columnMap = new HashMap<String,Map<String, Integer>>();
		for (TableDto tableDto : tableDtoList) {
			RecordEditorInformationDTO dto = recordEditorInformationDTOMap.get(tableDto.getId());
			final List<String> columnIdList = new ArrayList<String>(dto.getTableForm().getTableItemMap().keySet());
			final List<String> insertColumnIdList = new ArrayList<String>(columnIdList);
			final List<String> updateColumnIdList = new ArrayList<String>(columnIdList);
			Map<String, Integer> columnIdMap  = dao.getMultiColumnIdList(tableFormDTO.getTableItemMap(),columnIdList,tableDto);
			columnMap.put(tableDto.getId(),columnIdMap);
			final TableFormDTO tableForm = dto.getTableForm();
			final TableDefinitionDTO tableDef = dto.getTableDef();
			RetrievalProcessingOfRecordFromDatabaseLogic dbLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			ColumnDisplayDefinitionDTO columnDef = dbLogic.getColumnDisplayDefinition(connectDefinitionId, tableForm.getTableFormId(), tableDef,userInfo.getId());
			Map<String, TableItemDTO>  columnDefTemp = new HashMap<String, TableItemDTO>();
			for (String key : columnDef.getItemDefinitions().keySet()) {
				TableItemDTO tableItemDTO = columnDef.getItemDefinitions().get(key);
				String itemId =  tableItemDTO.getItemId();
				if (tableFormDTO.getTableItemMap().get(itemId) != null) {
					TableItemDTO tableItemDTOMulti = tableFormDTO.getTableItemMap().get(itemId);
					setChangeTableItemDTO(tableItemDTO, tableItemDTOMulti);
					columnDefTemp.put(itemId, tableItemDTO);
				}
			}
			columnDef.setItemDefinitions(columnDefTemp);
			for(final Entry<String, TableItemDTO> itemDef : columnDef.getItemDefinitions().entrySet()){
				final String defaultValue = itemDef.getValue().getDefaultValue();
		        final DefaultValueAnalysis compiler = new DefaultValueAnalysis(userInfo);
		        String insertReplaceData = compiler.analysis(defaultValue, UpdatePattern.INSERT, "");
		        String updateReplaceData = compiler.analysis(defaultValue, UpdatePattern.UPDATE, "");
				if (!StringUtils.isEmpty(insertReplaceData) && !columnIdMap.keySet().contains(itemDef.getKey())){
					insertColumnIdList.add(itemDef.getKey());
				}
				if (!StringUtils.isEmpty(updateReplaceData) && !columnIdMap.keySet().contains(itemDef.getKey())){
					updateColumnIdList.add(itemDef.getKey());
				}
			}
			
			final List<String> updatKeyList = tableForm.getUpdateKeyList();
			final String tableId1 = tableForm.getTableFormId();
			final Map<String, DefinitionOfColumn> defMap = tableDef.getDefinitionOfColumnMap();
			final DatabaseTypeConnectionDestination dbType = dbConnectInfomationDTO.getDatabaseTypeConnectionDestination();	
			
			changeAutoIncrement(tableId1, dto.getTableDef(), dbType, connection, true);
			insertStatment = connection.prepareStatement(createInsertSql(insertColumnIdList, tableId1, defMap, dbType));
			updateStatment = connection.prepareStatement(createUpdateSql(updateColumnIdList, updatKeyList, tableId1, defMap, dbType));
			selectStatment = connection.prepareStatement(createSelectCountSql(updatKeyList, tableId1, dbType));
			List<PreparedStatement> preparedStatementList = new ArrayList<PreparedStatement>();
			preparedStatementList.add(0, insertStatment);
			preparedStatementList.add(1, updateStatment);
			preparedStatementList.add(2, selectStatment);
			statmentMap.put(tableDto.getId(),preparedStatementList);
			columnDefMap.put(tableDto.getId(),columnDef);
		}
		while (dao.hasNext()) {
			//2.begin transaction
			boolean updateErrorCount,updateSuccessCount,insertErrorCount,insertSuccessCount;
			StatusCountDTO statusCount = new StatusCountDTO(false,false,false,false,false);
			boolean validateErrorCountTemp = false;
			boolean notIgnoreError= false;
			for (TableDto tableDto : tableDtoList) {
				RecordEditorInformationDTO dto = recordEditorInformationDTOMap.get(tableDto.getId());
				final List<String> columnIdList = new ArrayList<String>(dto.getTableForm().getTableItemMap().keySet());
				final List<String> insertColumnIdList = new ArrayList<String>(columnIdList);
				final List<String> updateColumnIdList = new ArrayList<String>(columnIdList);
				Map<String, Integer> columnIdMap  = columnMap.get(tableDto.getId());
				final Map<String, String> columnData = dao.readMulti(columnIdMap);
				final ColumnDisplayDefinitionDTO columnDef = columnDefMap.get(tableDto.getId());
				final LogicalCheckCommand logicalCheckCommand = new LogicalCheckCommand(columnDef);
				if (columnData.size() == 0) {
					continue;
				}
				//入力制約チェック
				final CheckMessageDTO checkMessageDTO = logicalCheckCommand.checkDataImport(dbConnectInfomationDTO, columnData,dto.getTableForm().getTableItemMap());
				/*check format csv or tsv data*/
				this.checkFormatCsvOrTsv(uploadFileType, columnData, checkMessageDTO);
				if (checkMessageDTO.hasWarning()) {
					String validateMessage = "";
			        for (final String columnId : columnDef.getColumnNames().values()){
			        	if (checkMessageDTO.hasWarning(columnId)){
			        		for (final String message : checkMessageDTO.getMessages(columnId)){
			        			validateMessage += message + System.getProperty("line.separator");
			        		}
			        	}
			        }
	        		validateErrorCountTemp = true;
					addFileImportResultMessage(recordCount, validateMessage.replaceFirst(System.getProperty("line.separator") + "$", ""));
					connection.rollback();
					if (importDTO.isIgnoreError()){
						continue;
					} else {
						notIgnoreError = true;
						break;
					}
				}
				insertStatment = statmentMap.get(tableDto.getId()).get(0);
				updateStatment = statmentMap.get(tableDto.getId()).get(1);
				selectStatment = statmentMap.get(tableDto.getId()).get(2);
				final TableFormDTO tableForm = dto.getTableForm();
				final TableDefinitionDTO tableDef = dto.getTableDef();
				statusCount = doExecuteUpdateMulti(
						insertStatment,
						updateStatment,
						selectStatment,
						userInfo,
						insertColumnIdList,
						updateColumnIdList,
						columnDef,
						columnData,
						tableForm,
						tableDef,
						importDTO.isIgnoreError(),
						importDTO.isSuperscribeUpdate(), recordCount);
				final boolean result = statusCount.isOK();
				if (!result) {
					insertErrorCount = statusCount.isInsertErrorCount();
					if(insertErrorCount){
						this.insertErrorCount++;
					}
					updateErrorCount  = statusCount.isUpdateErrorCount();
					if(updateErrorCount){
						this.updateErrorCount++;
					}
					connection.rollback();
					notIgnoreError = true;
					break;
				}
			}
			if (notIgnoreError) {
				break;
			}
			recordCount++;
			if (validateErrorCountTemp) {
				this.validateErrorCount++;
				statusCount.setUpdateSuccessCount(false);
				statusCount.setInsertSuccessCount(false);
				connection.rollback();
			} else {
				//4.end transaction
				connection.commit();
			}
			updateSuccessCount = statusCount.isUpdateSuccessCount();
			if(updateSuccessCount){
				this.updateSuccessCount++;
			}
			insertSuccessCount = statusCount.isInsertSuccessCount();
			if(insertSuccessCount){
				this.insertSuccessCount++;
			}
			insertErrorCount = statusCount.isInsertErrorCount();
			if(insertErrorCount){
				this.insertErrorCount++;
			}
			updateErrorCount  = statusCount.isUpdateErrorCount();
			if(updateErrorCount){
				this.updateErrorCount++;
			}
		}
		fileImportResultDTO.setInsertSuccessCount(insertSuccessCount);
		fileImportResultDTO.setValidateErrorCount(validateErrorCount);
		fileImportResultDTO.setInsertErrorCount(insertErrorCount);
		fileImportResultDTO.setUpdateSuccessCount(updateSuccessCount);
		fileImportResultDTO.setUpdateErrorCount(updateErrorCount);
		fileImportResultDTO.setTotalCount(validateErrorCount + insertSuccessCount + insertErrorCount + updateSuccessCount + updateErrorCount);
		final PreservationOfFileImportResultLogic logicSave = new PreservationOfFileImportResultLogic();
		return logicSave.save(fileImportResultDTO);
		} catch (final DAOException | SQLException | ApplicationDomainLogicException e) {
			try {
				if (connection != null) {
					connection.rollback();
				}
			} catch (final SQLException se) {
				this.logger.warn(se);
			}
			logger.error(e.getMessage(), e);
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} finally {
			if (insertStatment != null) {
				try {
					insertStatment.close();
				} catch (final SQLException e) {
					this.logger.warn(e);
				}
			}
			if (updateStatment != null) {
				try {
					updateStatment.close();
				} catch (final SQLException e) {
					this.logger.warn(e);
				}
			}
			if (manager != null) {
				manager.close();
			}
			if (dao != null) {
				dao.close();
			}
		}
	}


	/**
	 * @param columnList
	 * @return
	 */
//	private String checkColumnExistInTables(TableFormDTO tableFormDTO,List<String> columnList) {
//		for (String columnFile : columnList) {
//			boolean isColumnExist = false;
//			for (String columnId : tableFormDTO.getTableItemMap().keySet()) {
//				TableItemDTO tableItemDTO = tableFormDTO.getTableItemMap().get(columnId);
//				if (tableItemDTO != null) {
//					String columnLabel = tableItemDTO.getItemLabel();
//					if (columnFile.equalsIgnoreCase(columnLabel)) {
//						isColumnExist = true;
//						break;
//					}
//				}
//			}
//			if (!isColumnExist) {
//				return columnFile;
//			}
//		}
//		return "";
//	}


	/**
	 * @param tableItemDTO
	 * @param tableItemDTOMulti
	 */
	private void setChangeTableItemDTO(TableItemDTO tableItemDTO,
			TableItemDTO tableItemDTOMulti) {
		tableItemDTO.setItemLabel(tableItemDTOMulti.getItemLabel());
		tableItemDTO.setHtmlElement(tableItemDTOMulti.getHtmlElement());
		tableItemDTO.setSelectableItems(tableItemDTOMulti.getSelectableItems());
		tableItemDTO.setSqlString(tableItemDTOMulti.getSqlString());
		tableItemDTO.setParametersSql(tableItemDTOMulti.getParametersSql());
		tableItemDTO.getItemRestrictions().clear();
		tableItemDTO.getItemRestrictions().putAll(tableItemDTOMulti.getItemRestrictions());
		tableItemDTO.setDefaultValue(tableItemDTOMulti.getDefaultValue());
		tableItemDTO.setExplanation(tableItemDTOMulti.getExplanation());
		tableItemDTO.setPreview(tableItemDTOMulti.canPreview());
		tableItemDTO.setDisplayRecordEdit(tableItemDTOMulti.canDisplayRecordEdit());
		tableItemDTO.setDisplayNamePreview(tableItemDTOMulti.canDisplayNamePreview());
		tableItemDTO.setEditing(tableItemDTOMulti.canEditing());
		tableItemDTO.setUpdateKey(tableItemDTOMulti.isUpdateKey());
		tableItemDTO.setSelectKey(tableItemDTOMulti.isSelectKey());
		tableItemDTO.setPrimaryKey(tableItemDTOMulti.getPrimaryKey());
		tableItemDTO.setUnique(tableItemDTOMulti.getUnique());
		tableItemDTO.setForeignKey(tableItemDTOMulti.getForeignKey());
		tableItemDTO.setDataType(tableItemDTOMulti.getDataType());
		tableItemDTO.setDataLength(tableItemDTOMulti.getDataLength());
		tableItemDTO.setDataUnit(tableItemDTOMulti.getDataUnit());
	}

	/**
	 * 監査イベントログを出力します
	 */
	private void outputAuditLog(final String databaseId, final String tableId,
			final UserInfo userInfo,
			final boolean isSuccess,
			final String connectDefinisionId) {
		final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
		try {
			OutputAuditLog.writeImportLog(AuditEventKind.IMPORT, userInfo,
					databaseId,
					connectDefinitionListLogic.getTableForm(connectDefinisionId, tableId).getLabel(),
					isSuccess ? AuditStatus.success
							: AuditStatus.failure, fileImportResultDTO
							.getTotalCount(), fileImportResultDTO
							.getValidateErrorCount(), fileImportResultDTO
							.getInsertSuccessCount(), fileImportResultDTO
							.getInsertErrorCount(), fileImportResultDTO
							.getUpdateSuccessCount(), fileImportResultDTO
							.getUpdateErrorCount());
		} catch (ApplicationDomainLogicException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * ファイル読み込みようのDAOを生成します。
	 *
	 * @param stream
	 * @param isExcel
	 * @param tableForm
	 * @return
	 * @throws DAOException
	 */
	private BaseInputFileDAO createDAO(final InputStream stream,
			final UploadFileType fileType, final TableFormDTO tableForm,
			final String fileEncode) throws DAOException {
		final BaseInputFileDAO dao;
		if (fileType == UploadFileType.EXCEL || fileType == UploadFileType.NEWEXCEL) {
			dao = new InputToExcelDAO(stream, tableForm);
		} else {
			dao = new InputToCsvOrTsvDAO(stream, fileType, fileEncode,
					tableForm);
		}
		return dao;
	}

	/**
	 * 登録処理、更新処理を行います。
	 * <p>
	 * 登録処理に失敗した場合に、更新を行います。
	 * </p>
	 *
	 * @param insertStatment
	 * @param updateStatment
	 * @param columnIdList
	 * @param columnData
	 * @param tableForm
	 * @param tableDef
	 * @param isIgnoreError
	 * @param isSuperscribeUpdate
	 * @throws ApplicationDomainLogicException
	 */
	private boolean doExecuteUpdate(
			final PreparedStatement insertStatment,
			final PreparedStatement updateStatment,
			final PreparedStatement selectStatment,
			final UserInfo userInfo,
//			final List<String> columnIdList,
			final List<String> insertColumnIdList,
			final List<String> updateColumnIdList,
			final ColumnDisplayDefinitionDTO columnDef,
			final Map<String, String> columnData, final TableFormDTO tableForm,
			final TableDefinitionDTO tableDef, final boolean isIgnoreError,
			final boolean isSuperscribeUpdate, final int recordCount)
			throws ApplicationDomainLogicException {		
		//counting data before insert or update --BEGIN
		final int selectCount = doSelectCount(selectStatment, columnData, tableForm, tableDef);
		//counting data before insert or update --END		
		if(selectCount == 0){//insert
			//insert record --BEGIN--
			final Map<String, String> insertColumnData = createInsertColumnData(columnData,columnDef,userInfo);
			final String insertMessage = doInsert(insertStatment, insertColumnIdList, insertColumnData, tableForm, tableDef);
			if(StringUtils.isBlank(insertMessage)){
				insertSuccessCount++;
			}else{
				insertErrorCount++;
				if (isIgnoreError) {//エラーが発生した場合に、エラーを無視して処理を続行する
					addFileImportResultMessage(recordCount, insertMessage);
				} else {
					// MI-E-0129=データのインポート処理({0})に失敗しました。({1})
					final String args[] = { "登録処理", insertMessage };
					final String message = MessageUtils.getMessage("MI-E-0129", args);
					addFileImportResultMessage(recordCount, message);
					return false;
				}
			}
			//insert record --END--
		} else {//update
			if(isSuperscribeUpdate){//データが存在する場合は、上書き更新する
				//update record --BEGIN--
				final Map<String, String> updateColumnData = createUpdateColumnData(columnData,columnDef,userInfo);
				final String updateMessage = doUpdate(updateStatment, updateColumnIdList, updateColumnData, tableForm, tableDef);
				if(StringUtils.isBlank(updateMessage)){
					insertSuccessCount++;
				} else {
					insertErrorCount++;
					if (isIgnoreError) {//エラーが発生した場合に、エラーを無視して処理を続行する
						addFileImportResultMessage(recordCount, updateMessage);
					} else {
						// MI-E-0129=データのインポート処理({0})に失敗しました。
						final String args[] = { "更新処理", updateMessage };
						final String message = MessageUtils.getMessage("MI-E-0129", args);
						addFileImportResultMessage(recordCount, message);
						return false;
					}
				}
				//update record --END--
			} else {
				// MI-E-0129=データのインポート処理({0})に失敗しました。
				final String message = MessageUtils.getMessage("MI-E-00791");
				addFileImportResultMessage(recordCount, message);
				return false;
			}
		}
		return true;
//		//insert record --BEGIN--
//		final Map<String, String> insertColumnData = createInsertColumnData(columnData,columnDef,userInfo);
//		final String insertMessage = doInsert(insertStatment, insertColumnIdList, insertColumnData, tableForm, tableDef);
//		//insert record --END--
//		if (insertMessage.length() != 0) {
//			if (isSuperscribeUpdate) {
//				//update record --BEGIN--
//				final Map<String, String> updateColumnData = createUpdateColumnData(columnData,columnDef,userInfo);
//				final String updateMessage = doUpdate(updateStatment, updateColumnIdList, updateColumnData, tableForm, tableDef);
//				//update record --END--
//				if (updateMessage.length() != 0) {
//					updateErrorCount++;
//					if (isIgnoreError) {
//						addFileImportResultMessage(recordCount, updateMessage);
//					} else {
//						// MI-E-0129=データのインポート処理({0})に失敗しました。
//						final String args[] = { "更新処理", updateMessage };
//						final String message = MessageUtils.getMessage(
//								"MI-E-0129", args);
//						addFileImportResultMessage(recordCount, message);
//						return false;
//					}
//				} else {
//					updateSuccessCount++;
//				}
//			} else {
//				insertErrorCount++;
//				if (isIgnoreError) {
//					addFileImportResultMessage(recordCount, insertMessage);
//				} else {
//					// MI-E-0129=データのインポート処理({0})に失敗しました。({1})
//					final String args[] = { "登録処理", insertMessage };
//					final String message = MessageUtils.getMessage("MI-E-0129",
//							args);
//					addFileImportResultMessage(recordCount, message);
//					return false;
//				}
//			}
//		} else {
//			insertSuccessCount++;
//		}
//		return true;
	}

	/**
	 * 登録処理、更新処理を行います。
	 * <p>
	 * 登録処理に失敗した場合に、更新を行います。
	 * </p>
	 *
	 * @param insertStatment
	 * @param updateStatment
	 * @param columnIdList
	 * @param columnData
	 * @param tableForm
	 * @param tableDef
	 * @param isIgnoreError
	 * @param isSuperscribeUpdate
	 * @throws ApplicationDomainLogicException
	 */
	private StatusCountDTO doExecuteUpdateMulti(
			final PreparedStatement insertStatment,
			final PreparedStatement updateStatment,
			final PreparedStatement selectStatment,
			final UserInfo userInfo,
//			final List<String> columnIdList,
			final List<String> insertColumnIdList,
			final List<String> updateColumnIdList,
			final ColumnDisplayDefinitionDTO columnDef,
			final Map<String, String> columnData, final TableFormDTO tableForm,
			final TableDefinitionDTO tableDef, final boolean isIgnoreError,
			final boolean isSuperscribeUpdate, final int recordCount) throws ApplicationDomainLogicException {
		//counting data before insert or update --BEGIN
		final int selectCount = doSelectCount(selectStatment, columnData, tableForm, tableDef);
		//counting data before insert or update --END		
		if(selectCount == 0){//insert
			//insert record --BEGIN--
			final Map<String, String> insertColumnData = createInsertColumnData(columnData,columnDef,userInfo);
			final String insertMessage = doInsert(insertStatment, insertColumnIdList, insertColumnData, tableForm, tableDef);
			if(StringUtils.isBlank(insertMessage)){
//				insertSuccessCount++;
				return new StatusCountDTO(true,false,false,false,true);
			}else{
//				insertErrorCount++;
				if (isIgnoreError) {//エラーが発生した場合に、エラーを無視して処理を続行する
					addFileImportResultMessage(recordCount, insertMessage);
					return new StatusCountDTO(true,false,false,true,false);
				} else {
					// MI-E-0129=データのインポート処理({0})に失敗しました。({1})
					final String args[] = { "登録処理", insertMessage };
					final String message = MessageUtils.getMessage("MI-E-0129", args);
					addFileImportResultMessage(recordCount, message);
					return new StatusCountDTO(false,false,false,true,false);
				}
			}
			//insert record --END--
		} else{//update
			if(isSuperscribeUpdate){//データが存在する場合は、上書き更新する
				//update record --BEGIN--
				final Map<String, String> updateColumnData = createUpdateColumnData(columnData,columnDef,userInfo);
				final String updateMessage = doUpdate(updateStatment, updateColumnIdList, updateColumnData, tableForm, tableDef);
				if(StringUtils.isBlank(updateMessage)){
//					updateSuccessCount++;
					return new StatusCountDTO(true,false,true,false,false);
				}else{
//					updateErrorCount++;
					if (isIgnoreError) {//エラーが発生した場合に、エラーを無視して処理を続行する
						addFileImportResultMessage(recordCount, updateMessage);
						return new StatusCountDTO(true,true,false,false,false);
					} else {
						// MI-E-0129=データのインポート処理({0})に失敗しました。
						final String args[] = { "更新処理", updateMessage };
						final String message = MessageUtils.getMessage("MI-E-0129", args);
						addFileImportResultMessage(recordCount, message);
						return new StatusCountDTO(false,true,false,false,false);
					}
				}
				//update record --END--
			}else{
				// MI-E-00791=レコードの更新に失敗しました。
				final String message = MessageUtils.getMessage("MI-E-00791");
				addFileImportResultMessage(recordCount, message);
				return new StatusCountDTO(false,true,false,false,false);
			}
		}
//		final Map<String, String> insertColumnData = createInsertColumnData(columnData,columnDef,userInfo);
//		final String insertMessage = doInsert(insertStatment, insertColumnIdList, insertColumnData, tableForm, tableDef);
//		if (insertMessage.length() != 0) {
//			if (isSuperscribeUpdate) {
//				final Map<String, String> updateColumnData = createUpdateColumnData(columnData,columnDef,userInfo);
//				final String updateMessage = doUpdate(updateStatment, updateColumnIdList, updateColumnData, tableForm, tableDef);
//				if (updateMessage.length() != 0) {
////					updateErrorCount++;
//					if (isIgnoreError) {
//						addFileImportResultMessage(recordCount, updateMessage);
//						return new StatusCountDTO(true,true,false,false,false);
//					} else {
//						// MI-E-0129=データのインポート処理({0})に失敗しました。
//						final String args[] = { "更新処理", updateMessage };
//						final String message = MessageUtils.getMessage(
//								"MI-E-0129", args);
//						addFileImportResultMessage(recordCount, message);
//						return new StatusCountDTO(false,true,false,false,false);
//					}
//				} else {
////					updateSuccessCount++;
//					return new StatusCountDTO(true,false,true,false,false);
//				}
//			} else {
////				insertErrorCount++;
//				if (isIgnoreError) {
//					addFileImportResultMessage(recordCount, insertMessage);
//					return new StatusCountDTO(true,false,false,true,false);
//				} else {
//					// MI-E-0129=データのインポート処理({0})に失敗しました。({1})
//					final String args[] = { "登録処理", insertMessage };
//					final String message = MessageUtils.getMessage("MI-E-0129",
//							args);
//					addFileImportResultMessage(recordCount, message);
//					return new StatusCountDTO(false,false,false,true,false);
//				}
//			}
//		} else {
////			insertSuccessCount++;
//			return new StatusCountDTO(true,false,false,false,true);
//		}
////		return true;
	}

	private Map<String, String> createInsertColumnData(
			final Map<String, String> columnData,
			final ColumnDisplayDefinitionDTO columnDef,
			final UserInfo userInfo
			){

		final Map<String, String> map = new HashMap<String, String>();
		for(Map.Entry<String,String> entry : columnData.entrySet()){
			map.put(entry.getKey(), entry.getValue());
		}
		for(final Entry<String, TableItemDTO> itemDef : columnDef.getItemDefinitions().entrySet()){
			final String defaultValue = itemDef.getValue().getDefaultValue();
			if (!StringUtils.isEmpty(defaultValue)){		//デフォルト値設定ありのとき
		        final DefaultValueAnalysis compiler = new DefaultValueAnalysis(userInfo);
		        String replaceData = compiler.analysis(defaultValue, UpdatePattern.INSERT, "");
		        if (StringUtils.isEmpty(replaceData)){
		        	replaceData = ( columnData.containsKey(itemDef.getKey()) ? columnData.get(itemDef.getKey()) : "");
		        }
		        map.put(itemDef.getKey(), replaceData);
			}
		}
		return map;
	}

	private Map<String, String>  createUpdateColumnData(
			final Map<String, String> columnData,
			final ColumnDisplayDefinitionDTO columnDef,
			final UserInfo userInfo
			){
		final Map<String, String> map = new HashMap<String, String>();
		for(Map.Entry<String,String> entry : columnData.entrySet()){
			map.put(entry.getKey(), entry.getValue());
		}
		for(final Entry<String, TableItemDTO> itemDef : columnDef.getItemDefinitions().entrySet()){
			final String defaultValue = itemDef.getValue().getDefaultValue();
			if (!StringUtils.isEmpty(defaultValue)){		//デフォルト値設定ありのとき
		        final DefaultValueAnalysis compiler = new DefaultValueAnalysis(userInfo);
		        String replaceData = compiler.analysis(defaultValue, UpdatePattern.UPDATE, "");
		        if (StringUtils.isEmpty(replaceData)){
		        	replaceData = ( columnData.containsKey(itemDef.getKey()) ? columnData.get(itemDef.getKey()) : "");
		        }
		        map.put(itemDef.getKey(), replaceData);
			}
		}
		return map;
	}

	/**
	 * エラーメッセージをログ出力し、 FileImportResultDTO に格納します。
	 * <p>
	 * エラーメッセージの件数が 1000件以上の場合はログ出力のみを行います。
	 * </p>
	 *
	 * @param recordCount
	 *            エラーとなった行番号
	 * @param message
	 *            エラーメッセージ
	 */
	private void addFileImportResultMessage(final int recordCount,
			final String message) {
		SortedMap<Integer, String> map = fileImportResultDTO.getErrorMessage();
		if (map.containsKey(recordCount)){
			final String errorMessage = map.get(recordCount) + System.getProperty("line.separator") + message;
			if (map.get(recordCount) != null && !message.equals(map.get(recordCount))) {
				fileImportResultDTO.getErrorMessage().put(recordCount, errorMessage);
			}
		} else {
			if (map.size() <= MAX_OUTPUT_ERROR_COUNT) {
				fileImportResultDTO.getErrorMessage().put(recordCount, message);
			}
		}
		logger.error("行数:" + recordCount + ", メッセージ:" + message);
	}
	
	private int doSelectCount(
			final PreparedStatement statment,
			final Map<String, String> columnData, 
			final TableFormDTO tableForm,
			final TableDefinitionDTO tableDef) throws ApplicationDomainLogicException {
		int index = 1;
		try {
			for (final String key : tableForm.getUpdateKeyList()) {
				final String data = columnData.get(key);
				final DefinitionOfColumn definitionOfColumn = tableDef.getDefinitionOfColumnMap().get(key);
				final DefinedHtmlElement htmlElement = tableForm.getTableItemMap().get(key).getHtmlElement();
				if(this.setBinding(statment, key, data, definitionOfColumn, htmlElement, index)) {
					index++;
				}
			}
			ResultSet rs = statment.executeQuery();
			if(rs.next()){
				return Integer.valueOf(rs.getString("count"));
			}
		} catch (SQLException e) {
			throw new ApplicationDomainLogicException(e.getMessage());
		}		
		return 0;
	}

	/**
	 * テーブルの更新処理を行います。
	 *
	 * @param statment
	 * @param columnIdList
	 * @param columnData
	 * @param tableForm
	 * @param tableDef
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private String doUpdate(final PreparedStatement statment,
			final List<String> columnIdList,
			final Map<String, String> columnData, final TableFormDTO tableForm,
			final TableDefinitionDTO tableDef)
			throws ApplicationDomainLogicException {
		int index = 1;
		try {
			for (final String columnId : columnIdList) {
				if (!tableDef.getDefinitionOfColumnMap().get(columnId).isAutoIncrement()) {
					if (setBinding(
							statment,
							columnId,
							columnData.get(columnId),
							tableDef.getDefinitionOfColumnMap().get(columnId),
							tableForm.getTableItemMap().get(columnId).getHtmlElement(),
							index)) {
						index++;
					}
				}
			}

			for (final String key : tableForm.getUpdateKeyList()) {
				if (setBinding(
						statment,
						key,
						columnData.get(key),
						tableDef.getDefinitionOfColumnMap().get(key),
						tableForm.getTableItemMap().get(key).getHtmlElement(),
						index)) {
					index++;
				}
			}
		} catch (final ApplicationDomainLogicException e) {
			return e.getMessage();
		}

		java.sql.Savepoint sp = null;

		try {
			sp = statment.getConnection().setSavepoint();
			if (statment.executeUpdate() == 0) {
				statment.getConnection().rollback(sp);
				// MI-E-0151=更新対象のデータが存在しません。
				return MessageUtils.getMessage("MI-E-0151");
			} else {
				return "";
			}
		} catch (final SQLException e) {
			try {
				statment.getConnection().rollback(sp);
			} catch (SQLException e1) {
				// TODO 自動生成された catch ブロック
				e1.printStackTrace();
			}
			// MI-E-0079=レコードの更新に失敗しました。({0})
			final String message = OracleMessageWrapper.getWrapMessage(e
					.getErrorCode(), e.getMessage(), "MI-E-0079");
			// logger.error(message, e);
			return message;
		}
	}

	/**
	 * テーブルの登録処理を行います。
	 *
	 * @param statmenet
	 * @param columnIdList
	 * @param columnData
	 * @param tableForm
	 * @param tableDef
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private String doInsert(final PreparedStatement statment,
			final List<String> columnIdList,
			final Map<String, String> columnData, final TableFormDTO tableForm,
			final TableDefinitionDTO tableDef)
			throws ApplicationDomainLogicException {
		int index = 1;
		try {
			for (final String columnId : columnIdList) {
				if (setBinding(
						statment,
						columnId,
						columnData.get(columnId),
						tableDef.getDefinitionOfColumnMap().get(columnId),
						tableForm.getTableItemMap().get(columnId).getHtmlElement(),
						index)) {
					index++;
				}
			}
		} catch (final ApplicationDomainLogicException e) {
			return e.getMessage();
		}

		java.sql.Savepoint sp = null;

		try {
			sp = statment.getConnection().setSavepoint();
			statment.executeUpdate();
		} catch (final SQLException e) {
			try {
				statment.getConnection().rollback(sp);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			// MI-E-0097=レコードの登録に失敗しました。({0})
			final String message = OracleMessageWrapper.getWrapMessage(e
					.getErrorCode(), e.getMessage(), "MI-E-0097");
			logger.info("errorcode:" + e.getErrorCode());
			// logger.error(message, e);
			return message;
		}

		return "";
	}
	
	private String createSelectCountSql(
			final List<String> updatKeyList,
			final String tableId,
			final DatabaseTypeConnectionDestination dbType) {
		final TableIdDefinition tableiddefinition = new TableIdDefinition(tableId);
		final String schema = tableiddefinition.getSchem();
		final String table = tableiddefinition.getTable();
		final String schemaAndTable = String.format("\"%s\".\"%s\"", schema, table);
		
		//create clause where --BEGIN
		final StringBuilder whereSql = new StringBuilder();
		for (final String key : updatKeyList) {
			if (whereSql.length() != 0) {
				whereSql.append("and ");
			}
			whereSql.append(String.format("\"%s\"",key));
			whereSql.append(" = ? ");
		}
		//create clause where --END
		
		String result = String.format("SELECT COUNT(*) AS count FROM %s ", schemaAndTable);
		if(whereSql.length() != 0){
			result += String.format("WHERE %s", whereSql);
		}
		//todo リリース直前のためMySQL以外に影響しないようIF文で全体の処理を分割。次版でリファクタリングすること！
  		if (DatabaseTypeConnectionDestination.MySQL == dbType) {
  			result = result.replaceAll("\"", "`");
  		}
  		logger.debug("select sql :" + result);
  		return result;
	}

	/**
	 * insert文を生成します。
	 *
	 * @param columnIdList
	 * @param tableId
	 * @return
	 */
	private String createInsertSql(
			final List<String> columnIdList,
			final String tableId,
			final Map<String, DefinitionOfColumn> defMap,
			final DatabaseTypeConnectionDestination dbType) {
		final StringBuilder columnIdSql = new StringBuilder();
		final StringBuilder columnDataSql = new StringBuilder();
        TableIdDefinition tableiddefinition = new TableIdDefinition(tableId);
        String result = "";        
  		for (final String columnId : columnIdList) {
			final JDBCMetaDataType type = defMap.get(columnId).getJDBCMetaDataType();
			if (RelationOfJdbcAndHtml.metaDataTypeOf(type).isCorrespond()) {
				if (columnIdSql.length() != 0) {
					columnIdSql.append(",");
					columnDataSql.append(",");
				}
				columnIdSql.append(String.format("\"%s\"",columnId));
				columnDataSql.append("?");
			}
		}
		final StringBuilder sql = new StringBuilder();
		sql.append("insert into ");
		sql.append(String.format("\"%s\".\"%s\"",tableiddefinition.getSchem(), tableiddefinition.getTable()));
		sql.append(" (");
		sql.append(columnIdSql);
		sql.append(") values (");
		sql.append(columnDataSql);
		sql.append(")");
		result = sql.toString();
		//todo リリース直前のためMySQL以外に影響しないようIF文で全体の処理を分割。次版でリファクタリングすること！
  		if (DatabaseTypeConnectionDestination.MySQL == dbType) {
  			result = result.replaceAll("\"", "`");
  		}
  		logger.debug("insert sql :" + result);
		return result;
	}

	/**
	 * update 文を生成します。
	 *
	 * @param columnIdList
	 * @param updatKeyList
	 * @param tableId
	 * @return
	 */
	private String createUpdateSql(
			final List<String> columnIdList,
			final List<String> updatKeyList,
			final String tableId,
			final Map<String, DefinitionOfColumn> defMap,
			final DatabaseTypeConnectionDestination dbType
		) {
		final StringBuilder setSql = new StringBuilder();
        TableIdDefinition tableiddefinition = new TableIdDefinition(tableId);
        String result = "";        
        for (final String columnId : columnIdList) {
			final DefinitionOfColumn definitionOfColumn = defMap.get(columnId);
			final JDBCMetaDataType type = defMap.get(columnId).getJDBCMetaDataType();
			if (RelationOfJdbcAndHtml.metaDataTypeOf(type).isCorrespond()) {
				if (!definitionOfColumn.isAutoIncrement()) {
					if (setSql.length() == 0) {
						setSql.append("set ");
					} else {
						setSql.append(",");
					}
					setSql.append(String.format("\"%s\"",columnId));
					setSql.append(" = ?");
				}
			}
		}
		final StringBuilder whereSql = new StringBuilder();
		for (final String key : updatKeyList) {
			if (whereSql.length() != 0) {
				whereSql.append("and ");
			}
			whereSql.append(String.format("\"%s\"",key));
			whereSql.append(" = ? ");
		}
		final StringBuffer sql = new StringBuffer();
		sql.append("update ");
		sql.append(String.format("\"%s\".\"%s\"",tableiddefinition.getSchem(), tableiddefinition.getTable()));
		sql.append(" ");
		sql.append(setSql);
		if(whereSql.length() != 0){
			sql.append(" where ");
			sql.append(whereSql);
		}		
		result = sql.toString();
		//todo リリース直前のためMySQL以外に影響しないようIF文で全体の処理を分割。次版でリファクタリングすること！
  		if (DatabaseTypeConnectionDestination.MySQL == dbType) {
  			result = result.replaceAll("\"", "`");
  		}
		logger.debug("update sql :" + result);
		return result;
	}

	/**
	 * 指定のSQL(PreparedStatment)に値をバインドします。
	 *
	 * @param statment
	 * @param columnId
	 * @param columnData
	 * @param type
	 * @param element
	 * @param index
	 * @throws ApplicationDomainLogicException
	 */
	private boolean setBinding(final PreparedStatement statment,
			final String columnId, final String columnData,
			final DefinitionOfColumn definitionOfColumn, final DefinedHtmlElement element,
			final int index) throws ApplicationDomainLogicException {
		final JDBCMetaDataType type = definitionOfColumn.getJDBCMetaDataType();
		final String columnTypeName = definitionOfColumn.getColumnTypeName();
		try {
			SimpleDateFormat sdf = null;
			if (DefinedHtmlElement.INPUT_DATE == element) {
				sdf = new SimpleDateFormat("yyyy/MM/dd");
			} else if (DefinedHtmlElement.INPUT_DATETIME == element) {
				sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			} else if (DefinedHtmlElement.INPUT_TIMESTAMP == element) {
				sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
			} else if (DefinedHtmlElement.INPUT_TIME == element) {
				sdf = new SimpleDateFormat("HH:mm:ss");
			}

			if (!RelationOfJdbcAndHtml.metaDataTypeOf(type).isCorrespond()) {
				// TODO 非対応だが、方式を検討するか...？
				return false;
			} else if (JDBCMetaDataType.BIGINT == type) {
				if (columnData == null || columnData.equals("")) {
					statment.setNull(index, type.getDataType());
				} else {
					// MOD 日付、数値型を変更しインポートするとエラーとなる部分を対応　↓
					//statment.setLong(index, Long.valueOf(columnData));
					statment.setLong(index, Double.valueOf(columnData).longValue());
					// MOD 日付、数値型を変更しインポートするとエラーとなる部分を対応　↑
				}
			} else if (JDBCMetaDataType.VARCHAR == type
					|| JDBCMetaDataType.CHAR == type
					|| JDBCMetaDataType.NVARCHAR == type
					|| JDBCMetaDataType.NCHAR == type
					|| JDBCMetaDataType.LONGVARCHAR == type) {
				if (columnData == null) {
					statment.setNull(index, type.getDataType());
				} else if (columnData.equals("")) {
					statment.setString(index, "");
				} else {
					statment.setString(index, columnData);
				}
			} else if (JDBCMetaDataType.BIT == type) {
				if (columnData == null || columnData.equals("")) {
					statment.setNull(index, type.getDataType());
				} else {
					statment.setBoolean(index,
							(columnData.equals("1") || columnData
									.equals("true")));
				}
			} else if (JDBCMetaDataType.TINYINT == type
					|| JDBCMetaDataType.SMALLINT == type) {
				if (columnData == null || columnData.equals("")) {
					statment.setNull(index, type.getDataType());
				} else {
					statment.setShort(index, Short.valueOf(columnData));
				}
			} else if (JDBCMetaDataType.INTEGER == type) {
				if (columnData == null || columnData.equals("")) {
					statment.setNull(index, type.getDataType());
				} else {
					// MOD 日付、数値型を変更しインポートするとエラーとなる部分を対応　↓
					//statment.setInt(index, Integer.valueOf(columnData));
					statment.setInt(index, Double.valueOf(columnData).intValue());
					// MOD 日付、数値型を変更しインポートするとエラーとなる部分を対応　↑
				}
			} else if (JDBCMetaDataType.REAL == type) {
				if (columnData == null || columnData.equals("")) {
					statment.setNull(index, type.getDataType());
				} else {
					statment.setFloat(index, Float.valueOf(columnData));
				}
			} else if (JDBCMetaDataType.DOUBLE == type
					|| JDBCMetaDataType.FLOAT == type) {
				//check postgresql money type
				final boolean moneyType = columnTypeName.toUpperCase().equals("MONEY");
				if (columnData == null || columnData.equals("")) {
					if(moneyType){
						statment.setBigDecimal(index, null);
					}else{
						statment.setNull(index, type.getDataType());
					}					
				} else if(moneyType) {//check postgresql money type
					final String data = columnData.replaceAll("[,￥]", "");
					statment.setBigDecimal(index, new BigDecimal(data));
				}else{
					statment.setDouble(index, Double.valueOf(columnData));
				}
			} else if (JDBCMetaDataType.DECIMAL == type
					|| JDBCMetaDataType.NUMERIC == type) {
				if (columnData == null || columnData.equals("")) {
					statment.setNull(index, type.getDataType());
				} else {
					statment.setBigDecimal(index, new BigDecimal(columnData));
				}
			} else if (JDBCMetaDataType.DATE == type) {
				if (columnData == null || columnData.equals("")) {
					statment.setNull(index, type.getDataType());
				} else {
					final Date date = analyzeDatetime(type, columnId,
							columnData, sdf);
					statment.setTimestamp(index, new java.sql.Timestamp(date
							.getTime()));
				}
			} else if (JDBCMetaDataType.TIME == type) {
				if (columnData == null || columnData.equals("")) {
					statment.setNull(index, type.getDataType());
				} else {
					final Date date = analyzeDatetime(type, columnId,
							columnData, sdf);
					statment.setTime(index, new java.sql.Time(date.getTime()));
				}
			} else if (JDBCMetaDataType.TIMESTAMP == type) {
				if (columnData == null || columnData.equals("")) {
					statment.setNull(index, type.getDataType());
				} else {
					final Date date = analyzeDatetime(type, columnId,
							columnData, sdf);
					statment.setTimestamp(index, new java.sql.Timestamp(date
							.getTime()));
				}
			}

			return true;
		} catch (final SQLException e) {
			// MI-E-0130=バインド変数の設定に失敗しました。({0})
			final String message = OracleMessageWrapper.getWrapMessage(e
					.getErrorCode(), e.getMessage(), "MI-E-0130");
			logger.error(message);
			throw new ApplicationDomainLogicException(message);
		} catch (final NumberFormatException e) {
			// MI-E-0004={0}は数値で入力してください。
			final String args[] = { columnId };
			final String message = MessageUtils.getMessage("MI-E-0004", args);
			logger.error(message);
			throw new ApplicationDomainLogicException(message);
		}
	}

	/**
	 * 日付型のデータを java.sql.Date 型に変換して戻します。
	 * <p>
	 * inputFormat が指定された場合は、指定されたフォーマットに変換します。 inputFormat
	 * が指定されない場合(null)は、データを解析したフォーマットに 変換します。
	 * </p>
	 *
	 * @param type
	 * @param columnId
	 * @param columnData
	 * @param inputFormat
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	private Date analyzeDatetime(final JDBCMetaDataType type,
			final String columnId, final String columnData,
			final SimpleDateFormat inputFormat)
			throws ApplicationDomainLogicException {
		SimpleDateFormat sdf = null;
		try {
			for (final String format : DATE_FORMAT_MAP.keySet()) {
				if (columnData.matches(format)) {
					sdf = new SimpleDateFormat(DATE_FORMAT_MAP.get(format));
					final Date date = new Date(sdf.parse(columnData).getTime());
					if (inputFormat == null) {
						return date;
					} else {
						final String buff = inputFormat.format(date);
						return new Date(inputFormat.parse(buff).getTime());
					}
				}
			}
		} catch (final ParseException e) {
			// ここは何もしない
		}

		try {
			final java.util.Date date = HSSFDateUtil.getJavaDate(Double
					.parseDouble(columnData));
			logger.debug(columnId + ":" + date);
			return new Date(date.getTime());
		} catch (final NumberFormatException e) {
			// ここは何もしない
		}

		// MI-E-0138={0}の書式が不正です。(データ:{1})。
		final String args[] = { columnId, columnData };
		final String message = MessageUtils.getMessage("MI-E-0138", args);
		logger.error(message);
		throw new ApplicationDomainLogicException(message);
	}

	/**
	 * 日付の書式
	 */
	private static final Map<String, String> DATE_FORMAT_MAP;
	static {
		DATE_FORMAT_MAP = new HashMap<String, String>();
		DATE_FORMAT_MAP.put("\\d{4}\\/\\d{2}/\\d{2} \\d{2}:\\d{2}:\\d{2}",
				"yyyy/MM/dd HH:mm:ss");
		DATE_FORMAT_MAP.put(
				"\\d{4}\\/\\d{1,2}/\\d{1,2} \\d{1,2}:\\d{1,2}:\\d{1,2}",
				"yyyy/M/d H:m:s");
		DATE_FORMAT_MAP.put("\\d{4}\\/\\d{2}/\\d{2}", "yyyy/MM/dd");
		DATE_FORMAT_MAP.put("\\d{4}\\/\\d{1,2}/\\d{1,2}", "yyyy/M/d");
		DATE_FORMAT_MAP.put(
				"\\d{4}\\/\\d{2}/\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}",
				"yyyy/MM/dd HH:mm:ss.SSS");
		DATE_FORMAT_MAP
				.put(
						"\\d{4}\\/\\d{1,2}/\\d{1,2} \\d{1,2}:\\d{1,2}:\\d{1,2}\\.\\d{1,3}",
						"yyyy/M/d H:m:s.S");
		DATE_FORMAT_MAP.put("\\d{4}\\/\\d{2}/\\d{2}", "yyyy/MM/dd");
		DATE_FORMAT_MAP.put("\\d{4}\\/\\d{1}/\\d{1}", "yyyy/M/d");
		DATE_FORMAT_MAP.put("\\d{2}:\\d{2}:\\d{2}", "HH:mm:ss");
		DATE_FORMAT_MAP.put("\\d{1,2}:\\d{1,2}:\\d{1,2}", "H:m:s");
	}

	private boolean isAutoIncrement(
			final TableDefinitionDTO dto) {
		final Map<String, DefinitionOfColumn> map = dto.getDefinitionOfColumnMap();
		for (final String columnName : map.keySet()) {
			if (map.get(columnName).isAutoIncrement()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 自動インクリメントカラムがあるテーブルの自動インクリメントの有効化、無効化を行います。
	 * <p>
	 * SQL Serverの場合のみ、自動インクリメントカラムがあるテーブルの自動インクリメントの
	 * 有効化、無効化を行います。</br>
	 * Oracleの場合は何も行いません。
	 * </p>
	 *
	 * @param tableId
	 * @param dto
	 * @param type
	 * @param connection
	 * @param isOn true:自動インクリメント無効化、false:自動インクリメント有効化
	 * @throws DAOException
	 */
	private void changeAutoIncrement(
			final String tableId,
			final TableDefinitionDTO dto,
			final DatabaseTypeConnectionDestination type,
			final Connection connection,
			final boolean isOn) throws DAOException {
		if (DatabaseTypeConnectionDestination.SqlServer == type) {
			if (isAutoIncrement(dto)) {
				final StringBuffer sql = new StringBuffer();
				sql.append("SET IDENTITY_INSERT ");
				sql.append(tableId);
				sql.append(isOn ? " ON" : " OFF");
				Statement statment = null;
				try {
					logger.info(sql.toString());
					statment = connection.createStatement();
					logger.info(statment.execute(sql.toString()));
				} catch (SQLException e) {
					throw new DAOException(e);
				} finally {
					if (statment != null) {
						try {
							statment.close();
						} catch (SQLException e) {
							logger.warn(e);
						}
					}

					if (connection != null) {
						try {
							connection.commit();
						} catch (SQLException e) {
							logger.warn(e);
						}
					}
				}
			} else {
				return;
			}
		} else {
			return;
		}

	}

	/**
	 * コンストラクタ
	 */
	public ImportFromFileToTableLogic() {
		this.logger = LoggerFactory.getLogger(this.getClass().getName());
		this.fileImportResultDTO = new FileImportResultDTO();
	}
	
	/**
	 * @param columnData
	 * @param checkMessageDTO
	 * @return
	 */
	private CheckMessageDTO checkCsvData(
			Map<String, String> columnData, 
			CheckMessageDTO checkMessageDTO){
		//final String regex = ".*('\",).*";
		for(Map.Entry<String, String> item : columnData.entrySet()){
			final String columnId = item.getKey();
			final String data = item.getValue();
			//final boolean checkData = data.matches(regex);
			final String[] regex = new String[]{",", "'", "\""};
			boolean checkData = false;
			for(final String reg : regex){
				if(data.indexOf(reg) != -1){
					checkData = !checkData;
					break;
				}
			}
			if(checkData){
				// MI-E-0151=更新対象のデータが存在しません。
				final String str = MessageUtils.getMessage("MI-E-0151");
				checkMessageDTO.getMessages(columnId).add(str);
				break;
			}
		}
		return checkMessageDTO;
	}
	
	/**
	 * @param columnData
	 * @param checkMessageDTO
	 * @return
	 */
	private CheckMessageDTO checkTsvData(
			Map<String, String> columnData, 
			CheckMessageDTO checkMessageDTO){
		
		return checkMessageDTO;
	}
	
	/**
	 * @param uploadFileType
	 * @param columnData
	 * @param checkMessageDTO
	 * @return
	 */
	private CheckMessageDTO checkFormatCsvOrTsv(
			UploadFileType uploadFileType,
			Map<String, String> columnData, 
			CheckMessageDTO checkMessageDTO){
		switch(uploadFileType){
			case EXCEL: 
				break;
			case CSV:
				this.checkCsvData(columnData, checkMessageDTO);
				break;
			case TSV:
				this.checkTsvData(columnData, checkMessageDTO);
				break;
			default:
				break;
		}
		return checkMessageDTO;
	}
}
