/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectManyCheckboxItem;

/**
 * （JavaDoc）。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class SearchRegisteredOption implements SelectManyCheckboxItem {

    /**
     * 検索オプション：リポジトリ登録済、未登録、DBから欠落。
     * <p>検索オプションに付けた表示用名称です。</p>
     */
    private String label;
    
    /**
     * 検索オプション：リポジトリ登録済、未登録、DBから欠落。
     * <p>検索オプションで扱われる ID です。</p>
     */
    private String value;

    /**
     * label を戻します。
     * 
     * @return String
     */
    public String getLabel() {
        return label;
    }

    /**
     * label を設定します。
     *
     * @param String label 
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * value を戻します。
     * 
     * @return String
     */
    public String getValue() {
        return value;
    }

    /**
     * value を設定します。
     *
     * @param String value 
     */
    public void setValue(String value) {
        this.value = value;
    }
}
