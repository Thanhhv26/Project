/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.audit;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Layout;
import org.apache.log4j.PatternLayout;

import jp.co.systemexe.dbu.dbace.common.logger.AppRollingFileAppender;
import jp.co.systemexe.dbu.dbace.common.logger.AuditLogger;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

/**
 * 監査ログの出力を行います。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class OutputAuditLog {
    private static final Logger logger = new AuditLogger("jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog");

    /**
     * 監査ログのアクセス時刻を出力するための日付フォーマット
     */
    private static final SimpleDateFormat accessTimeFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

    /**
     * 監査ログを出力する、監査カテゴリを保持します。
     */
    private static final Map<String, String> auditCategoryMap = new HashMap<String, String>();

    /**
     * 監査ログを出力するための、log4jのAppender名
     */
    private static final String APPENDER_NAME = "audit_log_file";

    /**
     * log4j用の監査ログ設定を新規作成します。
     *
     * @param dto
     */
    public static void createAuditLogSetting(final AuditSettingDTO dto) {
        final AppRollingFileAppender appender = new AppRollingFileAppender();
        final Layout layout = new PatternLayout("%m%n");
        appender.setName(APPENDER_NAME);
        appender.setLayout(layout);
        appender.setAppend(true);
        appender.setFile(dto.getFilePath());
        appender.setMaxBackupIndex(dto.getFileRotation());
        appender.setMaxFileSize(dto.getFileSize() + dto.getFileUnit() + "B");
        appender.activateOptions();

        final org.apache.log4j.Logger log = ((AuditLogger)logger).getLogger();
        log.getParent().addAppender(appender);

        synchronized (auditCategoryMap) {
            auditCategoryMap.clear();

            for (String value : dto.getCategoryMap().values()) {
                auditCategoryMap.put(value, "");
            }
        }
    }

    /**
     * 監査ログの設定を変更します。
     *
     * @param dto
     */
    public static void changeAuditLogSetting(final AuditSettingDTO dto)
            throws Exception {
        AuditSettingDTO backUpDto = null;
        try {
            final org.apache.log4j.Logger log = ((AuditLogger)logger).getLogger();
            final AppRollingFileAppender appender
                = (AppRollingFileAppender)log.getParent().getAppender(APPENDER_NAME);

            // エラーが発生した場合のバックアップを保持
            backUpDto = new AuditSettingDTO();
            backUpDto.setFilePath(appender.getFile());
            backUpDto.setFileRotation(appender.getMaxBackupIndex());
            backUpDto.setFileSize(appender.getMaximumFileSize());
            for (Integer index : dto.getCategoryMap().keySet()) {
                backUpDto.getCategoryMap().put(index, dto.getCategoryMap().get(index));
            }

            appender.setAppend(true);//明示的にsetAppend(true)を再設定する。
            appender.setFile(dto.getFilePath());
            appender.setMaxBackupIndex(dto.getFileRotation());
            appender.setMaxFileSize(dto.getFileSize() + dto.getFileUnit() + "B");
            appender.activateOptions();

            synchronized (auditCategoryMap) {
                auditCategoryMap.clear();

                for (String value : dto.getCategoryMap().values()) {
                    auditCategoryMap.put(value, "");
                }
            }
        } catch (Exception e) {
            // バックアップから、ログ情報を戻す
            if (backUpDto != null) {
                final org.apache.log4j.Logger log = ((AuditLogger)logger).getLogger();
                final AppRollingFileAppender appender
                    = (AppRollingFileAppender)log.getParent().getAppender(APPENDER_NAME);
                appender.setFile(dto.getFilePath());
                appender.setMaxBackupIndex(dto.getFileRotation());
                appender.setMaxFileSize(dto.getFileSize() + dto.getFileUnit() + "B");
                appender.activateOptions();

                synchronized (auditCategoryMap) {
                    auditCategoryMap.clear();

                    for (String value : dto.getCategoryMap().values()) {
                        auditCategoryMap.put(value, "");
                    }
                }
            }
            throw e;
        }
    }

    /**
     * ログイン/ログアウトの監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param target
     */
    public static void writeLoginLogoutLog(
            final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final String target,
            final AuditStatus auditStatus) {
        if (auditCategoryMap.containsKey(AuditCategories.LOGIN_LOGOUT.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.LOGIN_LOGOUT.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            				userInfo,
            				"",
            				target,
            				auditStatus.getAuditStatusName(),
            				"",
            				"",
            				"",
            				""));
        }
    }

    // ADD　外部認証画面の監査ログを出力の機能追加　↓
    /**
     * ON/OFFの監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param serverName
     * @param serverType
     * @param domainTree
     * @param suffix
     * @param auditStatus
     */
    public static void writeExtAuthLog(final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final String serverName,
            final String serverType,
            final String domainTree,
            final String suffix,
            final AuditStatus auditStatus) {
        if (auditCategoryMap.containsKey(AuditCategories.EXTERNAL_AUTHENTICATION.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.EXTERNAL_AUTHENTICATION.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            				userInfo,
            				serverName,//AD/LDAPサーバー名
            				serverType,//サーバー種類
            				auditStatus.getAuditStatusName(),
            				domainTree,//AD:ドメイン名/LDAP:ユーザー検索対象ツリー
            				suffix,//接続ユーザーの識別子
            				"",
            				""));
        }
    }
    // ADD　外部認証画面の監査ログを出力の機能追加　↑

    /**
     * データ操作(登録、更新、削除)の監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param databaseName
     * @param target
     * @param auditStatus
     * @param condition
     * @param count
     */
    public static void writeExcuteUpdateLog(
            final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final String databaseName,
            final String target,
            final AuditStatus auditStatus,
            final Map<String, String> updateDataMap,
            final String condition,
            final String count) {
    	final StringBuffer buff = new StringBuffer();
    	for (final String columnId : updateDataMap.keySet()) {
    		if (buff.length() != 0) {
    			buff.append(",");
    		}
    		buff.append(columnId);
    		buff.append("=");
    		buff.append(updateDataMap.get(columnId));
    	}
        if (auditCategoryMap.containsKey(AuditCategories.EXCUTE.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.EXCUTE.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            			userInfo,
            				databaseName,
            				target,
            				auditStatus.getAuditStatusName(),
            				buff.toString(),
            				condition,
            				count,
            				""));
        }
    }

    /**
     * データ操作(インポート)の監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param databaseName
     * @param target
     * @param auditStatus
     * @param totalCount
     * @param validateErrorCount
     * @param insertSuccessCount
     * @param insertFailureCount
     * @param updateSuccessCount
     * @param updateFailureCount
     */
    public static void writeImportLog(
            final AuditEventKind auditEventKind,
           final UserInfo userInfo,
            final String databaseName,
            final String target,
            final AuditStatus auditStatus,
            final int totalCount,
            final int validateErrorCount,
            final int insertSuccessCount,
            final int insertFailureCount,
            final int updateSuccessCount,
            final int updateFailureCount) {
    	final StringBuffer buff = new StringBuffer();
    	buff.append(totalCount);
    	buff.append(",");
    	buff.append(validateErrorCount);
    	buff.append(",");
    	buff.append(insertSuccessCount);
    	buff.append(",");
    	buff.append(insertFailureCount);
    	buff.append(",");
    	buff.append(updateSuccessCount);
    	buff.append(",");
    	buff.append(updateFailureCount);
        if (auditCategoryMap.containsKey(AuditCategories.EXCUTE.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.EXCUTE.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            				userInfo,
            				databaseName,
            				target,
            				auditStatus.getAuditStatusName(),
            				"",
            				"",
            				buff.toString(),
            				""));
        }
    }

    /**
     * データ操作(検索、ダウンロード)の監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param databaseName
     * @param target
     * @param auditStatus
     * @param condition
     * @param count
     */
    public static void writeExcuteSearchLog(
            final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final String databaseName,
            final String target,
            final AuditStatus auditStatus,
            final String condition,
            final String count) {
        if (auditCategoryMap.containsKey(AuditCategories.EXCUTE.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.EXCUTE.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            				userInfo,
            				databaseName,
            				target,
            				auditStatus.getAuditStatusName(),
            				"",
            				condition,
            				count,
            				""));
        }
    }

    /**
     * ユーザー操作の監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param target
     * @param auditStatus
     */
    public static void writeUserOperationLog(
            final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final String target,
            final AuditStatus auditStatus,
            final String count) {
        if (auditCategoryMap.containsKey(AuditCategories.USER_OPERATION.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.USER_OPERATION.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            				userInfo,
            				"",
            				target,
            				auditStatus.getAuditStatusName(),
            				"",
            				"",
            				count,//count
            				""));
        }
    }

    /**
     * ユーザー権限操作の監査ログを出力します。
     * <p>
     * ユーザー権限操作の監査ログは、ユーザー操作の監査が有効の場合に出力されます。
     * </p>
     *
     * @param auditEventKind
     * @param userInfo
     * @param target
     * @param auditStatus
     * @param auditUserAuthority
     */
    public static void writeUserAuthorityChangeLog(
            final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final String databaseName,
            final String target,
            final AuditStatus auditStatus,
            final AuditUserAuthority auditUserAuthority) {
        if (auditCategoryMap.containsKey(AuditCategories.USER_OPERATION.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.USER_AUTHORITY_CHANGE.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            			userInfo,
            				databaseName,
            				target,
            				auditStatus.getAuditStatusName(),
            				"",
            				"",
            				"",
            				auditUserAuthority.getLogName()));
        }
    }

    /**
     * 接続定義操作の監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param target
     * @param auditStatus
     */
    public static void writeConnectedDefinitionLog(
            final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final String target,
            final AuditStatus auditStatus,
            final String count) {
        if (auditCategoryMap.containsKey(AuditCategories.CONNECTED_DEFINITION.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.CONNECTED_DEFINITION.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            			userInfo,
            				"",
            				target,
            				auditStatus.getAuditStatusName(),
            				"",
            				count,
            				"",
            				""));
        }
    }
    
    /**
     * 接続定義操作の監査ログを出力します。
     *
     * @param userInfo
     * @param auditStatus
     * @param databaseName
     * @param tableName
     * @param auditEventKind
     */
    public static void writeMakeViewLog(
            final UserInfo userInfo,
            final AuditStatus auditStatus,
            final String databaseName,            
            final String tableName,//tableName
            //final String auditCategories,
            final AuditEventKind auditEventKind,
            //final String updateData,
            //final String condition,
            final String count//,
            //final String auditUserAuthority
            ) {
        if (auditCategoryMap.containsKey(AuditCategories.MAKE_VIEW.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.MAKE_VIEW.getCategoryLogName(),//auditCategories
            				auditEventKind.getEventKindName(),//auditEventKind
            				userInfo,//info
            				databaseName,//databaseName
            				tableName,//tableName
            				auditStatus.getAuditStatusName(),//auditStatus
            				"",//updateData
            				"",//condition
            				count,//count
            				""));//auditUserAuthority
        }
    }
    
    /**
     * 接続定義操作の監査ログを出力します。
     *
     * @param userInfo
     * @param auditStatus
     * @param databaseName
     * @param tableName
     * @param auditEventKind
     */
    public static void writeRelationLog(
            final UserInfo userInfo,
            final AuditStatus auditStatus,
            final String databaseName,            
            final String tableName,//tableName
            //final String auditCategories,
            final AuditEventKind auditEventKind,
            //final String updateData,
            //final String condition,
            final String count//,
            //final String auditUserAuthority
            ) {
        if (auditCategoryMap.containsKey(AuditCategories.RELATION.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.RELATION.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            				userInfo,
            				databaseName,
            				tableName,
            				auditStatus.getAuditStatusName(),
            				"",//updateData
            				"",//condition
            				count,//count
            				""));//auditUserAuthority
        }
    }

    /**
     * 画面操作の監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param databaseName
     * @param target
     * @param auditStatus
     */
    public static void writeGuiSettingLog(
            final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final String databaseName,
            final String target,
            final AuditStatus auditStatus,
            final String count) {
        if (auditCategoryMap.containsKey(AuditCategories.GUI_SETTING.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.GUI_SETTING.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            				userInfo,
            				databaseName,
            				target,
            				auditStatus.getAuditStatusName(),
            				"",
            				"",
            				count,
            				""));
        }
    }

    /**
     * 監査ログ設定操作(開始、終了)の監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param target
     * @param auditStatus
     */
    public static void writeAuditSettingLog(
            final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final AuditCategories target,
            final AuditStatus auditStatus) {
        if (auditCategoryMap.containsKey(AuditCategories.AUDIT_SETTING.name())) {
            logger.info(
            		makeLog(
            				// ADD　外部認証画面の監査ログを出力の機能追加　↓
            				// AuditCategories.AUDIT_SETTING.getCategoryLogName(),
            				AuditCategories.EXTERNAL_AUTHENTICATION.getCategoryLogName()
    								.equalsIgnoreCase(target.getCategoryLogName()) ?
    										AuditCategories.EXTERNAL_AUTHENTICATION.getCategoryLogName() :
    												AuditCategories.AUDIT_SETTING.getCategoryLogName(),
            				// ADD　外部認証画面の監査ログを出力の機能追加　↑
            				auditEventKind.getEventKindName(),
            			userInfo,
            				"",
            				// ADD　外部認証画面の監査ログを出力の機能追加　↓
            				// target.getCategoryLogName(),
            				AuditCategories.EXTERNAL_AUTHENTICATION.getCategoryLogName()
            						.equalsIgnoreCase(target.getCategoryLogName()) ? "" : target.getCategoryLogName(),
            				// ADD　外部認証画面の監査ログを出力の機能追加　↑
            								auditStatus.getAuditStatusName(),
            				"",
            				"",
            				"",
            				""));
        }
    }

    /**
     * 監査ログ設定操作(その他更新)の監査ログを出力します。
     *
     * @param auditEventKind
     * @param userInfo
     * @param target
     * @param auditStatus
     */
    public static void writeAuditSettingOtherLog(
            final AuditEventKind auditEventKind,
            final UserInfo userInfo,
            final AuditStatus auditStatus) {
        if (auditCategoryMap.containsKey(AuditCategories.AUDIT_SETTING.name())) {
            logger.info(
            		makeLog(
            				AuditCategories.AUDIT_SETTING.getCategoryLogName(),
            				auditEventKind.getEventKindName(),
            			userInfo,
            				"",
            				"",
            				auditStatus.getAuditStatusName(),
            				"",
            				"",
            				"",
            				""));
        }
    }

    /**
     * 監査ログ文字列を生成します。
     * <p>
     * "クライアントIP Address","ログインユーザID","EASYインストールサーバ名","アクセス日付","監査が成否",
     * "接続先DB名","接続先DB名","監査ログカテゴリ","監査イベント種類" <br />
     * 順に文字列を生成します。
     * </p>
     *
     * @param auditCategories
     * @param auditEventKind
     * @param userInfo
     * @param databaseName
     * @param tableName
     * @param auditStatus
     * @return
     */
    private static String makeLog(
            final String auditCategories,
            final String auditEventKind,
            final UserInfo info,
            final String databaseName,
            final String tableName,
            final String auditStatus,
            final String updateData,
            final String condition,
            final String count,
            final String auditUserAuthority) {
        final UserInfo userInfo;
        if (info == null) {
            userInfo = new UserInfo();
        } else {
            userInfo = info;
        }

        final StringBuffer build = new StringBuffer();
        build.append("\"");
        build.append(replaceDoubleQuart(userInfo.getClientIpAddress()));
        build.append("\",\"");
        build.append(replaceDoubleQuart(userInfo.getId()));
        build.append("\",\"");
        build.append(replaceDoubleQuart(userInfo.getServerName()));
        build.append("\",\"");
        build.append(replaceDoubleQuart(accessTimeFormat.format(new Date())));
        build.append("\",\"");
        build.append(replaceDoubleQuart(auditStatus));
        build.append("\",\"");
        build.append(replaceDoubleQuart(databaseName));
        build.append("\",\"");
        build.append(replaceDoubleQuart(tableName));
        build.append("\",\"");
        build.append(replaceDoubleQuart(auditCategories));
        build.append("\",\"");
        build.append(replaceDoubleQuart(auditEventKind));
        build.append("\",\"");
        build.append(replaceDoubleQuart(updateData));
        build.append("\",\"");
        build.append(replaceDoubleQuart(condition));
        build.append("\",\"");
        build.append(replaceDoubleQuart(count));
        build.append("\",\"");
        build.append(replaceDoubleQuart(auditUserAuthority));
        build.append("\"");

        return build.toString();
    }

    /**
     * 文字列内にある 「"」を「""」に置き換えます。
     *
     * @param str
     * @return
     */
    private static String replaceDoubleQuart(final String str) {
    	return nullToZeroBlankString(str).replace("\"", "\"\"");
    }

    /**
     * nullをゼロブランクストリング("")に変換して戻します。
     *
     * @param str
     * @return
     */
    private static String nullToZeroBlankString(final String str) {
        if (str == null) {
            return "";
        } else {
            return str;
        }
    }

    private OutputAuditLog() {
        return;
    }
}
