/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.connect.dto;

import jp.co.systemexe.dbu.dbace.library.dto.BaseDto;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * @author bao-anh
 * @version 6.0 jan 3, 2017
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ConnectDto extends BaseDto {

	private static final long serialVersionUID = 1L;
	@Getter
	@Setter
	private String formId;
	@Getter
	@Setter
	private String connectDefinition;
	@Getter
	@Setter
	private String connectDefinitionName;
	@Getter
	@Setter
	private String templateDatabaseUrl;
	@Getter
	@Setter
	private String databaseUrl;
	@Getter
	@Setter
	private String serverId;
	@Getter
	@Setter
	private String port;
	@Getter
	@Setter
	private Boolean useDatabaseUrl = Boolean.FALSE;
	@Getter
	@Setter
	private String databaseId;
	@Getter
	@Setter
	private String instanceName;
	@Getter
	@Setter
	private String pid;
	@Getter
	@Setter
	private String password;
	@Getter
	@Setter
	private UserInfo userInfo;
}
