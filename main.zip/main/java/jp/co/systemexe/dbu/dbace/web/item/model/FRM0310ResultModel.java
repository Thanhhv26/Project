/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;
import jp.co.systemexe.dbu.dbace.presentation.item.ColumnListItemForGuiSetting;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.web.item.dto.SortColumnEditorDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SortDataEditorDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.TrRowDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.columnListItemDTO;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author THANH TRUC
 * @version 6.0 Feb 09, 2017
 */

@Data
public class FRM0310ResultModel {
	boolean status;
	private Map<String, List<IdSelectable>> mapConnTable;
	private List<ColumnListItemForGuiSetting> columnListItems;
	private columnListItemDTO itemSelect;
	List<MessageInfo> messageInfo = new ArrayList<MessageInfo>();
	public String insertDefaultValue;
	public String updateDefaultValue;
	public List<TrRowDTO> selectableListItems;
	private SortDataEditorDTO sortDataEditorDTO;
	private SortColumnEditorDTO sortColumnEditorDTO;
	/**
     * SQL 実行結果にて取得した、確認表示用リストプロパティを保持します。
     */
    private SelectOneMenuItem[] queryResultListItems;

}
