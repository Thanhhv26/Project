/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import java.util.List;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectTableItemForReposiotrySetting;
import lombok.Data;
@Data
public class SelectTableItemForReposiotrySettingAndMessage {
	String status;
	String message;
	// テーブル名の一覧
	List<SelectTableItemForReposiotrySetting> selectTableItemForReposiotrySettingList;
}
