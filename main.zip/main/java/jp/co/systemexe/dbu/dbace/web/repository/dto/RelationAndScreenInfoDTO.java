/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationAndScreenInfoDTO {
	private String relationId;
	private String relationLabel;
	private String connectDefinisionId;
	private String tableFormIdTypeMultiTable;
	private String tableFormLabelTypeMultiTable;
	private String itemContainCols;
	private String dataType;
	private String dataLength;
	private String dataUnit;

	/**
	 * @param relationId
	 * @param relationLabel
	 * @param connectDefinisionId
	 * @param tableFormIdTypeMultiTable
	 * @param tableFormLabelTypeMultiTable
	 */
//	public RelationAndScreenInfoDTO(String relationId, String relationLabel, String connectDefinisionId,
//			String tableFormIdTypeMultiTable, String tableFormLabelTypeMultiTable) {
//		this.relationId = relationId;
//		this.relationLabel = relationLabel;
//		this.connectDefinisionId = connectDefinisionId;
//		this.tableFormIdTypeMultiTable = tableFormIdTypeMultiTable;
//		this.tableFormLabelTypeMultiTable = tableFormLabelTypeMultiTable;
//	}

}