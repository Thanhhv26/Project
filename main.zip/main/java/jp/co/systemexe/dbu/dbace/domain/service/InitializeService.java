/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.service;

/**
 * WEBサーバー起動時の初期化処理を行います。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public interface InitializeService {
    void initialize();
}
