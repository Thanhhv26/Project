/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import java.io.Serializable;

/**
 * 各行毎のエラーメッセージ、行数を保持するプロパティ。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class ResultMessageItem implements Serializable {
	/**
	 * <code>serialVersionUID</code> のコメント。
	 */
	private static final long serialVersionUID = 4309104769404251006L;

	/**
	 * 行数
	 */
	private int rowCount;

	/**
	 * エラーメッセージ
	 */
	private String message;
	
	/**
	 * コンストラクタ
	 */
	public ResultMessageItem() {
		return ;
	}

	/**
	 * rowCount を戻します。
	 * 
	 * @return int
	 */
	public int getRowCount() {
		return rowCount;
	}

	/**
	 * rowCount を設定します。
	 *
	 * @param int rowCount 
	 */
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	/**
	 * message を戻します。
	 * 
	 * @return String
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * message を設定します。
	 *
	 * @param String message 
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}
