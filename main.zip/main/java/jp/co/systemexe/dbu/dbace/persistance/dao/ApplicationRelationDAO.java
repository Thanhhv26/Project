/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Relation;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationInformation;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
public interface ApplicationRelationDAO {

    /**
     * @param relationId
     * @return
     * @throws DAOException
     */
    public ApplicationRelationDTO getApplicationRelationDTO(final String relationId)
            throws DAOException;

    /**
     * リレーションー名の一覧マップを戻します。
     * <p>
     * リレーション ID、リレーション名の一覧を設定した Map を戻します。</p>
     *
     * @return Map&lt;リレーション ID, リレーション名&gt;
     * @throws DAOException
     */
    public Map<String, String> getRelationNameMap()
            throws DAOException;

    /**
     * リレーション情報の一覧マップを戻します。
     * <p>
     * リレーション ID、リレーション名、リレーション権限の一覧を設定した Map を戻します。
     * リレーション登録がない場合は DAOException をスローします。</p>
     *
     * @return Map&lt;リレーション ID, UserInformation&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationRelationDAO#getUserInformationMap()
     */
    public Map<String, RelationInformation> getRelationInformationMap()  throws DAOException;

	/**
	 * @param userInfo
	 * @param dto
	 * @param updateDivision
	 * @throws DAOException
	 */
	public void save(//final UserInfo userInfo,
			final ApplicationRelationDTO dto,
			final UpdateDivision updateDivision)
			throws DAOException;

    /**
     * リレーション情報を削除します。
     * <p>
     * リレーション IDのアプリケーションリレーション情報を削除
     * します。</p>
     *
     * @param userId リレーション ID
     * @throws DAOException
     */
    public void remove(final String relationId) throws DAOException;

    public boolean checkRelationExist(final String relationId) throws DAOException;
    
    public List<Relation> getRelations() throws DAOException;
}
