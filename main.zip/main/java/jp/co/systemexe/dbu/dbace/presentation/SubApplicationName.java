/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

/**
 * サブアプリケーション名定義 enum。
 * <p>
 * Teeda フレームワークのサブアプリケーション名を定義した列挙体です。
 * この列挙体内に定義されたサブアプリケーション名（＝パッケージ名）以外は、
 * 最終的に全て破棄されます。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public enum SubApplicationName {
    /**
     * 「コモン」サブアプリケーション。
     * <p>
     * システム共通ページが配置されています。特殊なパッケージであり、多用は推奨
     * されません。</p>
     */
    common("common"),
    /**
     * 「スタート」サブアプリケーション。
     * <p>画面全体を構成するフレームを定義したコンテンツが配置されています。</p>
     */
    start("start"),
    /**
     * 「ログイン」サブアプリケーション。
     * <p>アプリケーションログイン専用のパッケージです。</p>
     */
    login("login"),
    /**
     * 「メニュー」サブアプリケーション。
     */
    menu("menu"),
    /**
     * 「ユーザー」サブアプリケーション。
     * <p>
     * ユーザー設定処理用のサブアプリケーションです。ログイン中のユーザーの権限
     * に合わせて動作が変化します。</p>
     */
    user("user"),
    /**
     * 「接続定義」サブアプリケーション。
     * <p>
     * 接続定義情報設定用のサブアプリケーションです。</p>
     */
    connect("connect"),
    /**
     * 「リポジトリ」サブアプリケーション。
     * <p>
     * アプリケーションリポジトリの操作用サブアプリケーションです。</p>
     */
    repository("repository"),
    /**
     * 「テーブル」サブアプリケーション。
     * <p>
     * 対象テーブルの設定用のサブアプリケーションです。あくまでも DB 内の
     * テーブルを対象としたものであり、GUI 画面設定定義とは独立しています。</p>
     */
    table("table"),
    /**
     * 「GUI」サブアプリケーション。
     * <p>
     * 対象テーブル単位の GUI 画面カスタマイズ用のサブアプリケーションです。
     * 表示・編集対象カラムの設定や各カラムへの入力制約、入力値チェックの設定
     * などを行います。</p>
     */
    gui("gui"),
    /**
     * 「データベース」サブアプリケーション。
     * <p>
     * 実際のデータメンテナンスを行うアプリケーションの配置パッケージです。</p>
     */
    database("database");

    private final String key;

    /**
     * 画面遷移用のページ名を整形して戻します。
     * <p>
     * ページ ID を受け取り、サブアプリケーション名（アンダースコアを補完）して、
     * 遷移用のページ完全名称を戻します。
     * </p>
     * 
     * @param pageId
     * @return 遷移用のページ完全名称
     */
    public String makePageName(final String pageId) {
        return key.concat("_").concat(pageId);
    }

    /**
     * SubApplicationName の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param key
     */
    private SubApplicationName(final String name) {
        this.key = name;
    }
}
