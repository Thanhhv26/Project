/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.enums;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
public enum MessageEnum {
	OK(0, "OK"), NG(1, "NG"), UNK(2, "UNK");

	private int value;
	private String label;

	private MessageEnum(int value, String label) {
		this.value = value;
		this.label = label;
	}

	/**
	 * value を取得します。
	 *
	 * @return value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * label を取得します。
	 *
	 * @return label
	 */
	public String getLabel() {
		return label;
	}
}
