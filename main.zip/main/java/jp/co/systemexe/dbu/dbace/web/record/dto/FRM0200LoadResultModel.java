/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.Map;

import lombok.Data;

/**
 * @author bao-anh
 *
 */

@Data
public class FRM0200LoadResultModel extends FRM0200ResultModel {
//	private String connectDefinisionId;
//	private String tableId;
//
//	private ColumnDisplayDefinitionDTO columnDisplayDefinition;
	private Map<String, String> currentObject;
	private ColumnAttributeItem[] columnAttributeItems;
	private String actionType;

//	private boolean permissionDeleteFirst = false;
//	private boolean permissionDeleteSecond = false;
//	private boolean permissionDeleteThird = false;

//	private List<MessageInfo> messageInfo;
//
//	public FRM0200DeleteResultModel() {
//		messageInfo = new ArrayList<MessageInfo>();
//	}
}
