package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.io.Serializable;

/**
 * レコードの検索結果リスト画面要素表示用アイテム。
 * <p>
 * </p>
 *
 * @author EXE 相田 一英
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class SearchResultHeaderItem implements Serializable {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 8617905067089044014L;

    private SearchResultHeaderItem[] searchResultHeaderDetailItems;

    /**
     * カラムIDプロパティ。
     */
    private String columnId;

    /**
     * カラム名プロパティ。
     */
    private String columnLabel;

    /**
     * プライマリキー制約の有無。
     */
    private boolean primaryKey;

    /**
     * 表示可能かどうかの有無。
     */
    private boolean canPreview;

    /**
     * 表示可能かどうかの有無。
     */
    private boolean canDisplayPreview;

    /**
     * JDBC メタデータタイプ。
     */
    private int jdbcMetaData;

    /**
     * columnId を戻します。
     * 
     * @return String
     */
    public String getColumnId() {
        return columnId;
    }

    /**
     * columnId を設定します。
     *
     * @param String columnId 
     */
    public void setColumnId(String columnId) {
        this.columnId = columnId;
    }

    /**
     * columnLabel を戻します。
     * 
     * @return String
     */
    public String getColumnLabel() {
        return columnLabel;
    }

    /**
     * columnLabel を設定します。
     *
     * @param String columnLabel 
     */
    public void setColumnLabel(String columnLabel) {
        this.columnLabel = columnLabel;
    }

    /**
     * primaryKey を戻します。
     * 
     * @return boolean
     */
    public boolean isPrimaryKey() {
        return primaryKey;
    }

    /**
     * primaryKey を設定します。
     *
     * @param boolean primaryKey 
     */
    public void setPrimaryKey(boolean primaryKey) {
        this.primaryKey = primaryKey;
    }

    /**
     * searchResultHeaderDetailItems を戻します。
     * 
     * @return SearchResultHeaderItem[]
     */
    public SearchResultHeaderItem[] getSearchResultHeaderDetailItems() {
        return searchResultHeaderDetailItems;
    }

    /**
     * searchResultHeaderDetailItems を設定します。
     *
     * @param SearchResultHeaderItem[] searchResultHeaderDetailItems 
     */
    public void setSearchResultHeaderDetailItems(
            SearchResultHeaderItem[] searchResultHeaderDetailItems) {
        this.searchResultHeaderDetailItems = searchResultHeaderDetailItems;
    }

    /**
     * jdbcMetaData を戻します。
     * 
     * @return int
     */
    public int getJdbcMetaData() {
        return jdbcMetaData;
    }

    /**
     * jdbcMetaData を設定します。
     *
     * @param int jdbcMetaData 
     */
    public void setJdbcMetaData(int jdbcMetaData) {
        this.jdbcMetaData = jdbcMetaData;
    }

    /**
     * canPreview を戻します。
     * 
     * @return boolean
     */
    public boolean isCanPreview() {
        return canPreview;
    }

    /**
     * canPreview を設定します。
     *
     * @param boolean canPreview 
     */
    public void setCanPreview(boolean canPreview) {
        this.canPreview = canPreview;
    }

    /**
     * canDisplayPreview を戻します。
     * 
     * @return boolean
     */
    public boolean isCanDisplayPreview() {
        return canDisplayPreview;
    }

    /**
     * canPreview を設定します。
     *
     * @param boolean canPreview 
     */
    public void setCanDisplayPreview(boolean canDisplayPreview) {
        this.canDisplayPreview = canDisplayPreview;
    }
}
