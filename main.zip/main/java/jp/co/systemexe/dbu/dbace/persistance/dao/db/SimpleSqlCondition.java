/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.db;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;

/**
 * 単純な SQL 文生成用の条件保持 VO。
 * <p>
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class SimpleSqlCondition {

    /**
     * 対象テーブル名。
     */
    private String tableId;
    
    private String connectDefinitionId;

    /**
     * 更新値マップ。
     */
    private Map<String, String> valuesMap = new HashMap<String, String>();

    /**
     * 条件値マップ。
     */
    private Map<String, String> wheresMap = new HashMap<String, String>();

    /**
     * 並び順マップ。
     */
    private SortedMap<Integer, String> ordersMap = new TreeMap<Integer, String>();

    /**
     * JDBCMetaDataTypeマップ。
     */
    private Map<String, JDBCMetaDataType> jdbcMetaDataMap = new HashMap<String, JDBCMetaDataType>();

    /**
     * DefinedHtmlElementマップ。
     */
    private Map<String, DefinedHtmlElement> htmlElement = new HashMap<String, DefinedHtmlElement>();

    /**
     * バーチャル・カラムか否かマップ
     * <p>
     * Oracle 11gの場合のみ設定されます。
     * </p>
     */
    private Map<String, Boolean> virtualColumns = new HashMap<String, Boolean>();

    /**
     * Update時のSELECT文で列名を別名に置き換える際のマップ
     */
    private Map<String, String> aliasNameMap = new HashMap<String, String>();

    /**
     * データベースのデータ型名マップ。<br>
     * キー：カラム名、値：データベースのデータ型名。<br>
     * Oracleデータベースを対象としたWhere条件生成において、DATE型、TIMESTAMP型といった固有対応の再に使用します。
     */
    private Map<String, String> columnTypeNameMap = new HashMap<String, String>();


	/**
     * データベースのデータ型名を追加する。
     * @param columnName カラム名。
     * @param columnTypeName データ型名。
     * @return
     */
    public void addColumnTypeName(String columnName, String columnTypeName) {
        columnTypeNameMap.put(columnName, columnTypeName);
    }

    /**
     * データベースのデータ型名マップを返す。<br>
     * キー：カラム名、値：データベースのデータ型名。<br>
     * @return
     */
    public Map<String, String> getColumnTypeNameMap() {
        return columnTypeNameMap;
    }

    /**
     * 対象テーブル名を戻します。
     *
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * 対象テーブル名を設定します。
     *
     * @param String tableId
     */
    public void setTableId(String tableId) {
        this.tableId = tableId;
    }

    /**
     * 更新値マップを戻します。
     *
     * @return Map&lt;カラム名,更新値&gt;
     */
    public Map<String, String> getValuesMap() {
        return valuesMap;
    }

    /**
     * 更新値を追加します。
     *
     * @param columnName カラム名
     * @param value 更新値
     */
    public void addValues(final String columnName, final String value) {
        valuesMap.put(columnName, value);
    }

    /**
     * 条件値マップを戻します。
     *
     * @return Map&lt;カラム名,条件値&gt;
     */
    public Map<String, String> getWheresMap() {
        return wheresMap;
    }

    /**
     * 条件値マップを追加します。
     * <p>
     * カラム名 = A で表現される単純な条件しか指定できません。</p>
     *
     * @param columnName カラム名
     * @param value 条件値
     */
    public void addWheres(final String columnName, final String value) {
        wheresMap.put(columnName, value);
    }

    /**
     * ordersMap を戻します。
     *
     * @return SortedMap<Integer,String>
     */
    public SortedMap<Integer, String> getOrdersMap() {
        return ordersMap;
    }

    /**
     * 並び順マップに項目を追加します。
     * <p>
     * index で指定した順番に order by がかかります。</p>
     *
     * @param index 昇順並び優先順
     * @param columnName カラム名
     */
    public void addOrders(final int index, final String columnName) {
        ordersMap.put(index, columnName);
    }

    /**
     * SimpleSqlCondition の生成。
     * <p>コンストラクタ。</p>
     */
    public SimpleSqlCondition() {
        return;
    }

    /**
     * jdbcMetaDataMap を戻します。
     *
     * @return Map<String,JDBCMetaDataType>
     */
    public Map<String, JDBCMetaDataType> getJdbcMetaDataMap() {
        return jdbcMetaDataMap;
    }

    /**
     * JDBCメタデータタイプマップを追加します。
     *
     * @param columnName カラム名
     * @param type JDBC メタデータタイプ
     */
    public void addJdbcMetaData(final String columnName, final JDBCMetaDataType type) {
        jdbcMetaDataMap.put(columnName, type);
    }

    /**
     * htmlElement を設定します。
     *
     * @return Map<String,DefinedHtmlElement>
     */
    public Map<String, DefinedHtmlElement> getHtmlElement() {
        return htmlElement;
    }

    /**
     * JDBCメタデータタイプマップを追加します。
     *
     * @param columnName カラム名
     * @param element DefinedHtmlElement メタデータタイプ
     */
    public void addHtmlElement(final String columnName, final DefinedHtmlElement element) {
        htmlElement.put(columnName, element);
    }

	/**
     * VirtualColumnsマップを追加します。
	 *
     * @param columnName カラム名
     * @param virturalColumns Virtual Columnsか否か
	 */
	public void addVirtualColumns(final String columnName, final boolean virtual) {
		virtualColumns.put(columnName, Boolean.valueOf(virtual));
	}

	/**
	 * virtualColumns を戻します。
	 *
	 * @return Map<String,Boolean>
	 */
	public Map<String, Boolean> getVirtualColumns() {
		return virtualColumns;
	}

	public void addAliasNameMap(final String aliasName, final String columnName) {
		aliasNameMap.put(aliasName, columnName);
	}

	public Map<String, String> getAliasNameMap() {
		return aliasNameMap;
	}

	public String getConnectDefinitionId() {
		return connectDefinitionId;
	}

	public void setConnectDefinitionId(String connectDefinitionId) {
		this.connectDefinitionId = connectDefinitionId;
	}

}
