/**
 * Copyright(C) 2006-2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.exception;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * システム例外が発生した場合にスローされる例外。
 * <p>
 * 実行環境そのものが発生させる例外（いわゆるランタイム例外）です。</p>
 * <p>必要に応じてサブクラスを作成して下さい。</p>
 *
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public abstract class SystemException extends RuntimeException {

    /**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    /**
     * SystemException の生成。
     * <p>コンストラクターです。</p>
     *
     * @param message メッセージです。
     */
    public SystemException(final String message) {
        super(message);
        logger.error(super.getMessage());
    }

    /**
     * SystemException の生成。
     * <p>コンストラクターです。</p>
     *
     * @param message メッセージです。
     * @param te 元の例外です。
     */
    public SystemException(final String message, final Throwable te) {
        super(message, te);
        outputLogger(te);
    }

    /**
     * SystemException の生成。
     * <p>コンストラクターです。</p>
     *
     * @param te
     */
    public SystemException(final Throwable te) {
        super(te);
        outputLogger(te);
    }

    /**
     * SystemException の生成。
     * <p>デフォルトコンストラクタは隠蔽しています。</p>
     */
    private SystemException() {
        return;
    }

    private void outputLogger(final Throwable cause) {
        if (!cause.getClass().getName().matches("^jp\\.co\\.systemexe\\.dbu\\.dbace\\..*")) {
            final StringBuffer buff = new StringBuffer();
            buff.append(cause + "\n");
            for (final StackTraceElement element : cause.getStackTrace()) {
                buff.append("\tat " + element.toString() + "\n");
            }
            logger.error(buff.toString());
        }
    }
}
