/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.List;

import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 Mar 15, 2017
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0200DataParam {
	private String type;
	private String connectDefinisionId;
	private String tableId;
	private String tableLabel;
	private ColumnDisplayDefinitionDTO columnsDisplayDefinition;
	private SearchConditionItem[] searchConditionItems;
	private boolean orderDesc;
	private int resultRowCount;
	public List<ColumnAttributeItemDTO> columnAttributeItems;
	private UserInfo userInfo;
	public Integer columnAttributeIndex;
	public ColumnAttributeItem[] attributeItems;
}
