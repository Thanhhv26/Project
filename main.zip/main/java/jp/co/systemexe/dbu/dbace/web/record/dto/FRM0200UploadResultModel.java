/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author bao-anh
 *
 */

@Data
public class FRM0200UploadResultModel {
	private UploadFileInfo uploadFileInfo;
	private List<MessageInfo> messageInfo;

	public FRM0200UploadResultModel() {
		messageInfo = new ArrayList<MessageInfo>();
	}
}
