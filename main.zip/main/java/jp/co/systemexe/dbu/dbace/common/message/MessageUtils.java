/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.message;

import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Properties;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * メッセージプロパティ保持クラス。
 *
 * <p>
 * 画面表示用のメッセージを保持するクラスです。
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public final class MessageUtils {
    /**
     * ロガーへの参照を保持します。
     */
    private static final Logger logger = LoggerFactory.getLogger(MessageUtils.class.getName());

    //private static final String FILE_NAME = "/appMessages_ja.properties";
    private static final String FILE_NAME = "/i18n/messages_jp.properties";

	private static Properties messageProperties;

	static {
        InputStream stream = null;
        try {
        	stream = MessageUtils.class.getResourceAsStream(FILE_NAME);
            messageProperties = new Properties();
//    		PropertiesUtil.load(messageProperties, stream);
            messageProperties.load(stream);
        } catch (Exception e) {
        	try {
				stream.close();
			} catch (IOException e1) {
	        	logger.warn(e);
			}
        	final String message = "appMessages_ja.propertiesファイルの読込に失敗しました。";
        	logger.fatal(message, e);
        }
	}

	/**
	 * メッセージIDより、メッセージを返します。
	 *
	 * <p>
	 * [メッセージID：メッセージ]の形式でメッセージを返します。
	 * </p>
	 *
	 * @param id
	 * @return
	 */
	public static String getMessage(final String id) {
		//return id + ":" + messageProperties.getProperty(id);
		return messageProperties.getProperty(id);
	}

	/**
	 * メッセージIDとパラメータ(args)の連携されたメッセージを返します。
	 *
	 * <p>
	 * [メッセージID：メッセージ]の形式でメッセージを返します。
	 * </p>
	 *
	 * @param id
	 * @param args
	 * @return
	 */
	public static String getMessage(final String id, final Object[] args) {
		final MessageFormat format = new MessageFormat(getMessage(id));
		return format.format(args);
	}

	/**
	 * メッセージIDより、メッセージを返します。
	 *
	 * <p>
	 * [メッセージ]の形式でメッセージを返します。
	 * </p>
	 *
	 * @param id
	 * @return
	 */
	public static String getMessageNotMessageId(final String id) {
		return messageProperties.getProperty(id);
	}

	/**
	 * メッセージIDとパラメータ(args)の連携されたメッセージを返します。
	 *
	 * <p>
	 * [メッセージ]の形式でメッセージを返します。
	 * </p>
	 *
	 * @param id
	 * @param args
	 * @return
	 */
	public static String getMessageNotMessageId(final String id, final Object[] args) {
		final MessageFormat format = new MessageFormat(getMessageNotMessageId(id));
		return format.format(args);
	}
}
