/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.audit;

/**
 * ユーザー操作権限の付与、剥奪を定義する列挙体。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum AuditUserAuthority {
	GIVE("GIVE"),
	DEPRIVATION("DEPRIVATION");
	
    private String logName;
    public String getLogName() {
        return logName;
    }
    
    private AuditUserAuthority(final String logName) {
    	this.logName = logName;
    }
}
