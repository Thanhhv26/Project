/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.exception;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;

/**
 * DAO クラスで例外が発生した場合にスローされる一般例外です。
 * <p>
 * DAO 内で例外がキャッチされた場合、フォロー処理後、原則この例外に置き換えて
 * 呼び出し元クラス（サービスクラス）に再スローします。</p>
 *
 * @author EXE 相田 一英
 * @author EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class DAOException extends ApplicationException {
    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = -1991016887388422363L;

    /**
     * DAOException の生成。
     * <p>デフォルトコンストラクタ。</p>
     * <p>
     * DAO においては「理由の良く分からない例外」を許可しています。これは、
     * DB の内側で発生し、理由を取得する事が出来ない例外に対する備えです。
     * </p>
     */
    public DAOException() {
        super();
    }

    /**
     * DAOException の生成。
     * <p>コンストラクタ。</p>
     *
     * @param メッセージ文字列
     */
    public DAOException(final String message) {
        super(message);
    }

    /**
     * DAOException の生成。
     * <p>コンストラクタ。</p>
     *
     * @param Throwable
     */
    public DAOException(final Throwable cause) {
        super(cause);
    }

    /**
     * DAOException の生成。
     * <p>コンストラクタ。</p>
     *
     * @param メッセージ文字列
     * @param Throwable
     */
    public DAOException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
