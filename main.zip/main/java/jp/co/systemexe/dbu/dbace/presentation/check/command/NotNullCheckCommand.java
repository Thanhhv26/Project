/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;

/**
 * DB 内の Not Null 制約に対応した null チェック。
 * <p>
 * 値が null 或いは空文字だった場合、警告を出力します。Not Null 制約が定義された
 * 項目に対しては、（常識的には）有意符号を設定しなければならない、という指針に
 * 基き、空文字も警告するものとします。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class NotNullCheckCommand extends BaseLogicalCheckCommand {

    /**
     * NotNullCheckCommand の生成。
     * <p>コンストラクタ。</p>
     */
    public NotNullCheckCommand() {
        return;
    }

    /**
     * 検査を実行します。
     * <p>
     * 値が null 或いは空文字だった場合、警告を出力します。Not Null 制約が定義
     * された項目に対しては、（常識的には）有意符号を設定しなければならない、
     * という指針に基き、空文字も警告するものとします。</p>
     *
     * @param columnId カラム名
     * @param messages 論理チェック結果メッセージ保持 DTO
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#check(java.lang.String, jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO)
     */
    @Override
    public void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
 final CheckMessageDTO messages,
			final Map<String, TableItemDTO> tableItemMap) {
		final String value = messages.getCorrectedValue(columnId);
		if (value == null || value.equals("")) {
			TableItemDTO tableItemDTO = tableItemMap.get(columnId);
			String messErr = "";
			String columnLabel = tableItemMap.get(columnId).getItemLabel();
			final String args[] = { columnLabel };
			if (tableItemDTO.getHtmlElement().getKey().equals(DefinedHtmlElement.SELECT.getKey())
					|| tableItemDTO.getHtmlElement().getKey().equals(DefinedHtmlElement.INPUT_RADIO.getKey())) {
				// MI-E-00081={0}を選択してください
				messErr = MessageUtils.getMessage("MI-E-00081", args);
			} else {
				// MI-E-0008={0}を入力してください
				messErr = MessageUtils.getMessage("MI-E-0008", args);
			}
			if (messages.getMessages(columnId) != null) {
				if (messages.getMessages(columnId).size() > 0
						&& !messErr.equals(messages.getMessages(columnId).get(0))) {
					messages.getMessages(columnId).add(messErr);
				} else {
					messages.getMessages(columnId).add(messErr);
				}
			}

		}
	}

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * このクラスが検査対象とする条件は、
     * <ol>
     *  <li>DB 内に Not Null 制約が定義されている項目。</li>
     *  <li>DB 内に 主キー制約が定義されている項目。</li>
     * </ol>
     * です。通常は主キー制約が定義された時点で、Not Null 制約も併せて定義され
     * ている筈です。
     * </p>
     *
     * @param columnId カラム ID（＝カラム名）
     * @return true : 検査担当 / false : 担当ではない
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#isMyTask(java.lang.String)
     */
    @Override
    protected boolean isMyTask(final String columnId) {
        final DefinitionOfColumn def = getDisplayDef().getDefinitionOfColumns()
            .get(columnId);
        if (def.isNotNull() || def.isPrimaryKey()) {
            return true;
        } else {
            return false;
        }
    }
}
