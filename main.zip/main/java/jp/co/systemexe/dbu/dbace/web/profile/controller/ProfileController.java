package jp.co.systemexe.dbu.dbace.web.profile.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
/**
 * @author THANH TRUC
 * @version 6.0 dec 08, 2016
 */
@RestController
@RequestMapping(value = "/profile")
public class ProfileController extends AbstractController {

	/***/
	private static final long serialVersionUID = 1L;

//	/**
//	 * @see AccountService
//	 */
//	@Autowired
//	private AccountService accountService;

	/**
	 * Index page
	 *
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index(Model model) throws Exception {
		ModelAndView mv = new ModelAndView(PageConst.SCREEN_PROFILE);
		return mv;
	}
}
