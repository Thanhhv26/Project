package jp.co.systemexe.dbu.dbace.web.common;

import lombok.Data;

import org.springframework.http.HttpStatus;

@Data
public class Result<T> {

	private T data;
	private Message message;

	public Result() {}
	public Result(Message message, T data) {
		this.setMessage(message);
		this.setData(data);
	}
	public Result(int code) {
		this(code, null, null, null);
	}
	public Result(int code, String detail, T data) {
		this(code, null, detail, data);
	}
	public Result(int code, String detail) {
		this(code, null, detail, null);
	}
	public Result(int code, String title, String detail, T data) {
		this.setMessage(new Message(code, title, detail));
		this.setData(data);
	}
	public Result(HttpStatus status) {
		this(status.value(), null, null, null);
	}
	public Result(HttpStatus status, String detail, T data) {
		this(status.value(), null, detail, data);
	}
	public Result(HttpStatus status, String detail) {
		this(status.value(), null, detail, null);
	}
	public Result(HttpStatus status, String title, String detail, T data) {
		this.setMessage(new Message(status.value(), title, detail));
		this.setData(data);
	}
}
