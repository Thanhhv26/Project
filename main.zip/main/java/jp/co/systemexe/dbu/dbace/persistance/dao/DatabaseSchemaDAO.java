/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * データベースのスキーマ情報 DAO。
 * <p>
 * データベースのテーブル名一覧やテーブルスキーマ情報へのアクセスを行う DAO です。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public interface DatabaseSchemaDAO {

    /**
     * データベースとの接続テストを実行します。
     * <p>
     * 正常に接続出来た場合はすぐにコネクションを切断しメソッドを終了します。
     * 接続に問題があった場合はコネクションを切断後、例外をスローします。
     * </p>
     *
     * @param dto
     * @param connectionUserLabel
     * @throws DAOException
     */
    public void testConnect(final DbConnectInfomationDTO dto)
            throws DAOException;

    /**
     * データベースとの接続を確立します。
     * <p>
     * 既に接続されている場合は例外をスローします。</p>
     *
     * @param dto DbConnectInfomationDTO
     * @param connectionUserLabel
     * @exception DAOException
     */
    public void connect(final DbConnectInfomationDTO dtol) throws DAOException;

    /**
     * データベースとの接続を閉じます。
     *
     * @throws DAOException
     */
    public void close() throws DAOException;

    /**
     * テーブル名の一覧を取得して戻す。
     * <p>
     * 現在接続を確立しているデータベース内の、アクセス可能なテーブル名の一覧を
     * 取得して戻します。
     * </p><p>
     * テーブル名の前方はスキーマ名で修飾されています。
     * <code>(スキーマ名).(テーブル名)</code>
     * </p>
     *
     * @return List&lt;テーブル名&gt;
     * @throws DAOException
     */
    public List<String> getTableNameList(final String condition) throws DAOException;

    /**
     * テーブルの定義情報を取得します。
     * <p>
     * テーブルのカラム詳細情報 DTO を取得して戻します。</p>
     *
     * @param tableId テーブル ID
     * @return TableDefinitionDTO
     * @throws DAOException
     */
    public TableDefinitionDTO getTableDefinition(final String tableId)
            throws DAOException;

    /**
     * テーブルの定義情報を取得します。
     * <p>
     * テーブルのカラム詳細情報 DTO を取得して戻します。</p>
     *
     * @param tableId テーブル ID
     * @return TableDefinitionDTO
     * @throws DAOException
     */
    public TableDefinitionDTO getTableDefinition(TableFormDTO multiTableFormDTO)
            throws DAOException;

}
