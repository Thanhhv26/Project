/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.db;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerUtils;

/**
 * データベースの数値型フィールドの精度定義保持 VO。
 * <p>
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class DefinitionOfNumericalValue {
    /**
     * ロガーインスタンスを保持します。
     */
    private final Logger logger;

    /**
     * 10 進桁数。
     */
    private int precision;

    /**
     * 小数点以下桁数。
     */
    private int scale;

    /**
     *10 進桁数を戻します。
     * 
     * @return int
     */
    public int getPrecision() {
        return precision;
    }

    /**
     * 10 進桁数を設定します。
     *
     * @param int precision 
     */
    public void setPrecision(int precision) {
        this.precision = precision;
    }

    /**
     * 小数点以下桁数を戻します。
     * 
     * @return int
     */
    public int getScale() {
        return scale;
    }

    /**
     * 小数点以下桁数を設定します。
     *
     * @param int scale 
     */
    public void setScale(int scale) {
        this.scale = scale;
    }

    /**
     * DefinitionOfNumericalValue の生成。
     * <p>コンストラクタ。</p>
     */
    public DefinitionOfNumericalValue() {
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
        return;
    }
    
	/**
	 * クラスが保持しているプロパティ情報をログ出力します。
	 */
	public void outputDebugLog() {
		outputDebugLog(0);
	}
	
	/**
	 * クラスが保持しているプロパティ情報をログ出力します。
	 */
	public void outputDebugLog(final int index) {
		if (logger.isDebugEnabled()) {
			final String indexString = LoggerUtils.getIndexString(index);
			logger.debug(indexString + "DefinitionOfNumericalValue ---------- DEBUG START");
			logger.debug(indexString + "　Percision:" + precision);
			logger.debug(indexString + "　Scale:" + scale);
			logger.debug(indexString + "DefinitionOfNumericalValue ---------- DEBUG END");
		}
	}
}
