/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.xml.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * テーブルフォーム項目に付加する制限定義 enum。
 * <p>
 * テーブルフォーム項目、即ち画面上の入力項目に対して付加する入力制限（制約）の
 * 種類を定義した列挙体です。
 * </p><p>
 * 各項目に対してこれらの制約を複数組み合わせて定義する事が出来ます。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public enum ItemRestriction {
    /**
     * 日付書式のみ入力可能。
     */
    ONLY_DATE_FORMAT("only-date-format", "日付書式のみ入力可能"),
    /**
     * アルファベット入力不可。
     */
    ALPHABET_CANNOT_BE_INPUT("alphabet-cannot-be-input", "アルファベット入力不可"),
    /**
     * アルファベット大文字入力不可。
     */
    ALPHABET_UPPERCASE_CANNOT_BE_INPUT("alphabet-uppercase_cannot-be-input", "アルファベット大文字入力不可"),
    /**
     * アルファベット小文字入力不可。
     */
    ALPHABET_LOWERCASE_CANNOT_BE_INPUT("alphabet-lowercase_cannot-be-input", "アルファベット小文字入力不可"),
    /**
     * 数字入力不可。
     */
    NUM_CANNOT_BE_INPUT("num-cannot-be-input", "数字入力不可"),
    /**
     * 数字とアルファベット以外入力不可。
     */
    ONLY_FIGURE_AND_ALPHABET("only-figure-and-alphabet", "数字とアルファベット以外入力不可"),
    /**
     * 半角文字（半角数値、半角カナ、半角英語、半角記号）入力不可。
     * <p>
     * 半角文字（半角数値、半角カナ、半角英語、半角記号）の入力を禁じる制約です。
     * </p>
     */
    JISX0201_CANNOT_BE_INPUT("jisx0201-cannot-be-input", "半角文字入力不可"),
    /**
     * 全角文字入力不可。
     * <p>
     * 半角文字（半角数値、半角カナ、半角英語、半角記号）以外の入力、いわゆる全角文字の入力を禁じる制約です。
     * </p>
     */
    FULL_WIDTH_CHARACTER_CANNOT_BE_INPUT("full-width-character-cannot-be-input", "全角文字入力不可"),
    /**
     * null、空文字、ホワイトスペースのみの入力不可。
     * <p>
     * not null だけではなく、空文字やホワイトスペース（のみ）の入力を禁じる
     * 制約です。
     * </p>
     */
    EMPTY_CANNOT_BE_INPUT("empty-cannot-be-input", "null、空文字、ホワイトスペースのみの入力不可"),
    /**
     * 文字列の前後にホワイトスペースを含まない制約。
     * <p>
     * 入力値文字列の前後にホワイトスペースを含まないようにする制約です。
     * いわゆる trim をかける、という補正が必要な値が対象です。</p>
     */
    NOT_CONTAIN_WHITESPACE_BACK_AND_FORTH(
            "not-contain-whitespace-back-and-forth", "文字列の前後にホワイトスペースを含まない"),
    /**
     * 入力をリスト系アイテムの内容に制限する。
     * <p>
     * 入力をリスト系アイテムに存在する値に制限する制約です。
     * </p>
     */
    NOT_CONTAIN_LISTITEM("not-contain-listitem", "入力をリスト系アイテムのキー値に制限");

    private static Map<String, ItemRestriction> map;
    static {
        map = new HashMap<String, ItemRestriction>();
        for (final ItemRestriction buff : values()) {
            map.put(buff.getId(), buff);
        }
    }

    /**
     * ID に対応した定義インスタンスを検索して戻します。
     * <p>
     * 未定義 ID だった場合は null を戻します。</p>
     *
     * @param id
     * @return
     */
    public static ItemRestriction idOf(final String id) {
        if (map.containsKey(id)) {
            return map.get(id);
        } else {
            return null;
        }
    }

    private final String id;
    private final String label;

    /**
     * id を戻します。
     *
     * @return String
     */
    public String getId() {
        return id;
    }

    /**
     * label を戻します。
     *
     * @return String
     */
    public String getLabel() {
        return label;
    }

    private ItemRestriction(final String id, final String label) {
        this.id = id;
        this.label = label;
    }
}
