/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.config;

/**
 * system.propertiesを読み込む際のKeyを保持する列挙体です。
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum SystemPropertyKeys {

	/**
	 * アプリケーション名
	 */
	APPLICATION_NAME("application_name", "DB エース メンテナンスエディション"),

	/**
	 * 開発モードでの動作指示フラグ
	 */
	DEVELOPMENT_MODE("development_mode", "false"),

	/**
	 * アプリケーションリポジトリファイル
	 */
	APP_REPOSITORY("app_repository", "./webapps/dbace/WEB-INF/appresources/repository.xml"),

	/**
	 * レコード検索画面で一画面に表示するレコード数
	 */
	DISPLAYED_NUMBER_OF_RECORDS("displayed-number-of-records", "10"),

	/**
	 * レコード検索画面で一画面に表示するカラム数
	 */
	PREVIEW_COLUMN_COUNT("preview-column-count", "4"),

	/**
	 * レコード検索画面で検索できる最大件数
	 */
	SEARCH_MAX_RECORD_COUNT("search-max-record-count", "100000"),

	/**
	 * 検索条件XMLファイルのパスを返します。
	 */
	SEARCH_CONDITION_FILEPATH("search_condition_filepath", "./webapps/dbace/WEB-INF/user/searchcondition"),

	/**
	 * 工事中
	 */
	SEARCH_COMPARISON_OPERATOR_ORDER("search_comparison_operator_order",
			"isNull,isNotNull,equal,notEqual,greaterEqual,lessEqual,greaterThan,lessThan,likeContains,likeStartsWith,likeEndsWith,notLikeContains,notLikeStartsWith,notLikeEndsWith"),

	/**
	 * プルダウンに表示できる、アイテムの最大件数
	 */
	PULLDOWN_MAX_COUNT("pulldown_max_count", "2000"),

	/**
	 * データベースのフェッチサイズ(プルダウン用)
	 */
	PREFETCH_SIZE("prefetch_size", "100"),

	/**
	 * データベースのフェッチサイズ(検索用)
	 */
	DOWNLOAD_FETCH_SIZE("download_fetch_size", "100"),

	/**
	 * 監査ログ設定ファイルパス
	 */
	AUDIT_SETTING("audit_setting", "./webapps/dbace/WEB-INF/appresources/auditSetting.xml"),

	/**
	 * ダウンロードファイル最大バイト(EXCEL)
	 */
	DOWNLOAD_MAXIMUM_BYTE_FOR_EXCEL("download_maximum_byte_for_excel", "10"),

	/**
	 * ダウンロードファイル最大バイト(CSV)
	 */
	DOWNLOAD_MAXIMUM_BYTE_FOR_CSV("download_maximum_byte_for_csv", "10"),

	/**
	 * インポートファイル最大バイト(EXCEL)
	 */
	IMPORT_MAXIMUM_BYTE_FOR_EXCEL("import_maximum_byte_for_excel", "10"),

	/**
	 * インポートファイル最大バイト(CSV)
	 */
	IMPORT_MAXIMUM_BYTE_FOR_CSV("import_maximum_byte_for_csv", "10"),

	/**
	 * インポートファイル最大バイト(TSV)
	 */
	IMPORT_MAXIMUM_BYTE_FOR_TSV("import_maximum_byte_for_tsv", "10"),

	/**
	 * インポートファイルの一時格納フォルダパス
	 */
	IMPORT_TEMP_FILE_PATH("import_temp_file_path", "./webapps/dbace/WEB-INF/temp"),

	// ADD ライセンス認証と外部認証連携の機能追加　↓
	/**
	 * ライセンスキー
	 */
	LICENSE_KEY("license-key", ""),

	/**
	 * ライセンス数
	 */
	LICENSE_CNT("license-cnt", ""),

	/**
	 * 外部認証
	 */
	EXT_AUTH("ext-auth", "OFF"),

	/**
	 * サーバーID
	 */
	AUTH_SERVER_ID("auth-server-id", ""),

	/**
	 * サーバー種類
	 */
	AUTH_SERVER_TYPE("auth-server-type", ""),

	/**
	 * ポート番号
	 */
	AUTH_SERVER_PORT("auth-server-port", ""),

	/**
	 * ベースDN／ドメイン名
	 */
	AUTH_SERVER_BASE_DOMAIN("auth-server-base-domain", ""),

	/**
	 * 接続ユーザーの識別子
	 */
	AUTH_SERVER_USER_IDENTIFY("auth-server-user-identify", ""),

	/**
	 * サーバープロトコル
	 */
	AUTH_SERVER_PROTOCOL("auth-server-protocol", ""),

	/**
	 * サーバーセキュリティ
	 */
	AUTH_SERVER_SECURITY("auth-server-security", "simple"),

	/**
	 * サーバータイムアウト
	 */
	AUTH_SERVER_TIMEOUT("auth-server-timeout", "3000"),

	/**
	 * 接続ユーザー
	 */
	AUTH_CONNECT_USERNAME("auth-connect-username", ""),

	/**
	 * 接続パスワード
	 */
	AUTH_CONNECT_PWD("auth-connect-pwd", ""),

	/**
	 * Download Mode
	 */
	DOWNLOAD_MODE("download_mode", "0");
	// ADD ライセンス認証と外部認証連携の機能追加　↑

	private SystemPropertyKeys(final String propertyKey, final String defaultValue) {
		this.propertyKey = propertyKey;
		this.defaultValue = defaultValue;
	}

	private String propertyKey;
	private String defaultValue;

	/**
	 * defaultValue を戻します。
	 *
	 * @return String
	 */
	public String getDefaultValue() {
		return defaultValue;
	}

	/**
	 * propertyKey を戻します。
	 *
	 * @return String
	 */
	public String getPropertyKey() {
		return propertyKey;
	}

}
