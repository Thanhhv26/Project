package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import java.io.Serializable;

/**
 * カラムソート情報表示用の Item クラスです。
 *
 * @author  EXE 六本木 圭
 * @version 0.0.0
 */
public class SortingInformationItem implements Serializable {

    /**
     * serialVersionUID のコメント。
     */
    private static final long serialVersionUID = -1516547334703381468L;

    /**
     * ソート順序情報プロパティ。 
     */
    private Integer sortOrder;

    /**
     * カラム ID 情報保持プロパティ。 
     */
    private String colmunID;
    
    /**
     * カラム Label 情報保持プロパティ。
     */
    private String colmunLabel;

    /**
     * カラム ID 情報保持プロパティを戻します。
     * 
     * @return String
     */
    public String getColmunID() {
        return colmunID;
    }

    /**
     * カラム ID 情報保持プロパティを設定します。
     *
     * @param String colmunID 
     */
    public void setColmunID(String colmunID) {
        this.colmunID = colmunID;
    }

    /**
     * カラム Label 情報保持プロパティを戻します。
     * 
     * @return String
     */
    public String getColmunLabel() {
        return colmunLabel;
    }

    /**
     * カラム Label 情報保持プロパティを設定します。
     *
     * @param String colmunLabel 
     */
    public void setColmunLabel(String colmunLabel) {
        this.colmunLabel = colmunLabel;
    }

    /**
     * ソート順序情報プロパティを戻します。
     * 
     * @return Integer
     */
    public Integer getSortOrder() {
        return sortOrder;
    }

    /**
     * ソート順序情報プロパティを設定します。
     *
     * @param Integer sortOrder 
     */
    public void setSortOrder(Integer sort) {
        this.sortOrder = sort;
    }
}
