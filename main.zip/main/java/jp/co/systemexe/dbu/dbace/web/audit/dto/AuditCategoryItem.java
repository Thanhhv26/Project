/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.audit.dto;

import java.io.Serializable;

/**
 * 画面表示用の監査カテゴリを保持する DTOです。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class AuditCategoryItem implements Serializable {
    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 6447104079765014672L;
    
    /**
     * 監査カテゴリが選択されているか否か
     */
    private boolean selectedAuditCategory;
    
    /**
     * 画面表示用監査カテゴリ名
     */
    private String auditCategoryDispName;
    
    /**
     * 監査カテゴリ名
     */
    private String auditName;
    
    /**
     * 監査カテゴリの説明
     */
    private String auditCategoryExplanation;
    
    /**
     * ダミー(TeedaはforEach内の入力フィールドがcheckboxのみだと、正しく値が取得できないため)
     */
    private String dummy;
    
    /**
     * auditCategoryExplanation を戻します。
     * 
     * @return String
     */
    public String getAuditCategoryExplanation() {
        return auditCategoryExplanation;
    }
    /**
     * auditCategoryExplanation を設定します。
     *
     * @param String auditCategoryExplanation 
     */
    public void setAuditCategoryExplanation(String auditCategoryExplanation) {
        this.auditCategoryExplanation = auditCategoryExplanation;
    }
    /**
     * auditName を戻します。
     * 
     * @return String
     */
    public String getAuditName() {
        return auditName;
    }
    /**
     * auditName を設定します。
     *
     * @param String auditName 
     */
    public void setAuditName(String auditName) {
        this.auditName = auditName;
    }
    /**
     * selectedAuditCategory を戻します。
     * 
     * @return boolean
     */
    public boolean isSelectedAuditCategory() {
        return selectedAuditCategory;
    }
    /**
     * selectedAuditCategory を設定します。
     *
     * @param boolean selectedAuditCategory 
     */
    public void setSelectedAuditCategory(boolean selectedAuditCategory) {
        this.selectedAuditCategory = selectedAuditCategory;
    }
    /**
     * auditCategoryDispName を戻します。
     * 
     * @return String
     */
    public String getAuditCategoryDispName() {
        return auditCategoryDispName;
    }
    /**
     * auditCategoryDispName を設定します。
     *
     * @param String auditCategoryDispName 
     */
    public void setAuditCategoryDispName(String auditCategoryDispName) {
        this.auditCategoryDispName = auditCategoryDispName;
    }
    /**
     * dummy を戻します。
     * 
     * @return String
     */
    public String getDummy() {
        return dummy;
    }
    /**
     * dummy を設定します。
     *
     * @param String dummy 
     */
    public void setDummy(String dummy) {
        this.dummy = dummy;
    }
}
