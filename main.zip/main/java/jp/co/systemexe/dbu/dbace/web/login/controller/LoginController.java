/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.login.controller;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.config.SystemPropertyKeys;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.exception.CheckException;
import jp.co.systemexe.dbu.dbace.common.exception.SystemResourceNotFoundException;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.util.LicenseKeyUtils;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfAuditSettingLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.library.enums.AuthenticationEnum;
import jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseRepositoryXmlDAO;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
/**
 * Login User
 * @author tu-lenh
 * @version 0.0.0
 */
@RestController
@RequestMapping(value = {"","/","/web/login"})
public class LoginController extends AbstractController {
	private static final long serialVersionUID = 1L;
	/**
	 * Login
	 *
	 * @param error
	 * @param logout
	 * @param session
	 * @return
	 */
	@RequestMapping(method = { RequestMethod.GET })
	public ModelAndView login(@RequestParam(value = "error", required = false) String error,HttpSession session) {
		ModelAndView mv = new ModelAndView("FRM0000");
		boolean isLicenseInputVisible = false;
		if (error == null) {
			//check repository.xml valid
			 try {
		            final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		            logic.createConnectDefinisionDAO();
		        } catch (final ApplicationDomainLogicException e) {
		            getLogger().error(e.getMessage());
		            // MI-F-0019=リポジトリXMLファイルの解析中にエラーが発生しました。
		            String messXmlContentInvalid = MessageUtils.getMessage("MI-F-0019");
		            // MI-F-0014=リポジトリXMLファイルが存在しません。
		            String messXmlNotFound = MessageUtils.getMessage("MI-F-0014");
		            try {
						isLicenseInputVisible = isValidLicenseKeyXML();
					} catch (ApplicationException e1) {
						isLicenseInputVisible = true;
					}
		            mv.addObject("visibleLicenseKey", isLicenseInputVisible);
					if (e.getMessage() != null && e.getMessage().contains(messXmlContentInvalid)) {
						mv.addObject("error", messXmlContentInvalid);
						outputLoginAuditLog(false);
					} else if (e.getMessage() != null && e.getMessage().contains(messXmlNotFound)) {
						mv.addObject("error", messXmlNotFound);
						outputLoginAuditLog(false);
					}
		            return mv;
		        } catch (final Exception e) {
		            getLogger().error(e.getMessage());
		            mv.addObject("error", e.getMessage());
		            return mv;
		        }
			try {
				//check system.propertes
				String FILE_NAME = "/system.properties";
		        Properties prop = new Properties();
		        try {
		            final InputStream stream = SystemProperties.class.getResourceAsStream(FILE_NAME);
		            if(stream == null){
						String messSystemPropertiesNotExist =  messageService.getMessage("system.properties.notexist");
						mv.addObject("error", messSystemPropertiesNotExist);
						outputLoginAuditLog(false);
						return mv;
		            }
		            prop.loadFromXML(stream);
		            stream.close();
		        } catch (final IOException e) {
		        	// MI-F-0005=システム設定ファイル(system.properties)の読込みに失敗しました。
		            final String message = MessageUtils.getMessage("MI-F-0005");
		            logger.fatal(message, e);
		            String systemPropertiesIncomplete =  messageService.getMessage("system.properties.incomplete");
					mv.addObject("error", systemPropertiesIncomplete);
					outputLoginAuditLog(false);
					return mv;
		        }
		        //check audit
				try {
					File file = SystemProperties.getAuditSettingFile();
				} catch (SystemResourceNotFoundException e) {
					// MI-F-0003=監査ログ設定XMLファイルが存在しません。
//					final String message = MessageUtils.getMessage("MI-F-0003");
					logger.fatal(e.getMessage());
				   String messAuditSettingNotExist =  messageService.getMessage("audit.setting.notexist");
					mv.addObject("error", messAuditSettingNotExist);
					outputLoginAuditLog(false);
					return mv;
				}
				final AcquisitionOfAuditSettingLogic logic = new AcquisitionOfAuditSettingLogic();
		        try {
		        	logic.getAuditSetting();
		        } catch (final ApplicationDomainLogicException e) {
		        	logger.fatal(e.getMessage());
				    String messAuditSettingInComplete =  messageService.getMessage("audit.setting.incomplete");
					mv.addObject("error", messAuditSettingInComplete);
					outputLoginAuditLog(false);
					return mv;
		        }
				isLicenseInputVisible = isValidLicenseKeyXML();
			} catch (ApplicationException e) {
				//MI-F-0022=ライセンス期限切れです。延長を希望される場合は、販売元へお問い合わせください。
				String message =  messageService.getMessage("MI-F-0022");
				isLicenseInputVisible = true;
				if (e.getMessage().equals(message)) {
					String messageExpired =  messageService.getMessage("MI-F-000000");
					mv.addObject("error", messageExpired);
				}
				mv.addObject("visibleLicenseKey", isLicenseInputVisible);
				return mv;
			}
			mv.addObject("visibleLicenseKey", isLicenseInputVisible);
		} else {
			//check repository.xml valid
			 try {
		            final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		            logic.createConnectDefinisionDAO();
		        } catch (final ApplicationDomainLogicException e) {
		            getLogger().error(e.getMessage());
		            // MI-F-0019=リポジトリXMLファイルの解析中にエラーが発生しました。
		            String messXmlContentInvalid = MessageUtils.getMessage("MI-F-0019");
		            // MI-F-0014=リポジトリXMLファイルが存在しません。
		            String messXmlNotFound = MessageUtils.getMessage("MI-F-0014");
		            try {
						isLicenseInputVisible = isValidLicenseKeyXML();
					} catch (ApplicationException e1) {
						isLicenseInputVisible = true;
					}
		            mv.addObject("visibleLicenseKey", isLicenseInputVisible);
					if (e.getMessage() != null && e.getMessage().contains(messXmlContentInvalid)) {
						mv.addObject("error", messXmlContentInvalid);
						outputLoginAuditLog(false);
					} else if (e.getMessage() != null && e.getMessage().contains(messXmlNotFound)) {
						mv.addObject("error", messXmlNotFound);
						outputLoginAuditLog(false);
					}
		            return mv;
		        } catch (final Exception e) {
		            getLogger().error(e.getMessage());
		            mv.addObject("error", e.getMessage());
		            return mv;
		        }
			 String msg = "";
            AuthenticationEnum authEnum = AuthenticationEnum.authCodeMapOf(error);
            if (authEnum != null) {
                switch (authEnum) {
                    case U_PRINCIPAL_REQUIRED:
                        msg = MessageUtils.getMessage("MI-FF-0000");
                        break;
                    case P_PRINCIPAL_REQUIRED:
                    	msg = MessageUtils.getMessage("MI-FF-00000");
                        break;
                    case LK_PRINCIPAL_REQUIRED:
                    	isLicenseInputVisible = true;
                    	msg = MessageUtils.getMessage("MI-FF-000000");
                        break;
                    case VALIDLK_PRINCIPAL_REQUIRED:
                    	isLicenseInputVisible = true;
                    	msg = MessageUtils.getMessage("MI-F-00000");
                        break;
                    case NOTEXPIREDLK_PRINCIPAL_REQUIRED:
                    	isLicenseInputVisible = true;
                    	msg = MessageUtils.getMessage("MI-F-000000");
                        break;
                    case INCORRECTUP_PRINCIPAL_REQUIRED:
                    	msg = MessageUtils.getMessage("MI-F-0000");
                        break;
                    case REPOSITORY_NOT_EXIST:
    		            // MI-F-0014=リポジトリXMLファイルが存在しません。
    		            msg = MessageUtils.getMessage("MI-F-0014");
                        break;
                    case CONTENT_REPOSITORY_INVALID:
                    	// MI-F-0019=リポジトリXMLファイルの解析中にエラーが発生しました。
                    	msg = MessageUtils.getMessage("MI-F-0019");
                        break;
                    case VALID_BACKUP_REPOSITORY:
                    	//  MI-F-0012=リポジトリXMLバックアップファイルが存在しません。
                    	msg = MessageUtils.getMessage("MI-F-0033");
                        break;
                    default:
                        break;
                }
            }
            mv.addObject("error", msg);
		}
		mv.addObject("visibleLicenseKey", isLicenseInputVisible);
		return mv;
	}



	/**
	 * @param isSuccess
	 */
	private void outputLoginAuditLog(boolean isSuccess) {
		OutputAuditLog.writeLoginLogoutLog(
	    		AuditEventKind.LOGIN,
	    		null,
	    		"",
	    		isSuccess ? AuditStatus.success : AuditStatus.failure);
	}
	/**
	 *
	 * Check license key in System.Propertise
	 * @return
	 * @throws ApplicationException
	 */
	private boolean isValidLicenseKeyXML() throws ApplicationException{
		BaseRepositoryXmlDAO baseRepositoryXmlDAO = new BaseRepositoryXmlDAO() {};
		Properties prop = readAgainSystemPoperties();
		String license = getPropertyString(prop,SystemPropertyKeys.LICENSE_KEY);
		//String license = SystemProperties.getLicenseKey();
		//LicenseKeyUtils.notExistLicenseKeyInXML();
  		if (StringUtils.isEmpty(license)) {
  			String message =  messageService.getMessage("MI-F-0021");
			throw new CheckException(message);
		}
		if (!LicenseKeyUtils.isValidFormat(license, baseRepositoryXmlDAO.openSesame())) {
			//MI-F-0021=ライセンスキーがあっていません。
			String message =  messageService.getMessage("MI-F-0021");
			throw new CheckException(message);
		}
		if (!LicenseKeyUtils.isNotExpired(license, baseRepositoryXmlDAO.openSesame())) {
			// MI-F-0022=ライセンス期限切れです。延長を希望される場合は、販売元へお問い合わせください。
			String message =  messageService.getMessage("MI-F-0022");
			throw new CheckException(message);
		}
		return false;
	}

	 /**
	 * @return
	 */
	public Properties readAgainSystemPoperties() {
	    	String FILE_NAME = "/system.properties";
	        Properties prop = new Properties();
	        try {
	            final InputStream stream = SystemProperties.class.getResourceAsStream(FILE_NAME);
	            prop.loadFromXML(stream);
	            stream.close();
	        } catch (final IOException e) {
	        	// MI-F-0005=システム設定ファイル(system.properties)の読込みに失敗しました。
	            final String message = MessageUtils.getMessage("MI-F-0005");
	            logger.fatal(message, e);
	        }
	        return prop;
	    }

	    /**
	     * @param prop
	     * @param key
	     * @return
	     */
	    public String getPropertyString(Properties prop,final SystemPropertyKeys key) {
	    	final String value = prop.getProperty(key.getPropertyKey());
	    	if (value == null) {
	    		return key.getDefaultValue();
	    	} else {
	    		return value;
	    	}
	    }

}