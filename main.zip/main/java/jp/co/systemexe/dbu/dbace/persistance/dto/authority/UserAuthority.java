/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto.authority;

import java.io.Serializable;
import java.util.List;

/**
 * ユーザー権限定義 DTO。
 * <p>
 * 接続定義毎のユーザー権限を保持するDTOです。
 * </p>
 *
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public class UserAuthority implements Serializable {

	/**
     * serialVersionUID。
     */
    private static final long serialVersionUID = 1L;

	/**
	 * システム管理者か否か
	 */
	private boolean isSystemAdministrator;

	/**
	 * 接続定義毎のアプリケーション操作権限を保持する
	 */
	private List<ConnectDefinisionAuthority> connectDefinisionAuthoritys;

	/**
	 * isSystemAdministrator を戻します。
	 *
	 * @return boolean
	 */
	public boolean isSystemAdministrator() {
		return isSystemAdministrator;
	}

	/**
	 * isSystemAdministrator を設定します。
	 *
	 * @param boolean isSystemAdministrator
	 */
	public void setSystemAdministrator(boolean isSystemAdministrator) {
		this.isSystemAdministrator = isSystemAdministrator;
	}

	/**
	 * connectDefinisionAuthoritys を戻します。
	 *
	 * @return List<ConnectDefinisionAuthority>
	 */
	public List<ConnectDefinisionAuthority> getConnectDefinisionAuthoritys() {
		return connectDefinisionAuthoritys;
	}

	/**
	 * connectDefinisionAuthoritys を設定します。
	 *
	 * @param List<ConnectDefinisionAuthority> connectDefinisionAuthoritys
	 */
	public void setConnectDefinisionAuthoritys(
			List<ConnectDefinisionAuthority> connectDefinisionAuthoritys) {
		this.connectDefinisionAuthoritys = connectDefinisionAuthoritys;
	}
}
