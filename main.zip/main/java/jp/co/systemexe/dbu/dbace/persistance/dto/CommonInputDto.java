package jp.co.systemexe.dbu.dbace.persistance.dto;

import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

public class CommonInputDto implements InputDto {

	private DbConnectInfomationDTO dbConnectInfomationDTO;
	private UserInfo userInfo;
	private TableDefinitionDTO tableDef;
	private TableFormDTO tableForm;

	@Override
	public void setDbConnectInfomationDTO(DbConnectInfomationDTO dbConnectInfomationDTO) {
		this.dbConnectInfomationDTO = dbConnectInfomationDTO;
	}

	@Override
	public DbConnectInfomationDTO getDbConnectInfomationDTO() {
		return dbConnectInfomationDTO;
	}

	@Override
	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	@Override
	public UserInfo getUserInfo() {
		return userInfo;
	}

	@Override
	public void setTableDefinitionDTO(TableDefinitionDTO tableDef) {
		this.tableDef = tableDef;
	}

	@Override
	public TableDefinitionDTO getTableDefinitionDTO() {
		return tableDef;
	}

	@Override
	public void setTableFormDTO(TableFormDTO tableForm) {
		this.tableForm = tableForm;
	}

	@Override
	public TableFormDTO getTableFormDTO() {
		return tableForm;
	}
}
