/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.ItemRestriction;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;

/**
 * 数字とアルファベット以外入力不可チェック。
 * <p>
 * 数字とアルファベット以外の入力を禁じる項目用のチェックコマンドです。</p>
 *
 * @author	EXE 相田 一英
 * @author EXE 島田 雄一郎
 * @author EXE ウォン フェイ
 * @version 0.0.0
 */
public class OnlyFigureAndAlphabetCheckCommand extends BaseLogicalCheckCommand {

    /**
     * 「数字とアルファベット以外」の定義正規表現文字列。
     * <p>
     * 半角文字数字「\w」、全角アルファベット「ａ-ｚＡ-Ｚ」、全角数字「０-９」
     * 以外、として定義しています。
     * </p>
     */
    private static final String REGEX = "[\\wａ-ｚＡ-Ｚ０-９]+";

    /**
     * OnlyFigureAndAlphabetCheckCommand の生成。
     * <p>コンストラクタ。</p>
     */
    public OnlyFigureAndAlphabetCheckCommand() {
        return;
    }

    /**
     * 検査を実行します。
     * <p>
     * 大文字・小文字・全角・半角を問わず数字或いはアルファベット以外の文字を
     * 検出した場合、警告を設定した上で、対象文字を除外した補正値を設定します。
     * </p><p>
     * null または空文字だった場合は検査を行いません。</p>
     *
     * @param columnId カラム名
     * @param messages 論理チェック結果メッセージ保持 DTO
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#check(java.lang.String, java.lang.String, jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO)
     */
    @Override
    public void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
    		final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap) {
        final String value = messages.getCorrectedValue(columnId);
        if (value == null || value.equals("")) {
            return;
        }
        if (!value.matches(REGEX)) {
        	// MI-E-0083={0}には数字とアルファベット以外の入力は出来ません。
        	String columnLabel = tableItemMap.get(columnId).getItemLabel();
        	final String args[] = {columnLabel};
            messages.getMessages(columnId).add(MessageUtils.getMessage("MI-E-0083",args));
        }
    }

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * このクラスが検査対象とする条件は、
     * <ol>
     *  <li>リポジトリの入力値制約に ONLY_FIGURE_AND_ALPHABET 制約が存在する場合。</li>
     * </ol>
     * </p>
     *
     * @param columnId
     * @return true : 検査担当 / false : 担当ではない
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#isMyTask(java.lang.String)
     */
    @Override
    protected boolean isMyTask(final String columnId) {
        final TableItemDTO item = getDisplayDef().getItemDefinitions().get(
            columnId);
        if (item.getItemRestrictions().containsKey(
            ItemRestriction.ONLY_FIGURE_AND_ALPHABET)) {
            return true;
        }
        return false;
    }
}
