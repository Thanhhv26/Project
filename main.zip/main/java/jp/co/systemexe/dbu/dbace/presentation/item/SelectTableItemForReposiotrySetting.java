/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item;

import java.io.Serializable;

/**
 * Teeda ForEach Item。
 * <p>
 * リポジトリ設定テーブルアイテム。</p>
 * <p>
 * Teeda HTML テンプレート内で check box 要素を含む foreach 用リストを使用する際
 * に、そのリスト内の値を定義するためのクラスです。</p>
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class SelectTableItemForReposiotrySetting implements Serializable {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 5439511806652746637L;
    /**
     * angular ui-grid
     */
    private String $$hashKey;
    /**
     * チェックボックスの選択状態を保持します。
     * <p>check = true / not check = false</p>
     */
    private boolean selected;

    /**
     * テーブル ID を保持します。
     * <p>システム内部で扱われる テーブル ID です。</p>
     */
    private String value;

    /**
     * テーブル表示名を保持します。
     * <p>ユーザーが定義するテーブルIDに付けた表示用名称です。</p>
     */
    private String label;

    /**
     * テーブルがリポジトリに保存されているかどうかを保持します。
     */
    private String tableRegisteredInRepository;

    /**
     * ビューか否かを返します。
     */
    private boolean view;

    /**
     * ダミーフィールド
     */
    private String dummy;

    /**
	 * dummy を戻します。
	 *
	 * @return String
	 */
	public String getDummy() {
		return dummy;
	}

	/**
	 * dummy を設定します。
	 *
	 * @param String dummy
	 */
	public void setDummy(String dummy) {
		this.dummy = dummy;
	}

    /**
     * label を戻します。
     *
     * @return String
     */
    public String getLabel() {
        return label;
    }

    /**
     * label を設定します。
     *
     * @param String label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * selected を戻します。
     *
     * @return boolean
     */
    public boolean isSelected() {
        return selected;
    }

    /**
     * selected を設定します。
     *
     * @param boolean selected
     */
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    /**
     * value を戻します。
     *
     * @return String
     */
    public String getValue() {
        return value;
    }

    /**
     * value を設定します。
     *
     * @param String value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * SelectTableItemForReposiotrySetting.java の生成。
     * <p>コンストラクタ。</p>
     */
    public SelectTableItemForReposiotrySetting() {
        super();
    }

    /**
     * tableRegisteredInRepository を戻します。
     *
     * @return String
     */
    public String getTableRegisteredInRepository() {
        return tableRegisteredInRepository;
    }

    /**
     * tableRegisteredInRepository を設定します。
     *
     * @param String tableRegisteredInRepository
     */
    public void setTableRegisteredInRepository(String tableRegisteredInRepository) {
        this.tableRegisteredInRepository = tableRegisteredInRepository;
    }

	/**
	 * view を戻します。
	 *
	 * @return boolean
	 */
	public boolean isView() {
		return view;
	}

	/**
	 * view を設定します。
	 *
	 * @param boolean view
	 */
	public void setView(boolean view) {
		this.view = view;
	}

	public String get$$hashKey() {
		return $$hashKey;
	}

	public void set$$hashKey(String $$hashKey) {
		this.$$hashKey = $$hashKey;
	}

}
