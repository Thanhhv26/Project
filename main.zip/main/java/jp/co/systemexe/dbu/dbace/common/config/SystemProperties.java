/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.config;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.exception.SystemResourceNotFoundException;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * システムプロパティ保持クラス。
 * <p>
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @author EXE 相田 一英
 * @version 0.0.0
 */
public final class SystemProperties implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * ロガーへの参照を保持します。
	 */
	private static final Logger logger = LoggerFactory.getLogger(SystemProperties.class.getName());

	/**
	 * アプリケーションのバージョン
	 * <p>
	 * ナゼ定数で指定しているかというと･･･ system.propertiesファイルはバージョンアップ時に上書きされてしまうため、
	 * system.propertiesに設定を書いても、ずっと同じバージョンになってしまうため。
	 * </p>
	 */
	private static final String APPLICATION_VERSION = "5.0.0_0";

	private static final String FILE_NAME = "/system.properties";
	private static final URL FILE_URL = SystemProperties.class.getResource(FILE_NAME);
	private static Properties prop;

	static {
		prop = new Properties();
		try {
			final InputStream stream = SystemProperties.class.getResourceAsStream(FILE_NAME);
			prop.loadFromXML(stream);
			logger.info("system.properties path:" + FILE_URL.getPath());
			stream.close();
		} catch (final IOException e) {
			// MI-F-0005=システム設定ファイル(system.properties)の読込みに失敗しました。
			final String message = MessageUtils.getMessage("MI-F-0005");
			logger.fatal(message, e);
		}
	}

	private static void reLoadSystemProperties() {
		try {
			final InputStream stream = SystemProperties.class.getResourceAsStream(FILE_NAME);
			prop.loadFromXML(stream);
			logger.info("system.properties path:" + FILE_URL.getPath());
			stream.close();
		} catch (final IOException e) {
			// MI-F-0005=システム設定ファイル(system.properties)の読込みに失敗しました。
			final String message = MessageUtils.getMessage("MI-F-0005");
			logger.fatal(message, e);
		}
	}


	/**
	 * system.property から、keyの値を返します。
	 * <p>
	 * system.property に、keyの値が存在しない場合は、 システムのデフォルト値を返します。
	 * </p>
	 *
	 * @param key
	 * @return
	 */
	private static String getPropertyString(final SystemPropertyKeys key) {
		final String value = prop.getProperty(key.getPropertyKey());
		if (value == null) {
			return key.getDefaultValue();
		} else {
			return value;
		}
	}

	/**
	 * アプリケーション名を戻します。
	 *
	 * @return
	 */
	public static String getApplicationName() {
		return getPropertyString(SystemPropertyKeys.APPLICATION_NAME);
	}

	/**
	 * アプリケーションのバージョンを戻します。
	 *
	 * @return
	 */
	public static String getApplicationVersion() {
		return APPLICATION_VERSION;
	}

	/**
	 * 開発モードでの動作指示フラグ。
	 * <p>
	 * アプリケーションに開発モードでの動作を指示するフラグです。
	 * </p>
	 *
	 * @return true : 開発モード / false : 通常モード
	 */
	public static boolean isDevelopmentMode() {
		return getPropertyString(SystemPropertyKeys.DEVELOPMENT_MODE).equals("true");
	}

	/**
	 * レコード検索画面で一画面に表示するレコード数。
	 * <p>
	 * レコードを一覧で見る場合に、一画面に表示するレコード数です。
	 * </p>
	 * <p>
	 * 0 以下か 1,000以上の値が指定された場合には自動的に 1 或いは 999 に丸め
	 * られます。整数として解釈できない値が設定された場合には既定値 50 を戻し ます。
	 * </p>
	 *
	 * @return
	 */
	public static int getDisplayedNumberOfRecords() {
		final String count = getPropertyString(SystemPropertyKeys.DISPLAYED_NUMBER_OF_RECORDS);
		try {
			final int buff = Integer.valueOf(count);
			if (buff < 1) {
				return 1;
			} else if (buff >= 1000) {
				return 999;
			} else {
				return buff;
			}
		} catch (final Exception e) {
			return 50;
		}
	}

	/**
	 * レコード検索画面で一画面に表示するカラム数。
	 * <p>
	 * レコードを一覧で見る場合に、一画面に表示するカラム数です。
	 * </p>
	 * <p>
	 * 0 以下か 50以上の値が指定された場合には自動的に 1 或いは 49 に丸められ ます。整数として解釈できない値が設定された場合には既定値 10
	 * を戻します。
	 * </p>
	 *
	 * @return
	 */
	public static int getPreviewColumnCount() {
		final String count = getPropertyString(SystemPropertyKeys.PREVIEW_COLUMN_COUNT);
		try {
			final int buff = Integer.valueOf(count);
			if (buff < 1) {
				return 1;
			} else if (buff > 50) {
				return 50;
			} else {
				return buff;
			}
		} catch (Exception e) {
			return 10;
		}
	}

	/**
	 * レコード検索画面で検索できる最大件数。
	 *
	 * @return
	 */
	public static int getSearchMaxRecordCount() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.SEARCH_MAX_RECORD_COUNT));
		} catch (Exception e) {
			return 1000;
		}
	}

	/**
	 *
	 * （機能の説明）。
	 *
	 * @return
	 */
	public static String getPath() {
		// First, get root context path by catalina.base
		if (StringUtils.isNotEmpty(getRootContextPath())) {
			return getRootContextPath();
		}
		// Next, get path by current location of this class
		// String path =
		// SystemProperties.class.getClassLoader().getResource("").getPath();
		String path = null;
		if (isDevelopmentMode()) {
			path = SystemProperties.class.getClassLoader().getResource("").getPath().replaceAll("/target/test-classes",
					"");
		} else {
			path = SystemProperties.class.getClassLoader().getResource("").getPath();
		}
		String fullPath = "";
		try {
			fullPath = URLDecoder.decode(path, "UTF-8");
			String pathArr[] = fullPath.split("/webapps/dbace/WEB-INF/classes/");
			fullPath = pathArr[0];
			if (isDevelopmentMode()) {
				String pathArrDev[] = fullPath.split("/WEB-INF/classes/");
				fullPath = pathArrDev[0];
			}
		} catch (UnsupportedEncodingException e) {
			// MI-F-0005=システム設定ファイル(system.properties)の読込みに失敗しました。
			final String message = MessageUtils.getMessage("MI-F-0005");
			logger.fatal(message, e);
		} catch (Exception e) {
			// MI-F-0005=システム設定ファイル(system.properties)の読込みに失敗しました。
			final String message = MessageUtils.getMessage("MI-F-0005");
			logger.fatal(message, e);
		}

		String reponsePath = "";
		// to read a file from webcontent
		reponsePath = new File(fullPath).getPath();
		return reponsePath;

	}

	/**
	 * ルートコンテキストパス を戻す。
	 *
	 * @return String
	 */
	private static String getRootContextPath() {
		return System.getProperty("catalina.base");
	}

	/**
	 * アプリケーションリポジトリファイルを戻す。
	 * <p>
	 * アプリケーションリポジトリのファイル実体を戻します。
	 * </p>
	 *
	 * @return
	 */
	public static File getAppRepositoryFile() {
		String path = getPropertyString(SystemPropertyKeys.APP_REPOSITORY);
		if (isDevelopmentMode()) {
			// path = path.replaceAll("./webapps/dbace", "");
			path = path.replaceAll("./webapps/dbace", "/src/main/webapp");
		}
		// First, get file from config
		File ret = new File(path);

		if (ret.exists()) {
			return ret;
		} else {
			// If config file doesn't exist,
			// Cont, get from project path
			if (path.startsWith(".")) {
				ret = new File(SystemProperties.getPath() + path.substring(1));
			} else {
				ret = new File(SystemProperties.getPath() + path);
			}
			if (ret.exists()) {
				return ret;
			}

			// MI-F-0002=リポジトリXMLファイルが存在しません。
			final String message = MessageUtils.getMessage("MI-F-0002");
			logger.fatal(message);
			throw new SystemResourceNotFoundException(message);
		}
	}

	/**
	 * 検索条件XMLファイルのパスを返します。
	 *
	 * @return
	 */
	public static String getSearchConditionFilePath() {
		String curPath = getPropertyString(SystemPropertyKeys.SEARCH_CONDITION_FILEPATH);
		if (isDevelopmentMode()) {
			// curPath = curPath.replaceAll("./webapps/dbace", "");
			curPath = curPath.replaceAll("./webapps/dbace", "/src/main/webapp");
		}
		// check existed of current path
		File ret = new File(curPath);

		if (ret.exists()) {
			return curPath;
		} else {
			// else return current project path
			if (curPath.startsWith(".")) {
				return SystemProperties.getPath() + curPath.substring(1);
			} else {
				return SystemProperties.getPath() + curPath;
			}
		}
	}

	/*
	 * 工事中
	 */
	public static String getSearchComparisonOperatorOrder() {
		return getPropertyString(SystemPropertyKeys.SEARCH_COMPARISON_OPERATOR_ORDER);
	}

	/**
	 * アプリケーションリポジトリファイルのパスを戻す。
	 * <p>
	 * アプリケーションリポジトリのファイルパスを戻します。
	 * </p>
	 *
	 * @return
	 */
	public static String getAppRepositoryFilePath() {
		String curPath = getPropertyString(SystemPropertyKeys.APP_REPOSITORY);
		if (isDevelopmentMode()) {
			// curPath = curPath.replaceAll("./webapps/dbace", "");
			curPath = curPath.replaceAll("./webapps/dbace", "/src/main/webapp");
		}
		// check existed of current path
		File ret = new File(curPath);

		if (ret.exists()) {
			return curPath;
		} else {
			// else return current project path
			if (curPath.startsWith(".")) {
				return SystemProperties.getPath() + curPath.substring(1);
			} else {
				return SystemProperties.getPath() + curPath;
			}
		}
	}

	/**
	 * プルダウンに表示できる、アイテムの最大件数。
	 * <p>
	 * 値が取得できない場合は、1000が返されます。
	 * </p>
	 *
	 * @return
	 */
	public static int getPulldownMaxCount() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.PULLDOWN_MAX_COUNT));
		} catch (Exception e) {
			return 1000;
		}
	}

	/**
	 * データベースのフェッチサイズ(プルダウン用)。
	 * <p>
	 * 値が取得できない場合は、100が返されます。
	 * </p>
	 *
	 * @return
	 */
	public static int getPrefetchSize() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.PREFETCH_SIZE));
		} catch (Exception e) {
			return 100;
		}
	}

	/**
	 * データベースのフェッチサイズ(検索用)。
	 * <p>
	 * 値が取得できない場合は、100が返されます。
	 * </p>
	 *
	 * @return
	 */
	public static int getDownloadFetchSize() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.DOWNLOAD_FETCH_SIZE));
		} catch (Exception e) {
			return 100;
		}
	}

	/**
	 * アプリケーションリポジトリファイルを戻す。
	 * <p>
	 * アプリケーションリポジトリのファイル実体を戻します。
	 * </p>
	 *
	 * @return
	 */
	public static File getAuditSettingFile() {
		String curPath = getPropertyString(SystemPropertyKeys.AUDIT_SETTING);
		if (isDevelopmentMode()) {
			// curPath = curPath.replaceAll("./webapps/dbace", "");
			curPath = curPath.replaceAll("./webapps/dbace", "/src/main/webapp");
		}
		// check existed of current path
		File ret = new File(curPath);

		if (ret.exists()) {
			return ret;
		} else {
			// else return current project path
			if (curPath.startsWith(".")) {
				ret = new File(SystemProperties.getPath() + curPath.substring(1));
			} else {
				ret = new File(SystemProperties.getPath() + curPath);
			}
			if (ret.exists()) {
				return ret;
			} else {
				// MI-F-0003=監査ログ設定XMLファイルが存在しません。
				final String message = MessageUtils.getMessage("MI-F-0003");
				logger.fatal(message);
				throw new SystemResourceNotFoundException(message);
			}
		}
	}

	/**
	 * ダウンロード可能なExcelファイルのサイズ(MB)を返します。
	 *
	 * @return
	 */
	public static int getDownloadMaximumByteForExcel() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.DOWNLOAD_MAXIMUM_BYTE_FOR_EXCEL));
		} catch (Exception e) {
			return 100;
		}
	}

	/**
	 * ダウンロード可能なCSVファイルのサイズ(MB)を返します。
	 *
	 * @return
	 */
	public static int getDownloadMaximumByteForCsv() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.DOWNLOAD_MAXIMUM_BYTE_FOR_CSV));
		} catch (Exception e) {
			return 100;
		}
	}

	/**
	 * インポート可能なEXCELファイルのサイズ(MB)を返します。
	 *
	 * @return
	 */
	public static int getImportMaximumByteForExcel() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.IMPORT_MAXIMUM_BYTE_FOR_EXCEL));
		} catch (Exception e) {
			return 100;
		}
	}

	/**
	 * インポート可能なCSVファイルのサイズ(MB)を返します。
	 *
	 * @return
	 */
	public static int getImportMaximumByteForCsv() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.IMPORT_MAXIMUM_BYTE_FOR_CSV));
		} catch (Exception e) {
			return 100;
		}
	}

	/**
	 * インポート可能なTSVファイルのサイズ(MB)を返します。
	 *
	 * @return
	 */
	public static int getImportMaximumByteForTsv() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.IMPORT_MAXIMUM_BYTE_FOR_TSV));
		} catch (Exception e) {
			return 100;
		}
	}

	/**
	 * インポートファイルの一時格納フォルダパスを返します。
	 *
	 * @return
	 */
	public static String getImportTempFilePath() {
		String curPath = getPropertyString(SystemPropertyKeys.IMPORT_TEMP_FILE_PATH);
		if (isDevelopmentMode()) {
			// curPath = curPath.replaceAll("./webapps/dbace", "");
			curPath = curPath.replaceAll("./webapps/dbace", "/src/main/webapp");
		}
		// check existed of current path
		File ret = new File(curPath);

		if (ret.exists()) {
			return curPath;
		} else {
			// else return current project path
			if (curPath.startsWith(".")) {
				return SystemProperties.getPath() + curPath.substring(1);
			} else {
				return SystemProperties.getPath() + curPath;
			}
		}
	}

	/**
	 * システムプロパティから、全プロパティ値のマップを返します。
	 *
	 * @return
	 */
	public static Map<SystemPropertyKeys, String> getAllPropertiesMap() {
		final Map<SystemPropertyKeys, String> ret = new HashMap<SystemPropertyKeys, String>();
		for (final SystemPropertyKeys key : SystemPropertyKeys.values()) {
			ret.put(key, getPropertyString(key));
			logger.debug(key + ":" + getPropertyString(key));
		}
		return ret;
	}

	/**
	 * システムプロパティに引数の情報を保存します。
	 */
	public static void save(final Map<SystemPropertyKeys, String> propertyMap) throws DAOException {
		FileOutputStream stream = null;
		try {
			final Properties properties = new Properties();
			synchronized (properties) {
				stream = new FileOutputStream(new File(FILE_URL.toURI()));
				for (final SystemPropertyKeys key : propertyMap.keySet()) {
					/*
					 * logger.debug(key.getPropertyKey() + ":" +
					 * propertyMap.get(key));
					 */
					properties.setProperty(key.getPropertyKey(), propertyMap.get(key));
				}
				properties.storeToXML(stream, "システムプロパティ。", "UTF-8");
				prop = properties;
			}
		} catch (final URISyntaxException e) {
			// MI-E-0140=システム設定ファイル(system.properties)の出力に失敗しました。
			final String message = MessageUtils.getMessage("MI-E-0140");
			logger.error(message, e);
			throw new DAOException(message, e);
		} catch (final FileNotFoundException e) {
			// MI-E-0140=システム設定ファイル(system.properties)の出力に失敗しました。
			final String message = MessageUtils.getMessage("MI-E-0140");
			logger.error(message, e);
			throw new DAOException(message, e);
		} catch (final IOException e) {
			// MI-E-0140=システム設定ファイル(system.properties)の出力に失敗しました。
			final String message = MessageUtils.getMessage("MI-E-0140");
			logger.error(message, e);
			throw new DAOException(message, e);
		} finally {
			if (stream != null) {
				try {
					stream.close();
				} catch (final IOException e) {
					logger.warn(e.getMessage(), e);
				}
			}
		}
	}

	// ADD ライセンス認証と外部認証連携の機能追加 ↓
	/**
	 * ライセンスキーを返します。
	 *
	 *
	 * @return
	 */
	public static String getLicenseKey() {
		return getPropertyString(SystemPropertyKeys.LICENSE_KEY);
	}

	/**
	 * ライセンス数を返します。
	 *
	 * @return
	 */
	public static String getLicenseCnt() {
		return getPropertyString(SystemPropertyKeys.LICENSE_CNT);
	}

	/**
	 * 外部認証を返します。
	 *
	 *
	 * @return
	 */
	public static String getExtAuth() {
		return getPropertyString(SystemPropertyKeys.EXT_AUTH);
	}

	/**
	 * ユーザー種類を返します。
	 *
	 *
	 * @return
	 */
	public static String getAuthServerType() {
		return getPropertyString(SystemPropertyKeys.AUTH_SERVER_TYPE);
	}

	/**
	 * サーバーIDを返します。
	 *
	 *
	 * @return
	 */
	public static String getAuthServerId() {
		return getPropertyString(SystemPropertyKeys.AUTH_SERVER_ID);
	}

	/**
	 * ポート番号を返します。
	 *
	 *
	 * @return
	 */
	public static int getAuthServerPort() {
		try {
			return Integer.parseInt(getPropertyString(SystemPropertyKeys.AUTH_SERVER_PORT));
		} catch (Exception e) {
			return 389;
		}
	}

	/**
	 * ベースDN／ドメイン名を返します。
	 *
	 *
	 * @return
	 */
	public static String getAuthServerBaseDomain() {
		return getPropertyString(SystemPropertyKeys.AUTH_SERVER_BASE_DOMAIN);
	}

	/**
	 * サーバープロトコルを返します。
	 *
	 *
	 * @return
	 */
	public static String getAuthServerProtocol() {
		return getPropertyString(SystemPropertyKeys.AUTH_SERVER_PROTOCOL);
	}

	/**
	 * サーバーセキュリティを返します。
	 *
	 *
	 * @return
	 */
	public static String getAuthServerSecurity() {
		return getPropertyString(SystemPropertyKeys.AUTH_SERVER_SECURITY);
	}

	/**
	 * サーバータイムアウトを返します。
	 *
	 *
	 * @return
	 */
	public static String getAuthServerTimeout() {
		return getPropertyString(SystemPropertyKeys.AUTH_SERVER_TIMEOUT);
	}

	/**
	 * 接続ユーザーIDを返します。
	 *
	 *
	 * @return
	 */
	public static String getAuthServerUserIdentify() {
		return getPropertyString(SystemPropertyKeys.AUTH_SERVER_USER_IDENTIFY);
	}

	/**
	 * 接続ユーザーIDを返します。
	 *
	 *
	 * @return
	 */
	public static String getAuthConnectUsername() {
		return getPropertyString(SystemPropertyKeys.AUTH_CONNECT_USERNAME);
	}

	/**
	 * 接続パスワードを返します。
	 *
	 *
	 * @return
	 */
	public static String getAuthConnectPwd() {
		return getPropertyString(SystemPropertyKeys.AUTH_CONNECT_PWD);
	}

	/**
	 * ダウンロードモード。
	 * 0: JP mode(use SXSSF)</br>
	 * 1: VN mode(use XSSF, fix bug Out of memory) </br>
	 * 2: Old mode(ver 5.0)</br>
	 *
	 *
	 * @return
	 */
	public static String getDownLoadMode() {
		try {
			reLoadSystemProperties();
			return getPropertyString(SystemPropertyKeys.DOWNLOAD_MODE);
		} catch (Exception e) {
			return "0";
		}

	}

	// ADD ライセンス認証と外部認証連携の機能追加 ↑

	/**
	 * SystemProperties の生成。
	 * <p>
	 * デフォルトコンストラクタ隠蔽。
	 * </p>
	 */
	private SystemProperties() {
		return;
	}

	/**
	 * prop を設定します。
	 *
	 * @param Properties
	 *            prop
	 */
	public static void setProp(Properties prop) {
		SystemProperties.prop = prop;
	}

}
