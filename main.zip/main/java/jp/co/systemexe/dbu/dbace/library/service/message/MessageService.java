/**
 * Copyright(c) 2014 SystemEXE Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.service.message;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.library.dto.NotificationPush.NotificationType;


/**
 * MessageService.javaのクラス。
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
public interface MessageService extends Serializable {
	/**
	 * Get message content from resource based on system's locale
	 *
	 * @param key the message key
	 * @param args the message arguments
	 *
	 * @return the message from resource
	 */
	String getMessage(String key, Object... args);

	/**
	 * Send notification data to client via websocket
	 * @param broker the socket subscription destination
	 * @param data the data to send
	 */
	void sendMessage(String broker, Object data);
	/**
	 * Send notification to client via websocket
	 * @param type the notification type
	 * @param message the notification message
	 */
	void sendNotification(NotificationType type, String message);
	/**
	 * Send info notification to client via websocket
	 * @param message the notification message
	 */
	void sendInfo(String message);
	/**
	 * Send error notification to client via websocket
	 * @param message the notification message
	 */
	void sendError(String message);
	/**
	 * Send warning notification to client via websocket
	 * @param message the notification message
	 */
	void sendWarning(String message);
}
