package jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF;

import java.util.Map;

import org.apache.poi.ss.usermodel.CellStyle;

import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;
import lombok.Setter;

/**
 * @author van-thanh
 *
 */
public abstract class BaseFormatCell {
	
	@Setter
	protected SXSSFWorkbookCus workbook = null;
	
	@Setter
	protected DatabaseTypeConnectionDestination type = null;
	
	/**
	 * @return
	 */
	protected abstract CellStyle createFormatCellCharacter();
	
	/**
	 * @return
	 */
	protected abstract CellStyle createCellStyleNumeric();
	
	/**
	 * @return
	 */
	protected abstract CellStyle createCellStyleDate();
	
	/**
	 * @return
	 */
	protected abstract CellStyle createCellStyleDateTime();
	
	/**
	 * @return
	 */
	public abstract boolean checkDatabaseType();
	
	/**
	 * @return
	 */
	protected abstract Map<String, CellStyle> getMapFormatCell();
	
	/**
	 * @param workbook
	 * @param type
	 */
	protected abstract void init(
			final SXSSFWorkbookCus workbook,
			final DatabaseTypeConnectionDestination type);
	
	/**
	 * @param dataType
	 * @return
	 */
	public abstract String getTypeFormatsCellByDataType(final String dataType);

}
