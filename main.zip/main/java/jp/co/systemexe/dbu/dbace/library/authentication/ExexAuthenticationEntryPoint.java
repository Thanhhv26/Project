/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.authentication;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;

import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import jp.co.systemexe.dbu.dbace.library.util.Constants;

/**
 * SessionExpiredAuthenticationEntryPoint 認証エントリポイントクラス
 *
 * <p>認証エントリポイントクラスです。</p>
 *
 * @author SystemEXE:梶原 智史
 */
public class ExexAuthenticationEntryPoint extends LoginUrlAuthenticationEntryPoint {

    public ExexAuthenticationEntryPoint(String loginFormUrl) {
		super(loginFormUrl);
	}

	/**
     * SLF4J
     */
    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * @see MessageService
     */
    @Autowired
    private MessageService messageService;

    /**
     * commence 実行判定処理
     *
     * <p>処理開始時の処理を行います。</p>
     *
     * @author SystemEXE:梶原 智史
     * @param request httpリクエスト情報
     * @param response httpレスポンス情報
     * @param authException 認証エラー情報
     * @exception IOException, ServletException
     */
    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)
            throws IOException, ServletException {

        // セッションのタイムアウト判定を行う。
        if (Constants.AJAX_REQUEST_IDENTIFIER.equals(request.getHeader(Constants.AJAX_REQUEST_HEADER))) {
        	int status = HttpStatus.UNAUTHORIZED.value();
        	String msg = messageService.getMessage("message.unauth");
        	logger.warn(status + " - " + msg);

        	response.setStatus(status);
            response.setCharacterEncoding("utf-8");
            PrintWriter out = response.getWriter();
            out.println(msg);
            out.flush();

            return;
        }

        super.commence(request, response, authException);
    }

}
