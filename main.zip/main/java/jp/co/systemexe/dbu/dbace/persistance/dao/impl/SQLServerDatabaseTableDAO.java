/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.util.List;
import java.util.SortedMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.jdbc.DataTypeDBMappingWithJDBC;
import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableComparisonOperator;
import jp.co.systemexe.dbu.dbace.common.util.DateCheckUtility;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectSqlCondition;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;
import jp.co.systemexe.dbu.dbace.web.common.AppConst;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;

/**
 * （JavaDoc）。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public abstract class SQLServerDatabaseTableDAO extends BaseDatabaseTableDAO {

	@Override
    protected String createFuncCheckNullSelectWheresClause(SelectConditionItem item) {
            final StringBuffer wheres = new StringBuffer();
                if (item.getComparisonOperator()
                        == SqlWhereTableComparisonOperator.isNull) {
                    wheres.append(" (\"");
                    wheres.append(item.getColumnId());
                    wheres.append("\"");
                    wheres.append(" ");
                    wheres.append(item.getComparisonOperator().getComparisonOperator());
                    wheres.append(" ");
                    wheres.append(" or \"");
                    wheres.append(item.getColumnId());
                    wheres.append("\"");
                    wheres.append(" ");
                    wheres.append("=''");
                    wheres.append(") ");
                } else if (item.getComparisonOperator()
                            == SqlWhereTableComparisonOperator.isNotNull) {
                    wheres.append(" (\"");
                    wheres.append(item.getColumnId());
                    wheres.append("\"");
                    wheres.append(" ");
                    wheres.append(item.getComparisonOperator().getComparisonOperator());
                    wheres.append(" ");
                    wheres.append(" or \"");
                    wheres.append(item.getColumnId());
                    wheres.append("\"");
                    wheres.append(" ");
                    wheres.append("<>''");
                    wheres.append(") ");
                } else {
					if (item.getValue().matches("^\\d{4}/\\d{2}/\\d{2}$")
							&& DateCheckUtility.isDateStyleCheck(item.getValue(), "yyyy/mm/dd")) {
						wheres.append(" ");
						wheres.append("CONVERT(VARCHAR(10),CONVERT(DATETIME,\"" + item.getColumnId() + "\",111),111)");
						wheres.append(" ");
					} else if (item.getValue().matches("^\\d{2}:\\d{2}:\\d{2}$")
							&& DateCheckUtility.isDateStyleCheck(item.getValue(), "HH:mm:ss")) {
						wheres.append(" ");
						wheres.append("CONVERT(VARCHAR(8),CONVERT(DATETIME,\"" + item.getColumnId() + "\",108),108)");
						wheres.append(" ");
					} else {
						wheres.append(" \"");
						wheres.append(item.getColumnId());
						wheres.append("\"");
					}
                	 wheres.append(" ");
                     wheres.append(item.getComparisonOperator().getComparisonOperator());
                     wheres.append(" ");
                    if (StringUtils.isNotEmpty(item.getValue())) {
                        if (isJDBCMetaDataTypeToNumber(item.getJDBCMetaDataType())) {
                            wheres.append(item.getValue());
                        } else if (isJDBCMetaDataTypeToDate(item.getJDBCMetaDataType())) {
                        	if (item.getValue().matches("^\\d{4}/\\d{2}/\\d{2}$")
        							&& DateCheckUtility.isDateStyleCheck(item.getValue(), "yyyy/mm/dd")) {
                        		 wheres.append("CONVERT(VARCHAR(10),CONVERT(DATETIME,'"+ item.getValue() +"',111),111)");
                        	}else if (item.getValue().matches("^\\d{2}:\\d{2}:\\d{2}$")
        							&& DateCheckUtility.isDateStyleCheck(item.getValue(), "HH:mm:ss")) {
                        		 wheres.append("CONVERT(VARCHAR(8),CONVERT(DATETIME,'"+ item.getValue() +"',108),108)");
                        	}else{
                                wheres.append("CONVERT(");
                                wheres.append(item.getColumnTypeName());
                                wheres.append(",'");
                                wheres.append(item.getValue());
                                wheres.append("'");
                                wheres.append(")");
                        	}
                        } else {
                            wheres.append("'");
                            //条件に含まれるシングルクォーテーションを2重化する。
                            final String condition = item.getValue().replace("'", "''");
                            //演算子がパターンマッチングである場合に、条件にワイルドカードの役割を担うメタ文字%を付加する。
                            wheres.append(getPatternMatchCondition(item.getComparisonOperator(), condition));
                            wheres.append("'");
                            wheres.append(" ");
                        }
                        wheres.append(" ");
                    }
                }
                if(item.getLogicalOperator() != null){
                	wheres.append(item.getLogicalOperator().getLogicalOperator());
                }
            return wheres.toString();
    }

    /**
     * 項目名と値を単純に「=」で接続した Where 句文字列を作成して戻す。
     * <p>
     * 先頭に ' where ' も修飾して戻します。</p>
     * <p>
     * 条件指定が無い場合は空文字を戻します。</p>
     *
     * @param wheresMap
     * @return
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseDatabaseDAO#createSelectWheresClause(java.util.SortedMap)
     */
    @Override
    protected String createSelectWheresClause(SortedMap<Integer, SelectConditionItem> wheresMap) {
        if (wheresMap.size() <= 0) {
            return "";
        } else {
            final StringBuffer wheres = new StringBuffer();
            for (final Integer index : wheresMap.keySet()) {
                final SelectConditionItem item = wheresMap.get(index);
                
                if (item.getComparisonOperator() == SqlWhereTableComparisonOperator.isNull
                		|| item.getComparisonOperator() == SqlWhereTableComparisonOperator.isNotNull) {
                	String operator = (item.getComparisonOperator() == SqlWhereTableComparisonOperator.isNull) ? "=" : "<>";
                	if(AppConst.NULL_ONLY.equals(item.getJDBCMetaDataType().getSearchStringFlag())){
//                    	NULL_ONLY = 0 : where条件：is null/ is not null だけ（シングルクォーテーションと比較しない）
                    	wheres.append(" (\"");
                        wheres.append(item.getColumnId());
                        wheres.append("\"");
                        wheres.append(" ");
                        wheres.append(item.getComparisonOperator().getComparisonOperator());
                        wheres.append(" ");
                	} else if(AppConst.NULL_VARIABLE.equals(item.getJDBCMetaDataType().getSearchStringFlag())) {
//                    	NULL_VARIABLE = 1 (・可変長): [is null の場合     ：　　　where ISNULL(col_id, '') = '';]
                    	wheres.append(" (ISNULL(DATALENGTH(\"");
                        wheres.append(item.getColumnId());
                        wheres.append("\"), 0)");
                        wheres.append(" ");
                        wheres.append(operator);
                        wheres.append("0");
                	} else if(AppConst.NULL_FIXED.equals(item.getJDBCMetaDataType().getSearchStringFlag())) {
//                    	NULL_FIXED = 2(・固定長): [is null の場合     ：　　　where LTRIM(RTRIM(ISNULL(col_id, ''))) = '';]
                    	wheres.append(" (ISNULL(DATALENGTH(LTRIM(RTRIM(\"");
                        wheres.append(item.getColumnId());
                        wheres.append("\"))), 0)");
                        wheres.append(operator);
                        wheres.append("0");
                	}
                	wheres.append(") ");
                } else {

					if (item.getValue().matches("^\\d{4}/\\d{2}/\\d{2}$")
							&& DateCheckUtility.isDateStyleCheck(item.getValue(), "yyyy/mm/dd")) {
						wheres.append(" ");
						wheres.append("CONVERT(VARCHAR(10),CONVERT(DATETIME,\"" + item.getColumnId() + "\",111),111)");
						wheres.append(" ");
					} else if (item.getValue().matches("^\\d{2}:\\d{2}:\\d{2}$")
							&& DateCheckUtility.isDateStyleCheck(item.getValue(), "HH:mm:ss")) {
						wheres.append(" ");
						wheres.append("CONVERT(VARCHAR(8),CONVERT(DATETIME,\"" + item.getColumnId() + "\",108),108)");
						wheres.append(" ");
					} else {
						wheres.append(" \"");
						wheres.append(item.getColumnId());
						wheres.append("\"");
					}


                	 wheres.append(" ");
                     wheres.append(item.getComparisonOperator().getComparisonOperator());
                     wheres.append(" ");


                    if (StringUtils.isNotEmpty(item.getValue())) {
                        if (isJDBCMetaDataTypeToNumber(item.getJDBCMetaDataType())) {
                            wheres.append(item.getValue());
                        } else if (isJDBCMetaDataTypeToDate(item.getJDBCMetaDataType())) {

                        	if (item.getValue().matches("^\\d{4}/\\d{2}/\\d{2}$")
        							&& DateCheckUtility.isDateStyleCheck(item.getValue(), "yyyy/mm/dd")) {
                        		 wheres.append("CONVERT(VARCHAR(10),CONVERT(DATETIME,'"+ item.getValue() +"',111),111)");
                        	}else if (item.getValue().matches("^\\d{2}:\\d{2}:\\d{2}$")
        							&& DateCheckUtility.isDateStyleCheck(item.getValue(), "HH:mm:ss")) {
                        		 wheres.append("CONVERT(VARCHAR(8),CONVERT(DATETIME,'"+ item.getValue() +"',108),108)");
                        	}else{
                                wheres.append("CONVERT(");
                                wheres.append(item.getColumnTypeName());
                                wheres.append(",'");
                                wheres.append(item.getValue());
                                wheres.append("'");
                                wheres.append(")");
                        	}


                        } else {
                            wheres.append("'");

                            //条件に含まれるシングルクォーテーションを2重化する。
                            final String condition = item.getValue().replace("'", "''");

                            //演算子がパターンマッチングである場合に、条件にワイルドカードの役割を担うメタ文字%を付加する。
                            wheres.append(getPatternMatchCondition(item.getComparisonOperator(), condition));
                            wheres.append("'");

                            wheres.append(" ");
                        }
                        wheres.append(" ");
                    }
                }
                if(index <= wheresMap.size() && item.getLogicalOperator() != null){
                	wheres.append(item.getLogicalOperator().getLogicalOperator());
                }
            }
            return " where ".concat(wheres.toString());
        }
    }

//    /**
//     * 選択条件 VO を生成し値を設定して戻す。
//     *
//     * @param dto
//     * @param form
//     * @return SelectSqlCondition
//     */
//    protected SelectSqlCondition createSelectSqlCondition(
//            final RecordSearchConditionDTO dto, final TableFormDTO form) {
//        final SelectSqlCondition ret = new SelectSqlCondition();
//        ret.setTableId(dto.getTableId());
//        ret.setType(form.getType());
//        for (final Iterator<String> ite = form.getTableItemMap().keySet()
//            .iterator(); ite.hasNext();) {
//            ret.addValues(ite.next(), null);
//        }
//
//        for (final Integer index : dto.getConditions().keySet()) {
//            final SelectConditionItem buff = dto.getConditions().get(index);
//            ret.addWheres(index, buff);
//        }
//
//        for (final Iterator<Integer> ite = form.getSortConditionMap().keySet()
//            .iterator(); ite.hasNext();) {
//            final int index = ite.next();
//            ret.addOrders(index, form.getSortConditionMap().get(index));
//        }
//
//		for (final Iterator<String> ite = form.getRelationMap().keySet().iterator(); ite.hasNext();) {
//			final String id = ite.next();
//			ret.addRelation(id, form.getRelationMap().get(id));
//		}
//
//		for (final Iterator<String> ite = form.getTableItemMap().keySet().iterator(); ite.hasNext();) {
//			final String id = ite.next();
//			ret.addColumn(id, form.getTableItemMap().get(id));
//		}
//
//		ret.setTablesMap(form.getTableMap());
//
//        ret.setOrderAsc(dto.isOrderAsc());
//        return ret;
//    }

    /**
     * 選択条件 VO を生成し値を設定して戻す。
     *
     * @param dto
     * @param form
     * @return SelectSqlCondition
     */
    /*protected SelectSqlCondition createSelectSqlConditionTab(
            final RecordSearchConditionDTO dto, final TableFormDTO form,
            final TableDto table) {
        final SelectSqlCondition ret = new SelectSqlCondition();
        ret.setTableId(dto.getTableId());
        ret.setType(form.getType());
        for (final Iterator<String> ite = form.getTableItemMap().keySet()
            .iterator(); ite.hasNext();) {
            ret.addValues(ite.next(), null);
        }

        for (final Integer index : dto.getConditions().keySet()) {
            final SelectConditionItem buff = dto.getConditions().get(index);
            ret.addWheres(index, buff);
        }

        for (final Iterator<Integer> ite = form.getSortConditionMap().keySet()
            .iterator(); ite.hasNext();) {
            final int index = ite.next();
            ret.addOrders(index, form.getSortConditionMap().get(index));
        }

		for (final Iterator<String> ite = form.getRelationMap().keySet().iterator(); ite.hasNext();) {
			final String id = ite.next();
			ret.addRelation(id, form.getRelationMap().get(id));
		}

		for (final Iterator<String> ite = form.getTableItemMap().keySet().iterator(); ite.hasNext();) {
			final String id = ite.next();
			ret.addColumn(id, form.getTableItemMap().get(id));
		}

		ret.setTablesMap(form.getTableMap());

        ret.setOrderAsc(dto.isOrderAsc());
        return ret;
    }*/

    protected SelectSqlCondition createSelectSqlConditionTab(
            final RecordSearchConditionDTO dto,
            final TableDto table) {
        final SelectSqlCondition ret = new SelectSqlCondition();
        ret.setTableId(table.getId());

        for (final Integer index : dto.getConditions().keySet()) {
            final SelectConditionItem buff = dto.getConditions().get(index);
            ret.addWheres(index, buff);
        }
        return ret;
    }

//	@Override
//	protected String ignoreNullColumns(List<String> colList) {
//		final StringBuffer columnsBuff = new StringBuffer();
//		final StringBuffer bracketsBuff = new StringBuffer();
//		String dbFunc = "ISNULL";
//		//case 1 column : ISNULL(col1,null)
//		if (colList.size() == 1) {
//			columnsBuff.append(dbFunc);
//			columnsBuff.append("(");
//			columnsBuff.append(colList.get(0));
//			columnsBuff.append(", ");
//			columnsBuff.append("null");
//			bracketsBuff.append(")");
//			columnsBuff.append(bracketsBuff);
//			return columnsBuff.toString();
//		}
//		//case >= 2 column
//		int index = 0;
//		for (String name : colList) {
//			if (columnsBuff.length() > 0) {
//				columnsBuff.append(", ");
//			}
//			if(index >= colList.size() - 1){
//				columnsBuff.append(name);
//				break;
//			} else {
//				columnsBuff.append(dbFunc);
//				columnsBuff.append("(");
//				columnsBuff.append(name);
//			}
//			bracketsBuff.append(")");
//			index++;
//		}
//		columnsBuff.append(bracketsBuff);
//		return columnsBuff.toString();
//	}
    
    @Override
    protected String ignoreNullColumns(final List<String> columns, final String columnType) {
    	final int lastIndex = columns.size() - 1;
    	final String lastColumn = columns.get(lastIndex);
    	String temp = ignoreNullColumns(lastColumn, columnType);
    	for(int i = columns.size() - 2; i >= 0; i--){
    		String tempi = ignoreNullColumns(columns.get(i), columnType);
    		temp = tempi.replace(" NULL", String.format(" %s ", temp));
    	}
		return temp;
	}
    
    private String ignoreNullColumns(final String column, final String columnType) {
    	final String databaseType = DatabaseTypeConnectionDestination.SqlServer.getKey();
    	final String dataTypeDatabase = columnType;
    	final DataTypeDBMappingWithJDBC dataType;
    	dataType= DataTypeDBMappingWithJDBC.getByDataTypeDatabase(databaseType, dataTypeDatabase);
    	final JDBCMetaDataType jdbc = JDBCMetaDataType.dataTypeOf(dataType.getDataType());
    	final int columnNullType = jdbc.getSearchStringFlag();
    	
    	String temp = "";
    	if(AppConst.NULL_ONLY.equals(columnNullType)){
    	    temp += String.format("(ISNULL(%s, NULL))", column);
    	}else if(AppConst.NULL_VARIABLE.equals(columnNullType)) {
    		temp = "(CASE WHEN ";
    	    temp += String.format("(ISNULL(DATALENGTH(%s), 0) = 0) ", column);
    	    temp += "THEN NULL ";
    	    temp += String.format("ELSE %s ", column);
    	    temp += "END) ";
    	}else if(AppConst.NULL_FIXED.equals(columnNullType)) {
    		temp = "(CASE WHEN ";
    	    temp += String.format("(ISNULL(DATALENGTH(LTRIM(RTRIM(%s))), 0) = 0) ", column);
    	    temp += "THEN NULL ";
    	    temp += String.format("ELSE %s ", column);
    	    temp += "END) ";
    	}
	    return temp;
    }
    
}
