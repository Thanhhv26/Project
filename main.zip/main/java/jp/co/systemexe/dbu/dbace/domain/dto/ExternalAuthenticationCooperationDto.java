/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import jp.co.systemexe.dbu.dbace.library.dto.BaseDto;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * @author bao-anh
 * @version 6.0 jan 3, 2017
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
public class ExternalAuthenticationCooperationDto extends BaseDto {

	private static final long serialVersionUID = 1L;

	private Boolean extAuth = Boolean.FALSE;
	private String adLdapServerType;
	private String templateDatabaseUrl;
	private String authServerId;
	private String authServerPort;
	private String authServerTimeout;
	private String authServerBaseDomain;
	private String ldapUserServerIdentify;
	private String authConnectUsername;
	private String authConnectPwd;

}
