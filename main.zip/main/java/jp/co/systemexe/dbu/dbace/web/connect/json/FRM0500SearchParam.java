/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.connect.json;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0500SearchParam {
	private String connectDefinitionName;
	private String templateDatabaseUrl;
	private boolean flagSearch;
//	private ConnectDto searchData;
}
