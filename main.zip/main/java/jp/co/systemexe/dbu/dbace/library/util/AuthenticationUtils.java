/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.util;

import java.io.Serializable;
import java.security.Principal;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.util.WebUtils;

import jp.co.systemexe.dbu.dbace.library.dto.UserProfile;

/**
 * Authentication utilities
 *
 * @author long-hai
 *
 */
public final class AuthenticationUtils implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/** logger */
    protected static Logger logger = LoggerFactory.getLogger(AuthenticationUtils.class);

    /**
     * Get the safe-type {@link UserProfile} from the specified {@link Principal}
     *
     * @param principal the {@link Principal}
     *
     * @return the safe-type {@link UserProfile}
     */
//    public static UserProfile getProfile(Principal principal) {
//    	return getProfile(BeanUtils.safeType(principal, Authentication.class));
//    }
    public static UserProfile getProfile(Authentication authentication) {
    	return (authentication != null
    			? BeanUtils.safeType(authentication.getPrincipal(), UserProfile.class) : null);
    }
//    public static UserProfile getProfile(Object principal) {
//    	return (BeanUtils.isInstanceOf(principal, Principal.class)
//    			? getProfile((Principal) principal)
//    					: BeanUtils.isInstanceOf(principal, Authentication.class)
//    					? getProfile((Authentication) principal) : null);
//    }

    /**
     * Get the current {@link Authentication} principal from context
     * @return the current {@link Authentication} principal from context
     */
    public static Authentication getCurrentPrincipal() {
    	SecurityContext sc = SecurityContextHolder.getContext();
    	return (sc == null ? null : sc.getAuthentication());
    }

    /**
     * Get the current safe-type {@link UserProfile} from context
     * @return the current safe-type {@link UserProfile} from context
     */
//    public static UserProfile getCurrentProfile() {
//    	return getProfile(getCurrentPrincipal());
//    }

    /**
     * Generate CSRF token
     *
     * @param request the current request
     * @param response the current response
     * @param principal the current authentication
     * @param checkauth specify whether need to check authentication before generating
     * @param applycookie specify whether applying token to cookie
     *
     * @return the CSRF token string
     */
    public static String generateCsrfToken(
    		HttpServletRequest request, HttpServletResponse response,
    		Principal principal, boolean checkauth, boolean applycookie) {
    	// check parameters
    	String token = null;
    	if (request == null || response == null || (checkauth && principal == null)) {
    		logger.warn("Invalid request|response|principal to generate CSRF token!!!");
    		return token;
    	}
    	// need to check authentication
//    	if (checkauth) {
//	    	UserProfile user = getProfile(principal);
//	    	if (user == null) {
//	    		logger.warn("Invalid authentication to generate CSRF token!!!");
//	    		return token;
//	    	}
//    	}

    	// generate token
    	CsrfToken csrf = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
    	token = csrf.getToken();
		if (csrf != null && applycookie) {
			Cookie cookie = WebUtils.getCookie(request, Constants.COOKIE_CSRF_TOKEN);
			if (cookie == null || (token != null && !token.equals(cookie.getValue()))) {
				cookie = new Cookie(Constants.COOKIE_CSRF_TOKEN, token);
				cookie.setPath("/");
				response.addCookie(cookie);
			}
		}
		logger.warn(">>> GENERATED TOKEN: [" + token + "]");
		return token;
    }
    /**
     * Generate CSRF token
     *
     * @param request the current request
     * @param response the current response
     * @param checkauth specify whether need to check authentication before generating
     * @param applycookie specify whether applying token to cookie
     *
     * @return the CSRF token string
     */
    public static String generateCsrfToken(
    		HttpServletRequest request, HttpServletResponse response,
    		boolean checkauth, boolean applycookie) {
    	return generateCsrfToken(request, response, getCurrentPrincipal(), checkauth, applycookie);
    }
}
