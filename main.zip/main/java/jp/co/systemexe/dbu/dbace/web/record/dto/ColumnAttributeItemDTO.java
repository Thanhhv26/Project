/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;
import lombok.Data;
@Data
public class ColumnAttributeItemDTO {
	String columnId;
	String columnData;
}
