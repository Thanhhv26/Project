/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;

/**
 * 接続先ＵＲＬテンプレート表示用 リストボックス表示用アイテム。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class TemplateDatabaseUrlItem
        implements SelectOneMenuItem, Serializable {
    
    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = -1747411934189282173L;

    /**
     * 接続先データベースベンダー種類
     * <p>内部で使用するvalue値</p>
     */
    private String value;

    /**
     * 接続先データベースＵＲＬ表示用仮名
     * <p>GUI表示用仮名</p>
     */
    private String label;

    /**
     * label を戻します。
     * 
     * @return String
     */
    public String getLabel() {
        return label;
    }

    /**
     * label を設定します。
     *
     * @param String label 
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * value を戻します。
     * 
     * @return String
     */
    public String getValue() {
        return value;
    }

    /**
     * value を設定します。
     *
     * @param String value 
     */
    public void setValue(String value) {
        this.value = value;
    }
}
