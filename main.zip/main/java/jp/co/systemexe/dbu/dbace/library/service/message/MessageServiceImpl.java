/**
 * Copyright(c) 2014 SystemEXE Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.service.message;

import java.text.MessageFormat;
import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import jp.co.systemexe.dbu.dbace.library.dto.NotificationPush;
import jp.co.systemexe.dbu.dbace.library.dto.NotificationPush.NotificationType;

/**
 * MessageServiceImpl.javaのクラス。
 *
 * @author systemexe
 * @version 1.0 Nov 29, 2016
 *
 */
@Service
public class MessageServiceImpl implements MessageService {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/** Logger. **/
	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * @see MessageSource
	 */
	@Resource
	private MessageSource messageSource;

	/*
	 * (非 Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.common.service.MessageService#getMessage(java.lang.String, java.lang.Object[])
	 */
	@Override
	public String getMessage(String key, Object... args) {
		return getMessage(key, args, key);
	}
	/**
	 * Get message content from properties file based on system's locale
	 *
	 * @param messageKey the message key
	 * @param args the message arguments
	 * @param defmessage the default message in error cases
	 *
	 * @return the default message or message from bundle
	 */
	private String getMessage(String messageKey, Object[] args, String defmessage) {
		// checks parameters
		if (StringUtils.hasText(messageKey)) {
			// if not in job
			try {
				Locale locale = LocaleContextHolder.getLocale();
				if (locale == null) {
					ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
					if (sra != null) {
						locale = RequestContextUtils.getLocale(sra.getRequest());
					}
				}
				logger.debug(MessageFormat.format(
						"Get message from bundle with key [{0}] and locale [{1}]",
						(messageKey == null ? "NULL" : messageKey),
						(locale == null ? "NULL" : locale.getDisplayLanguage())));
				return messageSource.getMessage(messageKey, args, locale);
			}
			catch (Throwable e) {
				logger.error(e.getMessage(), e);
			}
		}
		return defmessage;
	}

	/*
	 * (非 Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.common.service.MessageService#sendMessage(java.lang.String, java.lang.Object)
	 */
	@Override
	public void sendMessage(String broker, Object data) {
		Assert.hasText(broker, "NotificationBrokerDestination");
		Assert.notNull(data, "NotificationData");
		// TODO Waiting for CHAT
		//		messagingTemplate.convertAndSend(broker, data);
	}
	/*
	 * (非 Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.common.service.MessageService#sendNotification(jp.co.systemexe.dbu.dbace.common.dto.NotificationPush.NotificationType, java.lang.String)
	 */
	@Override
	public void sendNotification(NotificationType type, String message) {
		this.sendMessage("/notification", new NotificationPush(type, message));
	}
	/*
	 * (非 Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.common.service.MessageService#sendInfo(java.lang.String)
	 */
	@Override
	public void sendInfo(String message) {
		this.sendNotification(NotificationType.Info, message);
	}
	/*
	 * (非 Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.common.service.MessageService#sendError(java.lang.String)
	 */
	@Override
	public void sendError(String message) {
		this.sendNotification(NotificationType.Error, message);
	}
	/*
	 * (非 Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.common.service.MessageService#sendWarning(java.lang.String)
	 */
	@Override
	public void sendWarning(String message) {
		this.sendNotification(NotificationType.Warning, message);
	}
}
