/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;


/**
 * データベース接続用の DAO 基底抽象クラスです。
 * <p>
 * 実際のデータベースメンテナンスに使用する DAO を実装するための基底抽象クラス
 * です。</p>
 *
 * @author  EXE 島田 雄一郎
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public abstract class BaseDatabaseTableDAO extends BaseDatabaseDAO {
}
