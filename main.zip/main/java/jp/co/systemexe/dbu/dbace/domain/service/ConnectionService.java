/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.web.connect.dto.ConnectDto;
import jp.co.systemexe.dbu.dbace.web.connect.json.FRM0500SearchParam;
import jp.co.systemexe.dbu.dbace.web.connect.model.FRM0500ResultModel;

public interface ConnectionService {

	/**
	 *
	 * @param searchParam
	 * @return
	 * @throws ApplicationRuntimeException
	 */
	FRM0500ResultModel search(FRM0500SearchParam searchParam) throws ApplicationRuntimeException;

	/**
	 *
	 * @param connectDto
	 * @return
	 * @throws ApplicationRuntimeException
	 */
	Boolean deleteConnect(ConnectDto connectDto) throws ApplicationRuntimeException;

	/**
	 *
	 * @param connectDto
	 * @return
	 * @throws ApplicationRuntimeException
	 */
	int insertConnect(ConnectDto connectDto) throws ApplicationRuntimeException;

	/**
	 *
	 * @param connectDto
	 * @return
	 * @throws ApplicationRuntimeException
	 */
	int updateConnect(ConnectDto connectDto) throws ApplicationRuntimeException;

	/**
	 *
	 * @param connectDto
	 * @return
	 * @throws ApplicationRuntimeException
	 */
	void testConnect(ConnectDto connectDto) throws ApplicationRuntimeException;

}
