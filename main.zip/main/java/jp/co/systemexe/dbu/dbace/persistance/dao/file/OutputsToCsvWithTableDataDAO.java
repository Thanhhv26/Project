/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.io.IOException;
import java.util.Map;
import java.util.SortedMap;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * テーブルデータをCSVに出力します。
 * <p>
 * 出力されるCSVのファイル名は テーブル名 + 日付(yyyy/MM/dd hh:mm:ss.SSS).csv
 * になります。
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class OutputsToCsvWithTableDataDAO extends BaseOutputsToFileWithTableDataDAO {
    /**
     * 最大出力ファイルサイズ
     */
	private long MAX_OUTPUT_BYTES =
		((long)SystemProperties.getDownloadMaximumByteForCsv()) * 1024L * 1024L;
	private long totalBytes = 0;
	private StringBuffer buff = new StringBuffer();

    /**
     * ヘッダレコードか否か
     */
    private boolean isFirstRow = true;

    /**
     * データ出力件数
     */
    private int recordCount = 0;

	/**
	 * ファイルサイズをチェックする、レコード件数
	 * <p>
	 * 初期値は1000
	 * </p>
	 */
	private int checkRecordCount = 1000;

    /**
     * OutputsToCsvWithTableDataDAO.java の生成。
     *
     */
    public OutputsToCsvWithTableDataDAO() {
        super();
    }

    /**
     * エクセルの出力を行います。
     *
     * @param tableId テーブル名
     * @param def 項目表示定義 DTO
     * @param dto レコード検索結果 DTO
     * @param outputStream
     */
    @Override
    public void outputFile(
    		final String tableId, 
			final SortedMap<Integer, TableItemDTO> columnId,
			final Map<String, String> columnData,
			final String dbType) throws DAOException {
        // ヘッダ作成
        if (isFirstRow) {
            createHeader(columnId);
            isFirstRow = false;
        }

        // 明細作成
        createDetails(columnId, columnData);
        recordCount++;
      	getLogger().debug(recordCount + "件目出力中");

    	if (!checkFileSize()) {
			// MI-E-0147=ダウンロード件数が多すぎます。データ件数を絞り込んでください。
			final String message = MessageUtils.getMessage("MI-E-0147");
			getLogger().error(message);
			throw new DAOException(message);
		}
    }

    @Override
    public void write()
            throws DAOException {
    	if (buff.length() == 0) {
    		return;
    	}
        try {
        	final byte[] outputBytes = buff.toString().getBytes("Windows-31J");
        	getOutputStream().write(outputBytes);
        	buff.setLength(0);
        } catch (final IOException e) {
        	final String message = "CSVファイルの出力に失敗しました。(" + e.getMessage() + ")";
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
    }

    @Override
    public boolean checkFileSize() throws DAOException {
    	if (buff.length() == 0) {
    		return true;
    	}
        try {
        	if (recordCount >= checkRecordCount) {
	        	final byte[] outputBytes = buff.toString().getBytes("Shift_JIS");
	        	totalBytes += outputBytes.length;

	        	if (totalBytes > MAX_OUTPUT_BYTES) {
	        		getLogger().debug("csv file size:" + totalBytes + "," + MAX_OUTPUT_BYTES);
	        		return false;
	        	} else {
	        		checkRecordCount = (int) (MAX_OUTPUT_BYTES / (totalBytes / recordCount));
	        		write();
	        		return true;
	        	}
        	}
        	return true;
        } catch (final IOException e) {
        	final String message = "CSVファイルの出力に失敗しました。(" + e.getMessage() + ")";
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
    }


    /**
     *
     * 明細の作成を行います。
     *
     * @param dto
     * @param buff
     */
    private void createDetails(
            final SortedMap<Integer, TableItemDTO> columnId,
            final Map<String, String> columnData) {
        boolean isFirst = true;
        for (final Integer index : columnId.keySet()) {
            if (isFirst) {
                isFirst = false;
            } else {
                buff.append(",");
            }
            buff.append("\"");

            final String data = replaceGarbledCharacter(
            		columnData.get(columnId.get(index).getItemId()));
            buff.append(data.replace("\"", "\"\""));
            buff.append("\"");
        }
        buff.append("\n");
    }

    /**
     * 文字化け対象の文字を変換します。
     * @param before
     * @return
     */
    private String replaceGarbledCharacter(final String before) {
    	if (before == null) {
    		return "";
    	}
    	final StringBuilder ret = new StringBuilder();
    	for (final char targetChar : before.toCharArray()) {
    		char replaceChar = targetChar;
    		for (final GarbledCharacter character
    				: GarbledCharacter.values()) {
    			if (targetChar == character.getBeforeCharacter()) {
    				replaceChar = character.getAfterCharacter();
    				break;
    			}
    		}
    		ret.append(replaceChar);
    	}

    	return ret.toString();
    }

    /**
     * 文字コード変換マッピング
     *
     * @author  EXE 島田 雄一郎
     * @version 0.0.0
     */
    private enum GarbledCharacter {
    	FULLWIDTH_TILDE('\u301c','\uff5e'),			// ～
    	HORIZONTAL_BAR('\u2014','\u2015'),			// ―
    	PARALLEL_TO('\u2016','\u2225'),				// ∥
    	FULLWIDTH_HYPHEN_MINUS('\u2212','\uff0d'),	// －
    	FULLWIDTH_CENT_SIGN('\u00a2','\uffe0'),		// ￠
    	FULLWIDTH_POUND_SIGN('\u00a3','\uffe1'),	// ￡
    	FULLWIDTH_NOT_SIGN('\u00ac','\uffe2');		// ￢

    	private char beforeCharacter;
    	private char afterCharacter;

    	private GarbledCharacter(
    			final char beforeCharacter,
    			final char afterCharacter) {
    		this.beforeCharacter = beforeCharacter;
    		this.afterCharacter = afterCharacter;
    	}

		/**
		 * beforeCharacter を戻します。
		 *
		 * @return char
		 */
		public char getBeforeCharacter() {
			return beforeCharacter;
		}

		/**
		 * afterCharacter を戻します。
		 *
		 * @return char
		 */
		public char getAfterCharacter() {
			return afterCharacter;
		}
    }

    /**
     *
     * ヘッダの作成を行います。
     *
     * @param def
     * @param buff
     */
    private void createHeader(final SortedMap<Integer, TableItemDTO> columnId) {
        boolean isFirst = true;
        for (final Integer index : columnId.keySet()) {
            if (isFirst) {
                isFirst = false;
            } else {
                buff.append(",");
            }
            buff.append("\"");
            buff.append(columnId.get(index).getItemLabel().replace("\"", "\"\""));
            buff.append("\"");
        }
        buff.append("\n");
    }

    /**
     * ファイルに出力したレコード件数を返します。
     *
     * @return 出力レコード数
     */
	@Override
	public int getOutputRecordCount() {
		return recordCount;
	}


}
