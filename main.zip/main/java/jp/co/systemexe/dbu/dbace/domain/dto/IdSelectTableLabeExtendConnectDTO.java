/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

/**
 * テーブル名 DTO。
 * <p>
 * テーブルID、テーブル名を保持する DTO です。
 * </p>
 *
 * @author  tu-lenh
 * @version 0.0.0
 */
public class IdSelectTableLabeExtendConnectDTO {
	//操作対象：マスタ 又は 子供
    private String tableConnectLabel;
    //情報
    private TableLabeExtendConnectDTO tableLabeExtendConnectDTO;

    /**
     * @param tableConnectLabel
     * @param tableLabeExtendConnectDTO
     */
    public IdSelectTableLabeExtendConnectDTO(String tableConnectLabel,TableLabeExtendConnectDTO tableLabeExtendConnectDTO){
    	this.tableConnectLabel = tableConnectLabel;
    	this.tableLabeExtendConnectDTO = tableLabeExtendConnectDTO;
    }
	/**
	 * @return the tableConnectLabel
	 */
	public String getTableConnectLabel() {
		return tableConnectLabel;
	}
	/**
	 * @param tableConnectLabel the tableConnectLabel to set
	 */
	public void setTableConnectLabel(String tableConnectLabel) {
		this.tableConnectLabel = tableConnectLabel;
	}
	/**
	 * @return the tableLabeExtendConnectDTO
	 */
	public TableLabeExtendConnectDTO getTableLabeExtendConnectDTO() {
		return tableLabeExtendConnectDTO;
	}
	/**
	 * @param tableLabeExtendConnectDTO the tableLabeExtendConnectDTO to set
	 */
	public void setTableLabeExtendConnectDTO(TableLabeExtendConnectDTO tableLabeExtendConnectDTO) {
		this.tableLabeExtendConnectDTO = tableLabeExtendConnectDTO;
	}

}
