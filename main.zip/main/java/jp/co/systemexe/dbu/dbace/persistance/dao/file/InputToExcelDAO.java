/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.ColsDto.ColDto;

/**
 * Excelファイルを読み込みます。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class InputToExcelDAO extends BaseInputFileDAO {
	/**
	 * バイト入力ストリーム
	 */
    private InputStream stream = null;

    /**
     * エクセルのシートオブジェクト
     */
//    private HSSFSheet sheet = null;
    private Sheet sheet = null;
    /**
     * 現在の読み込み中の行インデックス
     */
    private int nowRowIndex = 0;

    /**
     * データの存在する最大行インデックス
     */
    private int maxRowIndex = 0;

    /**
     * ファイル読込後の後始末を行います。
     * <p>
     * ファイルストリームのクローズを行います。
     * </p>
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseInputFileDAO#close()
     */
    @Override
    public void close() {
        try {
            if (stream != null) {
                stream.close();
            }
        } catch (final IOException e) {
        	// MI-E-0131=ファイルのクローズに失敗しました。
            getLogger().warn(MessageUtils.getMessage("MI-E-0131"), e);
        }
    }

    /**
     * 次のレコードが存在するか否かを返します。
     *
     * @return
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseInputFileDAO#hasNext()
     */
    @Override
    public boolean hasNext() throws DAOException {
        if ((nowRowIndex + 1) < maxRowIndex) {
            nowRowIndex++;
            return true;
        } else {
            nowRowIndex = -1;
            return false;
        }
    }

    /**
     * カラムのデータを返します。
     * <p>
     * 存在しない行、データが存在しない場合は空（サイズ０）のマップを返します。
     * </p>
     *
     * @return
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseInputFileDAO#read()
     */
    @Override
    public Map<String,String> read(final List<String> columnIdList) {
        final Map<String,String> ret = new HashMap<String, String>();

    	if (nowRowIndex == -1) {
    		return ret;
    	}

        //final HSSFRow row = sheet.getRow(nowRowIndex);
    	final Row row = sheet.getRow(nowRowIndex);
        boolean isEmptyRow = true;
        if (row == null) {
        	return ret;
        }

        for(short cellCount = 0; cellCount < columnIdList.size(); cellCount++) {
            //HSSFCell cell = row.getCell(cellCount);
        	Cell cell = row.getCell(cellCount);

            final String data;
            if (cell == null) {
                data = "";
            } else {
                data = getCellData(cell);
            }

            if (!StringUtils.isEmpty(data)) {
            	isEmptyRow = false;
            }

            ret.put(columnIdList.get(cellCount), data);
        }

        return isEmptyRow ? new HashMap<String, String>() : ret;
    }

    /**
     * @param columnIdMap
     * @return
     */
    @Override
    public Map<String,String> readMulti(final Map<String,Integer> columnIdMap) {
        final Map<String,String> ret = new HashMap<String, String>();
    	if (nowRowIndex == -1) {
    		return ret;
    	}
    	final Row row = sheet.getRow(nowRowIndex);
        boolean isEmptyRow = true;
        if (row == null) {
        	return ret;
        }
        for(String col:columnIdMap.keySet()){
        	int cellCount = columnIdMap.get(col);
        	Cell cell = row.getCell(cellCount);
            final String data;
            if (cell == null) {
                data = "";
            } else {
                data = getCellData(cell);
            }
            if (!StringUtils.isEmpty(data)) {
            	isEmptyRow = false;
            }
            ret.put(col, data);
        }
        return isEmptyRow ? new HashMap<String, String>() : ret;
    }

    /**
     * ヘッダレコード(カラムIDのリスト)を返します。
     *
     * @param columnIdList
     * @return
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseInputFileDAO#getColumnIdList()
     */
    @Override
    public List<String> getColumnIdList()
            throws DAOException {
        final List<String> columnIdList = new ArrayList<String>();
        short cellCount = 0;
        //final HSSFRow row = sheet.getRow(0);
    	final Row row = sheet.getRow(nowRowIndex);

        if (row == null) {
        	// MI-E-0136=ファイルにデータが存在しません。
        	final String message = MessageUtils.getMessage("MI-E-0136");
        	getLogger().error(message);
        	throw new DAOException(message);
        }
        while(true) {
            //final HSSFCell cell = row.getCell(cellCount);
            final Cell cell = row.getCell(cellCount);
            if (cell == null) {
                break;
            }

            final String cellData = getCellData(cell);

            if (StringUtils.isEmpty(cellData)) {
                break;
            }

            final String columnId = getColumnId(cellData);
        	if (columnId.equals("")) {
        		// MI-E-0133=ファイルに設定されているカラム名({0})が、テーブルに存在しません。
        		getLogger().debug("cell count:" + cellCount);
        		final String args[] = {cellData};
        		final String message = MessageUtils.getMessage("MI-E-0133", args);
        		getLogger().error(message);
        		throw new DAOException(message);
        	}
        	columnIdList.add(columnId);
        	cellCount++;
        }

        final List<String> keyList = getTableForm().getUpdateKeyList();
        for (final String pkey : keyList) {
            if (!columnIdList.contains(pkey)) {
            	// MI-E-0134=ファイルに更新時のキーカラムが設定されていません。(キーカラム：{0})
            	final String args[] = {pkey};
            	final String message = MessageUtils.getMessage("MI-E-0134", args);
            	getLogger().error(message);
            	throw new DAOException(message);
            }
        }
        return columnIdList;
    }

    @Override
    public Map<String,Integer> getMultiColumnIdList(Map<String, TableItemDTO> tableItemMap,List<String> columnIdList,TableDto tableDto) throws DAOException {
        final Map<String,Integer> columnIdMap = new HashMap<String,Integer>();
        int cellCount = 0;
    	final Row row = sheet.getRow(0);
        if (row == null) {
        	// MI-E-0136=ファイルにデータが存在しません。
        	final String message = MessageUtils.getMessage("MI-E-0136");
        	getLogger().error(message);
        	throw new DAOException(message);
        }
        while(true) {
            final Cell cell = row.getCell(cellCount);
            if (cell == null) {
                break;
            }
            final String cellData = getCellData(cell);
            if (StringUtils.isEmpty(cellData)) {
                break;
            }
            final String columnId = getColumnId(cellData);
			if (StringUtils.isNotEmpty(columnId)) {
				columnIdMap.put(columnId, cellCount);
			}
			cellCount++;
        }

        final List<String> keyList = getTableForm().getUpdateKeyList();
        for (final String pkey : keyList) {
            if (!columnIdMap.containsKey(pkey)) {
            	// MI-E-0134=ファイルに更新時のキーカラムが設定されていません。(キーカラム：{0})
            	final String args[] = {pkey};
            	final String message = MessageUtils.getMessage("MI-E-0134", args);
            	getLogger().error(message);
            	throw new DAOException(message);
            }
        }
        final Map<String,Integer> columnIdMapTemp = new HashMap<String,Integer>();
//		for (String col : columnIdMap.keySet()) {
//			if (columnIdList.contains(col)) {
//				columnIdMapTemp.put(col, columnIdMap.get(col));
//			}
//		}
		for (String colTbl : columnIdList) {
			int indexData = findIndexDataInColumnHeader(tableDto,colTbl,columnIdMap,tableItemMap);
			if (indexData != -1) {
				columnIdMapTemp.put(colTbl, indexData);
			}
		}

        return columnIdMapTemp;
    }

    /**
     * @param tableDto
     * @param colTbl
     * @param ret
     * @return
     */
    private int findIndexDataInColumnHeader(TableDto tableDto, String colTbl, Map<String, Integer> ret,Map<String, TableItemDTO> tableItemMap) {
    	for (String col : ret.keySet()) {
			if (colTbl.equals(col)) {
				return ret.get(col);
			} else {
				//column on csv : ID_U
				//list column tables-->table-->item : ID
				//List<ItemMultiDto> itemMultiDtoList = tableDto.getItemMultiDto();
				//find table , item in cols : ID_U{ID_U,ID}
				//tableItemMap : tableForm-->item-->cols
				TableItemDTO tableItemDTO = tableItemMap.get(col);
				Map<String, ColDto> colDtos= tableItemDTO.getCols();
				for(String  no:colDtos.keySet()){
					ColDto colDto = colDtos.get(no);
					if(colDto.getTableID().equals(tableDto.getId()) && colDto.getItemID().equals(colTbl)){
						return ret.get(col);
					}
				}
			}
		}
		return -1;
	}

    /**
     * セルに設定されているデータを取得します。
     *
     * @param cell
     * @return
     */
    private String getCellData(Cell cell) {
        final String data;
        switch (cell.getCellType()) {
            case HSSFCell.CELL_TYPE_BOOLEAN:
               boolean bdata = cell.getBooleanCellValue();
               getLogger().debug("CELL_TYPE_BOOLEAN:" + bdata);
               data = String.valueOf(bdata);
               break;
            case HSSFCell.CELL_TYPE_NUMERIC:
            	// ADD 日付、数値型を変更しインポートするとエラーとなる部分を対応　↓
            	//"Time-only" values have date set to 1899-12-31 so if year is "1899" --> "time-only" value
				if (cell.getDateCellValue() != null && "1899".equals(new SimpleDateFormat("yyyy").format(cell.getDateCellValue()))) {
					// SimpleDateFormat formatTime = new SimpleDateFormat("HH:mm:ss");
					// data = formatTime.format(cell.getDateCellValue()); // この方を使わない
					// Return "Time-only" value as String HH:mm:ss
					data = new DataFormatter().formatCellValue(cell); // Cellの元の値を取得
					getLogger().debug("CELL_TYPE_TIME:" + data);
				} else {
					// date-only or date-time value
				// ADD 日付、数値型を変更しインポートするとエラーとなる部分を対応　↑
					double ddata = cell.getNumericCellValue();
					if (HSSFDateUtil.isCellDateFormatted(cell)) {
						final SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
						data = format.format(HSSFDateUtil.getJavaDate(ddata));
						getLogger().debug("CELL_TYPE_DATE:" + data);
					} else {
						getLogger().debug("CELL_TYPE_NUMERIC:" + ddata);
						data = String.valueOf(ddata);
					}
				}
            	break;
            case HSSFCell.CELL_TYPE_STRING:
               data = cell.getRichStringCellValue().getString();
               getLogger().debug("CELL_TYPE_STRING:" + data);
               break;
            case HSSFCell.CELL_TYPE_BLANK:
            case HSSFCell.CELL_TYPE_ERROR:
            case HSSFCell.CELL_TYPE_FORMULA:
            default:
                data = "";
                break;
        }
        return data;
    }

    /**
     * コンストラクタ
     *
     * @param stream
     * @param tableForm
     * @throws DAOException
     */
    public InputToExcelDAO(
            final InputStream stream,
            final TableFormDTO tableForm)
            throws DAOException {
        super(tableForm);
        try {
        	/*
            this.stream = stream;
            final POIFSFileSystem fs = new POIFSFileSystem(this.stream);
            final HSSFWorkbook wb = new HSSFWorkbook(fs);
            sheet = wb.getSheetAt(0);
            this.maxRowIndex = sheet.getLastRowNum() + 1;
            */
        	this.stream = stream;
        	final Workbook wb = WorkbookFactory.create(this.stream);
        	sheet = wb.getSheetAt(0);
        	this.maxRowIndex = sheet.getLastRowNum() + 1;

        } catch (final InvalidFormatException e){
        	// MI-E-0137=ファイルの読込みに失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0137");
        	getLogger().error(message, e);
            throw new DAOException(message, e);
        } catch (final IOException e) {
        	// MI-E-0137=ファイルの読込みに失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0137");
        	getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }
}
