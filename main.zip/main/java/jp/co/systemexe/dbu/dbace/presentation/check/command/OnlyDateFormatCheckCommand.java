/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.ItemRestriction;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;

/**
 * 日付型書式チェック。
 * <p>
 * 日付解釈可能な入力値かどうかのチェックコマンドです。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class OnlyDateFormatCheckCommand extends BaseLogicalCheckCommand {

    /**
     * このクラスが対象とする JDBC データ型の定義リスト。
     */
    private static final List<JDBCMetaDataType> jdbcDateTypeList;
    static {
        jdbcDateTypeList = new ArrayList<JDBCMetaDataType>();
        jdbcDateTypeList.add(JDBCMetaDataType.DATE);
        jdbcDateTypeList.add(JDBCMetaDataType.TIME);
        jdbcDateTypeList.add(JDBCMetaDataType.TIMESTAMP);
    }

    /**
     * OnlyDateFormatCheckCommand の生成。
     * <p>コンストラクタ。</p>
     */
    public OnlyDateFormatCheckCommand() {
        return;
    }

    /**
     * 検査を実行します。
     * <p>
     * 日付型、時刻型、タイムスタンプ型それぞれの DB データ型に応じ、入力値が
     * パース可能かを調べ、解釈出来なかった場合警告を設定します。値の補正は行い
     * ません。
     * </p><p>
     * それ以外の型で本検査が実行されるのは、文字列項目に対する「ゆるい書式定義」
     * が成された場合だけです。この場合は文字列が日付として解釈可能であるか
     * どうか、正規表現による簡易検査を実行します。
     * </p><p>
     * null または空文字だった場合は検査を行いません。</p>
     *
     * @param columnId カラム名
     * @param messages 論理チェック結果メッセージ保持 DTO
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#check(java.lang.String, java.lang.String, jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO)
     */
    @Override
    public void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
    		final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap) {
        final String value = messages.getCorrectedValue(columnId);
        if (value == null || value.equals("")) {
            return;
        }
        final DefinitionOfColumn def = getDisplayDef().getDefinitionOfColumns()
            .get(columnId);
        final DefinedHtmlElement element = getDisplayDef().getItemDefinitions()
            .get(columnId).getHtmlElement();
         String format;
        if (DefinedHtmlElement.INPUT_DATE == element) {
            format = "yyyy/MM/dd";
        } else if (DefinedHtmlElement.INPUT_DATETIME == element) {
            format = "yyyy/MM/dd HH:mm:ss";
        } else if (DefinedHtmlElement.INPUT_TIMESTAMP == element) {
            format = "yyyy/MM/dd HH:mm:ss.SSS";
        } else if (DefinedHtmlElement.INPUT_TIME == element) {
            format = "HH:mm:ss";
        } else if (JDBCMetaDataType.DATE == def.getJDBCMetaDataType()) {
            format = "yyyy/MM/dd HH:mm:ss";
        } else if (JDBCMetaDataType.TIME == def.getJDBCMetaDataType()) {
            format = "HH:mm:ss";
        } else if (JDBCMetaDataType.TIMESTAMP == def.getJDBCMetaDataType()) {
            format = "yyyy/MM/dd HH:mm:ss.SSS";
        } else {
            if (value.matches(".*年.*月.*日.*")
                    || value.matches(".*時.*分.*秒.*")
                    || value
                        .matches("((19|[2-9][0-9])[0-9]{2})/([1-9]|(0[1-9]|1[0-2]))/([1-9]|(0[1-9]|([12][0-9]|3[01])))")
                    || value
                        .matches("((19|[2-9][0-9])[0-9]{2})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])")) {

                // TODO こんな簡易判定でよいかな？検討...

                return;
            } else {
            	// MI-E-0099={0}は日付または、時刻として解釈出来ません。
            	String columnLabel = tableItemMap.get(columnId).getItemLabel();
            	final String args[] = {columnLabel};
                messages.getMessages(columnId).add(MessageUtils.getMessage("MI-E-0099",args));
                return;
            }
        }

        final SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setLenient(false);
        final Date date;
        try {
        	if(value.matches("^[0-9/:. ]+$")){
	            date = sdf.parse(value);
	            messages.setCorrectedValue(columnId, sdf.format(date));
        	} else {
        		if (DefinedHtmlElement.INPUT_DATE == element) {
                    format = "YYYY/MM/DD";
                } else if (DefinedHtmlElement.INPUT_DATETIME == element) {
                    format = "YYYY/MM/DD hh:mm:ss";
                } else if (DefinedHtmlElement.INPUT_TIMESTAMP == element) {
                    format = "YYYY/MM/DD hh:mm:ss.sss";
                } else if (DefinedHtmlElement.INPUT_TIME == element) {
                    format = "hh:mm:ss";
                } else if (JDBCMetaDataType.DATE == def.getJDBCMetaDataType()) {
                    format = "YYYY/MM/DD hh:mm:ss";
                } else if (JDBCMetaDataType.TIME == def.getJDBCMetaDataType()) {
                    format = "hh:mm:ss";
                } else if (JDBCMetaDataType.TIMESTAMP == def.getJDBCMetaDataType()) {
                    format = "YYYY/MM/DD hh:mm:ss.sss";
                }
        		String columnLabel = tableItemMap.get(columnId).getItemLabel();
            	final String args[] = {columnLabel,format};
                messages.getMessages(columnId).add(MessageUtils.getMessage("MI-E-0100", args));
                return;
        	}
        } catch (final ParseException e) {
        	if (DefinedHtmlElement.INPUT_DATE == element) {
                format = "YYYY/MM/DD";
            } else if (DefinedHtmlElement.INPUT_DATETIME == element) {
                format = "YYYY/MM/DD hh:mm:ss";
            } else if (DefinedHtmlElement.INPUT_TIMESTAMP == element) {
                format = "YYYY/MM/DD hh:mm:ss.sss";
            } else if (DefinedHtmlElement.INPUT_TIME == element) {
                format = "hh:mm:ss";
            } else if (JDBCMetaDataType.DATE == def.getJDBCMetaDataType()) {
                format = "YYYY/MM/DD hh:mm:ss";
            } else if (JDBCMetaDataType.TIME == def.getJDBCMetaDataType()) {
                format = "hh:mm:ss";
            } else if (JDBCMetaDataType.TIMESTAMP == def.getJDBCMetaDataType()) {
                format = "YYYY/MM/DD hh:mm:ss.sss";
            }
        	// MI-E-0100={0}は日付書式  {1} として解釈出来ません。
        	String columnLabel = tableItemMap.get(columnId).getItemLabel();
        	final String args[] = {columnLabel,format};
            messages.getMessages(columnId).add(MessageUtils.getMessage("MI-E-0100", args));
            return;
        }
    }

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * このクラスが検査対象とする条件は、
     * <ol>
     *  <li>リポジトリの入力値制約に ONLY_DATE_FORMAT 制約が存在する場合。</li>
     *  <li>DB 定義の JDBC データ型が日付或いは時刻形式である場合。</li>
     * </ol>
     * </p>
     *
     * @param columnId
     * @return true : 検査担当 / false : 担当ではない
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#isCharge(java.lang.String)
     */
    @Override
    protected boolean isMyTask(final String columnId) {
        final TableItemDTO item = getDisplayDef().getItemDefinitions().get(
            columnId);
        if (item.getItemRestrictions().containsKey(
            ItemRestriction.ONLY_DATE_FORMAT)) {
            return true;
        }
        final DefinitionOfColumn def = getDisplayDef().getDefinitionOfColumns()
            .get(columnId);
        if (jdbcDateTypeList.contains(def.getJDBCMetaDataType())) {
            return true;
        }
        return false;
    }
}
