/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.ChangeAuditLogLogic;
import jp.co.systemexe.dbu.dbace.domain.service.InitializeService;

/**
 * WEBサーバー起動時の初期化処理を行います。
 * <p>
 * 監査ログ情報出力用のlog4j情報を取得します。
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class InitializeServiceImpl implements InitializeService {
    private static final Logger logger = LoggerFactory.getLogger("InitializeServiceImpl");

    /**
	 * 監査ログ情報出力用のlog4j情報を取得します。
     * @see jp.co.systemexe.dbu.dbace.service.InitializeService#initialize()
     */
    public void initialize() {
        final ChangeAuditLogLogic logic = new ChangeAuditLogLogic();
        try {
            logic.newAuditLog();
        } catch (ApplicationDomainLogicException e) {
            logger.fatal(e);
        }
    }
}
