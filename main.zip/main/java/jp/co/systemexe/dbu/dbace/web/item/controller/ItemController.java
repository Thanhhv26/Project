/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.controller;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;
import jp.co.systemexe.dbu.dbace.domain.dto.DbConnectDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.TableNameListIsAcquiredFromRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.service.CreationService;
import jp.co.systemexe.dbu.dbace.domain.service.ItemService;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectConnectListDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectItemDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectItemDTOSave;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectTablesDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SortColumnEditorDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SortDataEditorDTO;
import jp.co.systemexe.dbu.dbace.web.item.model.FRM0310ResultModel;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;
import jp.co.systemexe.dbu.dbace.web.user.dto.PageInfo;


/**
 * @author THANH TRUC
 * @version 6.0 Feb 09, 2017
 */
@RestController
@RequestMapping(value = "/data")

public class ItemController extends AbstractController {
	private static final long serialVersionUID = 1L;

	@Autowired
	private ItemService itemService;

	@Autowired
	CreationService creationService;

	/**
	 * get info page
	 * @return view
	 */
	@RequestMapping(value = "/customize/getInfoPage", method = { RequestMethod.POST })
	public PageInfo getInfoPage() throws Exception {
		return new PageInfo();
	}

    /**
     * Page クラスの初期化イベントハンドラ。
     *
     */
	@RequestMapping(value="/customize",method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index(Model model) throws Exception {
		ModelAndView mv = new ModelAndView(PageConst.SCREEN_ITEM);
		model.addAttribute("doInitialize", itemService.doInitialize(getUserAuthority()));
		return mv;
	}

	/**
	 *
	 */
	@RequestMapping(value = "/customize/loadSortData", method = RequestMethod.POST)
	public @ResponseBody FRM0310ResultModel doLoadSortData(@RequestBody SelectTablesDTO selectTablesDTO) {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel = itemService.loadSortData(selectTablesDTO);
		return resultModel;
	}

	/**
	 *
	 */
	@RequestMapping(value = "/customize/loadSortColumn", method = RequestMethod.POST)
	public @ResponseBody FRM0310ResultModel doLoadSortColumn(@RequestBody SelectTablesDTO selectTablesDTO) {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel = itemService.loadSortColumn(selectTablesDTO);
		return resultModel;
	}

	/**
	 *
	 */
	@RequestMapping(value = "/customize/updateSortData", method = RequestMethod.POST)
	public @ResponseBody FRM0310ResultModel doUpdateSortData(@RequestBody SortDataEditorDTO sortDataEditorDTO) {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		if (validateTableInformation(sortDataEditorDTO, resultModel)) {
			resultModel = itemService.updateSortData(sortDataEditorDTO, getUserInfo());
			if(resultModel.getMessageInfo().size() == 0){
				resultModel.getMessageInfo()
				.add(new MessageInfo("customize.sort.data.update.success", MessageType.SUCCESS, messageService));
			}
		}
		return resultModel;
	}

	/**
	 *
	 */
	@RequestMapping(value = "/customize/updateSortColumn", method = RequestMethod.POST)
	public @ResponseBody FRM0310ResultModel doUpdateSortColumn(@RequestBody SortColumnEditorDTO sortColumnEditorDTO) {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		if (validateColumnInformation(sortColumnEditorDTO, resultModel)) {
			resultModel = itemService.updateSortColumn(sortColumnEditorDTO, getUserInfo());
			if(resultModel.getMessageInfo().size() == 0){
				resultModel.getMessageInfo()
				.add(new MessageInfo("customize.sort.column.update.success", MessageType.SUCCESS, messageService));
			}
		}
		return resultModel;
	}

	private boolean validateTableInformation(SortDataEditorDTO sortDataEditorDTO, FRM0310ResultModel resultModel) {
		boolean isError = true;
		if (StringUtils.isBlank(sortDataEditorDTO.getTableFormDTO().getTableFormLabel())) {
			resultModel.getMessageInfo()
					.add(new MessageInfo("tableLabel", "MI-E-0500-0001", MessageType.ERROR, messageService,
							new String[] { messageService.getMessage("frm0310.objectName") }));
			isError = false;
		}

		//check table name display same name repository
				/* リポジトリXML上に登録されているテーブル一覧を取得*/
	    final TableNameListIsAcquiredFromRepositoryLogic repository = new TableNameListIsAcquiredFromRepositoryLogic();
	    List<IdSelectable> repList = null;
		try {
	        final AcquisitionOfConnectDefinitionLogic connectDefinitionLogic = new AcquisitionOfConnectDefinitionLogic();
	        final DbConnectDefinitionDTO connectDefinitionDTO = connectDefinitionLogic.getConnectDefinitionDTOByLabel(sortDataEditorDTO.getConnectDefinitionId());
			repList = repository.getAllTableNameMap(connectDefinitionDTO.getConnectDefinitionId());
		} catch (ApplicationDomainLogicException e) {
			getLogger().error(e);
		}
		String tableId = sortDataEditorDTO.getTableFormDTO().getTableFormId();
		String tableLabel = sortDataEditorDTO.getTableFormDTO().getTableFormLabel();
		if (checkTableNameSyncSameNameRepository(repList,tableId,tableLabel)) {
			String args[] = { tableLabel};
//			String mess = MessageUtils.getMessage("MI-F-0031", args);
//			resultModel.getMessageInfo().add(new MessageInfo(mess,MessageType.ERROR));
			resultModel.getMessageInfo().add(new MessageInfo("tableLabel", "MI-F-0031", MessageType.ERROR, messageService,args));
			isError = false;
		}

		return isError;
	}

	/**
	 * @param sortColumnEditorDTO
	 * @param resultModel
	 * @return
	 */
	private boolean validateColumnInformation(SortColumnEditorDTO sortColumnEditorDTO, FRM0310ResultModel resultModel) {
		boolean isError = true;
		if (StringUtils.isBlank(sortColumnEditorDTO.getTableFormDTO().getTableFormLabel())) {
			resultModel.getMessageInfo()
					.add(new MessageInfo("tableLabel", "MI-E-0500-0001", MessageType.ERROR, messageService,
							new String[] { messageService.getMessage("frm0310.objectName") }));
			isError = false;
		}

		//check table name display same name repository
		/* リポジトリXML上に登録されているテーブル一覧を取得*/
	    final TableNameListIsAcquiredFromRepositoryLogic repository = new TableNameListIsAcquiredFromRepositoryLogic();
	    List<IdSelectable> repList = null;
		try {
	        final AcquisitionOfConnectDefinitionLogic connectDefinitionLogic = new AcquisitionOfConnectDefinitionLogic();
	        final DbConnectDefinitionDTO connectDefinitionDTO = connectDefinitionLogic.getConnectDefinitionDTOByLabel(sortColumnEditorDTO.getConnectDefinitionId());
			repList = repository.getAllTableNameMap(connectDefinitionDTO.getConnectDefinitionId());
		} catch (ApplicationDomainLogicException e) {
			getLogger().error(e);
		}
		String tableId = sortColumnEditorDTO.getTableFormDTO().getTableFormId();
		String tableLabel = sortColumnEditorDTO.getTableFormDTO().getTableFormLabel();
		if (checkTableNameSyncSameNameRepository(repList,tableId,tableLabel)) {
			String args[] = { tableLabel};
//			String mess = MessageUtils.getMessage("MI-F-0031", args);
//			resultModel.getMessageInfo().add(new MessageInfo(mess,MessageType.ERROR));
			resultModel.getMessageInfo().add(new MessageInfo("tableLabel", "MI-F-0031", MessageType.ERROR, messageService,args));
			isError = false;
		}
		return isError;
	}

	/**
	 * @param repList
	 * @param tableName
	 * @return
	 */
	private boolean checkTableNameSyncSameNameRepository(List<IdSelectable> repList,String tableId,String tableName) {
		for (IdSelectable item : repList) {
			if (tableName.equals(item.getLabel()) && !tableId.equals(item.getId())) {
				return true;
			}
		}
		return false;
	}

	/**
	 *
    */
	@RequestMapping(value = "/customize/saveTableInformation",method = RequestMethod.POST )
	 public @ResponseBody FRM0310ResultModel saveTableInformation(@RequestBody SortDataEditorDTO tableInformationEditor) {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		return resultModel;
	 }

	/**
     * 選択された接続定義プロパティーより、接続定義のテーブル一覧情報を取得し、
     * テーブル一覧プルダウンリストを生成（初期化）します。</p>
     *
     * @return
     */
	@RequestMapping(value = "/customize/searchTable",method = RequestMethod.POST )
	 public @ResponseBody FRM0310ResultModel doOnceSearchTables(@RequestBody SelectConnectListDTO search) {
		FRM0310ResultModel resultModel = itemService.searchTable(search);
		return resultModel;
	 }
	/**
     * 選択されたテーブルプロパティーより、テーブルのカラム一覧情報を取得し、
     * カラム一覧プルダウンリストを生成（初期化）します。</p>
     *
     * @return
     */
	@RequestMapping(value = "/customize/searchColumn",method = RequestMethod.POST )
	 public @ResponseBody FRM0310ResultModel doOnceSearchTableItems(@RequestBody SelectTablesDTO search) {
		UserAuthority userAuthority = new UserAuthority();
		userAuthority.setSystemAdministrator(true);
		
		//check connection and table exists
		TableNameListIsAcquiredFromRepositoryLogic domainLogic = new TableNameListIsAcquiredFromRepositoryLogic();
		String connectionId;
		try {
			connectionId = domainLogic.getConnectDefinitionIdByConnectName(search.getConnectDefinitionId());
			TableFormDto checkTable = creationService.getTableFormDtoByID(connectionId, search.getTableId(), userAuthority);
			if(checkTable == null){
				FRM0310ResultModel returnError = new FRM0310ResultModel();
				returnError.getMessageInfo().add(new MessageInfo("frm0310.title.item.deleted.suffix", MessageType.ERROR, messageService));
				return returnError;
			}
		} catch (ApplicationDomainLogicException e) {
			// TODO Auto-generated catch block
			FRM0310ResultModel returnError = new FRM0310ResultModel();
			returnError.getMessageInfo().add(new MessageInfo("frm0310.title.item.deleted.suffix", MessageType.ERROR, messageService));
			return returnError;
		}

		String userId = getUserInfo().getId();
		FRM0310ResultModel resultModel = itemService.searchColumn(search,userId);
		MessageInfo error = new MessageInfo();
		if(resultModel.isStatus()==false)
		{
			//error = new MessageInfo("FRM0310-002", MessageType.ERROR, search.getTableId(), messageService);
			error = new MessageInfo("FRM0310-002", MessageType.ERROR, messageService);
			resultModel.getMessageInfo().add(error);
			OutputAuditLog.writeGuiSettingLog(
					AuditEventKind.SEARCH,
					getUserInfo(),
					creationService.getConnectionByLabel(search.getConnectDefinitionId(), 0, userAuthority).getId(),
					search.getTableLabel().replaceAll("\n", "").replaceAll("\t", ""),
					AuditStatus.failure,
               		String.valueOf(0));
		}else{
			OutputAuditLog.writeGuiSettingLog(
					AuditEventKind.SEARCH,
					getUserInfo(),
					creationService.getConnectionByLabel(search.getConnectDefinitionId(), 0, userAuthority).getId(),
					search.getTableLabel().replaceAll("\n", "").replaceAll("\t", ""),
					AuditStatus.success,
               		String.valueOf(resultModel.getColumnListItems().size()));
			resultModel.setStatus(true);
		}
		return resultModel;
	 }
	/**
     * Page クラスの初期化イベントハンドラ。
     * <p>
     * テーブルフォーム情報の編集操作はアプリケーション管理権限を持ったユーザー
     * 以外実行出来ません。ここではセッション中の管理権限を確認し、違反していた
     * 場合はセッション中に警告を設定し、エラー画面に遷移します。
     * </p><p>
     * 権限をクリアした場合は、初期化処理としてリポジトリからの画面表示情報の
     * 取得と画面への表示を行います。
     * </p>
     *
     */
	@RequestMapping(value = "/customize/doEditItem",method = RequestMethod.POST )
	 public @ResponseBody FRM0310ResultModel doEditItem(@RequestBody SelectItemDTO search) {
		search.setUserInfo(getUserInfo());
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		/*if(this.isDeletedItem(search)){
			MessageInfo error = new MessageInfo("", MessageType.NOT_EXISTS_ERROR);
			resultModel.getMessageInfo().add(e);
			return resultModel;
		}*/
		resultModel = itemService.doEditItem(search);
		return resultModel;
	 }
	/**
     * 「既定値 の確認」ボタンのイベントハンドラ。
     * <p>
     * 入力された 既定値の実行結果を検証するボタンです。
     * </p>
     *
     * @return 遷移先ページクラス
     */
	@RequestMapping(value = "/customize/doOnceDefaultValue",method = RequestMethod.POST )
	 public @ResponseBody FRM0310ResultModel doOnceDefaultValue(@RequestBody SelectItemDTO search) {
		FRM0310ResultModel resultModel = itemService.doOnceDefaultValue(search,getUserInfo());
		return resultModel;
	 }
	/**
     * 「プルダウンリストに追加する」ボタンのイベントハンドラ。
     * <p>
     * プルダウンリストへの表示値設定リストにキー値と表示値の値セットを追加
     * します。<br />
     * 追加後、入力欄はクリアします。
     * </p>
     *
     * @return null
     */
	@RequestMapping(value = "/customize/doOnceAddRestrictionItem",method = RequestMethod.POST )
	 public @ResponseBody FRM0310ResultModel doOnceAddRestrictionItem(@RequestBody SelectItemDTO search) {
		FRM0310ResultModel resultModel = itemService.doOnceAddRestrictionItem(search,getUserInfo());
		return resultModel;
	 }
	/**
     * 「削除」ボタンのイベントハンドラ。
     * <p></p>
     *
     * @return 遷移先ページクラス
     */
	@RequestMapping(value = "/customize/doOnceDelitationRestrictionItem",method = RequestMethod.POST )
	 public @ResponseBody FRM0310ResultModel doOnceDelitationRestrictionItem(@RequestBody SelectItemDTO search) {
		FRM0310ResultModel resultModel = itemService.doOnceDelitationRestrictionItem(search,getUserInfo());
		return resultModel;
	 }
	/**
     * 「SQL の確認」ボタンのイベントハンドラ。
     * <p>
     * 入力された SQL 文の妥当性を検証するボタンです。
     * </p><p>
     * SQL 文の指定が無い場合は、メッセージを表示して単にポストバックします。
     * </p><p>
     * 入力された SQL を実際に発行し、レコードを何件か取得し表示します。検証用の
     * ロジックが例外をスローして来た場合に問題がある、と判断します。
     * </p>
     *
     * @return 遷移先ページクラス
     */
	@RequestMapping(value = "/customize/doOnceSqlCheck",method = RequestMethod.POST )
	 public @ResponseBody FRM0310ResultModel doOnceSqlCheck(@RequestBody SelectItemDTO search) {
		FRM0310ResultModel resultModel = itemService.doOnceSqlCheck(search,getUserInfo());
		return resultModel;
	 }

	@RequestMapping(value = "/customize/doOnceSave",method = RequestMethod.POST )
	 public @ResponseBody FRM0310ResultModel doOnceSave(@RequestBody SelectItemDTOSave search) {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		// check item exist
		if (!isDeletedItem(search.getConnectDefinitionId(), search.getTableId(), search.getItemId())) {
			resultModel.setStatus(false);
			MessageInfo error = new MessageInfo("MI-E-0115",MessageType.NOT_EXISTS_ERROR, messageService);
			resultModel.getMessageInfo().add(error);
			//error.setId("frm0310.doEditItem.columnLabel");
			return resultModel;
		}
		resultModel = itemService.doOnceSave(search,getUserInfo());
		return resultModel;
	 }
	
	/**
	 * check connection exist, check table exist, check column exist
	 * @param search
	 * @return
	 */
	@RequestMapping(value = "/customize/isDeletedItem", method = { RequestMethod.POST })
	public boolean isDeletedItem(@RequestBody SelectItemDTO search) {
		TableNameListIsAcquiredFromRepositoryLogic domainLogic = new TableNameListIsAcquiredFromRepositoryLogic();
		String connectionId;
		try {
			connectionId = domainLogic.getConnectDefinitionIdByConnectName(search.getConnectDefinitionId());
			String tableID = search.getTableId();
			String itemID = search.getItemId();
			ItemDto itemDto =  creationService.getItemByID(connectionId, tableID, itemID, getUserAuthority());
			return (itemDto == null ? false : true);
		} catch (ApplicationDomainLogicException e) {
			return false;
		}
	}
	
	/**
	 * check connection exist, check table exist, check column exist
	 * @param connectionName
	 * @param tableID
	 * @param itemID
	 * @return
	 */
	public boolean isDeletedItem(String connectionName, String tableID, String itemID) {
		TableNameListIsAcquiredFromRepositoryLogic domainLogic = new TableNameListIsAcquiredFromRepositoryLogic();
		String connectionId;
		try {
			connectionId = domainLogic.getConnectDefinitionIdByConnectName(connectionName);
			ItemDto itemDto =  creationService.getItemByID(connectionId, tableID, itemID, getUserAuthority());
			return (itemDto == null ? false : true);
		} catch (ApplicationDomainLogicException e) {
			return false;
		}
	}

}
