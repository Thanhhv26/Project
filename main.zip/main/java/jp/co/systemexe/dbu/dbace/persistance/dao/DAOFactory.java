/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseAuditSettingXmlDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseRepositoryXmlDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.xml.AppRepository;
import jp.co.systemexe.dbu.dbace.persistance.dao.xml.AuditSettingXml;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAONotFoundException;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;

/**
 * DAO ファクトリ。
 * <p>
 * DAO を一括保持するファクトリクラスです。</p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public final class DAOFactory {

    /**
     * アプリケーションリポジトリへの参照。
     */
    private static final AppRepository appRepository = AppRepository
        .getInstance();

    /**
     * 監査ログ設定情報XMLへの参照
     */
    private static final AuditSettingXml auditSettingXml = AuditSettingXml.getInstance();

    /**
     * DAO の一覧マップMap&lt;インターフェース名,名前空間&gt;を保持します。
     * <p>
     * static initializer にてDAOをマップに登録していきます。</p>
     */
    private static Map<String, String> map;
    static {
        map = new HashMap<String, String>();
        map
            .put("ApplicationUserDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.ApplicationUserDAOImpl");
        map.put("ApplicationRelationDAO","jp.co.systemexe.dbu.dbace.persistance.dao.impl.ApplicationRelationDAOImpl");
        map
            .put("TableFormDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.TableFormDAOImpl");
        map
            .put(
                "DbConnectInfomationDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.DbConnectInfomationDAOImpl");
        map
            .put("ConnectDefinisionDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.ConnectDefinisionDAOImpl");
//        map
//            .put("DatabaseSchemaDAO",
//                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.DatabaseSchemaDAOImpl");
//        map
//            .put("DatabaseTableDAO",
//                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.DatabaseTableDAOImpl");
        map
            .put("OracleDatabaseSchemaDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.OracleDatabaseSchemaDAOImpl");
        map
            .put("SQLServerDatabaseSchemaDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.SQLServerDatabaseSchemaDAOImpl");
        map
        	.put("PostgreSQLDatabaseSchemaDAO",
        		"jp.co.systemexe.dbu.dbace.persistance.dao.impl.PostgreSQLDatabaseSchemaDAOImpl");
        map
        	.put("MySQLDatabaseSchemaDAO",
        		"jp.co.systemexe.dbu.dbace.persistance.dao.impl.MySQLDatabaseSchemaDAOImpl");
        map
            .put("DB2DatabaseSchemaDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.DB2DatabaseSchemaDAOImpl");

        map
            .put("OracleDatabaseTableDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.OracleDatabaseTableDAOImpl");
        map
            .put("SQLServerDatabaseTableDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.SQLServerDatabaseTableDAOImpl");
        map
        	.put("PostgreSQLDatabaseTableDAO",
            	"jp.co.systemexe.dbu.dbace.persistance.dao.impl.PostgreSQLDatabaseTableDAOImpl");
        map
        	.put("MySQLDatabaseTableDAO",
        		"jp.co.systemexe.dbu.dbace.persistance.dao.impl.MySQLDatabaseTableDAOImpl");
        map
            .put("DB2DatabaseTableDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.DB2DatabaseTableDAOImpl");

        map
            .put("RepositoryBackUpDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.RepositoryBackUpDAOImpl");
        map
            .put("OutputsToExcelWithTableDataDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.file.OutputsToExcelWithTableDataDAO");
        map
        .put("OutputsToExcelUseCustomWriterWithTableDataDAO",
            "jp.co.systemexe.dbu.dbace.persistance.dao.file.OutputsToExcelUseCustomWriterWithTableDataDAO");
        map
        .put("OutputsToExcelUseSXSSFWriterWithTableDataDAO",
            "jp.co.systemexe.dbu.dbace.persistance.dao.file.OutputsToExcelUseSXSSFWriterWithTableDataDAO");
        map
            .put("OutputsToCsvWithTableDataDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.file.OutputsToCsvWithTableDataDAO");
        map
            .put("OutputsToXmlWithTableDataDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.file.OutputsToXmlWithTableDataDAO");
        map
            .put("AuditSettingDAO",
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.AuditSettingDAOImpl");
        map
	        .put("OracleDatabaseTableOneRecordDAO",
	            "jp.co.systemexe.dbu.dbace.persistance.dao.impl.OracleDatabaseTableOneRecordDAOImpl");
	    map
	        .put("SQLServerDatabaseTableOneRecordDAO",
	            "jp.co.systemexe.dbu.dbace.persistance.dao.impl.SQLServerDatabaseTableOneRecordDAOImpl");
	    map
        	.put("PostgreSQLDatabaseTableOneRecordDAO",
            "jp.co.systemexe.dbu.dbace.persistance.dao.impl.PostgreSQLDatabaseTableOneRecordDAOImpl");
	    map
	    	.put("MySQLDatabaseTableOneRecordDAO",
	    		"jp.co.systemexe.dbu.dbace.persistance.dao.impl.MySQLDatabaseTableOneRecordDAOImpl");
	    map
    		.put("DB2DatabaseTableOneRecordDAO",
    			"jp.co.systemexe.dbu.dbace.persistance.dao.impl.DB2DatabaseTableOneRecordDAOImpl");
    }

    /**
     * DAO を生成して戻します。
     * <p>
     * 取得した DAO は、要求したインターフェースにキャストしてから使用します。</p>
     *
     * @param key DAO キー文字列（インターフェース名）
     * @return BaseDAO
     * @exception DAONotFoundException
     */
    public static BaseDAO createDAO(final String key)
            throws DAONotFoundException, DAOException {
        final Class clazz;
        try {
            clazz = Class.forName(map.get(key));
        } catch (final ClassNotFoundException e) {
        	// MI-F-0001={0} クラスが存在しません。
        	final String args[] = {map.get(key)};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            throw new DAONotFoundException(message, e);
        } catch (final Exception e) {
        	// MI-F-0001={0} クラスが存在しません。
        	final String args[] = {key};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            throw new DAONotFoundException(message, e);
        }

        try {
            final BaseDAO ret = (BaseDAO)clazz.newInstance();
            if (ret instanceof BaseRepositoryXmlDAO) {
                ((BaseRepositoryXmlDAO)ret).setAppRepository(appRepository);
                ((BaseRepositoryXmlDAO)ret).init();
            } else if (ret instanceof BaseAuditSettingXmlDAO) {
                ((BaseAuditSettingXmlDAO)ret).setAuditSettingXml(auditSettingXml);
                ((BaseAuditSettingXmlDAO)ret).init();
            }
            return ret;
        } catch (final Exception e) {
            throw new DAOException(e);
        }
    }

    /**
     * DAO を生成して戻します。
     * <p>
     * 取得した DAO は、要求したインターフェースにキャストしてから使用します。</p>
     *
     * @param key DAO キー文字列（インターフェース名）
     * @param type データベースタイプ
     * @return BaseDAO
     * @exception DAONotFoundException
     */
    public static BaseDAO createDAO(final String key, final DatabaseTypeConnectionDestination type)
            throws DAONotFoundException, DAOException {
        return createDAO(type.getKey() + key);
    }

    /**
     * DAOFactory の生成。
     * <p>デフォルトコンストラクタ隠蔽。</p>
     */
    private DAOFactory() {
        return;
    }
}
