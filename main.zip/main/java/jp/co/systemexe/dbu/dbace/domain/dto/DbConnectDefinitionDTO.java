/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;

/**
 * データベース接続定義情報 DTO。
 * <p>
 * データベースに対する接続定義情報を保持する DTO です。<br />
 * 概ねデータベースへの接続文字列を定義する情報を保持します。</p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class DbConnectDefinitionDTO {

    /**
     * 接続定義 ID。
     */
    private String connectDefinitionId;

    /**
     * 接続定義名称プロパティ。
     */
    private String connectDefinitionName;

    /**
     * サーバ ID プロパティ。
     * <p>サーバ名と等価です。</p>
     */
    private String serverId;
    
    /**
     * ポート番号。
     */
    private String port;

    /**
     * データベース ID プロパティ。
     */
    private String databaseId;

    /**
     * PID プロパティ。
     */
    private String pid;
    
    /**
     * DB 接続パスワードプロパティ。
     */
    private String password;
    
    /**
     * データベースＵＲＬをユーザが直に指定しいるか否か
     */
    private boolean useDatabaseUrl;
    
    /**
     * データベースＵＲＬ
     */
    private String databaseUrl;
    
    /**
     * 接続先データベースベンダー種類
     */
    private DatabaseTypeConnectionDestination databaseTypeConnectionDestination;

    /**
     * インスタンス名(SQL Serverのみ)
     */
    private String instanceName;
    
    /**
     * connectDefinitionId を戻します。
     * 
     * @return String
     */
    public String getConnectDefinitionId() {
        return connectDefinitionId;
    }

    /**
     * connectDefinitionId を設定します。
     *
     * @param String connectDefinitionId 
     */
    public void setConnectDefinitionId(String connectDefinitionId) {
        this.connectDefinitionId = connectDefinitionId;
    }

    /**
     * connectDefinitionName を戻します。
     * 
     * @return String
     */
    public String getConnectDefinitionName() {
        return connectDefinitionName;
    }

    /**
     * connectDefinitionName を設定します。
     *
     * @param String connectDefinitionName 
     */
    public void setConnectDefinitionName(String connectDefinitionName) {
        this.connectDefinitionName = connectDefinitionName;
    }

    /**
     * databaseName を戻します。
     * 
     * @return String
     */
    public String getDatabaseId() {
        return databaseId;
    }

    /**
     * databaseName を設定します。
     *
     * @param String databaseName 
     */
    public void setDatabaseId(String databaseId) {
        this.databaseId = databaseId;
    }

    /**
     * password を戻します。
     * 
     * @return String
     */
    public String getPassword() {
        return password;
    }

    /**
     * password を設定します。
     *
     * @param String password 
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * pid を戻します。
     * 
     * @return String
     */
    public String getPid() {
        return pid;
    }

    /**
     * pid を設定します。
     *
     * @param String pid 
     */
    public void setPid(String pid) {
        this.pid = pid;
    }

    /**
     * serverId を戻します。
     * 
     * @return String
     */
    public String getServerId() {
        return serverId;
    }

    /**
     * serverId を設定します。
     *
     * @param String serverId 
     */
    public void setServerId(String serverId) {
        this.serverId = serverId;
    }

    /**
     * port を戻します。
     * 
     * @return String
     */
    public String getPort() {
        return port;
    }

    /**
     * port を設定します。
     *
     * @param String port 
     */
    public void setPort(String port) {
        this.port = port;
    }

    /**
     * databaseUrl を戻します。
     * 
     * @return String
     */
    public String getDatabaseUrl() {
        return databaseUrl;
    }

    /**
     * databaseUrl を設定します。
     *
     * @param String databaseUrl 
     */
    public void setDatabaseUrl(String databaseUrl) {
        this.databaseUrl = databaseUrl;
    }

    /**
     * useDatabaseUrl を戻します。
     * 
     * @return boolean
     */
    public boolean isUseDatabaseUrl() {
        return useDatabaseUrl;
    }

    /**
     * useDatabaseUrl を設定します。
     *
     * @param boolean useDatabaseUrl 
     */
    public void setUseDatabaseUrl(boolean useDatabaseUrl) {
        this.useDatabaseUrl = useDatabaseUrl;
    }

    /**
     * databaseTypeConnectionDestination を戻します。
     * 
     * @return DatabaseTypeConnectionDestination
     */
    public DatabaseTypeConnectionDestination getDatabaseTypeConnectionDestination() {
        return databaseTypeConnectionDestination;
    }

    /**
     * databaseTypeConnectionDestination を設定します。
     *
     * @param DatabaseTypeConnectionDestination databaseTypeConnectionDestination 
     */
    public void setDatabaseTypeConnectionDestination(
            DatabaseTypeConnectionDestination databaseTypeConnectionDestination) {
        this.databaseTypeConnectionDestination = databaseTypeConnectionDestination;
    }
    
    /**
     * databaseTypeConnectionDestination を設定します。
     *
     * @param String databaseTypeConnectionDestination 
     */
    public void setDatabaseTypeConnectionDestination(
            String databaseTypeConnectionDestination) {
        this.databaseTypeConnectionDestination = DatabaseTypeConnectionDestination.keyOf(databaseTypeConnectionDestination);
    }

	/**
	 * instanceName を戻します。
	 * 
	 * @return String
	 */
	public String getInstanceName() {
		return instanceName;
	}

	/**
	 * instanceName を設定します。
	 *
	 * @param String instanceName 
	 */
	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}

}
