/**
 * Copyright 2014 SystemEXE,Inc. All Rights Reserved.
 *
 */
package jp.co.systemexe.dbu.dbace.library.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

/**
 * Download utilities
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
public final class DownloadUtils {

	private static final Logger logger = LoggerFactory.getLogger(DownloadUtils.class);

	/**
	 * Download the specified file path
	 *
	 * @param response the HTTP response to write
	 * @param filePath the file path to download
	 *
	 * @return the HTTP status
	 */
	public static ResponseEntity<HttpStatus> downloadEntity(HttpServletResponse response, String filePath) {
		return downloadEntity(response, filePath, null);
	}
	/**
	 * Download the specified file path alias to the downloaded file name
	 *
	 * @param response the HTTP response to write
	 * @param filePath the file path to download
	 * @param downloadFileName the alias file name
	 *
	 * @return the HTTP status
	 */
	public static ResponseEntity<HttpStatus> downloadEntity(HttpServletResponse response, String filePath, String downloadFileName) {
		return new ResponseEntity<HttpStatus>(downloadStatus(response, filePath, downloadFileName));
	}
	/**
	 * Download the specified file path alias to the downloaded file name
	 *
	 * @param response the HTTP response to write
	 * @param filePath the file path to download
	 * @param downloadFileName the alias file name
	 *
	 * @return the HTTP status
	 */
	public static HttpStatus downloadStatus(HttpServletResponse response, String filePath, String downloadFileName) {
		InputStream is = null;
		OutputStream os = null;
		HttpStatus status = HttpStatus.NOT_FOUND;
		if (StringUtils.hasText(filePath) && response != null) {
			try {
				File downloadFile = new File(filePath);
				if (!downloadFile.exists() || downloadFile.isDirectory()) {
					status = HttpStatus.NOT_FOUND;
				}
				else {
					downloadFileName = (!org.springframework.util.StringUtils.hasText(downloadFileName)
							? downloadFile.getName() : downloadFileName);
					response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
					response.setHeader("Content-Disposition",
							"attachment;filename=\"" + URLEncoder.encode(downloadFileName, "UTF-8") + "\"");
					response.setHeader("Set-Cookie", "fileDownload=true; path=/");

					is = new FileInputStream(downloadFile);
				    os = response.getOutputStream();
				    byte[] buffer = new byte[1024];
				    int read = 0;
				    while ((read = is.read(buffer)) != -1) {
				    	os.write(buffer, 0, read);
				    }
				    status = HttpStatus.OK;
				}
			}
			catch(Exception e) {
				logger.error(e.getMessage(), e);
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
			finally {
				try {
					if (os != null) {
						os.flush();
						os.close();
					}
					if (is != null) {
						is.close();
					}
				}
				catch(Exception e) {}
			}
		}
		return status;
	}

	/**
	 * Download the specified file path
	 *
	 * @param response the HTTP response to write
	 * @param xlsWrkbook the workbook to download
	 *
	 * @return the HTTP status
	 */
	public static ResponseEntity<HttpStatus> downloadEntity(HttpServletResponse response, Workbook xlsWrkbook) {
		return downloadEntity(response, xlsWrkbook,  null);
	}
	/**
	 * Download the specified file path alias to the downloaded file name
	 *
	 * @param response the HTTP response to write
	 * @param xlsWrkbook the workbook to download
	 * @param downloadFileName the alias file name
	 *
	 * @return the HTTP status
	 */
	public static ResponseEntity<HttpStatus> downloadEntity(HttpServletResponse response, Workbook xlsWrkbook, String downloadFileName) {
		return new ResponseEntity<HttpStatus>(downloadStatus(response, xlsWrkbook, downloadFileName));
	}
	/**
	 * Download the specified workbook alias the downloaded file name
	 *
	 * @param response the HTTP response to write
	 * @param xlsWrkbook the workbook to download
	 * @param downloadFileName the alias file name
	 *
	 * @return the HTTP status
	 */
	public static HttpStatus downloadStatus(HttpServletResponse response, Workbook xlsWrkbook, String downloadFileName) {
		OutputStream os = null;
		HttpStatus status = HttpStatus.NOT_FOUND;
		if (xlsWrkbook != null && response != null) {
			try {
				downloadFileName = (!org.springframework.util.StringUtils.hasText(downloadFileName)
						? xlsWrkbook.getSheetName(0) : downloadFileName);
				response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
				response.setHeader("Content-Disposition",
						"attachment;filename=\"" + URLEncoder.encode(downloadFileName, "UTF-8") + "\"");
				response.setHeader("Set-Cookie", "fileDownload=true; path=/");

				os = response.getOutputStream();
				xlsWrkbook.write(os);
			    status = HttpStatus.OK;
			}
			catch(Exception e) {
				logger.error(e.getMessage(), e);
				status = HttpStatus.INTERNAL_SERVER_ERROR;
			}
			finally {
				try {
					if (os != null) {
						os.flush();
						os.close();
					}
				}
				catch(Exception e) {}
			}
		}
		return status;
	}
}
