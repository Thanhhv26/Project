/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.authentication;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * @author tu-lenh
 * @version 0.0.0
 */
public class LoginAuthenticationFilter extends UsernamePasswordAuthenticationFilter {
	/**
	 * SLF4J
	 */
	protected Logger logger = LoggerFactory.getLogger(this.getClass());

//	private String extraParameter = "licenseKey";
//	private String isShowLicenseKey = "isShowLicenseKey";
//    private String delimiter = "¬";

	/**
	 * @see UserProfileService
	 */
//	@Autowired
//	private UserProfileService userProfileService;

	 @Override
	   public Authentication attemptAuthentication(HttpServletRequest request,HttpServletResponse response) throws AuthenticationException {
//	      String licenseKey = request.getParameter("licenseKey");
	      //System.out.println("License Key is " + licenseKey);
//	      request.getSession().setAttribute("licenseKey", licenseKey);
	      return super.attemptAuthentication(request, response);
	  }

	 @Override
		protected String obtainUsername(HttpServletRequest request) {
			String username = request.getParameter(getUsernameParameter());
			String password = request.getParameter(getPasswordParameter());
			String isShowLicenseKey = request.getParameter("isShowLicenseKey");
			String licenseKey = request.getParameter("licenseKey");

//			request.getSession().setAttribute("username", username);
//			request.getSession().setAttribute("password", password);
//			request.getSession().setAttribute("licenseKey", extraInput);

//			String combinedUsername = username + getDelimiter() + password + getDelimiter() + extraInput;
	        String clientIpAddress= request.getRemoteAddr();
	        String serverName = request.getServerName();

	        String combinedUsername = username + "¬" + password + "¬" + isShowLicenseKey + "¬" + licenseKey + "¬" + clientIpAddress+ "¬" + serverName;

			//System.out.println("Combined username = " + combinedUsername);
			return combinedUsername;
		}

	/*
	 * (Non-Javadoc)
	 * @see org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter#successfulAuthentication(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, javax.servlet.FilterChain, org.springframework.security.core.Authentication)
	 */
	@Override
	protected void successfulAuthentication(HttpServletRequest request,
			HttpServletResponse response, FilterChain chain,
			Authentication authResult) throws IOException, ServletException {
		super.successfulAuthentication(request, response, chain, authResult);
		logger.debug("Notify message");
		// Broadcast to the online users
		//userProfileService.broadcastOnlineUsers();
	}

	/**
	 * @return The parameter name which will be used to obtain the extra input
	 *         from the login request
	 */
//	public String getExtraParameter() {
//		return this.extraParameter;
//	}
//
//	/**
//	 * @param extraParameter
//	 *            The parameter name which will be used to obtain the extra
//	 *            input from the login request
//	 */
//	public void setExtraParameter(String extraParameter) {
//		this.extraParameter = extraParameter;
//	}
//
//	/**
//	 * @return The delimiter string used to separate the username and extra
//	 *         input values in the string returned by
//	 *         <code>obtainUsername()</code>
//	 */
//	public String getDelimiter() {
//		return this.delimiter;
//	}
//
//	/**
//	 * @param delimiter
//	 *            The delimiter string used to separate the username and extra
//	 *            input values in the string returned by
//	 *            <code>obtainUsername()</code>
//	 */
//	public void setDelimiter(String delimiter) {
//		this.delimiter = delimiter;
//	}
}
