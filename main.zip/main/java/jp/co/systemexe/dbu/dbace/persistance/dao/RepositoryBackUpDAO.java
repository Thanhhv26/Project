/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * リポジトリファイル DAO。
 * <p>
 * リポジトリファイル内のデータではなく、リポジトリファイル自体に対して行うこと
 * のできる操作を公開します。</p>
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public interface RepositoryBackUpDAO {
	
    /**
     * リポジトリファイルのバックアップが可能かどうか調べます
     * 
     * @return
     */
	public boolean isPossibleBackUp();
	
    /**
     * リポジトリファイルのバックアップを行います。
     * 
     * @return
     * @throws DAOException 
     * @throws FileNotFoundException 
     * @throws UnsupportedEncodingException 
     */
    public void backUp() throws DAOException;

    /**
     * バックアップファイルのリストを取得します。。
     * 
     * @return
     */
    public List<String> getRepositoyBackUpFileNameList();

    /**
     * リポジトリファイルの削除を行います。
     * 
     * @param List<String> fileForDeletion 削除対象ファイルリスト
     * @return
     */
    public void delete(List<String> fileForDeletion);

}
