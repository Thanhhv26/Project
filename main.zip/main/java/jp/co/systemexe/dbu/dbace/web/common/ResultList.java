package jp.co.systemexe.dbu.dbace.web.common;

import java.util.List;

import lombok.Data;

import org.springframework.http.HttpStatus;

@Data
public class ResultList<T> {

	private List<T> data;
	private Message message;

	public ResultList() {}
	public ResultList(Message message, List<T> data) {
		this.setMessage(message);
		this.setData(data);
	}
	public ResultList(int code) {
		this(code, null, null, null);
	}
	public ResultList(int code, String detail, List<T> data) {
		this(code, null, detail, data);
	}
	public ResultList(int code, String detail) {
		this(code, null, detail, null);
	}
	public ResultList(int code, String title, String detail, List<T> data) {
		this.setMessage(new Message(code, title, detail));
		this.setData(data);
	}
	public ResultList(HttpStatus status) {
		this(status.value(), null, null, null);
	}
	public ResultList(HttpStatus status, String detail, List<T> data) {
		this(status.value(), null, detail, data);
	}
	public ResultList(HttpStatus status, String detail) {
		this(status.value(), null, detail, null);
	}
	public ResultList(HttpStatus status, String title, String detail, List<T> data) {
		this.setMessage(new Message(status.value(), title, detail));
		this.setData(data);
	}
}
