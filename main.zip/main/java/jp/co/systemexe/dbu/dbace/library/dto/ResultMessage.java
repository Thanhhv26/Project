/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.dto;

import lombok.Data;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
@Data
public class ResultMessage {
	private int code;
	private String message;

}

