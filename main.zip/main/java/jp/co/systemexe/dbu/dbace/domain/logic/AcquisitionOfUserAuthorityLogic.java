/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationUserDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.GeneralUserOperationAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 認証ユーザー情報の取得処理。
 * <p>
 * パスワードを含み、認証を伴うユーザー情報取得を行うビジネスロジックです。
 * アプリケーションログインのためのユーザーなど、ユーザー認証が必要な際に使用
 * します。</p>
 *
 * @author EXE 島田 雄一郎
 * @author EXE 六本木 圭
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class AcquisitionOfUserAuthorityLogic extends BaseApplicationDomainLogic {

    /**
     * ユーザー情報を取得し、認証を確認して戻す。
     *
     * @param connectDefinitionId 接続定義 ID
     * @param userId ユーザー ID
     * @param password パスワード
     * @return UserInfoDTO
     * @exception ApplicationDomainLogicException
     *     : アプリケーションドメインロジック例外
     */
    public UserInfoDTO getUserInfoDTO(final String userId, final String password)
            throws ApplicationDomainLogicException {
        final UserInfoDTO ret = new UserInfoDTO();
        final ApplicationUserDAO dao = createApplicationUserDAO();
        try {
            if (dao.certify(userId, password)) {
                final ApplicationUserDTO dto;
                try {
                    dto = dao.getApplicationUserDTO(userId);
                } catch (DAOException e) {
                    throw new ApplicationDomainLogicException(e.getMessage(), e);
                }
                ret.setId(dto.getUserId());
                ret.setName(dto.getUserLabel());
                ret.setUserAuthority(dto.getAuthority());

                boolean isApplicationAdministrator = false;
                final Map<String, Boolean> applicationAdministratorMap
                	= new HashMap<String, Boolean>();

                for (final ConnectDefinisionAuthority def
                		: dto.getAuthority().getConnectDefinisionAuthoritys()) {
                	boolean isConnectDefinisionOfApplicationAdministrator = false;
                	for (final GeneralUserOperationAuthority auth
                			: def.getOperationAuthority()) {
                		if (auth == GeneralUserOperationAuthority.CUSTOMIZE) {
                			isApplicationAdministrator = true;
                			isConnectDefinisionOfApplicationAdministrator = true;
                			break;
                		}
                	}
        			applicationAdministratorMap.put(
        					def.getConnectDefinisionId(),
        					isConnectDefinisionOfApplicationAdministrator);
                }

                ret.setApplicationAdministrator(isApplicationAdministrator);
                ret.setApplicationAdministratorMap(applicationAdministratorMap);

            } else {
            	ret.setId(userId);
				outputLoginAuditLog(ret, false);
            	// MI-E-0104=ログイン認証に失敗しました。ログインユーザーID、パスワードをご確認ください。
                throw new ApplicationDomainLogicException(MessageUtils.getMessage("MI-E-0104"));
            }
        } catch (final DAOException e) {
        	ret.setId(userId);
			outputLoginAuditLog(ret, false);
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return ret;
    }

	/**
	 * ログイン成否のログを出力します。
	 *
	 * @param isSuccess
	 */
	private void outputLoginAuditLog(
	        final UserInfoDTO dto,
	        final boolean isSuccess) {
	        final UserInfo userInfo = new UserInfo();
	        userInfo.setId(dto.getId());
	        OutputAuditLog.writeLoginLogoutLog(
        		AuditEventKind.LOGIN,
        		userInfo,
        		"",
        		isSuccess ? AuditStatus.success : AuditStatus.failure);
	}

    /**
     * パスワードの暗号化処理
     * <p>文字列を暗号化して返します。</p>
     *
     * @param String 対象文字列
     * @return String 暗号化文字列
     * @exception ApplicationDomainLogicException
     *     : アプリケーションドメインロジック例外
     */
    public String passwordEncryption(final String password)
            throws ApplicationDomainLogicException {
        try {
            final ApplicationUserDAO dao = createApplicationUserDAO();
            return new String(dao.getEncryptionPassword(password));
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * ユーザー ID の重複チェック
     * <p>
     * ユーザー ID の重複チェックを行い、結果を返します。
     * </p>
     *
     * @param userID ユーザー ID
     * @return Boolean 存在可否
     * @exception ApplicationDomainLogicException
     *     : アプリケーションドメインロジック例外
     */
    public Boolean isUserIDRepetition(final String userID)
    		throws ApplicationDomainLogicException {
        try {
            final ApplicationUserDAO dao = createApplicationUserDAO();
            final Map<String, String> userMap = dao.getUserNameMap();

            return userMap.containsKey(userID);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e);
        }
    }

    /**
     * AcquisitionOfUserAuthorityLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public AcquisitionOfUserAuthorityLogic() {
        return;
    }

    /**
     * アプリケーションユーザー DAO を生成して戻す。
     *
     * @return ApplicationUserDAO
     * @throws ApplicationDomainLogicException
     */
    private ApplicationUserDAO createApplicationUserDAO()
            throws ApplicationDomainLogicException {
        try {
            return (ApplicationUserDAO)createDAO("ApplicationUserDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
