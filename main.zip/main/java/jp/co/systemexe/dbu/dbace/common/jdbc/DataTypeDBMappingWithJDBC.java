package jp.co.systemexe.dbu.dbace.common.jdbc;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.domain.logic.definition.RelationOfJdbcAndHtml;

@SuppressWarnings("serial")
public enum DataTypeDBMappingWithJDBC {
//	/*SQLServer*/
//	SQLServer_INT("INT", 4),
//	SQLServer_VARCHAR("VARCHAR", 12),
//	SQLServer_DECIMAL("DECIMAL", 3),
//	SQLServer_FLOAT("FLOAT", 8),
//	SQLServer_MONEY("MONEY", 3),
//	SQLServer_DATE("DATE", 91),
//	SQLServer_TIME("TIME", 92),
//	SQLServer_DATETIME("DATETIME", 93),
//	SQLServer_SMALLDATETIME("SMALLDATETIME", 93),
//	SQLServer_CHAR("CHAR", 1),
//	SQLServer_TEXT("TEXT", -1),
//	SQLServer_BINARY("BINARY", -2),
//	SQLServer_BIGINT("BIGINT", -5),
//	SQLServer_BIT("BIT", -7),
//	SQLServer_NUMERIC("NUMERIC", 2),
//	SQLServer_REAL("REAL", 7),
//	SQLServer_SMALLMONEY("SMALLMONEY", 3),
//	SQLServer_DATETIME2("DATETIME2", 93),
//	SQLServer_DATETIMEOFFSET("DATETIMEOFFSET", 1111),
//	SQLServer_NCHAR("NCHAR", -15),
//	SQLServer_NVARCHAR("NVARCHAR", -9),
//	SQLServer_NTEXT("NTEXT", 1111),
//	SQLServer_VARBINARY("VARBINARY", -3),
//	SQLServer_IMAGE("IMAGE", -4),
//	/*MySQL*/
//	MySQL_VARCHAR("VARCHAR", 12),
//	MySQL_BIGINT("BIGINT", -5),
//	MySQL_LONGTEXT("LONGTEXT", -1),
//	MySQL_DATETIME("DATETIME", 93),
//	MySQL_INT("INT", 4),
//	MySQL_TINYINT("TINYINT", -6),
//	MySQL_DECIMAL("DECIMAL", 3),
//	MySQL_DOUBLE("DOUBLE", 8),
//	MySQL_BINARY("BINARY", -2),
//	MySQL_SMALLINT("SMALLINT", 5),
//	MySQL_MEDIUMINT("MEDIUMINT", 4),
//	MySQL_FLOAT("FLOAT", 7),
//	MySQL_CHAR("CHAR", 1),
//	MySQL_BIT("BIT", -7),
//	MySQL_DATE("DATE", 91),
//	MySQL_TIMESTAMP("TIMESTAMP", 93),
//	MySQL_TIME("TIME", 92),
//	MySQL_YEAR("YEAR", -6),
//	MySQL_VARBINARY("VARBINARY", -3),
//	MySQL_TINYBLOB("TINYBLOB", -3),
//	MySQL_TINYTEXT("TINYTEXT", -1),
//	MySQL_BLOB("BLOB", -4),
//	MySQL_TEXT("TEXT", -1),
//	MySQL_MEDIUMBLOB("MEDIUMBLOB", -4),
//	MySQL_MEDIUMTEXT("MEDIUMTEXT", -1),
//	MySQL_LONGBLOB("LONGBLOB", -4),
//	MySQL_SET("SET", 1),
//	MySQL_ENUM("ENUM", 1),
//	/*PostgreSQL*/
//	PostgreSQL__TEXT("_TEXT", 2003),
//	PostgreSQL_INET("INET", 1111),
//	PostgreSQL_BPCHAR("BPCHAR", 1),
//	PostgreSQL_TIMESTAMPTZ("TIMESTAMPTZ", 93),
//	PostgreSQL_XID("XID", 1111),
//	PostgreSQL_NAME("NAME", 12),
//	PostgreSQL_BYTEA("BYTEA", -2),
//	PostgreSQL_DATE("DATE", 91),
//	PostgreSQL_FLOAT8("FLOAT8", 8),
//	PostgreSQL_MONEY("MONEY", 8),
//	PostgreSQL_PG_NODE_TREE("PG_NODE_TREE", 1111),
//	PostgreSQL_FLOAT4("FLOAT4", 7),
//	PostgreSQL_TIMESTAMP("TIMESTAMP", 93),
//	PostgreSQL_TIME("TIME", 92),
//	PostgreSQL_INTERVAL("INTERVAL", 1111),
//	PostgreSQL_VARCHAR("VARCHAR", 12),
//	PostgreSQL_ABSTIME("ABSTIME", 1111),
//	PostgreSQL_INT8("INT8", -5),
//	PostgreSQL_TIMETZ("TIMETZ", 92),
//	PostgreSQL_INT2("INT2", 5),
//	PostgreSQL_BOOL("BOOL", -7),
//	PostgreSQL_INT4("INT4", 4),
//	PostgreSQL__INT2("_INT2", 2003),
//	PostgreSQL_OID("OID", -5),
//	PostgreSQL_PG_LSN("PG_LSN", 1111),
//	PostgreSQL_REGPROC("REGPROC", 1111),
//	PostgreSQL_NUMERIC("NUMERIC", 2),
//	PostgreSQL_TEXT("TEXT", 12),
	
//	PostgreSQL_SMALLSERIAL("SMALLSERIAL", 5), => //	PostgreSQL_INT2("INT2", 5),
//	PostgreSQL_SERIAL("SERIAL", 4),
//	PostgreSQL_BIGSERIAL("BIGSERIAL", -5),
	
//	/*Oracle*/
//	Oracle_NUMBER("NUMBER", 2),
//	Oracle_VARCHAR2("VARCHAR2", 12),
//	Oracle_CHAR("CHAR", 1),
//	Oracle_NCHAR("NCHAR", -15),
//	Oracle_NVARCHAR2("NVARCHAR2", -9),
//	Oracle_FLOAT("FLOAT", 2),
//	Oracle_LONG("LONG", -1),
//	Oracle_BINARY_FLOAT("BINARY_FLOAT", 1111),
//	Oracle_BINARY_DOUBLE("BINARY_DOUBLE", 1111),
//	Oracle_DATE("DATE", 93),
//	Oracle_TIMESTAMP("TIMESTAMP", 93),
//	Oracle_TIMESTAMPWITHTIMEZONE("TIMESTAMPWITHTIMEZONE", 1111),
//	Oracle_TIMESTAMPWITHLOCALTIMEZONE("TIMESTAMPWITHLOCALTIMEZONE", 1111),
//	Oracle_INTERVALDAYTOSECOND("INTERVALDAYTOSECOND", 1111),
//	Oracle_RAW("RAW", -3),
//	Oracle_ROWID("ROWID", 1111),
//	Oracle_UROWID("UROWID", 1111),
//	Oracle_CLOB("CLOB", 2005),
//	Oracle_NCLOB("NCLOB", 1111),
//	Oracle_BLOB("BLOB", 2004),
//	Oracle_BFILE("BFILE", 1111);
	
	/*
	 * S_ = SQLServer_
	 * M_ = MySQL_
	 * P_ = PostgreSQL_
	 * O_ = Oracle_
	 * */
	
	//BIT = -7	
	BIT(java.sql.Types.BIT, new ArrayList<String>(){{add("S_BIT"); add("M_BIT"); add("P_BOOL"); }}),
	//TINYINT = -6
	TINYINT(java.sql.Types.TINYINT, new ArrayList<String>(){{add("M_TINYINT"); add("M_YEAR"); }}),
	//SMALLINT = 5;
	SMALLINT(java.sql.Types.SMALLINT, new ArrayList<String>(){{add("M_SMALLINT"); add("P_INT2"); add("P_SMALLSERIAL"); }}),
	//INTEGER = 4;
	INTEGER(java.sql.Types.INTEGER, new ArrayList<String>(){{add("S_INT"); add("M_INT"); add("M_MEDIUMINT"); add("P_INT4"); add("P_SERIAL"); }}),
	//BIGINT = -5;
	BIGINT(java.sql.Types.BIGINT, new ArrayList<String>(){{add("S_BIGINT");  add("M_BIGINT"); add("P_INT8"); add("P_OID"); add("P_BIGSERIAL"); }}),
	//FLOAT = 6;
	FLOAT(java.sql.Types.FLOAT, new ArrayList<String>(){{}}),
	//REAL = 7;
	REAL(java.sql.Types.REAL, new ArrayList<String>(){{add("S_REAL");  add("M_FLOAT"); add("P_FLOAT4"); }}),
	//DOUBLE = 8;
	DOUBLE(java.sql.Types.DOUBLE, new ArrayList<String>(){{add("S_FLOAT"); add("M_DOUBLE"); add("P_FLOAT8"); add("P_MONEY"); }}),
	//NUMERIC = 2;
	NUMERIC(java.sql.Types.NUMERIC, new ArrayList<String>(){{add("S_NUMERIC"); add("P_NUMERIC"); add("O_NUMBER"); add("O_FLOAT"); }}),
	//DECIMAL = 3;
	DECIMAL(java.sql.Types.DECIMAL, new ArrayList<String>(){{add("S_DECIMAL"); add("S_MONEY"); add("S_SMALLMONEY"); add("M_DECIMAL"); }}),
	//CHAR = 1;
	CHAR(java.sql.Types.CHAR, new ArrayList<String>(){{add("S_CHAR");  add("M_CHAR"); add("M_SET"); add("M_ENUM"); add("P_BPCHAR"); add("O_CHAR"); }}),
	//VARCHAR = 12;
	VARCHAR(java.sql.Types.VARCHAR, new ArrayList<String>(){{add("S_VARCHAR");  add("M_VARCHAR"); add("P_NAME"); add("P_VARCHAR"); add("P_TEXT"); add("O_VARCHAR2"); }}),
	//LONGVARCHAR = -1;
	LONGVARCHAR(java.sql.Types.LONGVARCHAR, new ArrayList<String>(){{add("S_TEXT");  add("M_LONGTEXT"); add("M_TINYTEXT"); add("M_TEXT"); add("M_MEDIUMTEXT"); add("O_LONG"); }}),
	//DATE = 91;
	DATE(java.sql.Types.DATE, new ArrayList<String>(){{add("S_DATE");  add("M_DATE"); add("P_DATE"); }}),
	//TIME = 92;
	TIME(java.sql.Types.TIME, new ArrayList<String>(){{add("S_TIME");  add("M_TIME"); add("P_TIME"); add("P_TIMETZ"); }}),
	//TIMESTAMP = 93;
	TIMESTAMP(java.sql.Types.TIMESTAMP, new ArrayList<String>(){{add("S_DATETIME");  add("S_SMALLDATETIME"); 
	add("S_DATETIME2"); add("M_DATETIME"); add("M_TIMESTAMP"); add("P_TIMESTAMPTZ"); add("P_TIMESTAMP"); add("O_DATE"); add("O_TIMESTAMP"); }}),
	//BINARY = -2;
	BINARY(java.sql.Types.BINARY, new ArrayList<String>(){{add("S_BINARY");  add("M_BINARY"); add("P_BYTEA"); }}),
	//VARBINARY = -3;
	VARBINARY(java.sql.Types.VARBINARY, new ArrayList<String>(){{add("S_VARBINARY");  add("M_VARBINARY"); add("M_TINYBLOB"); add("O_RAW"); }}),
	//LONGVARBINARY = -4;
	LONGVARBINARY(java.sql.Types.LONGVARBINARY, new ArrayList<String>(){{add("S_IMAGE");  add("M_BLOB"); add("M_MEDIUMBLOB"); add("M_LONGBLOB"); }}),
	//NULL = 0;
	NULL(java.sql.Types.NULL, new ArrayList<String>(){{}}),
	//OTHER = 1111;
	OTHER(java.sql.Types.OTHER, new ArrayList<String>(){{add("S_DATETIMEOFFSET");  add("S_NTEXT"); add("P_INET"); add("P_XID"); add("P_PG_NODE_TREE"); 
	add("P_INTERVAL"); add("P_ABSTIME"); add("P_PG_LSN"); add("P_REGPROC"); add("O_BINARY_FLOAT"); add("O_BINARY_DOUBLE"); add("O_TIMESTAMPWITHTIMEZONE"); 
	add("O_TIMESTAMPWITHLOCALTIMEZONE"); add("O_INTERVALDAYTOSECOND"); add("O_ROWID"); add("O_UROWID"); add("O_NCLOB"); add("O_BFILE"); }}),
	//JAVA_OBJECT = 2000;
	JAVA_OBJECT(java.sql.Types.JAVA_OBJECT, new ArrayList<String>(){{}}),
	//DISTINCT = 2001;
	DISTINCT(java.sql.Types.DISTINCT, new ArrayList<String>(){{}}),
	//STRUCT = 2002;
	STRUCT(java.sql.Types.STRUCT, new ArrayList<String>(){{}}),
	//ARRAY = 2003;
	ARRAY(java.sql.Types.ARRAY, new ArrayList<String>(){{add("P_TEXT");  add("P_INT2"); }}),
	//BLOB = 2004;
	BLOB(java.sql.Types.BLOB, new ArrayList<String>(){{add("O_BLOB");  }}),
	//CLOB = 2005;
	CLOB(java.sql.Types.CLOB, new ArrayList<String>(){{add("O_CLOB");  }}),
	//REF = 2006;
	REF(java.sql.Types.REF, new ArrayList<String>(){{}}),
	//DATALINK = 70;
	DATALINK(java.sql.Types.DATALINK, new ArrayList<String>(){{}}),
	//BOOLEAN = 16;
	BOOLEAN(java.sql.Types.BOOLEAN, new ArrayList<String>(){{}}),
	//ROWID = -8;
	ROWID(java.sql.Types.ROWID, new ArrayList<String>(){{}}),
	//NCHAR = -15;
	NCHAR(java.sql.Types.NCHAR, new ArrayList<String>(){{add("S_NCHAR");  add("O_NCHAR"); }}),
	//NVARCHAR = -9;
	NVARCHAR(java.sql.Types.NVARCHAR, new ArrayList<String>(){{add("O_NVARCHAR2");  add("S_NVARCHAR"); }}),
	//LONGNVARCHAR = -16;
	LONGNVARCHAR(java.sql.Types.LONGNVARCHAR, new ArrayList<String>(){{}}),
	//NCLOB = 2011;
	NCLOB(java.sql.Types.NCLOB, new ArrayList<String>(){{}}),
	//SQLXML = 2009;
	SQLXML(java.sql.Types.SQLXML, new ArrayList<String>(){{}}),
	//REF_CURSOR = 2012;
	REF_CURSOR(java.sql.Types.REF_CURSOR, new ArrayList<String>(){{}}),
	//TIME_WITH_TIMEZONE = 2013;
	TIME_WITH_TIMEZONE(java.sql.Types.TIME_WITH_TIMEZONE, new ArrayList<String>(){{}}),
	//TIMESTAMP_WITH_TIMEZONE = 2014;
	TIMESTAMP_WITH_TIMEZONE(java.sql.Types.TIMESTAMP_WITH_TIMEZONE, new ArrayList<String>(){{}});
	
	/**
	 * 
	 */
	private final Integer dataType;
	
	/**
	 * 
	 */
	private final List<String> dataTypeDatabase;
	
	/**
     * @param databaseType => Oracle, PostgreSQL, MySQL, SQLServer
     * @param dataTypeDatabase =>text, ntext, integer, bool...
     * @return JDBCMetaDataType
     */
    public static DataTypeDBMappingWithJDBC getByDataTypeDatabase(String databaseType, String dataTypeDatabase) {
    	DataTypeDBMappingWithJDBC result = DataTypeDBMappingWithJDBC.OTHER;
    	databaseType = databaseType.substring(0, 1).toUpperCase() + "_";
    	dataTypeDatabase = dataTypeDatabase.replaceAll("(\\s+)|([(\\d+)]{3,})", "").toUpperCase();
    	String valueSearch = databaseType + dataTypeDatabase;
    	for(DataTypeDBMappingWithJDBC item : values()){
    		List<String> temp = item.getDataTypeDatabase();
    		if(temp.indexOf(valueSearch) != -1){
    			result = item;
    			break;
    		}
    	}
        return result;
    }
    

    /**
     * check dataType of column is correspond
     * result: true(isCorrespond)/false(not correspond)
     * @param datebaseType
     * @param dataType
     * @return
     */
    public static boolean isCorrespond(final String datebaseType, final String dataType) {
    	DataTypeDBMappingWithJDBC dataTypeWithJDBC = DataTypeDBMappingWithJDBC.getByDataTypeDatabase(datebaseType, dataType);
    	JDBCMetaDataType jdbc = JDBCMetaDataType.dataTypeOf(dataTypeWithJDBC.getDataType());
    	RelationOfJdbcAndHtml relation = RelationOfJdbcAndHtml.metaDataTypeOf(jdbc);
    	return relation.isCorrespond();
    }
    
    /**
     * check dataType of column is correspond
     * result: true(isCorrespond)/false(not correspond)
     * @param jdbc
     * @return
     */
    public static boolean isCorrespond(final JDBCMetaDataType jdbc) {
    	RelationOfJdbcAndHtml relation = RelationOfJdbcAndHtml.metaDataTypeOf(jdbc);
    	return relation.isCorrespond();
    }
	
	/**
	 * contructor
	 * @param dataType
	 * @param dataTypeDatabase
	 */
	private DataTypeDBMappingWithJDBC(final Integer dataType, final List<String> dataTypeDatabase){
		this.dataType = dataType;
		this.dataTypeDatabase = dataTypeDatabase;
	}

	/**
	 * @return
	 */
	public Integer getDataType() {
		return dataType;
	}

	/**
	 * @return
	 */
	public List<String> getDataTypeDatabase() {
		return dataTypeDatabase;
	}
}
