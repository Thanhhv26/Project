/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.util.DateUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseDbAccessApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.DAOFactory;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableOneRecordDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseOutputsToFileWithTableDataDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.DaoNameConverter;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;
import jp.co.systemexe.dbu.dbace.presentation.FileOutputTableData;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;

/**
 * テーブルデータをファイルに出力します。
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class OutputsToFileWithTableDataLogic extends BaseDbAccessApplicationDomainLogic {
	private FileOutputTableData fileOutputTableData;

	/**
	 *
	 * OutputsToFileWithTableDataLogic.java の生成。
	 *
	 */
	public OutputsToFileWithTableDataLogic(final FileOutputTableData fileOutputTableData) {
		super();
		this.fileOutputTableData = fileOutputTableData;
	}

	// /**
	// *
	// * @param connectDefinisionId
	// * @param tableFormId
	// * @return
	// */
	// private boolean isMultiTable(final String connectDefinisionId, final
	// String tableFormId) throws ApplicationDomainLogicException{
	// final TableNameListIsAcquiredFromRepositoryLogic logic = new
	// TableNameListIsAcquiredFromRepositoryLogic();
	// return logic.isMultiTable(connectDefinisionId, tableFormId);
	// }
	//
	// /**
	// * プルダウン用アイテムから、keyと一致する表示名を返します。
	// *
	// * @param items
	// * @param value
	// * @return
	// */
	// private String getSelectItem(final SelectableItem[] items, String key) {
	// if (items == null || items.length == 0) {
	// return "";
	// }
	//
	// for (SelectableItem item : items) {
	// if (item.getValue().equals(key)) {
	// return item.getLabel();
	// }
	// }
	// return "";
	// }
	//
	// /**
	// * プルダウン用アイテムから、keyと一致する表示名を返します。
	// *
	// * @param items
	// * @param value
	// * @return
	// */
	// private String getSelectItem(final SelectableItem[] items, String key,
	// boolean canDisplayNamePreview) {
	// if (items == null || items.length == 0) {
	// return "";
	// }
	//
	// for (SelectableItem item : items) {
	// if (!canDisplayNamePreview &&
	// item != null && key != null &&
	// item.getValue().trim().toLowerCase().equals(key.toLowerCase())) {
	// return item.getValue();
	// }else if (canDisplayNamePreview &&
	// item != null && key != null &&
	// item.getLabel().trim().toLowerCase().equals(key.toLowerCase())) {
	// return item.getLabel();
	// }
	// }
	// return key;
	// }

	/**
	 * テーブルデータのファイル出力を行います。
	 *
	 * <p>
	 * 指定されたファイル形式で、テーブルデータを出力します。
	 * </p>
	 *
	 * @param tableId
	 *            テーブル名
	 * @param def
	 *            項目表示定義 DTO
	 * @param dto
	 *            レコード検索結果 DTO
	 * @param outPutAllColumn
	 *            全てのカラムを出力するか否か
	 * @param filePath
	 *            ファイルを出力するパス
	 * @param userInfo
	 *            ログインユーザ情報
	 * @param outputStream
	 */
	public void outputFile(final String connectDefinisionId, final String tableId,
			final RecordSearchConditionDTO searchConditionDTO,
			final RecordEditorInformationDTO recordEditorInformationDTO, final boolean outPutAllColumn,
			final String filePath, final UserInfo userInfo) throws ApplicationDomainLogicException {
		boolean isRecordExist = false;

		final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		final DbConnectInfomationDTO connectInfomationDTO = recordEditorInformationDTO.getDbConnectInfomationDTO();
		final DatabaseTypeConnectionDestination dbType = connectInfomationDTO.getDatabaseTypeConnectionDestination();

		Map<String, SelectableItem[]> selectableMap = new HashMap<String, SelectableItem[]>();
		DatabaseTableOneRecordDAO searchDao = null;
		BaseOutputsToFileWithTableDataDAO outputDao = null;
		final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
		try {
			searchDao = createDatabaseTableOneRecordDAO(connectInfomationDTO.getDatabaseTypeConnectionDestination());
			searchDao.connect(connectInfomationDTO);
			searchDao.executeQuery(searchConditionDTO, recordEditorInformationDTO.getTableForm(),
					recordEditorInformationDTO.getTableDef());

			outputDao = (BaseOutputsToFileWithTableDataDAO) DAOFactory
					.createDAO(DaoNameConverter.getClassName(fileOutputTableData));
			outputDao.setOutputFilePath(filePath);

			final SortedMap<Integer, TableItemDTO> sortedColumnMap = createColumnIdMap(
					recordEditorInformationDTO.getTableForm().getTableItemMap(), outPutAllColumn);

			ColumnDisplayDefinitionDTO defDb = logic.getColumnsDisplay(connectDefinisionId, tableId,
					recordEditorInformationDTO, userInfo.getId());

			while (searchDao.hasNext()) {
				isRecordExist = true;

				final Map<String, String> map = searchDao.next();

				for (final String columnName : map.keySet()) {
					final TableItemDTO item = defDb.getItemDefinitions().get(columnName);
					if (item != null) {
						if (item.getHtmlElement() == DefinedHtmlElement.SELECT
								|| item.getHtmlElement() == DefinedHtmlElement.INPUT_RADIO) {

							if (!selectableMap.containsKey(item.getItemId())) {
								SelectableItem[] selectOneMenuItem = (SelectableItem[]) logic.getSelectableMap(
										columnName, map, recordEditorInformationDTO.getDbConnectInfomationDTO(), item);
								selectableMap.put(item.getItemId(), selectOneMenuItem);
								item.setSelectableItems(selectOneMenuItem);

								Collections.sort(Arrays.asList(selectOneMenuItem), new Comparator<SelectOneMenuItem>() {
									public int compare(SelectOneMenuItem b1, SelectOneMenuItem b2) {
										return b1.getValue().compareTo(b2.getValue());
									}
								});
							}

							if (StringUtils.isEmpty(map.get(columnName))) {
								map.put(columnName, "");
							} else {
								// map.put(columnName,
								// logic.getSelectItem(item.getSelectableItems(),
								// map.get(columnName),
								// item.canDisplayNamePreview()));

								String data = map.get(columnName);
								map.put(columnName, data);

								// if (item.canDisplayNamePreview()) {
								// map.put(columnName,
								// getSelectItem(item.getSelectableItems(),
								// map.get(columnName)));
								// } else {
								// String data = map.get(columnName);
								// map.put(columnName, data);
								// if(item.getSelectableItems() != null){
								// for (SelectableItem selectableItem :
								// item.getSelectableItems()) {
								// if(selectableItem.getValue().equals(data)){
								// map.put(columnName,
								// selectableItem.getLabel());
								// }
								// }
								// }
								// }
							}
						} else {
							// MOD DBエースOracle日付対応 ↓
							// columnLabel.put(
							// columnName,
							// map.get(columnName));
							final DefinedHtmlElement element = item.getHtmlElement();
							if (element == DefinedHtmlElement.INPUT_DATE || element == DefinedHtmlElement.INPUT_DATETIME
									|| element == DefinedHtmlElement.INPUT_TIMESTAMP
									|| element == DefinedHtmlElement.INPUT_TIME) {
								String valueDsp = DateUtils.formatDateToString(map.get(columnName), element);
								map.put(columnName, valueDsp);
							} else {
								map.put(columnName, map.get(columnName));
								// MOD DBエースOracle日付対応 ↑
							}
						}
					}
				}
				outputDao.outputFile(tableId, sortedColumnMap, map, dbType.getKey());
			}

			if (!isRecordExist) {
				// E4-007=検索結果が0件のためファイル出力が行えません
				throw new ApplicationDomainLogicException(MessageUtils.getMessage("E4-007"));
			}
			
			outputDao.write();
			// 機能 #14429 - Comment by van-thanh
//			outputDao.outputFile(tableId, sortedColumnMap, map); =>being checked outputDao.checkFileSize()
//			if (!outputDao.checkFileSize()) {
//				// MI-E-0147
//				final String message = MessageUtils.getMessage("MI-E-0147");
//				getLogger().error(message);
//				throw new DAOException(message);
//			}

			// 機能 #14429 - Comment by bao-anh
			/*
			 * if (count > SystemProperties.getSearchMaxRecordCount()) { //
			 * MI-E-0125=該当データ件数が多すぎます。条件を絞り込み再度検索してください。 throw new
			 * ApplicationDomainLogicException(
			 * MessageUtils.getMessage("MI-E-0125")); }
			 */

			OutputAuditLog.writeExcuteSearchLog(AuditEventKind.DOWNLOAD, userInfo,
					connectDefinitionListLogic.getConnectionByID(connectDefinisionId).getLabel(),
					connectDefinitionListLogic.getTableForm(connectDefinisionId, searchConditionDTO.getTableId())
							.getLabel(),
					AuditStatus.success, searchDao.getSearchCondition(),
					String.valueOf(outputDao.getOutputRecordCount()));
		} catch (final DAOException e) {
			OutputAuditLog
					.writeExcuteSearchLog(AuditEventKind.DOWNLOAD, userInfo,
							connectDefinitionListLogic.getConnectionByID(connectDefinisionId).getLabel(),
							connectDefinitionListLogic
									.getTableForm(connectDefinisionId, searchConditionDTO.getTableId()).getLabel(),
					AuditStatus.failure, searchDao.getSearchCondition(), "0");

			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} catch (final OutOfMemoryError e) {
			final String message = MessageUtils.getMessage("MI-E-0147");
			getLogger().error(message, e);

			OutputAuditLog
					.writeExcuteSearchLog(AuditEventKind.DOWNLOAD, userInfo,
							connectDefinitionListLogic.getConnectionByID(connectDefinisionId).getLabel(),
							connectDefinitionListLogic
									.getTableForm(connectDefinisionId, searchConditionDTO.getTableId()).getLabel(),
					AuditStatus.failure, searchDao.getSearchCondition(), "0");

			throw new ApplicationDomainLogicException(message, e);
		} finally {
			if (searchDao != null) {
				searchDao.close();
			}

			if (outputDao != null) {
				outputDao.close();
			}
		}
	}

	/**
	 * カラム表示順でソートされたテーブル項目情報DTOを返します。
	 *
	 * @param columnIdMap
	 * @return
	 */
	private SortedMap<Integer, TableItemDTO> createColumnIdMap(final Map<String, TableItemDTO> columnIdMap,
			final boolean outPutAllColumn) {
		final SortedMap<Integer, TableItemDTO> ret = new TreeMap<Integer, TableItemDTO>();

		for (final String columnId : columnIdMap.keySet()) {
			final TableItemDTO item = columnIdMap.get(columnId);
			if (item.isRoot() && (item.canPreview() || outPutAllColumn)) {
				ret.put(item.getSortIndex(), item);
			}
		}

		return ret;
	}
}
