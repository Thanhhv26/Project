/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.text.SimpleDateFormat;
import java.util.Date;

import jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.DbConnectInfomationDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ConnectDefinisionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.DbConnectDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 接続定義情報の取得処理。
 * <p>
 * 接続定義情報の編集のため、リポジトリから接続定義情報を取得します。</p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class AcquisitionOfConnectDefinitionLogic
        extends BaseApplicationDomainLogic {

    /**
     * 接続定義ラベルを戻す。
     * <p>
     * 画面への表示のために、接続定義ラベル（仮名）を取得して戻します。</p>
     *
     * @param connectDefinitionId
     * @return 接続定義ラベル
     * @throws ApplicationDomainLogicException
     */
    public String getConnectDefinitionLabel(final String connectDefinitionId)
            throws ApplicationDomainLogicException {
        final ConnectDefinisionDAO defDao = createConnectDefinisionDAO();
        final ConnectDefinisionDTO def;
        try {
            def = defDao.getConnectDefinisionDTO(connectDefinitionId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return def.getConnectDefinisionLabel();
    }

    /**
     * 接続定義ラベルを戻す。
     * <p>
     * 画面への表示のために、接続定義ラベル（仮名）を取得して戻します。</p>
     *
     * @param connectDefinitionLabel
     * @return 接続定義ラベル
     * @throws ApplicationDomainLogicException
     */
    public String getConnectDefinitionId(final String connectDefinitionId)
            throws ApplicationDomainLogicException {
        final ConnectDefinisionDAO defDao = createConnectDefinisionDAO();
        final ConnectDefinisionDTO def;
        try {
            def = defDao.getConnectDefinisionDTOByLable(connectDefinitionId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return def.getConnectDefinisionId();
    }

    /**
     * 新しい接続定義 ID を生成して戻します。
     *
     * @return 接続定義 ID
     */
    public String generateConnectDefinitionId() {
        final SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmssZ");
        return sdf.format(new Date());
    }

    /**
     * データベース接続定義情報 DTO を取得します。
     * <p>
     * </p>
     *
     * @param connectDefinitionId 接続定義情報 ID
     * @return
     * @exception ApplicationDomainLogicException
     */
    public DbConnectDefinitionDTO getConnectDefinitionDTO(
            final String connectDefinitionId)
            throws ApplicationDomainLogicException {

        final DbConnectDefinitionDTO ret = new DbConnectDefinitionDTO();

        final ConnectDefinisionDAO defDao = createConnectDefinisionDAO();
        final ConnectDefinisionDTO def;
        try {
            def = defDao.getConnectDefinisionDTO(connectDefinitionId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

        ret.setConnectDefinitionId(connectDefinitionId);
        ret.setConnectDefinitionName(def.getConnectDefinisionLabel());

        final DbConnectInfomationDAO dbDao = createDbConnectInfomationDAO();
        final DbConnectInfomationDTO info;
        try {
            info = dbDao.getDbConnectInfomationDTO(connectDefinitionId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        ret.setServerId(info.getServerId());
        ret.setPort(info.getPortId());
        ret.setDatabaseId(info.getDatabaseId());
        ret.setPid(info.getUserId());
        ret.setPassword(info.getPassword());
        ret.setDatabaseTypeConnectionDestination(info.getDatabaseTypeConnectionDestination());
        ret.setUseDatabaseUrl(info.isUseDatabaseUrl());
        ret.setDatabaseUrl(info.getDatabaseUrl());
        ret.setInstanceName(info.getInstanceName());

        return ret;
    }

    /**
     * データベース接続定義情報 DTO を取得します。
     * <p>
     * </p>
     *
     * @param connectDefinitionId 接続定義情報 ID
     * @return
     * @exception ApplicationDomainLogicException
     */
    public DbConnectDefinitionDTO getConnectDefinitionDTOByLabel(
            final String connectDefinitionId)
            throws ApplicationDomainLogicException {

        final DbConnectDefinitionDTO ret = new DbConnectDefinitionDTO();

        final ConnectDefinisionDAO defDao = createConnectDefinisionDAO();
        final ConnectDefinisionDTO def;
        try {
            def = defDao.getConnectDefinisionDTOByLable(connectDefinitionId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

        ret.setConnectDefinitionId(def.getConnectDefinisionId());
        ret.setConnectDefinitionName(def.getConnectDefinisionLabel());

        final DbConnectInfomationDAO dbDao = createDbConnectInfomationDAO();
        final DbConnectInfomationDTO info;
        try {
            info = dbDao.getDbConnectInfomationLableDTO(connectDefinitionId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        ret.setServerId(info.getServerId());
        ret.setPort(info.getPortId());
        ret.setDatabaseId(info.getDatabaseId());
        ret.setPid(info.getUserId());
        ret.setPassword(info.getPassword());
        ret.setDatabaseTypeConnectionDestination(info.getDatabaseTypeConnectionDestination());
        ret.setUseDatabaseUrl(info.isUseDatabaseUrl());
        ret.setDatabaseUrl(info.getDatabaseUrl());
        ret.setInstanceName(info.getInstanceName());

        return ret;
    }

    /**
     * AcquisitionOfConnectDefinitionLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public AcquisitionOfConnectDefinitionLogic() {
        return;
    }

    /**
     * 接続定義情報 DAO を生成して戻す。
     *
     * @return ConnectDefinisionDAO
     * @throws ApplicationDomainLogicException
     */
    private ConnectDefinisionDAO createConnectDefinisionDAO()
            throws ApplicationDomainLogicException {
        try {
            return (ConnectDefinisionDAO)createDAO("ConnectDefinisionDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * データベースの接続情報 DAO を生成して戻す。
     *
     * @return DbConnectInfomationDAO
     * @throws ApplicationDomainLogicException
     */
    private DbConnectInfomationDAO createDbConnectInfomationDAO()
            throws ApplicationDomainLogicException {
        try {
            return (DbConnectInfomationDAO)createDAO("DbConnectInfomationDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
