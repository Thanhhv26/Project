/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;

import lombok.Data;

/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationScreenForDeleteDTO {
	//relation,multi-table
	private String tableDeleteUseCase;
	private String connectDefinitionId;
	private String tableFormId;
	private String relationId;
	private String relationLabel;
	private String tableFormIdTypeMultiTable;
	private String tableFormLabelTypeMultiTable;
}