/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.io.Serializable;
import java.util.Map;
import java.util.SortedMap;

/**
 * レコード検索結果 DTO。
 * <p>
 * データベース内のレコード検索結果を保持する DTO です。</p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class RecordSearchResultDTO implements Serializable  {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = -4870911276383977702L;
    
    /**
     * レコード取得件数 を保持します
     */
    private int resultRowCount;

    /**
     * レコード検索結果 を保持します
     * <p>
     * SortedMap&lt;並び順, Map&lt;カラム ID, 値&gt;&gt;
     * </p>
     */
    private SortedMap<Integer, Map<String, String>> recordSearchResult;
    
    /**
     * 検索時に使用した、WHERE句(where抜き)を保持します。
     */
    private String searchCondition;

    /**
     * recordSearchResult を戻します。
     * 
     * @return SortedMap<Integer,Map<String,String>>
     */
    public SortedMap<Integer, Map<String, String>> getRecordSearchResult() {
        return recordSearchResult;
    }

    /**
     * recordSearchResult を設定します。
     *
     * @param SortedMap<Integer,Map<String,String>> recordSearchResult 
     */
    public void setRecordSearchResult(
            SortedMap<Integer, Map<String, String>> recordSearchResult) {
        this.recordSearchResult = recordSearchResult;
    }

    /**
     * resultRowCount を戻します。
     * 
     * @return int
     */
    public int getResultRowCount() {
        return resultRowCount;
    }

    /**
     * resultRowCount を設定します。
     *
     * @param int resultRowCount 
     */
    public void setResultRowCount(int resultRowCount) {
        this.resultRowCount = resultRowCount;
    }

	/**
	 * searchCondition を戻します。
	 * 
	 * @return String
	 */
	public String getSearchCondition() {
		return searchCondition;
	}

	/**
	 * searchCondition を設定します。
	 *
	 * @param String searchCondition 
	 */
	public void setSearchCondition(String searchCondition) {
		this.searchCondition = searchCondition;
	}
}
