/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class GetTableDependenceDatabaseDTO {
	// 接続定義Idの選択
	String connectDefinitionId;
	// テーブルId
	String tableId;
	// テーブル名 + Connection
	String tableConnectLabel;
}
