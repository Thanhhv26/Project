package jp.co.systemexe.dbu.dbace.library.service.certification;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.stereotype.Service;

import jp.co.systemexe.dbu.dbace.library.service.AbstractService;

/**
 * {@link ModuleDto} service
 *
 * @author long-hai
 */
@Service
public class ModuleServiceImpl extends AbstractService implements ModuleService {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.service.ModuleService#hasPermission(java.lang.String, java.lang.String[], boolean)
	 */
	@Override
	public boolean hasPermission(String userName, String[] moduleCds, boolean writable) {
		List<String> modules = new ArrayList<String>();
		if (!ArrayUtils.isEmpty(moduleCds))
			modules.addAll(Arrays.asList(moduleCds));
		//		return moduleDao.hasPermission(userName, modules, writable);
		return true;
	}

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.service.ModuleService#checkWritable(java.lang.String, java.util.List)
	 */
	@Override
	public List<String> checkWritable(String userName, List<String> moduleCds) {
		//		return moduleDao.checkWritable(userName, moduleCds);
		return null;
	}

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.service.ModuleService#checkReadable(java.lang.String, java.util.List)
	 */
	@Override
	public List<String> checkReadable(String userName, List<String> moduleCds) {
		//		return moduleDao.checkReadable(userName, moduleCds);
		return null;
	}

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.service.ModuleService#getModuleCss(java.util.List)
	 */
	@Override
	public List<String> getModuleCss(List<String> moduleCds) {
		//		return moduleDao.getModuleCss(moduleCds);
		return null;
	}

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.service.ModuleService#hasPermissionOnRequest(java.lang.String, java.lang.String[], java.lang.String, boolean)
	 */
	@Override
	public boolean hasPermissionOnRequest(String userName, String[] moduleCds, String requestURI, boolean writable) {
		List<String> modules = new ArrayList<String>();
		if (!ArrayUtils.isEmpty(moduleCds))
			modules.addAll(Arrays.asList(moduleCds));
		//		return moduleDao.hasPermissionOnRequest(userName, modules, requestURI, writable);
		return true;
	}

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.service.ModuleService#isEnabled(java.lang.String[])
	 */
	@Override
	public boolean isEnabled(String[] moduleCds) {
		List<String> modules = new ArrayList<String>();
		if (!ArrayUtils.isEmpty(moduleCds))
			modules.addAll(Arrays.asList(moduleCds));
		//		return moduleDao.isEnabled(modules);
		return true;
	}

	/*
	 * (Non-Javadoc)
	 * @see vn.co.exex.isev.common.service.ModuleService#isEnabledOnRequest(java.lang.String[], java.lang.String)
	 */
	@Override
	public boolean isEnabledOnRequest(String[] moduleCds, String requestURI) {
		List<String> modules = new ArrayList<String>();
		if (!ArrayUtils.isEmpty(moduleCds))
			modules.addAll(Arrays.asList(moduleCds));
		//		return moduleDao.isEnabledOnRequest(modules, requestURI);
		return true;
	}
}
