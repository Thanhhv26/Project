/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.jdbc.DataTypeDBMappingWithJDBC;
import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseDbAccessApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.DbConnectDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.definition.RelationOfJdbcAndHtml;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.ItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.ItemMulti;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Table;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm.Relations;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Tables;
import jp.co.systemexe.dbu.dbace.web.common.AppConst;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationInformation;
import jp.co.systemexe.dbu.dbace.web.repository.dto.ChangeColumnInfoDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.ColumnChangeInfoDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.DeleteInfoDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.RelationAndScreenInfoDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.RelationScreenDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.RelationScreenForDeleteDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.RelationTableItemDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SelectTablesRegister;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SynchrInfoDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.TrDTO;
import jp.co.systemexe.dbu.dbace.web.repository.model.ChangeColumnItem;
import jp.co.systemexe.dbu.dbace.web.repository.model.ColumnChangePresence;

/**
 * リポジトリへのテーブル新規登録ロジック。
 * <p>
 * アプリケーションリポジトリに対し、メンテナンス対象テーブルを新規登録します。
 * </p><p>
 * その際に各カラムに対し、アプリケーション画面上での動作定義（テーブルフォーム
 * 情報）を初期設定します。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class TableRegistrationToRepositoryLogic
        extends BaseDbAccessApplicationDomainLogic {

    /**
     * テーブルの同期処理を行います。
     * <p>
     * アプリケーションリポジトリに登録されているテーブル情報と、
     * DBのテーブル情報の同期処理を行います。。
     * </p><p>
     * 同期の際にリポジトリ情報より、カラムの設定情報をコピーします。
     * </p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableId テーブル ID
     * @param tableName テーブル仮名
     * @param connectionUserLabel 接続ユーザー表示名
     * @throws ApplicationDomainLogicException
     */
    public void syncrozieTable(
    		final String connectDefinitionId,
            final String tableId,
            final String tableName,
            final List<ChangeColumnItem> changeColumnItems,
            final String connectionUserLabel)
            throws ApplicationDomainLogicException {
        final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		final RecordEditorInformationDTO recordEditorInformationDTO = logic.getRecordEditorInformation(connectDefinitionId, tableId, connectionUserLabel);

        final TableFormDTO dto = new TableFormDTO();
        dto.setTableFormId(tableId);
        dto.setTableFormLabel(tableName);
        dto.getSortConditionMap().putAll(recordEditorInformationDTO.getTableForm().getSortConditionMap());

        for (final ChangeColumnItem item : changeColumnItems) {
        	final TableItemDTO tableItemDTO;
        	if (item.getChangePresence() == ColumnChangePresence.no_change) {
        		tableItemDTO = recordEditorInformationDTO.getTableForm().getTableItemMap().get(item.getColumnId());
        	} else if (item.getChangePresence() == ColumnChangePresence.update) {
        		tableItemDTO = recordEditorInformationDTO.getTableForm().getTableItemMap().get(item.getColumnId());//item at xml
        		DefinitionOfColumn defCol = recordEditorInformationDTO.getTableDef().getDefinitionOfColumnMap().get(item.getColumnId());//item at database
    			//DBの項目の型変更
    			String columnTypeNameDB = defCol.getColumnTypeName();
    			String dataTypeXML = tableItemDTO.getDataType();
    			//dataUnit
    			String dataUnitDb = defCol.getDataUnit();
    			String dataUnitXml = tableItemDTO.getDataUnit();
    			//サイズ
    			String dataLengthDb = makeSizeColumnTypeLabel(defCol);
    			String dataLength = tableItemDTO.getDataLength();

    			if ((!columnTypeNameDB.equalsIgnoreCase(dataTypeXML))
    					|| ((dataUnitDb != null || dataUnitXml != null) && (dataUnitDb!=null &&!dataUnitDb.equalsIgnoreCase(dataUnitXml)))
    					||(!dataLengthDb.equals(dataLength))) {
    				tableItemDTO.setDataType(columnTypeNameDB);
    				tableItemDTO.setDataLength(dataLengthDb);
    				tableItemDTO.setDataUnit(defCol.getDataUnit());
    				tableItemDTO.setExplanation(StringUtils.isEmpty(defCol.getRemarks()) ? "" : defCol.getRemarks());
    				if(!DataTypeDBMappingWithJDBC.isCorrespond(defCol.getJDBCMetaDataType())){//未対応
    					tableItemDTO.setHtmlElement(DefinedHtmlElement.SPAN);
    					tableItemDTO.setExplanation(MessageUtils.getMessageNotMessageId("MI-E-0108"));
    					tableItemDTO.setPreview(false);//一覧に表示するか
    					tableItemDTO.setDisplayRecordEdit(false);//登録・更新時に表示するか
    					tableItemDTO.setDisplayNamePreview(false);//表示置き換えするかどうか
    					tableItemDTO.setEditing(false);//更新可能か
    					tableItemDTO.setUpdateKey(false);//更新キーか
    					tableItemDTO.setSelectKey(false);//検索キーか
    				}
    			}
    			//DBの項目にPK追加
    			boolean isPrimaryKeyDb = defCol.isPrimaryKey();
    			boolean isPrimaryKeyXml = tableItemDTO.getPrimaryKey();
    			if (isPrimaryKeyDb == true && isPrimaryKeyDb != isPrimaryKeyXml) {
    				tableItemDTO.setPrimaryKey(isPrimaryKeyDb);
    				tableItemDTO.setUpdateKey(true);
    				tableItemDTO.setSelectKey(true);
    			}
    			//DBの項目にPK削除
    			if (isPrimaryKeyDb == false && isPrimaryKeyXml == true) {
    				tableItemDTO.setPrimaryKey(false);
//    				tableItemDTO.setUpdateKey(true);
//    				tableItemDTO.setSelectKey(true);
    			}
        	 } else if (item.getChangePresence() == ColumnChangePresence.add) {
                tableItemDTO = createTableItemDTO(
                		recordEditorInformationDTO.getTableDef()
                			.getDefinitionOfColumnMap().get(item.getColumnId()),
                			SystemProperties.getPreviewColumnCount(),
                        item.getSortIndex());

    			tableItemDTO.setItemLabel(item.getColumnLabel());
        		if (!StringUtils.isEmpty(item.getCopyColumnId())) {
        			final TableItemDTO buff = recordEditorInformationDTO.getTableForm()
						.getTableItemMap().get(item.getCopyColumnId());
        			tableItemDTO.setHtmlElement(buff.getHtmlElement());
        			tableItemDTO.getItemRestrictions().putAll(buff.getItemRestrictions());
        			tableItemDTO.setDefaultValue(buff.getDefaultValue());
        			tableItemDTO.setExplanation(buff.getExplanation());
        			tableItemDTO.setPreview(buff.canPreview());
        			tableItemDTO.setEditing(buff.canEditing());
        			tableItemDTO.setSelectKey(buff.isSelectKey());
        			tableItemDTO.setSelectableItems(buff.getSelectableItems());
        			tableItemDTO.setSqlString(buff.getSqlString());
        		}
        	} else if (item.getChangePresence() == ColumnChangePresence.delete) {
        		final String columnid = item.getColumnId();
        		final List<Integer> dellist = new ArrayList<Integer>();

        		if (dto.getSortConditionMap().containsValue(columnid)){
        			for(final Map.Entry<Integer, String> entry: dto.getSortConditionMap().entrySet()){
        				if (entry.getValue().equals(columnid) ){
        					dellist.add(entry.getKey());
        				}
        			}
        		    for(final Integer delval : dellist){
        		    	dto.getSortConditionMap().remove(delval);
        		    }
        		}
        		continue;
        	} else {
        		continue;
        	}
        	tableItemDTO.setItemLabel(item.getColumnLabel());
            dto.getTableItemMap().put(item.getColumnId(), tableItemDTO);
        }

        final TableFormDAO dao = createTableFormDAO();
        try {
            dao.save(connectDefinitionId, dto);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
	 * @param deleteInfoDTO
	 */
	public void deleteRelationAndMultiTable(DeleteInfoDTO deleteInfoDTO) throws ApplicationDomainLogicException{
		List<RelationScreenForDeleteDTO> relationScreens = deleteInfoDTO.getRelationScreens();
		for (RelationScreenForDeleteDTO relationScreen : relationScreens) {
			//relation
			if("relation".equals(relationScreen.getTableDeleteUseCase())){
				//delete : relation
				delRelationUseTable(relationScreen);
			}
			//multi-table
			if(AppConst.MULTI_TABLE.equals(relationScreen.getTableDeleteUseCase())){
				//delete : multi-table
				delMultiTableUseTable(relationScreen);
			}
		}
	}

	/**
	 * @param relationScreen
	 */
	private void delMultiTableUseTable(RelationScreenForDeleteDTO relationScreen) {
		String tableFormIdTypeMultiTable = relationScreen.getTableFormIdTypeMultiTable();
	   	final DeletionProcessingOfTableFromRepositoryLogic logic = new DeletionProcessingOfTableFromRepositoryLogic();
	   	String connectDefinisionId = relationScreen.getConnectDefinitionId();
        try {
			logic.delete(connectDefinisionId,tableFormIdTypeMultiTable);
		} catch (ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
	}

	/**
	 * @param relationScreen
	 */
	private void delRelationUseTable(RelationScreenForDeleteDTO relationScreen) {
		String relationId = relationScreen.getRelationId();
    	final PreservationOfAppRelationLogic logicRelation = new PreservationOfAppRelationLogic();
		try {
			logicRelation.remove(relationId);
		} catch (ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
	}

	/**
	 * @param synchrInfoDTO
	 */
	public void synchrMultiTable(SynchrInfoDTO synchrInfoDTO) throws ApplicationDomainLogicException{
		List<RelationScreenDTO> relationScreens = synchrInfoDTO.getRelationScreens();
		for (RelationScreenDTO relationScreen : relationScreens) {
			//DELETE_COLUMN_USE_RELATION_SCREEN
			if("DELETE_COLUMN_USE_RELATION_SCREEN".equals(relationScreen.getColumnChangeUseCase())){
				//delete : relation,tableForm type="multi-table"
				delRelationMultiTableDelColUseRelScreen(relationScreen);
			}
			//DELETE_COLUMN_USE_ITEM_COLS
			if("DELETE_COLUMN_USE_ITEM_COLS".equals(relationScreen.getColumnChangeUseCase())){
				//update : enable = false
				updateMultiTableDelColUseItemCols(relationScreen);
			}
			//COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM
			if("COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM".equals(relationScreen.getColumnChangeUseCase())){
				//DataType、DataLength、DataUnitを変更
				updateMultiTableColTypeChangeUseItem(relationScreen);
			}
			//COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM
			if("COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM".equals(relationScreen.getColumnChangeUseCase())){
				//tablesの中の該当テーブルのPrimaryKey、isUpdateKey、isSelectKeyをtrueに変更
				updateMultiTableColAddPkUseItem(relationScreen);
			}
			//COLUMN_DELETE_PK_USE_TABLES_TABLE_ITEM
			if("COLUMN_DELETE_PK_USE_TABLES_TABLE_ITEM".equals(relationScreen.getColumnChangeUseCase())){
				//tablesの中の該当テーブルのPrimaryKey、isUpdateKey、isSelectKeyをtrueに変更
				updateMultiTableColDeletePkUseItem(relationScreen);
			}
		}
	}

    /**
     * @param relationScreen
     */
    private void delRelationMultiTableDelColUseRelScreen(RelationScreenDTO relationScreen) {
    	//delete : relation
    	String relationId = relationScreen.getRelationAndScreenInfoDTO().getRelationId();
    	final PreservationOfAppRelationLogic logicRelation = new PreservationOfAppRelationLogic();
		try {
			logicRelation.remove(relationId);
		} catch (ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
    	//delete : tableForm type="multi-table"
    	String tableFormIdTypeMultiTable = relationScreen.getRelationAndScreenInfoDTO().getTableFormIdTypeMultiTable();
    	 final DeletionProcessingOfTableFromRepositoryLogic logic = new DeletionProcessingOfTableFromRepositoryLogic();
    	 String connectDefinisionId = relationScreen.getRelationAndScreenInfoDTO().getConnectDefinisionId();
         try {
			logic.delete(connectDefinisionId,tableFormIdTypeMultiTable);
		} catch (ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
	}

	/**
     * @param relationScreen
     */
    private void updateMultiTableColAddPkUseItem(RelationScreenDTO relationScreen) {
    	String connectDefinisionId = relationScreen.getRelationAndScreenInfoDTO().getConnectDefinisionId();
    	String tableFormId = relationScreen.getTableFormId();
		if (tableFormId != null) {
	    	AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
			try {
				TableFormDAO tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
				TableFormDto dto = new TableFormDto();
				dto.setId(relationScreen.getRelationAndScreenInfoDTO().getTableFormIdTypeMultiTable());
				TableForm tableForm = null;
				try {
					tableForm = tableFormDAO.getTargetTableFormMulti(connectDefinisionId, dto);
			        //tables
			        Tables tables = tableForm.getTables();
		            for (final Table tab : tables.getTable()) {
		            	if (tab.getId().equals(tableFormId)){
		            		for (final ItemMulti ite : tab.getItem()) {
		            			if (ite.getId().equals(relationScreen.getItemId())){
		            				ite.setPrimaryKey(true);
		            				ite.setUpdateKey(true);
		            				ite.setSelectKey(true);
		            			}
		            		}
		            	}
		            }
					TableFormDto tableFormDto = new TableFormDto(tableForm);
					tableFormDAO.saveTableMulti(connectDefinisionId, tableFormDto);
				} catch (DAOException e) {
					getLogger().error(e.getMessage());
				}
			} catch (ApplicationDomainLogicException e) {
				getLogger().error(e.getMessage());
			}
    	}
	}

    /**
     * @param relationScreen
     */
    private void updateMultiTableColDeletePkUseItem(RelationScreenDTO relationScreen) {
    	String connectDefinisionId = relationScreen.getRelationAndScreenInfoDTO().getConnectDefinisionId();
    	String tableFormId = relationScreen.getTableFormId();
		if (tableFormId != null) {
	    	AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
			try {
				TableFormDAO tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
				TableFormDto dto = new TableFormDto();
				dto.setId(relationScreen.getRelationAndScreenInfoDTO().getTableFormIdTypeMultiTable());
				TableForm tableForm = null;
				try {
					tableForm = tableFormDAO.getTargetTableFormMulti(connectDefinisionId, dto);
			        //tables
			        Tables tables = tableForm.getTables();
		            for (final Table tab : tables.getTable()) {
		            	if (tab.getId().equals(tableFormId)){
		            		for (final ItemMulti ite : tab.getItem()) {
		            			if (ite.getId().equals(relationScreen.getItemId())){
		            				ite.setPrimaryKey(false);
//		            				ite.setUpdateKey(true);
//		            				ite.setSelectKey(true);
		            			}
		            		}
		            	}
		            }
					TableFormDto tableFormDto = new TableFormDto(tableForm);
					tableFormDAO.saveTableMulti(connectDefinisionId, tableFormDto);
				} catch (DAOException e) {
					getLogger().error(e.getMessage());
				}
			} catch (ApplicationDomainLogicException e) {
				getLogger().error(e.getMessage());
			}
    	}
	}

	/**
     * @param relationScreen
     */
    private void updateMultiTableColTypeChangeUseItem(RelationScreenDTO relationScreen) {
    	String connectDefinisionId = relationScreen.getRelationAndScreenInfoDTO().getConnectDefinisionId();
    	String tableFormIdTypeMultiTable = relationScreen.getRelationAndScreenInfoDTO().getTableFormIdTypeMultiTable();
    	String itemContainCols = relationScreen.getRelationAndScreenInfoDTO().getItemContainCols();
		if (tableFormIdTypeMultiTable != null) {
	    	AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
			try {
				TableFormDAO tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
				TableFormDto dto = new TableFormDto();
				dto.setId(tableFormIdTypeMultiTable);
				TableForm tableForm = null;
				try {
					tableForm = tableFormDAO.getTargetTableFormMulti(connectDefinisionId, dto);
					//items
	                for (final Iterator<Item> itemIte = tableForm.getItem().iterator(); itemIte.hasNext();) {
	                	Item item = itemIte.next();
						if (itemContainCols.equals(item.getId())) {
							item.setDataType(relationScreen.getRelationAndScreenInfoDTO().getDataType());
							item.setDataLength(relationScreen.getRelationAndScreenInfoDTO().getDataLength());
							item.setDataUnit(relationScreen.getRelationAndScreenInfoDTO().getDataUnit());
						}
	                }
	                //tables
			        Tables tables = tableForm.getTables();
			        String tableFormId = relationScreen.getTableFormId();
		            for (final Table tab : tables.getTable()) {
		            	if (tab.getId().equals(tableFormId)){
		            		for (final ItemMulti ite : tab.getItem()) {
		            			if (ite.getId().equals(relationScreen.getItemId())){
		            				ite.setDataType(relationScreen.getRelationAndScreenInfoDTO().getDataType());
									ite.setDataLength(relationScreen.getRelationAndScreenInfoDTO().getDataLength());
									ite.setDataUnit(relationScreen.getRelationAndScreenInfoDTO().getDataUnit());
		            			}
		            		}
		            	}
		            }
					TableFormDto tableFormDto = new TableFormDto(tableForm);
					tableFormDAO.saveTableMulti(connectDefinisionId, tableFormDto);
				} catch (DAOException e) {
					getLogger().error(e.getMessage());
				}
			} catch (ApplicationDomainLogicException e) {
				getLogger().error(e.getMessage());
			}
    	}
	}

	/**
     * @param relationScreen
     */
    private void updateMultiTableDelColUseItemCols(RelationScreenDTO relationScreen) {
    	String connectDefinisionId = relationScreen.getRelationAndScreenInfoDTO().getConnectDefinisionId();
    	String tableFormId = relationScreen.getRelationAndScreenInfoDTO().getTableFormIdTypeMultiTable();
		if (tableFormId != null) {
	    	AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
			try {
				TableFormDAO tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
				TableFormDto dto = new TableFormDto();
				dto.setId(tableFormId);
				TableForm tableForm = null;
				try {
					tableForm = tableFormDAO.getTargetTableFormMulti(connectDefinisionId, dto);
					TableFormDto tableFormDto = new TableFormDto(tableForm);
					if (tableFormDto.getId() == null) {
						return;
					}
					tableFormDto.setEnable(false);
					tableFormDAO.saveTableMulti(connectDefinisionId, tableFormDto);
				} catch (DAOException e) {
					getLogger().error(e.getMessage());
				}
			} catch (ApplicationDomainLogicException e) {
				getLogger().error(e.getMessage());
			}
    	}
	}

    /**
	 * @param selectTablesRegister
	 * @return
	 */
	public List<RelationScreenForDeleteDTO> getRelationScreenUseTableDTO(SelectTablesRegister selectTablesRegister) throws ApplicationDomainLogicException {
		List<RelationScreenForDeleteDTO> relationScreens = new ArrayList<RelationScreenForDeleteDTO>();
		final String connectDefinitionId = selectTablesRegister.getConnectDefinitionId();
		for (final TrDTO table : selectTablesRegister.getTable()) {
			final String tableId = table.getTdTableId().getValue();
			//1.relation use table
			List<RelationScreenForDeleteDTO> relationsUseTable = getRelationUseTable(connectDefinitionId,tableId);
			if (relationsUseTable.size() > 0) {
				relationScreens.addAll(relationsUseTable);
			}
			//2.table multi use table
			List<RelationScreenForDeleteDTO> multiTablesUseTable = getMultiTableUseTable(connectDefinitionId,tableId);
			if (multiTablesUseTable.size() > 0) {
				relationScreens.addAll(multiTablesUseTable);
			}
		}
		return relationScreens;
	}

	/**
	 * @param connectDefinitionId
	 * @param tableId
	 * @return
	 */
	private List<RelationScreenForDeleteDTO> getMultiTableUseTable(String connectDefinitionId, String tableId) {
		//MultiTable in connectDefinisionId
    	Map<String,TableForm> tableFormMultisMap = getAllMultiTable(connectDefinitionId);
		List<RelationScreenForDeleteDTO> tableFormMultis = new ArrayList<RelationScreenForDeleteDTO>();
		for (String tableIdMulti : tableFormMultisMap.keySet()) {
			TableForm tableFormMulti = tableFormMultisMap.get(tableIdMulti);
	        //table use tables
	        Tables tables = tableFormMulti.getTables();
	        for (final Table tab : tables.getTable()) {
				if (tab.getId().equals(tableId)) {
					RelationScreenForDeleteDTO delTableUseMulti = new RelationScreenForDeleteDTO();
					delTableUseMulti.setTableDeleteUseCase(AppConst.MULTI_TABLE);
					delTableUseMulti.setConnectDefinitionId(connectDefinitionId);
					delTableUseMulti.setTableFormIdTypeMultiTable(tableFormMulti.getId());
					delTableUseMulti.setTableFormLabelTypeMultiTable(tableFormMulti.getLabel());
					tableFormMultis.add(delTableUseMulti);
				}
	        }
		}
		return tableFormMultis;
	}

	/**
	 * @param tableId
	 * @return
	 */
	private List<RelationScreenForDeleteDTO> getRelationUseTable(String connectDefinitionId,String tableId) {
		//relation
    	Map<String, RelationInformation> relationsMap = getAllRelation();
    	List<RelationScreenForDeleteDTO> relations = new ArrayList<RelationScreenForDeleteDTO>();
		for (String table : relationsMap.keySet()) {
			RelationInformation relation = relationsMap.get(table);
			//use table in relation
			boolean useTableInRelation = isUseTableInRelation(connectDefinitionId,tableId,relation);
			if (useTableInRelation) {
				RelationScreenForDeleteDTO delTableUseRelation = new RelationScreenForDeleteDTO();
				delTableUseRelation.setTableDeleteUseCase("relation");
				delTableUseRelation.setConnectDefinitionId(connectDefinitionId);
				delTableUseRelation.setRelationId(relation.getId());
				delTableUseRelation.setRelationLabel(relation.getLabel());
				relations.add(delTableUseRelation);
			}
		}
		return relations;
	}

	/**
     * @param changeColumnInfoDTO
     * @return
     * @throws ApplicationDomainLogicException
     */
    public List<RelationScreenDTO> getRelationScreenDTO(ChangeColumnInfoDTO changeColumnInfoDTO) throws ApplicationDomainLogicException {
    	final String connectDefinitionId = changeColumnInfoDTO.getConnectDefinitionId();
        final String tableId = changeColumnInfoDTO.getTableFormId();
        final List<ChangeColumnItem> changeColumnItems = changeColumnInfoDTO.getChangeColumnItems();
        final String connectionUserLabel = changeColumnInfoDTO.getUserId();
        final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		final RecordEditorInformationDTO recordEditorInformationDTO = logic.getRecordEditorInformation(connectDefinitionId,tableId,connectionUserLabel);
		List<RelationScreenDTO> relationScreens = new ArrayList<RelationScreenDTO>();
        for (final ChangeColumnItem item : changeColumnItems) {
        	final String columnid = item.getColumnId();
        	if (item.getChangePresence() == ColumnChangePresence.delete) {
        		//1.DELETE_COLUMN_USE_RELATION_SCREEN
        		ColumnChangeInfoDTO columnChangeInfoDTO1 = new ColumnChangeInfoDTO("DELETE_COLUMN_USE_RELATION_SCREEN",connectionUserLabel,connectDefinitionId,tableId,columnid,null,null,null);
        		List<RelationScreenDTO> delColUseRelScreen = getColumnInfoUseTableMulti(columnChangeInfoDTO1);
				if (delColUseRelScreen.size() > 0) {
					relationScreens.addAll(delColUseRelScreen);
				}
        		//2.DELETE_COLUMN_USE_ITEM_COLS
				ColumnChangeInfoDTO columnChangeInfoDTO2 = new ColumnChangeInfoDTO("DELETE_COLUMN_USE_ITEM_COLS",connectionUserLabel,connectDefinitionId,tableId,columnid,null,null,null);
				List<RelationScreenDTO> delColUseItemCols = getColumnInfoUseTableMulti(columnChangeInfoDTO2);
				if (delColUseItemCols.size() > 0) {
					relationScreens.addAll(delColUseItemCols);
				}
        	} else if (item.getChangePresence() == ColumnChangePresence.update) {
        		TableItemDTO itemDTO = recordEditorInformationDTO.getTableForm().getTableItemMap().get(item.getColumnId());
        		DefinitionOfColumn defCol = recordEditorInformationDTO.getTableDef().getDefinitionOfColumnMap().get(item.getColumnId());
    			//DBの項目の型変更
    			String columnTypeNameDB = defCol.getColumnTypeName();
    			String dataLength = String.valueOf(defCol.getColumnDisplayMaxSize());
    			String dataUnit = defCol.getDataUnit();
    			String dataTypeXML = itemDTO.getDataType();
    			if (!columnTypeNameDB.equalsIgnoreCase(dataTypeXML)) {
    				//3.COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM
    				ColumnChangeInfoDTO columnChangeInfoDTO3 = new ColumnChangeInfoDTO("COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM",
    						connectionUserLabel,connectDefinitionId,tableId,columnid,columnTypeNameDB,dataLength,dataUnit);
    				List<RelationScreenDTO> colTypeChangeUseItemColsTables = getColumnInfoUseTableMulti(columnChangeInfoDTO3);
    				if (colTypeChangeUseItemColsTables.size() > 0) {
    					relationScreens.addAll(colTypeChangeUseItemColsTables);
    				}
    			}
    			//DBの項目にPK追加
    			boolean isPrimaryKeyDb = defCol.isPrimaryKey();
    			boolean isPrimaryKeyXml = itemDTO.getPrimaryKey();
    			if (isPrimaryKeyDb == true && isPrimaryKeyDb != isPrimaryKeyXml) {
    				//4.COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM
    				ColumnChangeInfoDTO columnChangeInfoDTO4 = new ColumnChangeInfoDTO("COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM",connectionUserLabel,
    						connectDefinitionId,tableId,columnid,columnTypeNameDB,dataLength,dataUnit);
    				List<RelationScreenDTO> colAddPkUseTables = getColumnInfoUseTableMulti(columnChangeInfoDTO4);
    				if (colAddPkUseTables.size() > 0) {
    					relationScreens.addAll(colAddPkUseTables);
    				}
    			}
    			//DBの項目にPK削除
    			if (isPrimaryKeyDb == false && isPrimaryKeyXml == true) {
    				//5.COLUMN_DELETE_PK_USE_TABLES_TABLE_ITEM
    				ColumnChangeInfoDTO columnChangeInfoDTO5 = new ColumnChangeInfoDTO("COLUMN_DELETE_PK_USE_TABLES_TABLE_ITEM",connectionUserLabel,
    						connectDefinitionId,tableId,columnid,columnTypeNameDB,dataLength,dataUnit);
    				List<RelationScreenDTO> colDelPkUseTables = getColumnInfoUseTableMulti(columnChangeInfoDTO5);
    				if (colDelPkUseTables.size() > 0) {
    					relationScreens.addAll(colDelPkUseTables);
    				}
    			}
        	 }
        }
        return relationScreens;
    }

    /**
     * @param columnChangeInfoDTO
     * @return
     */
    private List<RelationScreenDTO> getColumnInfoUseTableMulti(ColumnChangeInfoDTO columnChangeInfoDTO){
    	//1.MultiTable in connectDefinisionId
    	Map<String,TableForm> tableFormMultisMap = getAllMultiTable(columnChangeInfoDTO.getConnectDefinitionId());
    	//2.relation
    	Map<String, RelationInformation> relationsMap = getAllRelation();
    	//3.column change use in case
    	List<RelationScreenDTO> relationScreenDTOList = getColumnChangeUseCase(columnChangeInfoDTO,tableFormMultisMap,relationsMap);
		return relationScreenDTOList;
	}

	/**
	 * @param columnChangeInfoDTO
	 * @param tableFormMultisMap
	 * @param relationsMap
	 * @return
	 */
	private List<RelationScreenDTO> getColumnChangeUseCase(ColumnChangeInfoDTO columnChangeInfoDTO,
			Map<String, TableForm> tableFormMultisMap, Map<String, RelationInformation> relationsMap) {
		List<RelationScreenDTO> relationScreens = new ArrayList<RelationScreenDTO>();
    	//DELETE_COLUMN_USE_RELATION_SCREEN
		if ("DELETE_COLUMN_USE_RELATION_SCREEN".equals(columnChangeInfoDTO.getActionColumn())) {
			//1.column use relation items
			List<RelationScreenDTO> relations = columnUseRelationItems(columnChangeInfoDTO,relationsMap);
			//2.tableForm type="multi-table" use relation
			if (relations.size() > 0) {
				relationScreens.addAll(relations);
				List<RelationScreenDTO> multiTableUseRelations = multiTableUseRelation(columnChangeInfoDTO,relations,tableFormMultisMap);
				if (multiTableUseRelations.size() > 0) {
					relationScreens.addAll(multiTableUseRelations);
				}
			}
		}
    	//DELETE_COLUMN_USE_ITEM_COLS
		if ("DELETE_COLUMN_USE_ITEM_COLS".equals(columnChangeInfoDTO.getActionColumn()) && tableFormMultisMap!=null) {
			List<RelationScreenDTO> multiTableUseItemCols = multiTableUseItemCols(columnChangeInfoDTO,tableFormMultisMap);
			relationScreens.addAll(multiTableUseItemCols);
		}
    	//COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM
		if ("COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM".equals(columnChangeInfoDTO.getActionColumn()) && tableFormMultisMap!=null) {
			List<RelationScreenDTO> multiTableUseItemColsListNo1Tables = multiTableUseItemColsListNo1Tables(columnChangeInfoDTO,tableFormMultisMap);
			relationScreens.addAll(multiTableUseItemColsListNo1Tables);
		}
    	//COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM
		if ("COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM".equals(columnChangeInfoDTO.getActionColumn())&& tableFormMultisMap!=null) {
			List<RelationScreenDTO> multiTableUseTablesTableItem = multiTableUseTablesTableItem(columnChangeInfoDTO,tableFormMultisMap);
			relationScreens.addAll(multiTableUseTablesTableItem);
		}
		//COLUMN_DELETE_PK_USE_TABLES_TABLE_ITEM
		if ("COLUMN_DELETE_PK_USE_TABLES_TABLE_ITEM".equals(columnChangeInfoDTO.getActionColumn())&& tableFormMultisMap!=null) {
			List<RelationScreenDTO> multiTableUseTablesTableItem = delPKMultiTableUseTablesTableItem(columnChangeInfoDTO,tableFormMultisMap);
			relationScreens.addAll(multiTableUseTablesTableItem);
		}
		return relationScreens;
	}

	/**
	 * @param columnChangeInfoDTO
	 * @param tableFormMultisMap
	 * @return
	 */
	private List<RelationScreenDTO> multiTableUseTablesTableItem(ColumnChangeInfoDTO columnChangeInfoDTO,
			Map<String, TableForm> tableFormMultisMap) {
		List<RelationScreenDTO> tableFormMultis = new ArrayList<RelationScreenDTO>();
		for (String tableId : tableFormMultisMap.keySet()) {
			TableForm tableFormMulti = tableFormMultisMap.get(tableId);
	        //tables
	        Tables tables = tableFormMulti.getTables();
	        for (final Table tab : tables.getTable()) {
	        	if (tab.getId().equals(columnChangeInfoDTO.getTableId())){
	        		for (final ItemMulti ite : tab.getItem()) {
	        			if (ite.getId().equals(columnChangeInfoDTO.getItemId())){
	        				RelationScreenDTO colAddPkUseTablesTableItem = new RelationScreenDTO();
							colAddPkUseTablesTableItem.setTableFormId(columnChangeInfoDTO.getTableId());
							colAddPkUseTablesTableItem.setItemId(columnChangeInfoDTO.getItemId());
							colAddPkUseTablesTableItem.setColumnChangeUseCase("COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM");
//							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO(null,null,
//									columnChangeInfoDTO.getConnectDefinitionId(),tableFormMulti.getId(),tableFormMulti.getLabel());
							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO();
							relationAndScreenInfoDTO.setConnectDefinisionId(columnChangeInfoDTO.getConnectDefinitionId());
							relationAndScreenInfoDTO.setTableFormIdTypeMultiTable(tableFormMulti.getId());
							relationAndScreenInfoDTO.setTableFormLabelTypeMultiTable(tableFormMulti.getLabel());
							//relationAndScreenInfoDTO.setItemContainCols(ite.getId());
							colAddPkUseTablesTableItem.setRelationAndScreenInfoDTO(relationAndScreenInfoDTO);
							tableFormMultis.add(colAddPkUseTablesTableItem);
	        			}
	        		}
	        	}
	        }
		}
		return tableFormMultis;
	}

	/**
	 * @param columnChangeInfoDTO
	 * @param tableFormMultisMap
	 * @return
	 */
	private List<RelationScreenDTO> delPKMultiTableUseTablesTableItem(ColumnChangeInfoDTO columnChangeInfoDTO,
			Map<String, TableForm> tableFormMultisMap) {
		List<RelationScreenDTO> tableFormMultis = new ArrayList<RelationScreenDTO>();
		for (String tableId : tableFormMultisMap.keySet()) {
			TableForm tableFormMulti = tableFormMultisMap.get(tableId);
	        //tables
	        Tables tables = tableFormMulti.getTables();
	        for (final Table tab : tables.getTable()) {
	        	if (tab.getId().equals(columnChangeInfoDTO.getTableId())){
	        		for (final ItemMulti ite : tab.getItem()) {
	        			if (ite.getId().equals(columnChangeInfoDTO.getItemId())){
	        				RelationScreenDTO colDelPkUseTablesTableItem = new RelationScreenDTO();
							colDelPkUseTablesTableItem.setTableFormId(columnChangeInfoDTO.getTableId());
							colDelPkUseTablesTableItem.setItemId(columnChangeInfoDTO.getItemId());
							colDelPkUseTablesTableItem.setColumnChangeUseCase("COLUMN_DELETE_PK_USE_TABLES_TABLE_ITEM");
//							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO(null,null,
//									columnChangeInfoDTO.getConnectDefinitionId(),tableFormMulti.getId(),tableFormMulti.getLabel());
							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO();
							relationAndScreenInfoDTO.setConnectDefinisionId(columnChangeInfoDTO.getConnectDefinitionId());
							relationAndScreenInfoDTO.setTableFormIdTypeMultiTable(tableFormMulti.getId());
							relationAndScreenInfoDTO.setTableFormLabelTypeMultiTable(tableFormMulti.getLabel());
							//relationAndScreenInfoDTO.setItemContainCols(ite.getId());
							colDelPkUseTablesTableItem.setRelationAndScreenInfoDTO(relationAndScreenInfoDTO);
							tableFormMultis.add(colDelPkUseTablesTableItem);
	        			}
	        		}
	        	}
	        }
		}
		return tableFormMultis;
	}
	/**
	 * @param columnChangeInfoDTO
	 * @param tableFormMultisMap
	 * @return
	 */
	private List<RelationScreenDTO> multiTableUseItemColsListNo1Tables(ColumnChangeInfoDTO columnChangeInfoDTO,
			Map<String, TableForm> tableFormMultisMap) {
		List<RelationScreenDTO> tableFormMultis = new ArrayList<RelationScreenDTO>();
		for (String tableId : tableFormMultisMap.keySet()) {
			TableForm tableFormMulti = tableFormMultisMap.get(tableId);
			//item-->cols
	        for (Iterator<Item> ite = tableFormMulti.getItem().iterator(); ite.hasNext();) {
	            final Item item = ite.next();
	            if (item.getCols() != null) {
	        		for (final Iterator<Item.Cols.Col> itemCol = item.getCols().getCol().iterator(); itemCol.hasNext();) {
		    			final Item.Cols.Col xmlCol = itemCol.next();
						if (xmlCol.getListNO().equals("1") && xmlCol.getTableID().equals(columnChangeInfoDTO.getTableId())
								&& xmlCol.getItemID().equals(columnChangeInfoDTO.getItemId())) {
							RelationScreenDTO colTypeChangeUseItem = new RelationScreenDTO();
							colTypeChangeUseItem.setTableFormId(columnChangeInfoDTO.getTableId());
							colTypeChangeUseItem.setItemId(columnChangeInfoDTO.getItemId());
							colTypeChangeUseItem.setColumnChangeUseCase("COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM");
//							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO(null,null,
//									columnChangeInfoDTO.getConnectDefinitionId(),tableFormMulti.getId(),tableFormMulti.getLabel());
							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO();
							relationAndScreenInfoDTO.setConnectDefinisionId(columnChangeInfoDTO.getConnectDefinitionId());
							relationAndScreenInfoDTO.setTableFormIdTypeMultiTable(tableFormMulti.getId());
							relationAndScreenInfoDTO.setTableFormLabelTypeMultiTable(tableFormMulti.getLabel());
							relationAndScreenInfoDTO.setItemContainCols(item.getId());
							relationAndScreenInfoDTO.setDataType(columnChangeInfoDTO.getDataType());
							relationAndScreenInfoDTO.setDataLength(columnChangeInfoDTO.getDataLength());
							relationAndScreenInfoDTO.setDataUnit(columnChangeInfoDTO.getDataUnit());
							colTypeChangeUseItem.setRelationAndScreenInfoDTO(relationAndScreenInfoDTO);
							tableFormMultis.add(colTypeChangeUseItem);
		    			}
	        		}
	            }
	        }
	        //tables
	        Tables tables = tableFormMulti.getTables();
            for (final Table tab : tables.getTable()) {
            	if (tab.getId().equals(columnChangeInfoDTO.getTableId())){
            		for (final ItemMulti ite : tab.getItem()) {
            			if (ite.getId().equals(columnChangeInfoDTO.getItemId())){
            				RelationScreenDTO colTypeChangeUseItem = new RelationScreenDTO();
							colTypeChangeUseItem.setTableFormId(columnChangeInfoDTO.getTableId());
							colTypeChangeUseItem.setItemId(columnChangeInfoDTO.getItemId());
							colTypeChangeUseItem.setColumnChangeUseCase("COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM");
//							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO(null,null,
//									columnChangeInfoDTO.getConnectDefinitionId(),tableFormMulti.getId(),tableFormMulti.getLabel());
							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO();
							relationAndScreenInfoDTO.setConnectDefinisionId(columnChangeInfoDTO.getConnectDefinitionId());
							relationAndScreenInfoDTO.setTableFormIdTypeMultiTable(tableFormMulti.getId());
							relationAndScreenInfoDTO.setTableFormLabelTypeMultiTable(tableFormMulti.getLabel());
							relationAndScreenInfoDTO.setItemContainCols(ite.getId());
							relationAndScreenInfoDTO.setDataType(columnChangeInfoDTO.getDataType());
							relationAndScreenInfoDTO.setDataLength(columnChangeInfoDTO.getDataLength());
							relationAndScreenInfoDTO.setDataUnit(columnChangeInfoDTO.getDataUnit());
							colTypeChangeUseItem.setRelationAndScreenInfoDTO(relationAndScreenInfoDTO);
							tableFormMultis.add(colTypeChangeUseItem);
            			}
            		}
            	}
            }
		}
		return tableFormMultis;
	}

	/**
	 * @param columnChangeInfoDTO
	 * @param tableFormMultisMap
	 * @return
	 */
	private List<RelationScreenDTO> multiTableUseItemCols(ColumnChangeInfoDTO columnChangeInfoDTO,Map<String, TableForm> tableFormMultisMap) {
		List<RelationScreenDTO> tableFormMultis = new ArrayList<RelationScreenDTO>();
		for (String tableId : tableFormMultisMap.keySet()) {
			TableForm tableFormMulti = tableFormMultisMap.get(tableId);
	        for (Iterator<Item> ite = tableFormMulti.getItem().iterator(); ite.hasNext();) {
	            final Item item = ite.next();
	            if (item.getCols() != null) {
	        		for (final Iterator<Item.Cols.Col> itemCol = item.getCols().getCol().iterator(); itemCol.hasNext();) {
		    			final Item.Cols.Col xmlCol = itemCol.next();
						if (xmlCol.getTableID().equals(columnChangeInfoDTO.getTableId())
								&& xmlCol.getItemID().equals(columnChangeInfoDTO.getItemId())) {
							RelationScreenDTO delColUseItemCols = new RelationScreenDTO();
							delColUseItemCols.setTableFormId(columnChangeInfoDTO.getTableId());
							delColUseItemCols.setItemId(columnChangeInfoDTO.getItemId());
							delColUseItemCols.setColumnChangeUseCase("DELETE_COLUMN_USE_ITEM_COLS");
//							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO(null,null,
//									columnChangeInfoDTO.getConnectDefinitionId(),tableFormMulti.getId(),tableFormMulti.getLabel());
							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO();
							relationAndScreenInfoDTO.setConnectDefinisionId(columnChangeInfoDTO.getConnectDefinitionId());
							relationAndScreenInfoDTO.setTableFormIdTypeMultiTable(tableFormMulti.getId());
							relationAndScreenInfoDTO.setTableFormLabelTypeMultiTable(tableFormMulti.getLabel());
							delColUseItemCols.setRelationAndScreenInfoDTO(relationAndScreenInfoDTO);
							tableFormMultis.add(delColUseItemCols);
		    			}
	        		}
	            }
	        }
		}
		return tableFormMultis;
	}

	/**
	 * @param columnChangeInfoDTO
	 * @param relations
	 * @param tableFormMultisMap
	 * @return
	 */
	private List<RelationScreenDTO> multiTableUseRelation(ColumnChangeInfoDTO columnChangeInfoDTO,
			List<RelationScreenDTO> colUseRelations, Map<String, TableForm> tableFormMultisMap) {
		List<RelationScreenDTO> tableFormMultis = new ArrayList<RelationScreenDTO>();
		for (RelationScreenDTO colUseRelation : colUseRelations) {
			String relationId = colUseRelation.getRelationAndScreenInfoDTO().getRelationId();
			for (String tableId : tableFormMultisMap.keySet()) {
				TableForm tableFormMulti = tableFormMultisMap.get(tableId);
            	if(tableFormMulti.getRelations() != null && tableFormMulti.getRelations().getRelation() != null){
                	for (final Iterator<Relations.Relation> resIte = tableFormMulti.getRelations().getRelation().iterator(); resIte.hasNext();) {
                        final Relations.Relation res = resIte.next();
						if (relationId.equals(res.getId())) {
							RelationScreenDTO delColUseRelScreen = new RelationScreenDTO();
							delColUseRelScreen.setTableFormId(columnChangeInfoDTO.getTableId());
							delColUseRelScreen.setItemId(columnChangeInfoDTO.getItemId());
							delColUseRelScreen.setColumnChangeUseCase("DELETE_COLUMN_USE_RELATION_SCREEN");
//							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO(relationId,colUseRelation.getRelationAndScreenInfoDTO().getRelationLabel(),
//									columnChangeInfoDTO.getConnectDefinitionId(),tableFormMulti.getId(),tableFormMulti.getLabel());
							RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO();
							relationAndScreenInfoDTO.setRelationId(relationId);
							relationAndScreenInfoDTO.setRelationLabel(colUseRelation.getRelationAndScreenInfoDTO().getRelationLabel());
							relationAndScreenInfoDTO.setConnectDefinisionId(columnChangeInfoDTO.getConnectDefinitionId());
							relationAndScreenInfoDTO.setTableFormIdTypeMultiTable(tableFormMulti.getId());
							relationAndScreenInfoDTO.setTableFormLabelTypeMultiTable(tableFormMulti.getLabel());
							delColUseRelScreen.setRelationAndScreenInfoDTO(relationAndScreenInfoDTO);
							tableFormMultis.add(delColUseRelScreen);
						}
                    }
            	}
			}
		}
		return tableFormMultis;
	}

	/**
	 * @param columnChangeInfoDTO
	 * @param relationsMap
	 * @return
	 */
	private List<RelationScreenDTO> columnUseRelationItems(ColumnChangeInfoDTO columnChangeInfoDTO,Map<String, RelationInformation> relationsMap) {
		List<RelationScreenDTO> relations = new ArrayList<RelationScreenDTO>();
		for (String tableId : relationsMap.keySet()) {
			RelationInformation relation = relationsMap.get(tableId);
			//exist table in tables
			RelationTableItemDTO existTableInTables = isExistTableInTables(columnChangeInfoDTO,relation);
			//exist column in items
			if (existTableInTables != null && existTableInTables.isExistTableIn()) {
				boolean isExistColumnInItems = isExistColumnInItems(existTableInTables,columnChangeInfoDTO, relation);
				if (isExistColumnInItems) {
					RelationScreenDTO delColUseRelScreen = new RelationScreenDTO();
					delColUseRelScreen.setTableFormId(columnChangeInfoDTO.getTableId());
					delColUseRelScreen.setItemId(columnChangeInfoDTO.getItemId());
					delColUseRelScreen.setColumnChangeUseCase("DELETE_COLUMN_USE_RELATION_SCREEN");
//					RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO(relation.getId(),relation.getLabel(),
//							columnChangeInfoDTO.getConnectDefinitionId(),null,null);
					RelationAndScreenInfoDTO relationAndScreenInfoDTO = new RelationAndScreenInfoDTO();
					relationAndScreenInfoDTO.setRelationId(relation.getId());
					relationAndScreenInfoDTO.setRelationLabel(relation.getLabel());
					relationAndScreenInfoDTO.setConnectDefinisionId(columnChangeInfoDTO.getConnectDefinitionId());
					delColUseRelScreen.setRelationAndScreenInfoDTO(relationAndScreenInfoDTO);
					relations.add(delColUseRelScreen);
				}
			}
		}
		return relations;
	}

	/**
	 * @param existTableInTables
	 * @param columnChangeInfoDTO
	 * @param relation
	 * @return
	 */
	private boolean isExistColumnInItems(RelationTableItemDTO existTableInTables, ColumnChangeInfoDTO columnChangeInfoDTO,RelationInformation relation) {
		for (final ItemDTO ite : relation.getItems()) {
			if (existTableInTables.getType().equals(AppConst.RELATION_TABLE_DETAIL) 
					&& columnChangeInfoDTO.getItemId().equals(ite.getDetail())
					|| existTableInTables.getType().equals(AppConst.RELATION_TABLE_MASTER) 
					&& columnChangeInfoDTO.getItemId().equals(ite.getMaster())) {
				return true;
			}
        }
		return false;
	}

	/**
	 * @param relation
	 * @return
	 */
	private RelationTableItemDTO isExistTableInTables(ColumnChangeInfoDTO columnChangeInfoDTO,RelationInformation relation) {
        for (final TableDTO tab : relation.getTables()) {
			if (tab.getConnectid().equals(columnChangeInfoDTO.getConnectDefinitionId())
					&& tab.getTableid().equals(columnChangeInfoDTO.getTableId())) {
				return new RelationTableItemDTO(true,tab.getType());
			}
        }
		return null;
	}
	/**
	 * @param connectDefinitionId
	 * @param tableId
	 * @param relation
	 * @return
	 */
	private boolean isUseTableInRelation(String connectDefinitionId,String tableId,RelationInformation relation) {
        for (final TableDTO tab : relation.getTables()) {
			if (tab.getConnectid().equals(connectDefinitionId)
					&& tab.getTableid().equals(tableId)) {
				return true;
			}
        }
		return false;
	}

	/**
	 * @return
	 */
	private Map<String, RelationInformation> getAllRelation() {
		final PreservationOfAppRelationLogic logic = new PreservationOfAppRelationLogic();
		try {
			return logic.getRelationInformationMap();
		} catch (final ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
		return null;
	}

	/**
	 * @param columnChangeInfoDTO
	 */
	private Map<String,TableForm> getAllMultiTable(String connectDefinitionId) {
		AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
    	TableFormDAO tableFormDAO = null;
		try {
			tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
		} catch (ApplicationDomainLogicException ex) {
			getLogger().error(ex.getMessage());
		}
		try {
			Map<String,TableForm> tableMultiFormsMap = tableFormDAO.getAllTableFormMulti(connectDefinitionId);
			return tableMultiFormsMap;
		} catch (DAOException e) {
			getLogger().error(e.getMessage());
		}
		return null;
	}

    /**
     * リポジトリにテーブルを追加する。
     * <p>
     * アプリケーションリポジトリにテーブル情報を追加します。
     * </p><p>
     * 追加の際にデータベースからテーブル情報メタデータを取得し、画面上の項目
     * 定義情報の初期値も生成します。
     * </p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableId テーブル ID
     * @param tableName テーブル仮名
     * @param connectionUserLabel 接続ユーザー表示名
     * @throws ApplicationDomainLogicException
     */
    public void addTable(final String connectDefinitionId,
            final String tableId, final String tableName,
            final String connectionUserLabel)
            throws ApplicationDomainLogicException {
        final AcquisitionOfConnectDefinitionLogic connectDefinitionLogic
            = new AcquisitionOfConnectDefinitionLogic();
        final DbConnectDefinitionDTO connectDefinitionDTO
            = connectDefinitionLogic.getConnectDefinitionDTO(connectDefinitionId);
        final TableDefinitionDTO def = getTableDefinitionDTO(
            connectDefinitionId,
            connectDefinitionDTO.getDatabaseTypeConnectionDestination(),
            tableId,
            connectionUserLabel);
        final TableFormDTO dto = new TableFormDTO();
        dto.setTableFormId(tableId);
        dto.setTableFormLabel(tableName);
        dto.getSortConditionMap().putAll(createSortMap(def));
        int previewColumnCounter = 0;
        int sortIndex = 0;
        for (final Iterator<String> ite = def.getColumnNames().values()
            .iterator(); ite.hasNext();) {
            final String name = ite.next();

            final TableItemDTO item = createTableItemDTO(
                def.getDefinitionOfColumnMap().get(name),
                previewColumnCounter,
                sortIndex);
            dto.getTableItemMap().put(name, item);
            if (item.canPreview()) {
                previewColumnCounter++;
            }
            sortIndex++;
        }
        final TableFormDAO dao = createTableFormDAO();
        try {
            dao.save(connectDefinitionId, dto);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * ソート条件マップを初期設定します。
     * <p>
     * 主キー制約があった場合は、主キー昇順を設定します。無かった場合は、
     * ユニーク制約が無いか確認し、ユニークキー昇順を設定します。それも無かった
     * 場合は一番最初のカラム昇順で設定します。</p>
     *
     * @param def
     */
    private SortedMap<Integer, String> createSortMap(
            final TableDefinitionDTO def) {
        final SortedMap<Integer, String> ret = new TreeMap<Integer, String>();
        int index = 0;
        final SortedMap<Integer, String> map = def.getColumnNames();
        for (final Iterator<String> ite = map.values().iterator(); ite
            .hasNext();) {
            final String name = ite.next();
            if (def.getDefinitionOfColumnMap().get(name).isPrimaryKey()) {
                ret.put(index, name);
                index++;
            }
        }
        if (index > 0) {
            return ret;
        } else {
            for (final Iterator<String> ite = map.values().iterator(); ite
                .hasNext();) {
                final String name = ite.next();
                if (def.getDefinitionOfColumnMap().get(name).isUnique()) {
                    ret.put(index, name);
                    index++;
                }
            }
        }
        if (index > 0) {
            return ret;
        } else {
            ret.put(index, map.get(1));
            return ret;
        }
    }

    /**
     * TableItemDTO を生成して戻します。
     * <p>
     * DB のカラム定義をもとに、画面項目定義の初期値を生成し DTO に設定して
     * 戻します。
     * </p><p>
     * カラム名・ラベル（表示）名にはテーブル名をそのまま設定します。
     * </p><p>
     * HTML 要素は、マッピング定義に従って初期設定します。
     * </p><p>
     * プレビュー対象か否かは、定義された最大数に達しているか否かで初期設定
     * します。
     * </p><p>
     * 編集可能か否かは、自動インクリメントフィールドを除いて「可能」で初期設定
     * します。
     * </p><p>
     * 主キー、ユニークキー、外部キーは注釈を自動付加します。また主キー或いは
     * ユニークキーの場合は更新キーかつ検索キーとして定義します。<br />
     * 外部キーの場合は検索キーとしてだけ初期定義します。
     * </p><p>
     * 各カラムに対し、最大文字数制限が DB から取得できた場合は、その数字を注釈
     * に初期設定します。
     * </p><p>
     * 本アプリケーションで対応できない項目だった場合は、プレビューには現れず
     * 編集が出来ないよう初期設定し、その旨注釈を出力します。
     * </p>
     *
     * @param def DB のカラム定義
     * @param previewColumnIndex 項目表示数カウンタ
     * @return TableItemDTO テーブル項目情報
     */
    private TableItemDTO createTableItemDTO(
            final DefinitionOfColumn def,
            final int previewColumnIndex,
            final int sortIndex) {
        final TableItemDTO ret = new TableItemDTO();
        ret.setItemId(def.getColumnId());
        ret.setItemLabel(def.getColumnId());
        ret.setSortIndex(sortIndex);

        ret.setPrimaryKey(def.isPrimaryKey());
        ret.setUnique(def.isUnique());
        ret.setForeignKey(def.isForeignKey());
        ret.setDataType(def.getColumnTypeName());
        ret.setDataLength(makeSizeColumnTypeLabel(def));
        ret.setDataUnit(def.getDataUnit());

        final RelationOfJdbcAndHtml relation = RelationOfJdbcAndHtml.metaDataTypeOf(def.getJDBCMetaDataType());

        if(def.isVirtualColumns()) {
        	ret.setHtmlElement(DefinedHtmlElement.SPAN);
        } else {
        	ret.setHtmlElement(relation.getHtml());
        }

        // TODO プルダウン系のためにスキーマ解析して初期リストか SQL 設定...
        /*
         * ＞ 将来暇で暇で仕方なければ...
         *
         * 初期値定義の取り込みも将来的に検討...
         *
         * ret.setDefaultValue(defaultValue);
         */

        if (relation.isCorrespond()) {
//            if (previewColumnIndex < SystemProperties.getPreviewColumnCount()) {
                ret.setPreview(true);
//            } else {
//                ret.setPreview(false);
//            }
            if (def.isAutoIncrement()) {
                ret.setEditing(false);
            } else {
                ret.setEditing(true);
            }
            if (def.isPrimaryKey()) {
                ret.setUpdateKey(true);
                ret.setSelectKey(true);//table in database is primary key -->isUpdateKey = true && isSelectKey = true
            } else {
                if (def.isUnique()) {
                    //ret.setUpdateKey(true);
                } else {
                    //ret.setUpdateKey(false);
                    if (def.isForeignKey()) {
                    } else {
                    }
                }
            }
            //ret.setSelectKey(true);
            final String exp = StringUtils.isEmpty(def.getRemarks()) ? "" : def.getRemarks();
            ret.setExplanation(exp);
        } else {
        	// MI-E-0108=本アプリケーションで未対応のデータ型です。
            ret.setExplanation(MessageUtils.getMessageNotMessageId("MI-E-0108"));
            ret.setPreview(false);//一覧に表示するか
            ret.setDisplayRecordEdit(false);//登録・更新時に表示するか
            ret.setDisplayNamePreview(false);//表示置き換えするかどうか
            ret.setEditing(false);//更新可能か
            ret.setUpdateKey(false);//更新キーか
            ret.setSelectKey(false);//検索キーか
        }

        return ret;
    }

    /**
	 * 引数のJDBCMetaDataTypeが数値型が否かを返します。
	 *
	 * @param type
	 * @return
	 */
	private boolean isJDBCMetaDataTypeIsNumeric(final JDBCMetaDataType type) {
		if (type == JDBCMetaDataType.TINYINT || type == JDBCMetaDataType.SMALLINT || type == JDBCMetaDataType.INTEGER
				|| type == JDBCMetaDataType.BIGINT || type == JDBCMetaDataType.FLOAT || type == JDBCMetaDataType.REAL
				|| type == JDBCMetaDataType.DOUBLE || type == JDBCMetaDataType.NUMERIC
				|| type == JDBCMetaDataType.DECIMAL) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 引数のJDBCMetaDataTypeが日付型が否かを返します。
	 *
	 * @param type
	 * @return
	 */
	private boolean isJDBCMetaDataTypeIsDate(final JDBCMetaDataType type) {
		if (type == JDBCMetaDataType.DATE || type == JDBCMetaDataType.TIME || type == JDBCMetaDataType.TIMESTAMP) {
			return true;
		} else {
			return false;
		}
	}

    /**
	 * 精度或いは桁数注釈の作成。
	 * <p>
	 * 精度、或いは最大桁数の定義が存在しない場合は空文字を戻します。
	 * </p>
	 *
	 * @param def
	 * @return ret 精度或いは桁数注釈
	 */
	private String makeSizeColumnTypeLabel(final DefinitionOfColumn def) {
		final String ret;
		// アプリケーション非対応
		if (!RelationOfJdbcAndHtml.metaDataTypeOf(def.getJDBCMetaDataType()).isCorrespond()) {
			return "";

			// 数値型
		} else if (isJDBCMetaDataTypeIsNumeric(def.getJDBCMetaDataType())) {
			// ORACLEの場合、NUMBERで桁数指定されていない場合は getPrecision が 0 を返す。
			// そして、10gの場合は getScale が -127 (9iは0)を返す。。。（謎
			if (def.getDefinitionOfNumericalValue().getPrecision() == 0) {
				ret = "(38,0)";
			} else {
				//Oracle
				if ("FLOAT".equals(def.getColumnTypeName())) {
					ret = "(" + def.getDefinitionOfNumericalValue().getPrecision() + ")";
				} //SQL Server
				else if ("float".equals(def.getColumnTypeName())) {
					ret = "";
				}
				else {
					ret = "(" + def.getDefinitionOfNumericalValue().getPrecision() + ","
							+ def.getDefinitionOfNumericalValue().getScale() + ")";
				}
			}

			// 日付型
		} else if (isJDBCMetaDataTypeIsDate(def.getJDBCMetaDataType())) {
			ret = "";
			// 文字列型 or バイナリ型
		} else {
			if (def.getColumnDisplayMaxSize() > 0) {
				ret = "(" + def.getColumnDisplayMaxSize() + ")";
			} else {
				ret = "";
			}
		}
		return ret;
	}

    /**
     * TableRegistrationToRepositoryLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public TableRegistrationToRepositoryLogic() {
        return;
    }

    /**
     * テーブルフォーム DAO を生成して戻す。
     *
     * @return TableFormDAO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDAO createTableFormDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
