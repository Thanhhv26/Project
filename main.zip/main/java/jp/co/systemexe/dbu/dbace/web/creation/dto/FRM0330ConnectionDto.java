/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import java.util.List;

import jp.co.systemexe.dbu.dbace.library.dto.BaseDto;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author van-thanh
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0330ConnectionDto extends BaseDto {

	private static final long serialVersionUID = 1L;
	
	private String id;
	private String label;
	
	List<TableForm> tables;

}
