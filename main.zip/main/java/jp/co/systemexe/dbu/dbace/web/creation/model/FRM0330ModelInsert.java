/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.model;

import java.util.List;

import jp.co.systemexe.dbu.dbace.web.creation.dto.ConnectionDefinisionDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationInformation;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author van-thanh
 */

@Data
public class FRM0330ModelInsert {

	List<ConnectionDefinisionDto> connectionList;

	List<RelationInformation> relationList;

    List<MessageInfo> messages;

    //object insert
    TableFormDto objectInsert;

    List<TableFormDto> TableFormDtoList;
}
