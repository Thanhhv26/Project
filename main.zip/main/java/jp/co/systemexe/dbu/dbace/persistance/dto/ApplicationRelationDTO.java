/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.io.Serializable;
import java.util.List;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
public class ApplicationRelationDTO implements Serializable{
	private static final long serialVersionUID = 1L;
	private String relationId;
	private String relationLabel;
    private String relationType;
    private List<TableDTO> tables;
    private List<ItemDTO> items;
	/**
	 * relationId を戻します。
	 *
	 * @return String
	 */
	public String getRelationId() {
		return relationId;
	}
	/**
	 * relationId を設定します。
	 *
	 * @param String relationId
	 */
	public void setRelationId(String relationId) {
		this.relationId = relationId;
	}

	/**
	 * relationId を戻します。
	 *
	 * @return String
	 */
	public String getRelationLabel() {
		return relationLabel;
	}
	/**
	 * relationId を設定します。
	 *
	 * @param String relationId
	 */
	public void setRelationLabel(String relationLabel) {
		this.relationLabel = relationLabel;
	}
	/**
	 * relationType を戻します。
	 *
	 * @return String
	 */
	public String getRelationType() {
		return relationType;
	}
	/**
	 * relationType を設定します。
	 *
	 * @param String relationType
	 */
	public void setRelationType(String relationType) {
		this.relationType = relationType;
	}
	/**
	 * tables を戻します。
	 *
	 * @return List<TableDTO>
	 */
	public List<TableDTO> getTables() {
		return tables;
	}
	/**
	 * tables を設定します。
	 *
	 * @param List<TableDTO> tables
	 */
	public void setTables(List<TableDTO> tables) {
		this.tables = tables;
	}
	/**
	 * items を戻します。
	 *
	 * @return List<ItemDTO>
	 */
	public List<ItemDTO> getItems() {
		return items;
	}
	/**
	 * items を設定します。
	 *
	 * @param List<ItemDTO> items
	 */
	public void setItems(List<ItemDTO> items) {
		this.items = items;
	}

}
