/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.logger;

/**
 * （JavaDoc）。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class LoggerUtils {
	public static String getIndexString(int index) {
		StringBuffer buff = new StringBuffer();
		for (int i = 0; i < index; i++) {
			buff.append("　");
		}
		return buff.toString();
	}
}
