/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchResultDTO;
import lombok.Data;

/**
 * @author bao-anh
 *
 */

@Data
public class FRM0200SearchResultModel extends FRM0200ResultModel {
	private ColumnDisplayDefinitionDTO columnsDisplayDefinition;
	private SearchConditionItem[] searchConditionItems;
	private SearchConditionItem defaultSearchConditionItem;
	private int maxSearchConditionSize;
	private String maxSearchConditionSizeError;
	private RecordSearchResultDTO recordSearchResultDTO;
	private int resultRowCount;
	private boolean orderDesc;
	private SortedMap<Integer, String> sortConditionMap = new TreeMap<Integer, String>();
}
