/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.persistance.dao.BaseDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.DAOFactory;
import jp.co.systemexe.dbu.dbace.persistance.dao.impl.DbConnectInfomationDAOImpl;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAONotFoundException;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * ドメインロジック作成用の基底抽象クラス。
 * <p>
 * アプリケーションドメインのトップレイヤを構成する、アプリケーションドメイン
 * ロジッククラスを作成するための基底抽象クラスです。
 * </p><p>
 * 本クラスのサブクラスは、Teeda Page クラス内に定義されたイベントハンドラに
 * 使用され、ビジネスロジックを実行します。<br />
 * つまり、概ね１ボタンに一つのサブクラスが作成されます。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public abstract class BaseApplicationDomainLogic {

    /**
     * ロガーへの参照を保持します。
     */
    private final Logger logger;

    /**
     * ロガーへの参照を戻します。
     *
     * @return Logger
     */
    protected Logger getLogger() {
        return logger;
    }

    /**
     * DAO を生成して戻します。
     * <p>
     * リポジトリ或いはデータベースにアクセスするための DAO を生成して戻します。
     * </p>
     *
     * @param key DAO キー文字列（インターフェース名）
     * @param type 接続先DBベンダ
     * @return BaseDAO
     * @exception DAOException
     */
    protected BaseDAO createDAO(final String key,
            final DatabaseTypeConnectionDestination type)
            throws DAOException {
        try {
            return DAOFactory.createDAO(key, type);
        } catch (final DAONotFoundException e) {
            getLogger().fatal(e.getMessage(), e);
            throw e;
        } catch (final DAOException e) {
            getLogger().fatal(e.getMessage(), e);
            throw e;
        }
    }

    /**
     * DAO を生成して戻します。
     * <p>
     * リポジトリ或いはデータベースにアクセスするための DAO を生成して戻します。
     * </p>
     *
     * @param key DAO キー文字列（インターフェース名）
     * @return BaseDAO
     * @exception DAOException
     */
    protected BaseDAO createDAO(final String key)
            throws DAOException {
        try {
            return DAOFactory.createDAO(key);
        } catch (final DAONotFoundException e) {
            getLogger().fatal(e.getMessage(), e);
            throw e;
        } catch (final DAOException e) {
            throw e;
        }
    }

    /**
     * BaseApplicationDomainLogic の生成。
     * <p>
     * コンストラクタ。ロガーの初期化を行っています。</p>
     */
    public BaseApplicationDomainLogic() {
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
    }

    //ADD ライセンス認証 機能追加　↓
 	/**
 	 * データベースへの接続情報 DAO を生成して戻す。
 	 *
 	 * @return DbConnectInfomationDAOImpl
 	 * @throws ApplicationDomainLogicException
 	 */
 	public DbConnectInfomationDAOImpl createDbConnectInfomationDAOImpl() throws ApplicationDomainLogicException {
 		try {
 			return (DbConnectInfomationDAOImpl) createDAO("DbConnectInfomationDAO");
 		} catch (final DAOException e) {
 			throw new ApplicationDomainLogicException(e.getMessage(), e);
 		}
 	}

 	/**
 	 * リポジトリXMLに登録されているテーブル数[重複は除く] を戻します。
 	 *
 	 * @return Integer
 	 */
 	public int countNumberOfTableHasRegisted() {
 		int objExist = 0;
 		try {
 			DbConnectInfomationDAOImpl dao = createDbConnectInfomationDAOImpl();
 			objExist = dao.countNumberOfTableHasRegisted();
 		} catch (ApplicationDomainLogicException e) {
 		}
 		return objExist;
 	}

 	/**
     * 画面に今回登録するテーブル数 を戻します。
     *
     * @return Integer
     */
    public int countNumberOfTableIsAddNew(String selectedConnectDefinisionId, SelectOneMenuItem[] confirmTableItems) {
 		int objNew = 0;
 		try {
 			DbConnectInfomationDAOImpl dao = createDbConnectInfomationDAOImpl();
 			objNew = dao.countNumberOfTableIsAddNew(selectedConnectDefinisionId, confirmTableItems);
 		} catch (ApplicationDomainLogicException e) {
 		}
 		return objNew;
 	}
    //ADD ライセンス認証 機能追加　↑
}
