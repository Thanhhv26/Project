/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.util;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.exception.CheckException;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * Checking license key format Decrypt, encrypt
 * 
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
// ADD ライセンス認証と外部認証連携の機能追加 ↓
public class LicenseKeyUtils {

	public static final int DATA_LENGTH = 3;
	public static final String LICENSE_DATE_PATTERN = "yyyyMMdd";
	public static final String SPLIT_CHAR = "-";
	public static final String UNLIMITED = "UNLIMITED";
	public static final Logger logger = LoggerFactory.getLogger(LicenseKeyUtils.class.getName());

	/**
	 *
	 * Decrypt the input string
	 *
	 * @param encrytedString
	 * @return input string (before encryption).
	 * @throws ApplicationException
	 */
	public String decrypt(String encrytedString, String openSesame) throws ApplicationException {
		try {
			String primitiveString = BlowfishUtils.decrypt4b64(openSesame, encrytedString);
			return primitiveString;
		} catch (Exception e) {
			throw new CheckException(e.getMessage(), e);
		}
	}

	/**
	 *
	 * ライセンスキーがあっていません。 will be thrown when System.propertise has no license
	 *
	 * @throws ApplicationException
	 */
	public static void notExistLicenseKeyInXML() throws ApplicationException {
		if (StringUtils.isEmpty(SystemProperties.getLicenseKey())) {
			// MI-F-0021=ライセンスキーがあっていません。
			// throw new CheckException(MessageUtils.getMessage("MI-F-0021"));
			throw new CheckException("MI-F-0021:ライセンスキーがあっていません。");
		}
	}

	/**
	 *
	 * true when licence key is invalid format false when other case
	 * (ライセンスキーの形式がSystem.Property[licencekey]元値の仕様と違う)
	 * 
	 * @param ecryptedLicenseKey
	 * @return
	 */
	public static boolean isValidFormat(String ecryptedLicenseKey, String openSesame) {
		if (ecryptedLicenseKey == null)
			return false;
		String primitiveLicense = null;
		try {
			primitiveLicense = new LicenseKeyUtils().decrypt(ecryptedLicenseKey, openSesame);
		} catch (Exception e) {
			logger.error(e);
			return false;
		}
		// Split by 「-」
		String[] data = primitiveLicense.split(LicenseKeyUtils.SPLIT_CHAR);
		// Not have enough 3 parts.
		if (data.length != LicenseKeyUtils.DATA_LENGTH) {
			return false;
		}
		// License date is not valid format
		if (!DateCheckUtility.isDateStyleCheck(data[1], LicenseKeyUtils.LICENSE_DATE_PATTERN)) {
			return false;
		}
		// 「ライセンス数」は無制限の場合は「Unlimited」をセットし、それ以外は「50」「100」など数値をセットする
		if (!data[2].equalsIgnoreCase(LicenseKeyUtils.UNLIMITED)) {
			try {
				Integer.valueOf(data[2]);
			} catch (NumberFormatException e) {
				return false;
			}
		}
		return true;
	}

	/**
	 *
	 * false when license is expired true when other case
	 *
	 * @param ecryptedLicenseKey
	 * @return
	 */
	public static boolean isNotExpired(String ecryptedLicenseKey, String openSesame) {
		String primitiveLicense = null;
		Date licenseDate = null;
		try {
			primitiveLicense = new LicenseKeyUtils().decrypt(ecryptedLicenseKey, openSesame);
		} catch (Exception e) {
			logger.error(e);
			return false;
		}
		String[] data = primitiveLicense.split(LicenseKeyUtils.SPLIT_CHAR);
		Date now = DateUtils.getCurrentDate();
		try {
			licenseDate = DateUtils.parseToDate(data[1], LicenseKeyUtils.LICENSE_DATE_PATTERN);
		} catch (ApplicationException e) {
			logger.error(e);
			return false;
		}
		// APサーバのシステム日付 > ライセンス日付 場合
		if (now.after(licenseDate)) {
			return false;
		}
		return true;
	}

	/**
	 *
	 * get table count
	 *
	 * @param ecryptedLicenseKey
	 * @return
	 */
	public static String getCnt(String ecryptedLicenseKey, String openSesame) {
		try {
			return new LicenseKeyUtils().decrypt(ecryptedLicenseKey, openSesame).split(LicenseKeyUtils.SPLIT_CHAR)[2];
		} catch (Exception e) {
			logger.error(e);
			return "";
		}
	}
	// ADD ライセンス認証と外部認証連携の機能追加 ↑
}
