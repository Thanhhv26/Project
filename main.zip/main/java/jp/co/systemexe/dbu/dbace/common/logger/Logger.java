/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.logger;

/**
 * ロガーのインターフェース定義。
 * <p>将来的なロガーの拡張・変更に備え、インターフェースを独自に定義します。</p>
 * 
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public interface Logger {
	
    /**
     * ステータス FATAL でログを出力します。
     * <p></p>
     * 
     * @param obj ログとして出力する内容です。
     */
    void fatal(final Object obj);

    /**
     * ステータス FATAL でログを出力します。
     * <p></p>
     * 
     * @param obj ログとして出力する内容です。
     * @param te スタックトレースを出力するThrowableオブジェクトです。
     */
    void fatal(final Object obj, final Throwable te);

    /**
     * ステータス ERROR でログを出力します。
     * <p></p>
     * 
     * @param obj ログとして出力する内容です。
     */
    void error(final Object obj);

    /**
     * ステータス ERROR でログを出力します。
     * <p></p>
     * 
     * @param obj ログとして出力する内容です。
     * @param te スタックトレースを出力するThrowableオブジェクトです。
     */
    void error(final Object obj, final Throwable te);

    /**
     * ステータス WARN でログを出力します。
     * <p></p>
     * 
     * @param obj ログとして出力する内容です。
     */
    void warn(final Object obj);

    /**
     * ステータス WARN でログを出力します。
     * 
     * @param obj ログとして出力する内容です。
     * @param te スタックトレースを出力するThrowableオブジェクトです。
     */
    void warn(final Object obj, final Throwable te);

    /**
     * ステータス INFO でログを出力します。
     * <p></p>
     * 
     * @param obj ログとして出力する内容です。
     */
    void info(final Object obj);

    /**
     * ステータス INFO でログを出力します。
     * <p></p>
     * 
     * @param obj ログとして出力する内容です。
     * @param te スタックトレースを出力するThrowableオブジェクトです。
     */
    void info(final Object obj, final Throwable te);

    /**
     * ステータス DEBUG でログを出力します。
     * <p></p>
     * 
     * @param obj ログとして出力する内容です。
     */
    void debug(final Object obj);

    /**
     * ステータス DEBUG でログを出力します。
     * <p></p>
     * 
     * @param obj ログとして出力する内容です。
     * @param te スタックトレースを出力するThrowableオブジェクトです。
     */
    void debug(final Object obj, final Throwable te);

    /**
     * ログレベルがDEBUGか否かを返します。
     * 
     * @return
     */
    boolean isDebugEnabled();
}
