/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.SystemConnectDefinision;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 接続定義情報の削除処理。
 * <p>
 * 接続定義情報の削除のため、リポジトリから接続定義情報を取得します。</p>
 *
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class DeletionOfConnectDefinitionLogic
        extends BaseApplicationDomainLogic {

    /**
     * 接続定義情報の削除処理。
     * 
     * @param connectDefinitionId
     */
    public void remove(final String connectDefinitionId)
            throws ApplicationDomainLogicException {
        if (SystemConnectDefinision.SYSTEM == SystemConnectDefinision
            .idOf(connectDefinitionId)) {
            throw new ApplicationDomainLogicException(
                "システム管理接続定義情報は削除できません。");
        }

        ConnectDefinisionDAO defDao = createConnectDefinisionDAO();
        try {
            defDao.remove(connectDefinitionId);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

    }

    /**
     * DeletionOfConnectDefinitionLogic.java の生成。
     * <p>コンストラクタ。</p>
     * 
     */
    public DeletionOfConnectDefinitionLogic() {
        super();
    }

    /**
     * 接続定義情報 DAO を生成して戻す。
     * 
     * @return ConnectDefinisionDAO
     * @throws ApplicationDomainLogicException
     */
    private ConnectDefinisionDAO createConnectDefinisionDAO()
            throws ApplicationDomainLogicException {
        try {
            return (ConnectDefinisionDAO)createDAO("ConnectDefinisionDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

}
