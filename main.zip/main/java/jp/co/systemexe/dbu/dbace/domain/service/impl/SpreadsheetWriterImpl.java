/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.util.CellReference;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.util.UUIDKeyGenerator;
import jp.co.systemexe.dbu.dbace.domain.service.SpreadsheetWriter;

public class SpreadsheetWriterImpl implements SpreadsheetWriter {

	private static final String XML_ENCODING = "UTF-8";

	private Writer _out;
	private int _rownum;

	public SpreadsheetWriterImpl(Writer out) throws IOException {
		_out = out;

	}

	/**
	 * データを削除
	 *
	 * @throws IOException
	 */
	public void clearBuff() throws IOException {

	}

	/**
	 * 出力ロジックの途中でチェックするようにするために xmlファイル再作成
	 */
	public void reOpenFile(String path) throws IOException {

		UUIDKeyGenerator generator = new UUIDKeyGenerator();
		String filePath = SystemProperties.getImportTempFilePath() + File.separator + generator.nextKeyValue() + "."
				+ "xml";

		File temp = new File(filePath);
		FileUtils.copyFile(new File(path), temp);

		_out = new OutputStreamWriter(new FileOutputStream(path), XML_ENCODING);

		FileReader fileReader = new FileReader(temp);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		String line;
		while ((line = bufferedReader.readLine()) != null) {
			if (!"</sheetData>".equals(line) && !"</worksheet>".equals(line)
					&& !"</sheetData></worksheet>".equals(line)) {
				_out.write(line);
			}
		}
		_out.flush();
		fileReader.close();
		temp.delete();
	}

	@Override
	public SpreadsheetWriter closeFile() throws IOException {
		_out.close();
		return this;
	}

	@Override
	public SpreadsheetWriter beginSheet() throws IOException {
		String beginSheet = "<?xml version=\"1.0\" encoding=\"" + XML_ENCODING + "\"?>"
				+ "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">";
		String tagSheetBegin = "<sheetData>\n";
		_out.write(beginSheet);
		_out.write(tagSheetBegin);

		return this;
	}

	@Override
	public SpreadsheetWriter endSheet() throws IOException {
		String tagSheetEnd = "</sheetData>";
		String tagWorkSheetEnd = "</worksheet>";
		_out.write(tagSheetEnd);
		_out.write(tagWorkSheetEnd);

		closeFile();
		return this;
	}

	/**
	 * Insert a new row
	 *
	 * @param rownum
	 *            0-based row number
	 */
	@Override
	public SpreadsheetWriter insertRow(int rownum) throws IOException {
		String rowData = "<row r=\"" + (rownum + 1) + "\">\n";
		_out.write(rowData);

		this._rownum = rownum;

		return this;
	}

	/**
	 * Insert row end marker
	 */
	@Override
	public SpreadsheetWriter endRow() throws IOException {
		String tagRowEnd = "</row>\n";
		_out.write(tagRowEnd);

		return this;
	}

	@Override
	public SpreadsheetWriter createCell(int columnIndex, String value, int styleIndex) throws IOException {
		String ref = new CellReference(_rownum, columnIndex).formatAsString();
		_out.write("<c r=\"" + ref + "\" t=\"inlineStr\"");

		if (styleIndex != -1) {
			_out.write(" s=\"" + styleIndex + "\"");
		}
		_out.write(">");

		_out.write("<is><t>" + "<![CDATA[" + value + "]]>" + "</t></is>");

		_out.write("</c>");

		return this;
	}

	@Override
	public SpreadsheetWriter createCell(int columnIndex, String value) throws IOException {
		createCell(columnIndex, value, -1);

		return this;
	}

	@Override
	public SpreadsheetWriter createCell(int columnIndex, double value, int styleIndex) throws IOException {
		String ref = new CellReference(_rownum, columnIndex).formatAsString();
		_out.write("<c r=\"" + ref + "\" t=\"n\"");

		if (styleIndex != -1) {
			_out.write(" s=\"" + styleIndex + "\"");
		}
		_out.write(">");

		_out.write("<v>" + "<![CDATA[" + value + "]]>" + "</v>");

		_out.write("</c>");

		return this;
	}

	@Override
	public SpreadsheetWriter createCell(int columnIndex, double value) throws IOException {
		createCell(columnIndex, value, -1);

		return this;
	}

	@Override
	public SpreadsheetWriter createCell(int columnIndex, Calendar value, int styleIndex) throws IOException {
		createCell(columnIndex, DateUtil.getExcelDate(value, false), styleIndex);

		return this;
	}

	@Override
	public SpreadsheetWriter createCell(int columnIndex, Calendar value) throws IOException {
		createCell(columnIndex, value, -1);

		return this;
	}
}
