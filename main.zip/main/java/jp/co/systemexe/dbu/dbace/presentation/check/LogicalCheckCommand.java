/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.presentation.check.command.AlphabetCannotBeInputCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.AlphabetLowercaseCannotBeInputCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.AlphabetUppercaseCannotBeInputCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.EmptyCannotBeInputCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.FullWidthCharaterCannotBeInputCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.HalfWidthCharacterCannotBeInputCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.ListItemOtherThanCannotBeInputCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.NotContainWhitespaceBackAndForthCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.NotNullCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.NumCannotBeInputCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.OnlyDateFormatCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.OnlyFigureAndAlphabetCheckCommand;
import jp.co.systemexe.dbu.dbace.presentation.check.command.OnlyFigureCheckCommand;

/**
 * 論理チェックコマンド。
 * <p>
 * カラム名と入力値を受け取り、論理チェックを実行します。チェックの結果は DTO に
 * 設定して戻します。
 * </p><p>
 * 本クラスはコマンドパターンで設計されています。新たにチェックコマンドを作成
 * した場合には、内部に定義されたコマンドキャッシュに登録して下さい。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public final class LogicalCheckCommand {

    /**
     * コマンドキャッシュ。
     * <p>作成したチェックコマンドは全てここに登録します。</p>
     */
    private static final List<BaseLogicalCheckCommand> commandList;
    static {
        commandList = new ArrayList<BaseLogicalCheckCommand>();
        commandList.add(new AlphabetCannotBeInputCheckCommand());
        commandList.add(new AlphabetUppercaseCannotBeInputCheckCommand());
        commandList.add(new AlphabetLowercaseCannotBeInputCheckCommand());
        commandList.add(new EmptyCannotBeInputCheckCommand());
        commandList.add(new HalfWidthCharacterCannotBeInputCheckCommand());
        commandList.add(new NumCannotBeInputCheckCommand());
        commandList.add(new NotNullCheckCommand());
        commandList.add(new OnlyDateFormatCheckCommand());
        commandList.add(new OnlyFigureAndAlphabetCheckCommand());
        commandList.add(new OnlyFigureCheckCommand());
        commandList.add(new NotContainWhitespaceBackAndForthCheckCommand());
        commandList.add(new FullWidthCharaterCannotBeInputCheckCommand());
        commandList.add(new ListItemOtherThanCannotBeInputCheckCommand());
        // TODO 文字列長さチェックは仕様再検討。詳細はコマンド内部のコメントを参照。
        //        commandList.add(new StringLengthCheckCommand());
    }

    private ColumnDisplayDefinitionDTO displayDef = null;
    /**
     * 検査を実行します。
     * <p>
     * 入力値検査を実行します。検査対象値はカラム名と入力値のマップで設定します。
     * </p><p>
     * 検査結果は DTO で戻します。DTO には検査結果を評価する評価メソッドが定義
     * されています。
     * </p><p>
     * また、各コマンドが自動的に値補正をする場合があります。本メソッドでは補正
     * 値の初期化も行っています。
     * </p>
     *
     * @param columns
     * @return CheckMessageDTO
     */
    public CheckMessageDTO check(final DbConnectInfomationDTO dbConnectInfomationDTO, final Map<String, String> columnIdAndValue,final Map<String, TableItemDTO>  tableItemMap) {
        final CheckMessageDTO ret = new CheckMessageDTO();
        for (final String columnId : columnIdAndValue.keySet()) {
        	ret.appendColumn(columnId);
            ret.setCorrectedValue(columnId, columnIdAndValue.get(columnId));
            executeCommands(dbConnectInfomationDTO, columnId, columnIdAndValue, ret,tableItemMap);
        }
        return ret;
    }

    /**
     * 検査を実行します。
     * <p>
     * 入力値検査を実行します。検査対象値はカラム名と入力値のマップで設定します。
     * </p><p>
     * 検査結果は DTO で戻します。DTO には検査結果を評価する評価メソッドが定義
     * されています。
     * </p><p>
     * また、各コマンドが自動的に値補正をする場合があります。本メソッドでは補正
     * 値の初期化も行っています。
     * </p>
     *
     * @param columns
     * @return CheckMessageDTO
     */
    public CheckMessageDTO checkDataImport(final DbConnectInfomationDTO dbConnectInfomationDTO, final Map<String, String> columnIdAndValue,
    		final Map<String, TableItemDTO>  tableItemMap) {
//        final CheckMessageDTO ret = new CheckMessageDTO();
    	Map<String, String> allColumnIdAndValues = new HashMap<String, String>(columnIdAndValue);
		for (final String columnId : displayDef.getItemDefinitions().keySet()) {
			if (!allColumnIdAndValues.containsKey(columnId)) {
				allColumnIdAndValues.put(columnId, null);
			}
		}
        return check(dbConnectInfomationDTO, allColumnIdAndValues,tableItemMap);
    }

    /**
     * 各コマンドによるチェックを実行します。
     *
     * @param columnId
     * @param columnValue
     * @param messages
     */
    private void executeCommands(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
            final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap) {
        for (final Iterator<BaseLogicalCheckCommand> ite = commandList
            .iterator(); ite.hasNext();) {
            final BaseLogicalCheckCommand command = ite.next();
            if (command.isCharge(columnId)) {
                command.check(dbConnectInfomationDTO, columnId, columnIdAndValue, messages,tableItemMap);
            }
        }
    }

    /**
     * LogicalCheckCommand の生成。
     * <p>
     * 検査項目の確定、検査条件の保持のため項目表示定義 DTO を受け取り、検査
     * コマンドに参照を設定します。
     * </p>
     *
     * @param displayDef 項目表示定義 DTO
     */
    public LogicalCheckCommand(final ColumnDisplayDefinitionDTO displayDef) {
    	this.displayDef = displayDef;
        for (final Iterator<BaseLogicalCheckCommand> ite = commandList
            .iterator(); ite.hasNext();) {
            ite.next().init(displayDef);
        }
    }
}
