/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.exception;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * システムリソース未発見例外。
 * <p>
 * アプリケーションの動作に必要なシステムリソースが存在しない場合の例外。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class SystemResourceNotFoundException extends SystemException {
    final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    /**
     * <code>serialVersionUID</code>。
     */
    private static final long serialVersionUID = 2093310050093849637L;

    /**
     * SystemResourceNotFoundException の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param message
     */
    public SystemResourceNotFoundException(final String message) {
        super(message);
        logger.error(super.getMessage());
    }

    /**
     * SystemResourceNotFoundException の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param message
     * @param te
     */
    public SystemResourceNotFoundException(final String message,
            final Throwable te) {
        super(message, te);
        logger.error(te.getMessage());
    }

    /**
     * SystemResourceNotFoundException の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param te
     */
    public SystemResourceNotFoundException(final Throwable te) {
        super(te);
        logger.error(te.getMessage());
    }
}
