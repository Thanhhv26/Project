/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfTableLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfAppRelationLogic;
import jp.co.systemexe.dbu.dbace.domain.service.CreationService;
import jp.co.systemexe.dbu.dbace.library.service.AbstractService;
import jp.co.systemexe.dbu.dbace.persistance.dao.CreationDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.xml.AppRepository;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.ConnectDefinision;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForms;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ConnectionDefinisionDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.DbConnectDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormsDto;
import jp.co.systemexe.dbu.dbace.web.creation.json.FRM0330JsonInsert;
import jp.co.systemexe.dbu.dbace.web.creation.json.FRM0330JsonSearch;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationInformation;

/**
 * @author van-thanh
 *
 */

/**
 *
 *
 */
@Service
public class CreationServiceImpl extends AbstractService implements CreationService {

	private static final long serialVersionUID = 1L;

	@Autowired
	CreationDAO creationDAO;

	/*
	 * get all TableForm in all connections
	 * justTableMulti = 1 => just get table multi
	 * justTableMulti = -1 => just get table normal
	 * justTableMulti = 0 => get all
	 * return result <= List<ConnectionDefinisionDto>
	 * (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#getConnectionList(boolean)
	 */
	@Override
	public List<ConnectionDefinisionDto> getConnectionList(int justTableMulti,UserAuthority userAuthority) {
		List<ConnectDefinision> connections;
		try {
			connections = creationDAO.getAllConnection();
		} catch (ApplicationDomainLogicException e) {
			return null;
		}
		List<ConnectionDefinisionDto> result = new ArrayList<ConnectionDefinisionDto>();
		List<ConnectionDefinisionDto> resultAuthor = new ArrayList<ConnectionDefinisionDto>();
		if(connections != null && connections.size() > 0){
			for(ConnectDefinision item : connections){
				ConnectionDefinisionDto dto = new ConnectionDefinisionDto();
				dto.setId(item.getId());
				dto.setLabel(item.getLabel());
				if(item.getDbConnect() !=null){
					dto.setDbConnectDto(new DbConnectDto(item.getDbConnect()));
				}
				if(item.getTableForms() !=null){
					TableForms tableForms = item.getTableForms();
					List<TableForm> tableFormList = tableForms.getTableForm();
					List<TableForm> tableFormListTemp = new ArrayList<TableForm>();
					if(justTableMulti == 1){//just get table multi
						for(TableForm tableForm : tableFormList){
							if(StringUtils.isNotBlank(tableForm.getType())){
								tableFormListTemp.add(tableForm);
							}
						}
						item.getTableForms().setTableForm(tableFormListTemp);
						dto.setTableFormsDto(new TableFormsDto(item.getTableForms()));
					}else if(justTableMulti == -1){//just get table normal
						for(TableForm tableForm : tableFormList){
							if(StringUtils.isBlank(tableForm.getType())){
								tableFormListTemp.add(tableForm);
							}
						}
						item.getTableForms().setTableForm(tableFormListTemp);
						dto.setTableFormsDto(new TableFormsDto(item.getTableForms()));
					}else if(justTableMulti == 0){//get all
						dto.setTableFormsDto(new TableFormsDto(item.getTableForms()));
					}
				}
				result.add(dto);
			}
		}
		if (userAuthority.isSystemAdministrator()) {
			return result;
		} else {
			for (ConnectDefinisionAuthority connectDefinisionAuthority : userAuthority.getConnectDefinisionAuthoritys()) {
				String connectDefinisionId = connectDefinisionAuthority.getConnectDefinisionId();
				for(ConnectionDefinisionDto connectionDefinisionDto:result){
					if(connectDefinisionId.equals(connectionDefinisionDto.getId())){
						resultAuthor.add(connectionDefinisionDto);
					}
				}
			}
		}
		return resultAuthor;
	}

	@Override
	public ConnectionDefinisionDto getConnectionById(String id, int justTableMulti,UserAuthority userAuthority) {
		//param -1 is not get table multi
		ConnectionDefinisionDto result = null;
		List<ConnectionDefinisionDto> connections = this.getConnectionList(justTableMulti,userAuthority);
		if(connections != null && connections.size() > 0){
			for(ConnectionDefinisionDto connection : connections){
				if(connection.getId().equals(id)){
					result = connection;
					break;
				}
			}
		}
		return result;
	}
	
	@Override
	public ConnectionDefinisionDto getConnectionByLabel(String label, int justTableMulti,UserAuthority userAuthority) {
		//param -1 is not get table multi
		ConnectionDefinisionDto result = null;
		List<ConnectionDefinisionDto> connections = this.getConnectionList(justTableMulti,userAuthority);
		if(connections != null && connections.size() > 0){
			for(ConnectionDefinisionDto connection : connections){
				if(connection.getLabel().equals(label)){
					result = connection;
					break;
				}
			}
		}
		return result;
	}

	/*
	 * get table multi by condition search
	 *
	 * (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#getAllTableMulti(jp.co.systemexe.dbu.dbace.web.creation.json.FRM0330JsonSearch)
	 */
	@Override
	public Map<String, TableFormDto> getAllTableMulti(FRM0330JsonSearch paramSearch) {
		List<ConnectionDefinisionDto> connections = this.getConnectionList(1,paramSearch.getUserAuthority());//just get table multi
		Map<String, TableFormDto> tableFormMultiList = new HashMap<String, TableFormDto>();
		if(connections == null){
			return null;
		}
		if (paramSearch.getUserAuthority().isSystemAdministrator()) {
			for(ConnectionDefinisionDto connectionItem : connections){
				if(connectionItem.getTableFormsDto() != null){
					for(TableFormDto tableFormDtoItem : connectionItem.getTableFormsDto().getTableFormDtoList()){
						if(tableFormDtoItem != null && StringUtils.isNotBlank(tableFormDtoItem.getType())){
							if(StringUtils.isBlank(paramSearch.getTableMultiName())
									|| connectionItem.getLabel().toLowerCase().contains(paramSearch.getTableMultiName().toLowerCase())
									|| tableFormDtoItem.getLabel().toLowerCase().contains(paramSearch.getTableMultiName().toLowerCase())
									|| tableFormDtoItem.getDiscription().toLowerCase().contains(paramSearch.getTableMultiName().toLowerCase())){
								String key = connectionItem.getId() + "@#$%" + connectionItem.getLabel() + "@#$%" + tableFormDtoItem.getId();
								tableFormDtoItem.setConnectionId(connectionItem.getId());
								tableFormDtoItem.setConnectionLabel(connectionItem.getLabel());
								tableFormMultiList.put(key, tableFormDtoItem);
							}
						}
					}
				}
			}
		} else {
			for (ConnectDefinisionAuthority connectDefinisionAuthority : paramSearch.getUserAuthority().getConnectDefinisionAuthoritys()) {
				String connectDefinisionId = connectDefinisionAuthority.getConnectDefinisionId();
				for(ConnectionDefinisionDto connectionItem : connections){
					if (connectDefinisionId.equals(connectionItem.getId())) {
						if(connectionItem.getTableFormsDto() != null){
							for(TableFormDto tableFormDtoItem : connectionItem.getTableFormsDto().getTableFormDtoList()){
								if(tableFormDtoItem != null && StringUtils.isNotBlank(tableFormDtoItem.getType())){
									if(StringUtils.isBlank(paramSearch.getTableMultiName())
											|| connectionItem.getLabel().toLowerCase().contains(paramSearch.getTableMultiName().toLowerCase())
											|| tableFormDtoItem.getLabel().toLowerCase().contains(paramSearch.getTableMultiName().toLowerCase())
											|| tableFormDtoItem.getDiscription().toLowerCase().contains(paramSearch.getTableMultiName().toLowerCase())){
										String key = connectionItem.getId() + "@#$%" + connectionItem.getLabel() + "@#$%" + tableFormDtoItem.getId();
										tableFormDtoItem.setConnectionId(connectionItem.getId());
										tableFormDtoItem.setConnectionLabel(connectionItem.getLabel());
										tableFormMultiList.put(key, tableFormDtoItem);
									}
								}
							}
						}
					}
				}
			}
		}
		return tableFormMultiList;
	}

	/*
	 *
	 *
	 * (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#insertTableMulti(java.lang.String, jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto)
	 */
	@Override
	public void insertTableMulti(FRM0330JsonInsert param) throws DAOException {
		String databaseName = "";
		try {
			AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
			TableFormDAO tableFormDAO;

			tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
			tableFormDAO.saveTableMulti(param.getConnectionIdUIRD(), param.getTableUIRD());

			databaseName = this.getConnectionById(param.getConnectionIdUIRD(), 0, param.getUserAuthority()).getLabel();//databaseName
			OutputAuditLog.writeMakeViewLog(
					param.getUserInfo(), //userInfo
					AuditStatus.success,
					databaseName,//databaseName
					param.getTableUIRD().getLabel(),
					AuditEventKind.INSERT,
					String.valueOf(1));
		} catch (ApplicationDomainLogicException e) {
			OutputAuditLog.writeMakeViewLog(
					param.getUserInfo(), //userInfo
					AuditStatus.failure,
					databaseName,//databaseName
					param.getTableUIRD().getLabel(),
					AuditEventKind.INSERT,
					String.valueOf(1));
			throw new DAOException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#updateTableMulti(java.lang.String, jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto)
	 */
	@Override
	public void updateTableMulti(FRM0330JsonInsert param) throws DAOException {
		String databaseName = "";
		try {
			AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
			TableFormDAO tableFormDAO;

			tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
			tableFormDAO.remove(param.getConnectionIdUIRD(), param.getTableUIRD().getId());
			tableFormDAO.saveTableMulti(param.getConnectionIdUIRD(), param.getTableUIRD());

			databaseName = this.getConnectionById(param.getConnectionIdUIRD(), 0, param.getUserAuthority()).getLabel();//databaseName
			OutputAuditLog.writeMakeViewLog(
					param.getUserInfo(), //userInfo
					AuditStatus.success,
					databaseName,//databaseName
					param.getTableUIRD().getLabel(),
					AuditEventKind.UPDATE,
					String.valueOf(1));
		} catch (ApplicationDomainLogicException e) {
			OutputAuditLog.writeMakeViewLog(
					param.getUserInfo(), //userInfo
					AuditStatus.failure,
					databaseName,//databaseName
					param.getTableUIRD().getLabel(),
					AuditEventKind.UPDATE,
					String.valueOf(1));
			throw new DAOException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#removeTableMulti(java.lang.String, java.lang.String)
	 */
	@Override
	public void removeTableMulti(FRM0330JsonInsert param) throws DAOException {
		try {
			AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
			TableFormDAO tableFormDAO;

			tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
			tableFormDAO.remove(param.getD_connectionID(), param.getD_tableID());			
		} catch (ApplicationDomainLogicException e) {			
			throw new DAOException(e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#getAllRelationDTO()
	 */
	@Override
	public List<RelationInformation> getAllRelationInformationList() {
		Map<String, RelationInformation> relations = this.getAllRelationInformationMap();
		List<RelationInformation> result = new ArrayList<RelationInformation>();
		if(relations != null && relations.size() > 0){
			for (String key : relations.keySet()) {
				RelationInformation temp = relations.get(key);
				result.add(temp);
			}
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#getAllRelationInformationMap()
	 */
	@Override
	public Map<String, RelationInformation> getAllRelationInformationMap() {
		final PreservationOfAppRelationLogic logic = new PreservationOfAppRelationLogic();
		Map<String, RelationInformation> result;
		try {
			result = logic.getRelationInformationMap();
		} catch (final ApplicationDomainLogicException e) {
			result = new HashMap<String, RelationInformation>();
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#checkFileRepositoryExist()
	 */
	@Override
	public boolean checkFileRepositoryExist() {
		final AppRepository appRepository = AppRepository.getInstance();
		if(!appRepository.getFile().exists()){
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#checkTableLabelExist(java.lang.String, java.lang.String)
	 */
	@Override
	public boolean checkTableLabelExist(String connectionID, String tableID, String tableLabel) {
		List<ConnectDefinision> connections;
		try {
			connections = creationDAO.getAllConnection();
		} catch (ApplicationDomainLogicException e) {
			return false;
		}
		if(connections != null && connections.size() > 0){
			for(ConnectDefinision item : connections){
				/*if(item.getId().equals(connectionID)){*/
				if(item.getTableForms() != null && item.getTableForms().getTableForm() != null){
					for(TableForm item1 : item.getTableForms().getTableForm()){
						if(item1.getLabel().equals(tableLabel) && !item1.getId().equals(tableID)){
							return true;
						}
					}
				}					
				/*}*/
			}
		}
		return false;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.CreationService#checkFormatFileRepositoryXml()
	 */
	/*@Override
	public boolean checkFormatFileRepositoryXml() {
		boolean flag = true;
		try {
			flag = creationDAO.checkFormatFileRepositoryXml();
		} catch (ApplicationDomainLogicException e) {
			return !flag;
		}
		return flag;
	}*/

	/**
     * @return UserInfo
     */
	/*@Override
    public UserInfo getUserInfo(){
    	MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    	UserInfo userInfo = myUserDetails.getUserInfo();
        return userInfo;
    }*/

	/**
     * @return databaseLabel
     */
	/*@Override
    public String getDatabaseIDByConnectionID(final String connectionID){
		ConnectionDefinisionDto connection = this.getConnectionById(connectionID, 0);
		String databaseLabel = connection.getDbConnectDto().getDatabase().getId();
        return databaseLabel;
    }*/
	
	@Override
	public TableFormDto getTableFormDtoByLabel(String connectionId, String tableLabel, UserAuthority userAuthority) {
		//param -1 is not get table multi
		ConnectionDefinisionDto connection = this.getConnectionById(connectionId, 0, userAuthority);
		TableFormDto result = null;
		
		if(connection != null 
				&& connection.getTableFormsDto() != null ){
			for(TableFormDto item : connection.getTableFormsDto().getTableFormDtoList()){
				if(item.getLabel().equals(tableLabel)){
					result = item;
					result.setConnectionId(connection.getId());
					result.setConnectionLabel(connection.getLabel());
					break;
				}
			}
		}
		
		return result;
	}
	
	@Override
	public TableFormDto getTableFormDtoByID(String connectionId, String tableID, UserAuthority userAuthority) {
		//param -1 is not get table multi
		ConnectionDefinisionDto connection = this.getConnectionById(connectionId, 0, userAuthority);
		TableFormDto result = null;
		
		if(connection != null 
				&& connection.getTableFormsDto() != null ){
			for(TableFormDto item : connection.getTableFormsDto().getTableFormDtoList()){
				if(item.getId().equals(tableID)){
					result = item;
					result.setConnectionId(connection.getId());
					result.setConnectionLabel(connection.getLabel());
					break;
				}
			}
		}
		
		return result;
	}
	
	/**
	 * @param connectionId
	 * @param tableID
	 * @param itemID
	 * @param userAuthority
	 * @return
	 */
	@Override
	public ItemDto getItemByID(String connectionId, String tableID, String itemID, UserAuthority userAuthority) {
		TableFormDto tableFormDto = this.getTableFormDtoByID(connectionId, tableID, userAuthority);
		ItemDto itemDto = null;
		if(tableFormDto != null && tableFormDto.getItemDtoList() != null){
			for(ItemDto item : tableFormDto.getItemDtoList()){
				if(item.getId().equals(itemID)){
					itemDto = item;
					break;
				}
			}
		}
		return itemDto;
	}

}
