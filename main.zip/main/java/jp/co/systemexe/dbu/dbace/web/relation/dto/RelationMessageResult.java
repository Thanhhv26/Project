/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.relation.dto;
import java.util.List;

import lombok.Data;
@Data
public class RelationMessageResult {
	String status;
	String message;
	// リレーション名の一覧
	List<RelationDTO> relations;
}
