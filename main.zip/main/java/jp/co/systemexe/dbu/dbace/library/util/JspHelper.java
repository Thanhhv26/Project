/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.util;

import org.springframework.util.StringUtils;

/**
 *
 * JspHelper.
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
public final class JspHelper {
	private JspHelper() {

	}

	/**
	 *
	 * Format body attribute.
	 *
	 * @param module
	 *            Module name
	 * @param ngInit
	 *            ngInit Function
	 * @param cssClass
	 *            css class
	 * @return
	 */
	public static String angularBodyAttr(String id, String module,
			String ngInit, String cssClass) {
		StringBuffer sb = new StringBuffer();

		if (!StringUtils.isEmpty(id)) {
			sb.append("id='").append(id).append("'");
		}

		if (!StringUtils.isEmpty(module)) {
			sb.append("ng-controller='").append(module).append("'");
		}

		if (!StringUtils.isEmpty(ngInit)) {
			sb.append(" ng-init='").append(ngInit).append("'");
		}

		if (!StringUtils.isEmpty(cssClass)) {
			sb.append(" class='").append(cssClass).append("'");
		}

		return sb.toString();
	}

	/**
	 *
	 * Get class active menu.
	 *
	 * @param menu
	 * @param active
	 * @return
	 */
	public static String activeClass(String menu, String active) {
		if (StringUtils.trimWhitespace(menu).equalsIgnoreCase(StringUtils.trimWhitespace(active))) {
			return "active";
		}

		return "";
	}
}
