/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jp.co.systemexe.dbu.dbace.persistance.dao.BaseConnectionManager;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;

/**
 * MySQL データベース接続マネージャ。
 * <p>
 * MySQL データベース接続のコネクションを保持するクラスです。データベース向けの DAO に
 * 対してコネクションを提供します。
 * </p><p>
 * 本アプリケーションは DAO内で自動トランザクションを実装するため、本マネージャが
 * トランザクションも保持します。</p>
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class MySQLConnectionManager extends BaseConnectionManager {

    /**
     * PostgreSQL データベースコネクションを戻します。
     * <p>
     * データベースコネクションを取得し、戻します。
     * 既にコネクションが保持されている場合はそれを戻します。<br />
     * また、初期設定として自動コミットを ON に設定しています。</p>
     *
     * @param dto 接続定義情報
     * @param connectionUserLabel 接続ユーザー（ログインユーザー表示名）
     * @return Connection
     * @exception SQLException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.BaseConnectionManager#getConnection(jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO, java.lang.String)
     */
	public Connection getConnection(
			final DbConnectInfomationDTO dto)
			throws SQLException {
        final long start = System.currentTimeMillis();
		Connection connection = getConnection();
		if (connection == null) {
			try{
				Class.forName("com.mysql.jdbc.Driver");
			} catch (final ClassNotFoundException e){
				final String message = "'com.mysql.jdbc.Driver' was not found.";
				getLogger().fatal(message, e);
				throw new SQLException(message);
			}
			connection = DriverManager.getConnection(
				createDatabaseUrl(dto),
				dto.getUserId(),
				dto.getPassword());
			connection.setAutoCommit(true);
			setConnection(connection);
		}

        if (getLogger().isDebugEnabled()) {
            getLogger().debug("Connection acquisition time :" + (System.currentTimeMillis() - start));
        }
        return connection;
	}

}
