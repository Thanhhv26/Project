/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.util;

//import ch.qos.logback.classic.pattern.ClassicConverter;
//import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * ProcessIdConverterのクラス。
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
public class ProcessIdConverter /*extends ClassicConverter*/ {

	/**
	 * Get process id
	 *
	 * @return
	 */
//	private String getPID() {
//		RuntimeMXBean rtmx = ManagementFactory.getRuntimeMXBean();
//		final String pid = rtmx.getName().split("\\@")[0];
//		return pid;
//	}

	/*
	 * (non-Javadoc)
	 *
	 * @see ch.qos.logback.core.pattern.Converter#convert(java.lang.Object)
	 */
//	@Override
//	public String convert(ILoggingEvent arg0) {
//		return getPID();
//	}

}
