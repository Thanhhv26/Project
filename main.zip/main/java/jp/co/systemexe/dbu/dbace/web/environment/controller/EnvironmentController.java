package jp.co.systemexe.dbu.dbace.web.environment.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.systemexe.dbu.dbace.common.util.LicenseKeyUtils;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingLicenseKeyDTO;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfEnvironmentSetting;
import jp.co.systemexe.dbu.dbace.domain.service.EnvironmentService;
import jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseRepositoryXmlDAO;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
import jp.co.systemexe.dbu.dbace.web.environment.dto.EnvironmentDto;
import jp.co.systemexe.dbu.dbace.web.environment.model.FRM0520ResultModel;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SearchCriteria;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;

/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 06/01/2017
 *
 */

@RestController
@RequestMapping(value = "/system/environment")
public class EnvironmentController extends AbstractController {

	/***/
	private static final long serialVersionUID = 1L;
	private static final String UNLIMITED_JA = "無制限";
	/**
	 * Environment Service
	 */
	@Autowired
	private EnvironmentService environmentService;
	/**
     * Page クラスの初期化イベントハンドラ。
	 *
	 * @return
	 */
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody EnvironmentSettingLicenseKeyDTO index(@RequestBody SearchCriteria search) throws Exception {
		final AcquisitionOfEnvironmentSetting logicEnv = new AcquisitionOfEnvironmentSetting();
		final EnvironmentSettingDTO dto = logicEnv.getAllProperties();
		int numberTableRegisteredInRepository = logicEnv.countNumberOfTableHasRegisted();
		EnvironmentSettingLicenseKeyDTO environmentSettingLicenseKeyDTO = new EnvironmentSettingLicenseKeyDTO();
		environmentSettingLicenseKeyDTO.setEnvironmentSettingDTO(dto);
		// ライセンス数が「Unlimited」文字の場合、「無制限」を表示
		if (StringUtils.isNotEmpty(dto.getLicenseCnt())
				&& LicenseKeyUtils.UNLIMITED.equalsIgnoreCase(dto.getLicenseCnt())) {
			environmentSettingLicenseKeyDTO.getEnvironmentSettingDTO().setLicenseCnt(UNLIMITED_JA);
		} else {
		// 他の文字列の場合、原則数値を表
			environmentSettingLicenseKeyDTO.getEnvironmentSettingDTO().setLicenseCnt(dto.getLicenseCnt());
		}
		environmentSettingLicenseKeyDTO.setNumberTableRegisteredInRepository(numberTableRegisteredInRepository);
		return environmentSettingLicenseKeyDTO;
	}

	@RequestMapping(value = "/doOnceSave", method = RequestMethod.POST)
	public FRM0520ResultModel updateConnect(@RequestBody EnvironmentDto environmentDto)
			throws ReflectiveOperationException {
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		BaseRepositoryXmlDAO baseRepositoryXmlDAO = new BaseRepositoryXmlDAO() {};
		MessageInfo error = new MessageInfo();
		FRM0520ResultModel resultModel = new FRM0520ResultModel();
		resultModel.setStatus(true);
		//ADD ライセンス認証 機能追加　↓
		if (StringUtils.isBlank(environmentDto.getLicenseKey())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0520.environmentSetting.licenseKey", messageService);
			error.setId("licenseKey");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else
		{
			if (!LicenseKeyUtils.isValidFormat(environmentDto.getLicenseKey(), baseRepositoryXmlDAO.openSesame())) {
				// MI-F-0021=ライセンスキーがあっていません。
				error = new MessageInfo("MI-F-0021", MessageType.ERROR, messageService);
				error.setId("licenseKey");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (!LicenseKeyUtils.isNotExpired(environmentDto.getLicenseKey(), baseRepositoryXmlDAO.openSesame())) {
					// MI-F-0022=ライセンス期限切れです。延長を希望される場合は、販売元へお問い合わせください。
					error = new MessageInfo("MI-F-0022", MessageType.ERROR, messageService);
					error.setId("licenseKey");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}
		}

		if (StringUtils.isBlank(environmentDto.getSearchMaxRecordCount())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0520.environmentSetting.searchMaxRecordCount", messageService);
			error.setId("searchMaxRecordCount");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else {
			if (!environmentDto.getSearchMaxRecordCount().matches("[0-9]*")) {
				error = new MessageInfo("FRM0520.update.maxRecord", MessageType.ERROR, messageService);
				error.setId("searchMaxRecordCount");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (Integer.valueOf(environmentDto.getSearchMaxRecordCount()) > 1000000
						|| Integer.valueOf(environmentDto.getSearchMaxRecordCount()) < 1) {
					error = new MessageInfo("FRM0520.update.maxRecord", MessageType.ERROR, messageService);
					error.setId("searchMaxRecordCount");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}
		}

		if (StringUtils.isBlank(environmentDto.getPulldownDisplayMaximumCount())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0520.environmentSetting.pulldownDisplayMaximumCount", messageService);
			error.setId("pulldownDisplayMaximumCount");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else
		{
			if (!environmentDto.getPulldownDisplayMaximumCount().matches("[0-9]*")) {
				error = new MessageInfo("FRM0520.update.max10000", MessageType.ERROR, "frm0520.environmentSetting.pulldownDisplayMaximumCount", messageService);
				error.setId("pulldownDisplayMaximumCount");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (Integer.valueOf(environmentDto.getPulldownDisplayMaximumCount()) > 10000
						|| Integer.valueOf(environmentDto.getPulldownDisplayMaximumCount()) < 1) {
					error = new MessageInfo("FRM0520.update.max10000", MessageType.ERROR, "frm0520.environmentSetting.pulldownDisplayMaximumCount", messageService);
					error.setId("pulldownDisplayMaximumCount");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}
		}

		if (StringUtils.isBlank(environmentDto.getPulldownDisplayFetchSize())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0520.environmentSetting.pulldownDisplayFetchSize", messageService);
			error.setId("pulldownDisplayFetchSize");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else
		{
			if (!environmentDto.getPulldownDisplayFetchSize().matches("[0-9]*")) {
				error = new MessageInfo("FRM0520.update.max10000", MessageType.ERROR, "frm0520.environmentSetting.pulldownDisplayFetchSize", messageService);
				error.setId("pulldownDisplayFetchSize");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (Integer.valueOf(environmentDto.getPulldownDisplayFetchSize()) > 10000
						|| Integer.valueOf(environmentDto.getPulldownDisplayFetchSize()) < 1) {
					error = new MessageInfo("FRM0520.update.max10000", MessageType.ERROR, "frm0520.environmentSetting.pulldownDisplayFetchSize", messageService);
					error.setId("pulldownDisplayFetchSize");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}
		}

		if (StringUtils.isBlank(environmentDto.getFileDownloadFetchSize())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0520.environmentSetting.fileDownloadFetchSize", messageService);
			error.setId("fileDownloadFetchSize");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else
		{
			if (!environmentDto.getFileDownloadFetchSize().matches("[0-9]*")) {
				error = new MessageInfo("FRM0520.update.max10000", MessageType.ERROR, "frm0520.environmentSetting.fileDownloadFetchSize", messageService);
				error.setId("fileDownloadFetchSize");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (Integer.valueOf(environmentDto.getFileDownloadFetchSize()) > 10000
						|| Integer.valueOf(environmentDto.getFileDownloadFetchSize()) < 1) {
					error = new MessageInfo("FRM0520.update.max10000", MessageType.ERROR, "frm0520.environmentSetting.fileDownloadFetchSize", messageService);
					error.setId("fileDownloadFetchSize");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}

		}

		if (StringUtils.isBlank(environmentDto.getDownloadMaximumByteForExcel())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0520.environmentSetting.downloadMaximumByteForExcel", messageService);
			error.setId("downloadMaximumByteForExcel");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else
		{
			if (!environmentDto.getDownloadMaximumByteForExcel().matches("[0-9]*")) {
				error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.downloadMaximumByteForExcel", messageService);
				error.setId("downloadMaximumByteForExcel");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (Integer.valueOf(environmentDto.getDownloadMaximumByteForExcel()) > 999
						|| Integer.valueOf(environmentDto.getDownloadMaximumByteForExcel()) < 1) {
					error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.downloadMaximumByteForExcel", messageService);
					error.setId("downloadMaximumByteForExcel");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}
		}

		if (StringUtils.isBlank(environmentDto.getDownloadMaximumByteForCsv())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0520.environmentSetting.downloadMaximumByteForCsv", messageService);
			error.setId("downloadMaximumByteForCsv");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else
		{
			if (!environmentDto.getDownloadMaximumByteForCsv().matches("[0-9]*")) {
				error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.downloadMaximumByteForCsv", messageService);
				error.setId("downloadMaximumByteForCsv");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (Integer.valueOf(environmentDto.getDownloadMaximumByteForCsv()) > 999
						|| Integer.valueOf(environmentDto.getDownloadMaximumByteForCsv()) < 1) {
					error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.downloadMaximumByteForCsv", messageService);
					error.setId("downloadMaximumByteForCsv");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}
		}

		if (StringUtils.isBlank(environmentDto.getImportMaximumByteForExcel())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "データの一括取込み時のファイル最大バイト(EXCEL)", messageService);
			error.setId("importMaximumByteForExcel");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else
		{
			if (!environmentDto.getImportMaximumByteForExcel().matches("[0-9]*")) {
				error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.importMaximumByteForExcel", messageService);
				error.setId("importMaximumByteForExcel");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (Integer.valueOf(environmentDto.getImportMaximumByteForExcel()) > 999
						|| Integer.valueOf(environmentDto.getImportMaximumByteForExcel()) < 1) {
					error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.importMaximumByteForExcel", messageService);
					error.setId("importMaximumByteForExcel");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}
		}

		if (StringUtils.isBlank(environmentDto.getImportMaximumByteForCsv())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0520.environmentSetting.importMaximumByteForCsv", messageService);
			error.setId("importMaximumByteForCsv");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else
		{
			if (!environmentDto.getImportMaximumByteForCsv().matches("[0-9]*")) {
				error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.importMaximumByteForCsv", messageService);
				error.setId("importMaximumByteForCsv");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (Integer.valueOf(environmentDto.getImportMaximumByteForCsv()) > 999
						|| Integer.valueOf(environmentDto.getImportMaximumByteForCsv()) < 1) {
					error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.importMaximumByteForCsv", messageService);
					error.setId("importMaximumByteForCsv");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}

		}

		if (StringUtils.isBlank(environmentDto.getImportMaximumByteForTsv())) {
			// MI-E-0008={0}は必須入力項目です。
			error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0520.environmentSetting.importMaximumByteForTsv", messageService);
			error.setId("importMaximumByteForTsv");
			messageInfoList.add(error);
			resultModel.setStatus(false);
		}
		else
		{
			if (!environmentDto.getImportMaximumByteForTsv().matches("[0-9]*")) {
				error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.importMaximumByteForTsv", messageService);
				error.setId("importMaximumByteForTsv");
				messageInfoList.add(error);
				resultModel.setStatus(false);
			}
			else
			{
				if (Integer.valueOf(environmentDto.getImportMaximumByteForTsv()) > 999
						|| Integer.valueOf(environmentDto.getImportMaximumByteForTsv()) < 1) {
					error = new MessageInfo("FRM0520.update.max999", MessageType.ERROR, "frm0520.environmentSetting.importMaximumByteForTsv", messageService);
					error.setId("importMaximumByteForTsv");
					messageInfoList.add(error);
					resultModel.setStatus(false);
				}
			}
		}

		resultModel.setMessageInfo(messageInfoList);
		if (resultModel.isStatus()== true){
			resultModel = environmentService.updateEnvironment(environmentDto);
			resultModel.setStatus(true);
		}
		return resultModel;

	}


}
