/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.BaseDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.RepositoryBackUpDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.xml.AppRepository;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * リポジトリファイル DAO。
 * <p>
 * リポジトリファイル内のデータではなく、リポジトリファイル自体に対して行うこと
 * のできる操作の実装クラスです。</p>
 *
 * @author  EXE 島田 雄一郎
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class RepositoryBackUpDAOImpl extends BaseDAO implements RepositoryBackUpDAO {
	
	public boolean isPossibleBackUp(){
        final String backuppath = getRepositoryDirectoryDath() + "back";
        final File backupdirectory = new File(backuppath);
        try{
        	if (backupdirectory.exists()) return true;
        	return backupdirectory.mkdir();
        } catch (Exception e){
            getLogger().warn(e);
        }
		return false;
	}

    /**
     * リポジトリファイルのバックアップ処理を行います。
     * <p>
     * バックアップ用リポジトリファイル保存ディレクトリは ./bak です。
     * </p>
     * <p>
     * バックアップ用リポジトリファイル名は 「"repository.xml" + yyyyMMddHHmmssSSS」 です。
     * </p>
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.RepositoryBackUpDAO#backUp()
     * @exception DAOException
     */
    public void backUp() throws DAOException {
        final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
        final File backupFile = new File(getRepositoryDirectoryDath()
                                    + "back"
                                    + System.getProperty("file.separator")
                                    + "repository.xml"
                                    + dateFormat.format(new Date()));
        final AppRepository appRepository = AppRepository.getInstance();
        final BufferedReader reader;
        try {
            reader = new BufferedReader(new InputStreamReader(appRepository
                .getInputStream(), "UTF8"));
        } catch (final UnsupportedEncodingException e) {
        	// MI-F-0018=ファイル出力時のエンコード設定に失敗しました。{0} は指定できません。
        	final String args[] = {"UTF8"};
            final String message = MessageUtils.getMessage("MI-F-0018", args);
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        } catch (final FileNotFoundException e) {
        	// MI-F-0014=リポジトリXMLファイルが存在しません。
            final String message = MessageUtils.getMessage("MI-F-0014");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
        final BufferedWriter writer;
        try {
            writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(backupFile), "UTF8"));
        } catch (final UnsupportedEncodingException e) {
            throw new DAOException(e);
        } catch (final FileNotFoundException e) {
        	// MI-F-0012=リポジトリXMLバックアップファイルが存在しません。
            final String message = MessageUtils.getMessage("MI-F-0012");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
        final char[] buf = new char[1024];
        int i = 0;
        try {
            while ((i = reader.read(buf)) != -1) {
                try {
                    writer.write(buf, 0, i);
                } catch (final IOException e) {
                	// MI-F-0013=リポジトリXMLバックアップファイルの出力に失敗しました。
                    final String message = MessageUtils.getMessage("MI-F-0013");
                    getLogger().fatal(message, e);
                    throw new DAOException(message, e);
                }
            }
        } catch (final IOException e) {
        	// MI-F-0013=リポジトリXMLバックアップファイルの出力に失敗しました。
            final String message = MessageUtils.getMessage("MI-F-0013");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                reader.close();
            } catch (final IOException e) {
                getLogger().warn(e);
            }
            try {
                writer.close();
            } catch (final IOException e) {
                getLogger().warn(e);
            }
        }
    }

    /**
     * リポジトリバックアップファイルを削除します。
     * 
     * @param List<String> fileForDeletion 削除対象ファイルリスト
     */
    public void delete(List<String> fileForDeletion) {
        final String repositoryBackUpDirectoryPath = getRepositoryDirectoryDath()
                                                        + "back"
                                                        + System.getProperty("file.separator");
        
        for (String deletionFile : fileForDeletion) {
            final File file = new File(repositoryBackUpDirectoryPath + deletionFile);
            file.delete();
        }
    }

    /**
     * リポジトリバックアップファイルのリストを取得します。
     * 
     * @return ret リポジトリバックアップファイル名
     */
    public List<String> getRepositoyBackUpFileNameList() {
        final String repositoryPath = getRepositoryDirectoryDath();
        final String[] fileForDeletion = new File(repositoryPath
                                            + "back"
                                            + System.getProperty("file.separator")).list();
        return (fileForDeletion == null) ? new ArrayList<String>() : Arrays.asList(fileForDeletion);
    }
    
    /**
     * リポジトリファイルが存在するディレクトリパスを返します。
     * 
     * @return String リポジトリファイルが存在するディレクトリのパス
     */
    private String getRepositoryDirectoryDath() {
        return SystemProperties.getAppRepositoryFilePath().replace("repository.xml", "");
    }

    /**
     * RepositoryBackUpDAOImpl.java の生成。
     * <p>コンストラクタ。</p>
     * 
     */
    public RepositoryBackUpDAOImpl() {
        super();
    }

}
