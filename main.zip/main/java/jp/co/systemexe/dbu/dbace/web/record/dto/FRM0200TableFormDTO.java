/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 Mar 30, 2017
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0200TableFormDTO {
	public boolean status;
	public Integer countRecord;
	public TableFormDTO tableFormDTO;
	public Map<String, String> listItem;
	public RecordEditorInformationDTO recordEditorDTO;
	public RecordSearchConditionDTO recordSearchConditionDTO;
}
