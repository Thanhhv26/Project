/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.SortedMap;

import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;

/**
 * テーブルフォーム情報の取得処理。
 * <p>
 * テーブルフォーム情報の取得取得を行うビジネスロジックです。</p>
 *
 * @author EXE 六本木 圭
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class AcquisitionOfTableLogic extends BaseApplicationDomainLogic {

    /**
     * リポジトリからテーブルフォーム情報を取得して戻します。
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブル ID
     * @return TableFormDTO
     * @throws ApplicationDomainLogicException
     */
    public TableFormDTO getTableFormDTO(final String connectDefinitionId,
            final String tableFormId) throws ApplicationDomainLogicException {

        final TableFormDAO dao = createTableFormDAO();
        final TableFormDTO ret;
        try {
            ret = dao.getTableFormDTO(connectDefinitionId, tableFormId);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return ret;
    }

    public SortedMap<String, TableForm> getTableFormsMapByConnectName(
    		final String connectDefinitionId) throws ApplicationDomainLogicException {

        final TableFormDAO dao = createTableFormDAO();
        final SortedMap<String, TableForm> ret;
        try {
            ret = dao.getTableFormsMapByConnectName(connectDefinitionId);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return ret;
    }

    /**
     * AcquisitionOfTableLogic.java の生成。
     * <p>コンストラクタ。</p>
     */
    public AcquisitionOfTableLogic() {
        super();
    }

    /**
     * テーブルフォーム DAO を生成して戻す。
     *
     * @return TableFormDAO
     * @throws ApplicationDomainLogicException
     */
    public TableFormDAO createTableFormDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
