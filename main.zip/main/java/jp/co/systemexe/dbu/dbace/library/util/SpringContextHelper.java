/**
 * Copyright 2014 SystemEXE,Inc. All Rights Reserved.
 *
 */
package jp.co.systemexe.dbu.dbace.library.util;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * WEB context helper
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
@Component
public final class SpringContextHelper implements Serializable, ApplicationContextAware {

	private static final long serialVersionUID = 1L;

	/**
	 * SLF4J
	 */
	private static final Logger logger = LoggerFactory.getLogger(SpringContextHelper.class);

	/**
	 * WEBコンテクスト
	 */
	private static ApplicationContext applicationContext = null;

	/**
	 * Initialize an instance of {@link ApplicationContext}
	 * @param appContext
	 */
	public SpringContextHelper() {}
	public SpringContextHelper(ApplicationContext appContext) {
		this.setApplicationContext(appContext);
	}

	/*
	 * (Non-Javadoc)
	 * @see org.springframework.context.ApplicationContextAware#setApplicationContext(org.springframework.context.ApplicationContext)
	 */
	@Override
	public void setApplicationContext(ApplicationContext appContext) {
		applicationContext = appContext;
	}

    /**
     * Gets bean object from servlet context
     *
     * @param beanRef
     * 		the bean name/id
     *
     * @return the bean object from servlet context
     */
    protected static Object findBean(final String beanRef) {
    	if (applicationContext != null) {
	    	try {
	    		return applicationContext.getBean(beanRef);
	    	}
	    	catch (NoSuchBeanDefinitionException e) {
	    		logger.error(e.getMessage(), e);
	    	}
	    	catch (BeansException e) {
	    		logger.error(e.getMessage(), e);
	    	}
    	}
    	return null;
    }
    /**
     * Gets bean object from servlet context
     *
     * @param beanClass
     * 		the bean class
     *
     * @return the bean object from servlet context
     */
    public static <T> T findBean(final Class<T> beanClass) {
    	return findBean(beanClass, Boolean.TRUE);
    }
    /**
     * Gets bean object from servlet context
     *
     * @param beanClass
     * 		the bean class
     * @param inherited
     * 		specifies the finder whether search bean base on the specified bean class;
     * 		if not found; it will search with the specified bean class as parent class
     *
     * @return the bean object from servlet context
     */
    @SuppressWarnings("unchecked")
	public static <T> T findBean(final Class<T> beanClass, boolean inherited) {
    	Map<String, ?> beans = null;
    	T bean = null;
    	if (applicationContext != null && beanClass != null) {
	    	try {
	    		beans = applicationContext.getBeansOfType(beanClass);
	    	}
	    	catch (BeansException e) {
	    		logger.error(e.getMessage(), e);
	    		beans = null;
	    	}
	    	if (!CollectionUtils.isEmpty(beans)) {
		    	for(final Iterator<String> it = beans.keySet().iterator(); it.hasNext();) {
		    		String beanref = it.next();
		    		Object fbean = beans.get(beanref);
		    		if (beanClass.equals(fbean.getClass())
		    				|| (inherited && BeanUtils.isInstanceOf(fbean.getClass(), beanClass))) {
		    			bean = (T) fbean;
		    			break;
		    		}
		    	}
	    	}
    	}
    	// if not found the bean with specified class but using inherited flag;
    	// then returning the found first bean
    	return bean;
    }
}
