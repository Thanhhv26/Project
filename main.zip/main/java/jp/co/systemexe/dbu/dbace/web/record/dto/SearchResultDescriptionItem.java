package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.io.Serializable;

/**
 * レコードの検索結果リスト画面要素表示用アイテム。
 * <p>
 * レコード一本に相当します。カラムの保持のため自分自身と同型の配列プロパティを
 * 定義しています。</p>
 *
 * @author EXE 相田 一英
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class SearchResultDescriptionItem implements Serializable {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 8617905067089044014L;

    /**
     * カラムに相当する明細配列。
     */
    private SearchResultDescriptionItem[] searchResultDescriptionDetailItems;

    /**
     * カラムデータプロパティ。
     */
    private String columnData;
    
    /**
     * 表示用カラムデータプロパティ。
     */
    private String columnDataLabel;

    /**
     * 表示可能かどうかの有無。
     */
    private boolean canPreview;

    /**
     * 表示可能かどうかの有無。
     */
    private boolean canDisplayPreview;

    /**
     * columnData を戻します。
     * 
     * @return String
     */
    public String getColumnData() {
        return columnData;
    }

    /**
     * columnData を設定します。
     *
     * @param String columnData 
     */
    public void setColumnData(String columnData) {
        this.columnData = columnData;
    }

    // スタブ
    //    public SearchResultDescriptionItem createItem(String option) {
    //        final SearchResultDescriptionItem item = new SearchResultDescriptionItem();
    //        item.columnData = "columnData" + option;
    //        
    //        return item;
    //    }

    /**
     * searchResultDescriptionDetailItems を戻します。
     * 
     * @return SearchResultDescriptionItem[]
     */
    public SearchResultDescriptionItem[] getSearchResultDescriptionDetailItems() {
        return searchResultDescriptionDetailItems;
    }

    /**
     * searchResultDescriptionDetailItems を設定します。
     *
     * @param SearchResultDescriptionItem[] searchResultDescriptionDetailItems 
     */
    public void setSearchResultDescriptionDetailItems(
            SearchResultDescriptionItem[] details) {
        this.searchResultDescriptionDetailItems = details;
    }

    /**
     * canPreview を戻します。
     * 
     * @return boolean
     */
    public boolean isCanPreview() {
        return canPreview;
    }

    /**
     * canPreview を設定します。
     *
     * @param boolean canPreview 
     */
    public void setCanPreview(boolean canPreview) {
        this.canPreview = canPreview;
    }

    /**
     * canDisplayPreview を戻します。
     * 
     * @return boolean
     */
    public boolean isCanDisplayPreview() {
        return canDisplayPreview;
    }

    /**
     * canDisplayPreview を設定します。
     *
     * @param boolean canDisplayPreview 
     */
    public void setCanDisplayPreview(boolean canDisplayPreview) {
        this.canDisplayPreview = canDisplayPreview;
    }

    /**
     * 表示用カラムデータプロパティ を戻します。
     * 
     * @return String
     */
    public String getColumnDataLabel() {
        return columnDataLabel;
    }

    /**
     * 表示用カラムデータプロパティ を設定します。
     *
     * @param String columnDataLabel 
     */
    public void setColumnDataLabel(String columnDataLabel) {
        this.columnDataLabel = columnDataLabel;
    }
}
