/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;

/**
 * アプリケーションユーザー情報を保持する DTO クラスです。
 * <p>
 * 本アプリケーションの利用の情報を保持する DTO です。ユーザー ID、表示名（仮名）、
 * 権限情報などを保持します。
 * </p><p>
 * 本アイテムはリポジトリの定義に従って定義されています。
 * </p>
 *
 * @author EXE 相田 一英
 * @author EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class ApplicationUserDTO {
	/**
	 * ユーザーID
	 */
    private String userId;
    
    /**
     * ユーザー表示名
     */
    private String userLabel;
    
    /**
     * パスワード
     */
    private String password;
    
    /**
     * ユーザー権限
     */
    private UserAuthority authority;
    
    /**
     * password を戻します。
     * 
     * @return String
     */
    public String getPassword() {
        return password;
    }

    /**
     * password を設定します。
     *
     * @param String password 
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * userId を戻します。
     * 
     * @return String
     */
    public String getUserId() {
        return userId;
    }

    /**
     * userId を設定します。
     *
     * @param String userId 
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * userLabel を戻します。
     * 
     * @return String
     */
    public String getUserLabel() {
        return userLabel;
    }

    /**
     * userLabel を設定します。
     *
     * @param String userLabel 
     */
    public void setUserLabel(String userLabel) {
        this.userLabel = userLabel;
    }

	/**
	 * authority を戻します。
	 * 
	 * @return UserAuthority
	 */
	public UserAuthority getAuthority() {
		return authority;
	}

	/**
	 * authority を設定します。
	 *
	 * @param UserAuthority authority 
	 */
	public void setAuthority(UserAuthority authority) {
		this.authority = authority;
	}

}
