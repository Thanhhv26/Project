/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import java.util.List;

import jp.co.systemexe.dbu.dbace.web.repository.model.ChangeColumnItem;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class ObjectSyncronizeDTO {
	private String type;//check,synchr
	private String connectDefinitionId;
	//テーブルIdとテーブル名
	private TrDTO trDTO;
	/**
     * テーブル情報の同期画面に表示する、カラム情報を保持するリスト
     */
    private List<ChangeColumnItem> changeColumnItems;
	}
