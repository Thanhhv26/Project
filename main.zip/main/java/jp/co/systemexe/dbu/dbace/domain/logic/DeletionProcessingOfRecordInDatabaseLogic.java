/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.Iterator;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.domain.BaseDbAccessApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordDeleteConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

/**
 * データベース内のレコードの削除ロジック。
 * <p>
 * レコードを一件削除するビジネスロジックです。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class DeletionProcessingOfRecordInDatabaseLogic
        extends BaseDbAccessApplicationDomainLogic {

    /**
     * 指定されたレコードを削除します。
     * <p>
     * テーブル名、プライマリキー値セットの指定に従いレコードを削除します。
     * </p><p>
     * また、リポジトリ内の定義に従い、削除キーマップを作成します。これは
     * リポジトリ内で、主キーとは独立して定義された更新キー情報をもとに、更新
     * 条件を自動的に組み立てる機能です。<br />
     * この機能により、本メソッドは主キーが存在しないようなテーブルに対しても
     * 削除処理を実行する事が出来ます。
     * </p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableId テーブル ID（テーブル名）
     * @param records レコード保持コレクション
     * @param connectionUserLabel 接続ユーザー表示名
     * @throws ApplicationDomainLogicException
     */
    public void delete(final String connectDefinitionId,
            final String tableId,
            final Map<String, String> records,
            final DbConnectInfomationDTO dbConnectInfomationDTO,
            final TableDefinitionDTO tableDef,
            final TableFormDTO tableForm,
            final UserInfo userInfo
            )
            throws ApplicationDomainLogicException {
//        final RecordSearchConditionDTO dto = new RecordSearchConditionDTO();
//        dto.setConnectDefinitionId(connectDefinitionId);
//        dto.setTableId(tableId);
//        for (final Iterator<String> ite = tableForm.getUpdateKeyList().iterator(); ite
//            .hasNext();) {
//            final String key = ite.next();
//            dto.getConditions().put(key, records.get(key));
//        }
//
//        final DatabaseTableDAO dao = createDatabaseTableDAO(
//            dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
//        try {
//            dao.connect(dbConnectInfomationDTO);
//            dao.doDelete(dto, tableDef, dbConnectInfomationDTO.getDatabaseId(), userInfo);
//        } catch (final DAOException e) {
//            throw new ApplicationDomainLogicException(e.getMessage(), e);
//        } finally {
//            try {
//                dao.close();
//            } catch (final DAOException ex) {
//                getLogger().warn(ex);
//            }
//        }
    }

    /**
     * DeletionProcessingOfRecordInDatabaseLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public DeletionProcessingOfRecordInDatabaseLogic() {
        return;
    }
}
