/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0200LoadParam {
	private String connectDefinisionId;
	private String tableId;
	private String actionType;


	private Map<String, String> currentObject;
	private UserInfo userInfo;

}
