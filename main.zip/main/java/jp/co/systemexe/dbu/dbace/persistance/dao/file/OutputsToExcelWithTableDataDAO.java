/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.SortedMap;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * テーブルデータをExcelに出力します。
 * <p>
 * 出力されるExcelのファイル名は テーブル名 + 日付(yyyy/MM/dd hh:mm:ss.SSS).xlsx になります。<br />
 * また、出力されるExcelのシート名は テーブル名 となります。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class OutputsToExcelWithTableDataDAO extends BaseOutputsToFileWithTableDataDAO {

	/**
	 * Excel Max行数
	 */
	private final int MAX_ROW_COUNT = 1048576;

	/**
	 * 現在のExcel行数
	 */
	private int rowCount = 1;

	/**
	 *
	 */
	private int sheetIndex = 1;

	/**
	 * ファイルサイズをチェックする、レコード件数
	 * <p>
	 * 初期値は1000
	 * </p>
	 */
	private int checkRecordCount = 1000;

	/**
	 * 最大出力ファイルサイズ
	 */
	private long MAX_OUTPUT_BYTES = ((long) SystemProperties.getDownloadMaximumByteForExcel()) * 1024L * 1024L;

	/**
	 * Old mode(ver 5.0)
	 */
	private XSSFWorkbook wb = null;
	private XSSFSheet sheet = null;

	/**
	 * データ出力件数
	 */
	private int recordCount = 0;

	/**
	 * OutputsToExcelWithTableDataDAO.java の生成。
	 *
	 */
	public OutputsToExcelWithTableDataDAO() {
		super();
	}

	/**
	 * エクセルの出力を行います。
	 *
	 * @param tableId
	 *            テーブル名
	 * @param def
	 *            項目表示定義 DTO
	 * @param dto
	 *            レコード検索結果 DTO
	 * @param outputStream
	 */
	@Override
	public void outputFile(
			final String tableId, 
			final SortedMap<Integer, TableItemDTO> columnId,
			final Map<String, String> columnData,
			final String dbType) throws DAOException {
		if (wb == null) {
			wb = new XSSFWorkbook();
		}

		if (rowCount == 1 || rowCount >= MAX_ROW_COUNT) {
			rowCount = 1;
			final String tableName;
			if (tableId.indexOf(".") == -1) {
				tableName = tableId;
			} else {
				tableName = tableId.substring(tableId.indexOf(".") + 1);
			}

			String sheetName = tableName.length() > 10 ? tableName.substring(0, 10) : tableName;
			sheetName += "_" + sheetIndex;
			sheet = wb.createSheet(sheetName);

			sheetIndex++;

			// ヘッダ部作成
			createHeader(columnId, sheet);
		}

		// 名細部作成
		createRow(columnId, columnData, sheet);
		//getLogger().debug(recordCount + "件目出力中");

		if (!checkFileSize()) {
			// MI-E-0147=ダウンロード件数が多すぎます。データ件数を絞り込んでください。
			final String message = MessageUtils.getMessage("MI-E-0147");
			getLogger().error(message);
			throw new DAOException(message);
		}

	}

	/**
	 * 出力するファイルサイズがシステムプロパティに設定されている、 ダウンロードファイルサイズよりも大きいかどうかをチェックします。
	 * <p>
	 * <code>wb.getBytes()</code>は処理が遅いため、初回時は10件のデータ容量を元に
	 * 最大容量に達する件数を予測します。予測した結果件数に達した場合は、実際の
	 * ファイルサイズと最大ファイルサイズを比較し、ファイルサイズが最大ファイルサイズ を超えている場合は false
	 * を最大ファイルサイズを超えていない場合は、 予測件数を再計算します。
	 * </p>
	 *
	 * @return
	 * @throws DAOException
	 */
	@Override
	public boolean checkFileSize() throws DAOException {
		if (recordCount >= checkRecordCount) {

			// hssfworkbook get all bytes
			// final long bytes = wb.getBytes().length;

			// xssfworkbook get all bytes : begin
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			try {
				wb.write(bos);
				bos.close();
			} catch (IOException e) {
				final String message = "Excelファイルの出力に失敗しました。(" + e.getMessage() + ")";
				getLogger().fatal(message, e);
				throw new DAOException(message, e);
			}
			final long bytes = bos.toByteArray().length;
			// xssfworkbook get all bytes : end

			if (bytes > MAX_OUTPUT_BYTES) {
				getLogger().debug("excel file size:" + bytes + "," + MAX_OUTPUT_BYTES);
				return false;
			} else {
				checkRecordCount = (int) (MAX_OUTPUT_BYTES / (bytes / recordCount));
				getLogger().debug("checkRecordCount:" + checkRecordCount);
				return true;
			}
		} else {
			return true;
		}
	}

	/**
	 *
	 */
	@Override
	public void write() throws DAOException {
		try {
			wb.write(getOutputStream());
		} catch (final IOException e) {
			final String message = "Excelファイルの出力に失敗しました。(" + e.getMessage() + ")";
			getLogger().fatal(message, e);
			throw new DAOException(message, e);
		} catch (final OutOfMemoryError e) {
			final String message = MessageUtils.getMessage("MI-E-0147");
			getLogger().fatal(message, e);
			throw new DAOException(message, e);
		}
	}

	/**
	 * ファイルに出力したレコード件数を返します。
	 *
	 * @return 出力レコード数
	 */
	@Override
	public int getOutputRecordCount() {
		return recordCount;
	}

	/**
	 * ヘッダ行の作成を行います。</br>
	 * Old mode(ver 5.0)
	 *
	 * @param def
	 * @param sheet
	 */
	private void createHeader(final SortedMap<Integer, TableItemDTO> columnId, final XSSFSheet sheet) {
		final XSSFRow headerRow = sheet.createRow(0);
		short headerCellIndex = 0;
		for (final Integer index : columnId.keySet()) {
			final TableItemDTO item = columnId.get(index);
			final XSSFCell cell = headerRow.createCell(headerCellIndex);
			final XSSFRichTextString richTextString = new XSSFRichTextString(item.getItemLabel());
			cell.setCellValue(richTextString);
			headerCellIndex++;
		}
	}

	/**
	 * 明細行の作成を行います。</br>
	 * Old mode(ver 5.0)
	 *
	 * @param dto
	 * @param sheetIndex
	 * @param sheet
	 */
	private void createRow(final SortedMap<Integer, TableItemDTO> columnId, final Map<String, String> columnData,
			final XSSFSheet sheet) {
		// 行の作成
		final XSSFRow detailRow = sheet.createRow(rowCount);
		short detailCellIndex = 0;
		for (final Integer index : columnId.keySet()) {
			final XSSFCell cell = detailRow.createCell(detailCellIndex);
			final XSSFRichTextString richTextString = new XSSFRichTextString(
					columnData.get(columnId.get(index).getItemId()));
			cell.setCellValue(richTextString);
			detailCellIndex++;
		}
		recordCount++;
		rowCount++;
	}

}
