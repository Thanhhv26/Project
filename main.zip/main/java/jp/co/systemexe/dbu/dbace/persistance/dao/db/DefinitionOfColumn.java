/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.db;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerUtils;

/**
 * テーブルカラム定義保持 VO。
 * <p>
 * データベース内テーブルのデータ型、（定義がある場合は）精度、その他制約情報の
 * 保持 VO です。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class DefinitionOfColumn implements Serializable{
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
     * ロガーインスタンスを保持します。
     */
    private final Logger logger;

    /**
     *
     */
    private String tableId;

    /**
     * カラム ID。
     * <p>カラム名です。</p>
     */
    private String columnId;

    /**
     * JDBC メタデータ型。
     */
    private JDBCMetaDataType jDBCMetaDataType;

    /**
     * データサイズと精度保持オブジェクト。
     */
    private DefinitionOfNumericalValue definitionOfNumericalValue = new DefinitionOfNumericalValue();

    /**
     * カラムの表示最大文字数。
     * <p>カラムの最大文字数を戻します。</p>
     */
    private int columnDisplayMaxSize;

    /**
     * 自動インクリメントフィールドか否か。
     * <p>自動インクリメントフィールドであれば参照専用となります。</p>
     */
    private boolean autoIncrement;

    /**
     * プライマリキー制約の有無。
     */
    private boolean primaryKey;

    /**
     * 外部キー制約の有無。
     */
    private boolean foreignKey;

    /**
     * ユニーク制約の有無。
     */
    private boolean unique;

    /**
     * NOT NULL 制約の有無。
     */
    private boolean notNull;

    /**
     * カラムコメント(REMARKS)
     */
    private String remarks;

    /**
     * カラムタイプ（データベースの実カラム型）
     */
    private String columnTypeName;

//    private String dataLength;
    /*
     * oracle : char , byte
     */
    private String dataUnit;

    /**
     * バーチャル・カラムか否か
     * <p>
     * Oracle 11gの場合のみ設定されます。
     * </p>
     */
    private boolean virtualColumns;

    /**
     * 自動インクリメントフィールドか否かを戻します。
     *
     * @return boolean
     */
    public boolean isAutoIncrement() {
        return autoIncrement;
    }

    /**
     * 自動インクリメントフィールドか否かを設定します。
     *
     * @param boolean autoIncrement
     */
    public void setAutoIncrement(boolean autoIncrement) {
        this.autoIncrement = autoIncrement;
    }

    /**
     * columnDisplayMaxSize を戻します。
     *
     * @return int
     */
    public int getColumnDisplayMaxSize() {
        return columnDisplayMaxSize;
    }

    /**
     * columnDisplayMaxSize を設定します。
     *
     * @param int columnDisplayMaxSize
     */
    public void setColumnDisplayMaxSize(int columnDisplayMaxSize) {
        this.columnDisplayMaxSize = columnDisplayMaxSize;
    }

    /**
     * columnId を戻します。
     *
     * @return String
     */
    public String getColumnId() {
        return columnId;
    }

    /**
     * データサイズと精度保持オブジェクトを戻します。
     *
     * @return DefinitionOfNumericalValue
     */
    public DefinitionOfNumericalValue getDefinitionOfNumericalValue() {
        return definitionOfNumericalValue;
    }

    /**
     * jDBCMetaDataType を戻します。
     *
     * @return JDBCMetaDataType
     */
    public JDBCMetaDataType getJDBCMetaDataType() {
        return jDBCMetaDataType;
    }

    /**
     * jDBCMetaDataType を設定します。
     *
     * @param JDBCMetaDataType metaDataType
     */
    public void setJDBCMetaDataType(JDBCMetaDataType metaDataType) {
        jDBCMetaDataType = metaDataType;
    }

    /**
     * foreignKey を戻します。
     *
     * @return boolean
     */
    public boolean isForeignKey() {
        return foreignKey;
    }

    /**
     * foreignKey を設定します。
     *
     * @param boolean foreignKey
     */
    public void setForeignKey(boolean foreignKey) {
        this.foreignKey = foreignKey;
    }

    /**
     * notNull を戻します。
     *
     * @return boolean
     */
    public boolean isNotNull() {
        return notNull;
    }

    /**
     * notNull を設定します。
     *
     * @param boolean notNull
     */
    public void setNotNull(boolean notNull) {
        this.notNull = notNull;
    }

    /**
     * primaryKey を戻します。
     *
     * @return boolean
     */
    public boolean isPrimaryKey() {
        return primaryKey;
    }

    /**
     * primaryKey を設定します。
     *
     * @param boolean primaryKey
     */
    public void setPrimaryKey(boolean primaryKey) {
        this.primaryKey = primaryKey;
    }

    /**
     * unique を戻します。
     *
     * @return boolean
     */
    public boolean isUnique() {
        return unique;
    }

    /**
     * unique を設定します。
     *
     * @param boolean unique
     */
    public void setUnique(boolean unique) {
        this.unique = unique;
    }

    /**
     * DefinitionOfColumn の生成。
     * <p>
     * コンストラクタ。カラム名の初期化を行います。</p>
     *
     * @param columnId カラム ID
     */
    public DefinitionOfColumn(final String columnId) {
        this.columnId = columnId;
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
    }

    /**
     * DefinitionOfColumn の生成。
     * <p>
     * コンストラクタ。カラム名の初期化を行います。</p>
     *
     * @param columnId カラム ID
     */
    public DefinitionOfColumn(final String tableId, final String columnId) {
    	this.tableId = tableId;
    	this.columnId = columnId;
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
    }

    /**
     * remarks を戻します。
     *
     * @return String
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * remarks を設定します。
     *
     * @param String remarks
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    /**
     * columnTypeName を戻します。
     *
     * @return String
     */
    public String getColumnTypeName() {
        return columnTypeName;
    }

    /**
     * columnTypeName を設定します。
     *
     * @param String columnTypeName
     */
    public void setColumnTypeName(String columnTypeName) {
        this.columnTypeName = columnTypeName;
    }

	/**
	 * virtualColumns を戻します。
	 *
	 * @return boolean
	 */
	public boolean isVirtualColumns() {
		return virtualColumns;
	}

	/**
	 * virtualColumns を設定します。
	 *
	 * @param boolean virtualColumns
	 */
	public void setVirtualColumns(boolean virtualColumns) {
		this.virtualColumns = virtualColumns;
	}

	/**
	 * クラスが保持しているプロパティ情報をログ出力します。
	 */
	public void outputDebugLog() {
		outputDebugLog(0);
	}

	/**
	 * クラスが保持しているプロパティ情報をログ出力します。
	 */
	public void outputDebugLog(int index) {
		if (logger.isDebugEnabled()) {
			final String indexString = LoggerUtils.getIndexString(index);
			logger.debug(indexString + "DefinitionOfColumn ---------- DEBUG START");
			logger.debug(indexString + "　Column ID:" + columnId);
			logger.debug(indexString + "　JDBC Meta Data Type:" + jDBCMetaDataType);
			logger.debug(indexString + "　Column Display Max Size:" + columnDisplayMaxSize);
			logger.debug(indexString + "　Auto Increment:" + autoIncrement);
			logger.debug(indexString + "　Primary Key:" + primaryKey);
			logger.debug(indexString + "　Foreign Key:" + foreignKey);
			logger.debug(indexString + "　Unique Key:" + unique);
			logger.debug(indexString + "　Not Null:" + notNull);
			logger.debug(indexString + "　Remarks:" + remarks);
			logger.debug(indexString + "　Column Type Name:" + columnTypeName);
			logger.debug(indexString + "　Virtual Columns:" + virtualColumns);
			definitionOfNumericalValue.outputDebugLog(index + 1);
			logger.debug(indexString + "DefinitionOfColumn ---------- DEBUG END");
		}
	}

//	/**
//	 * @return the dataLength
//	 */
//	public String getDataLength() {
//		return dataLength;
//	}
//
//	/**
//	 * @param dataLength the dataLength to set
//	 */
//	public void setDataLength(String dataLength) {
//		this.dataLength = dataLength;
//	}

	/**
	 * @return the dataUnit
	 */
	public String getDataUnit() {
		return dataUnit;
	}

	/**
	 * @param dataUnit the dataUnit to set
	 */
	public void setDataUnit(String dataUnit) {
		this.dataUnit = dataUnit;
	}

	public DefinitionOfColumn() {
		logger = null;
	}

	/**
	 * @return the tableId
	 */
	public String getTableId() {
		return tableId;
	}

	/**
	 * @param tableId the tableId to set
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}
}
