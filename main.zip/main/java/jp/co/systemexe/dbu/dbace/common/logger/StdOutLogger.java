/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.logger;

import java.io.File;
import java.io.FileWriter;
import java.util.Calendar;

import jp.co.systemexe.dbu.dbace.common.config.SystemDirectories;

/**
 * 標準出力を利用した簡易ロガー。
 * <p></p>
 *
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public class StdOutLogger implements Logger {

    /** 優先度DEBUGのメッセージ出力時に使用する文字列です。 */
    public static final String PRIORITY_DEBUG = "DEBUG";

    /** 優先度INFOのメッセージ出力時に使用する文字列です。 */
    public static final String PRIORITY_INFO = "INFO";

    /** 優先度WARNのメッセージ出力時に使用する文字列です。 */
    public static final String PRIORITY_WARN = "WARN";

    /** 優先度ERRORのメッセージ出力時に使用する文字列です。 */
    public static final String PRIORITY_ERROR = "ERROR";

    /** 優先度FATALのメッセージ出力時に使用する文字列です。 */
    public static final String PRIORITY_FATAL = "FATAL";

    /** 月を表示する桁数です */
    private static final int MONTH_MAX = 2;

    /** 日を表示する桁数です */
    private static final int DAY_MAX = 2;

    /** 時を表示する桁数です */
    private static final int HOUR_MAX = 2;

    /** 分を表示する桁数です */
    private static final int MINUTE_MAX = 2;

    /** 秒を表示する桁数です */
    private static final int SECOND_MAX = 2;

    /** ミリ秒を表示する桁数です */
    private static final int MILLISECOND_MAX = 3;

    /**
     * 初期化元クラス名です。
     */
    private final String className;

    /**
     * ログファイルオブジェクト。
     */
    private static File tempLog;

    /**
     * コンストラクタ。
     * <p>カテゴリ名を指定します。</p>
     * 
     * @param className カテゴリ名です。Loggerを使用するクラス名を指定してください。
     */
    StdOutLogger(final String className) {
        this.className = className;
        try {
            boolean isMakeDir = SystemDirectories.WORK_DIR.makeDir();
            final File dir = SystemDirectories.WORK_DIR.getFileObject();
            tempLog = new File(dir.getPath() + "/" + makeFileName());
            if (isMakeDir) {
                info("ログ用ディレクトリ[" + dir.getPath() + "]を新規に生成しました。");
            }
        } catch (Exception e) {
            tempLog = null;
            fatal("ログファイルの初期化に失敗しました。", e);
        }
    }

    /**
     * 優先度FATALでログを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object)
     */
    public void fatal(final Object message) {
        final String buff = formatLog(PRIORITY_FATAL, message);
        outputTempLog(buff, null);
        System.out.println(buff);
    }

    /**
     * 優先度FATALでログとスタックトレースを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @param t スタックトレースを出力する Throwable オブジェクトです。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object, java.lang.Throwable)
     */
    public void fatal(final Object message, final Throwable t) {
        final String buff = formatLog(PRIORITY_FATAL, message);
        outputTempLog(buff, t);
        stdOut(t);
    }

    /**
     * 優先度ERRORでログを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object)
     */
    public void error(final Object message) {
        final String buff = formatLog(PRIORITY_ERROR, message);
        outputTempLog(buff, null);
        System.out.println(buff);
    }

    /**
     * 優先度ERRORでログとスタックトレースを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @param t スタックトレースを出力するThrowableオブジェクトです。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object, java.lang.Throwable)
     */
    public void error(final Object message, final Throwable t) {
        final String buff = formatLog(PRIORITY_ERROR, message);
        outputTempLog(buff, t);
        stdOut(t);
    }

    /**
     * 優先度WARNでログを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object)
     */
    public void warn(final Object message) {
        final String buff = formatLog(PRIORITY_WARN, message);
        outputTempLog(buff, null);
    }

    /**
     * 優先度WARNでログとスタックトレースを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @param t スタックトレースを出力するThrowableオブジェクトです。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object, java.lang.Throwable)
     */
    public void warn(final Object message, final Throwable t) {
        final String buff = formatLog(PRIORITY_WARN, message);
        outputTempLog(buff, t);
        stdOut(t);
    }

    /**
     * 優先度INFOでログを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object)
     */
    public void info(final Object message) {
        final String buff = formatLog(PRIORITY_INFO, message);
        outputTempLog(buff, null);
    }

    /**
     * 優先度INFOでログとスタックトレースを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @param t スタックトレースを出力するThrowableオブジェクトです。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object, java.lang.Throwable)
     */
    public void info(final Object message, final Throwable t) {
        final String buff = formatLog(PRIORITY_INFO, message);
        outputTempLog(buff, t);
        stdOut(t);
    }

    /**
     * このオブジェクトが優先度 INFO でのログ出力を行うかどうかを返します。
     * 
     * @return 優先度 INFO でのログ出力を行うなら true そうでないなら false。
     */
    public boolean isInfoEnabled() {
        return true;
    }

    /**
     * 優先度DEBUGでログを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object)
     */
    public void debug(final Object message) {
        final String buff = formatLog(PRIORITY_DEBUG, message);
        outputTempLog(buff, null);
    }

    /**
     * 優先度DEBUGでログとスタックトレースを出力します。
     * 
     * @param message ログとして出力する内容です。
     * @param t スタックトレースを出力するThrowableオブジェクトです。
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object, java.lang.Throwable)
     */
    public void debug(final Object message, final Throwable t) {
        final String buff = formatLog(PRIORITY_DEBUG, message);
        outputTempLog(buff, t);
        stdOut(t);
    }

    /**
     * このオブジェクトが優先度DEBUGのログ出力を行うかどうかを返します。
     * 
     * @return 優先度DEBUGでのログ出力を行うならtrue そうでないならfalse。
     */
    public boolean isDebugEnabled() {
        return false;
    }

    /**
     * このオブジェクトのカテゴリー名を返します。
     * <p>通常、このオブジェクトを生成したクラスの名前が返されます。</p>
     * 
     * @return オブジェクトのカテゴリー名。
     */
    public String getCategoryName() {
        return className;
    }

    /**
     * ファイル名の生成。
     * 
     * @return
     */
    private final String makeFileName() {
        StringBuffer buffer = new StringBuffer();
        final Calendar cal = Calendar.getInstance();
        buffer.append(cal.get(Calendar.YEAR));
        buffer.append(zeroPadding(cal.get(Calendar.MONTH) + 1, MONTH_MAX));
        buffer.append(cal.get(Calendar.DATE));
        buffer.append(".log");
        return buffer.toString();
    }

    /**
     * ログファイルへの書き込み。
     * 
     * @param message
     * @param t
     */
    private final void outputTempLog(final Object message, final Throwable t) {
        FileWriter out = null;
        try {
            out = new FileWriter(tempLog, true);
            if (message instanceof String) {
                out.append(message.toString() + "\n");
            } else {
                out.append("No Message.\n");
            }
            if (t != null) {
                out.append(t.toString());
            }
            out.close();
            System.out.println(message);
        } catch (Exception e) {
            System.out.println(message);
            stdOut(t);
            try {
                out.close();
            } catch (Exception ex) {
            }
        } finally {
        }
    }

    /**
     * 現在時刻を取得します。
     * 
     * @return 現在時刻です。
     */
    private final String getSysTime() {
        final Calendar cal = Calendar.getInstance();

        final StringBuffer buff = new StringBuffer();
        buff.append(cal.get(Calendar.YEAR));
        buff.append("-");

        buff.append(StdOutLogger.zeroPadding(cal.get(Calendar.MONTH) + 1,
            MONTH_MAX));
        buff.append("-");

        buff.append(StdOutLogger.zeroPadding(cal.get(Calendar.DAY_OF_MONTH),
            DAY_MAX));
        buff.append(" ");

        buff.append(StdOutLogger.zeroPadding(cal.get(Calendar.HOUR_OF_DAY),
            HOUR_MAX));
        buff.append(":");

        buff.append(StdOutLogger.zeroPadding(cal.get(Calendar.MINUTE),
            MINUTE_MAX));
        buff.append(":");

        buff.append(StdOutLogger.zeroPadding(cal.get(Calendar.SECOND),
            SECOND_MAX));
        buff.append(".");

        buff.append(StdOutLogger.zeroPadding(cal.get(Calendar.MILLISECOND),
            MILLISECOND_MAX));

        return buff.toString();
    }

    /**
     * メッセージをログ出力用にフォーマットします。
     * 
     * @param level ログ出力レベルです。
     * @param message ログ出力内容です。
     * @return ログ出力用にフォーマットされた文字列です。
     */
    private String formatLog(final String level, final Object message) {

        final int priorityPlaceHolder = 6;

        final StringBuffer buff = new StringBuffer();
        buff.append("[");
        buff.append(getSysTime());
        buff.append("]: ");
        buff.append(level);

        for (int i = 0; i < priorityPlaceHolder - level.length(); i++) {
            buff.append(' ');
        }

        buff.append("(");
        buff.append(className);
        buff.append("):");

        if (message != null) {
            buff.append(message.toString());
        }

        return buff.toString();
    }

    /**
     * 先頭を '0' で埋めて桁を合わせます。
     * 
     * @param n 桁合わせして文字列に変換する数です。
     * @param figure 合わせる桁数です。
     * @return 先頭が'0'で埋められた文字列です。
     */
    private static String zeroPadding(int n, int figure) {
        final String numberString = String.valueOf(n);
        final StringBuffer buff = new StringBuffer();
        buff.append(numberString);
        for (int i = 0; i < figure - numberString.length(); i++) {
            buff.insert(0, '0');
        }
        return buff.toString();
    }

    /**
     * 例外のスタックトレースを標準出力に出力します。
     * 
     * @param t 例外です。
     */
    private static void stdOut(final Throwable t) {
        t.printStackTrace(System.out);
    }
}
