package jp.co.systemexe.dbu.dbace.library.service.certification;

import java.util.List;

/**
 * {@link ModuleDto} service interface
 *
 * @author long-hai
 */
public interface ModuleService {
	/**
	 * Check the specified user code whether has permission to access the specified module code
	 *
	 * @param userName the user name
	 * @param moduleCds the module codes
	 * @param writable specify this module require write permission
	 *
	 * @return true for having permission; else otherwise
	 */
	boolean hasPermission(String userName, String[] moduleCds, boolean writable);
	/**
	 * Check the specified modules to find modules that the specified user has writable permission
	 *
	 * @param userName the user name
	 * @param moduleCds the module codes
	 *
	 * @return the modules list (sub-list of the specified modules that the specified user has writable permission)
	 * or null if not found
	 */
	List<String> checkWritable(String userName, List<String> moduleCds);
	/**
	 * Check the specified modules to find modules that the specified user has readable permission
	 *
	 * @param userName the user name
	 * @param moduleCds the module codes
	 *
	 * @return the modules list (sub-list of the specified modules that the specified user has readable permission)
	 * or null if not found
	 */
	List<String> checkReadable(String userName, List<String> moduleCds);
	/**
	 * Get the module CSS data list
	 *
	 * @param moduleCds module codes
	 *
	 * @return the module CSS data list
	 */
	List<String> getModuleCss(List<String> moduleCds);
	/**
	 * Check the specified user code whether has permission to access the specified module code, request URI
	 * (such as module link)
	 *
	 * @param userName the user name
	 * @param moduleCds the module codes
	 * @param requestURI such as module link (may be using regular expression base on PostgreSQL)
	 * @param writable specify this module require write permission
	 *
	 * @return true for having permission; else otherwise
	 */
	boolean hasPermissionOnRequest(String userName, String[] moduleCds, String requestURI, boolean writable);

	/**
	 * Check the specified module codes whether existed or enabled all
	 *
	 * @param moduleCd the module codes to check
	 *
	 * @return true for existed and enabled; otherwise false
	 */
	boolean isEnabled(String[] moduleCds);
	/**
	 * Check the specified module codes whether existed or enabled all
	 *
	 * @param moduleCd the module codes to check
	 *
	 * @return true for existed and enabled; otherwise false
	 */
	boolean isEnabledOnRequest(String[] moduleCds, String requestURI);
}
