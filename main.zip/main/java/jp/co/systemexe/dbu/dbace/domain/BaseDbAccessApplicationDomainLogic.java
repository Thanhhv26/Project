/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableOneRecordDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.DbConnectInfomationDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * DB アクセスのあるドメインロジック作成用の基底抽象クラス。
 * <p>
 * データベース接続を行うビジネスロジックを実装するための基底抽象クラスです。
 * DB 入出力に必要な DAO の生成等のメソッドが定義されています。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public abstract class BaseDbAccessApplicationDomainLogic
        extends BaseApplicationDomainLogic {

    /**
     * 自動インクリメントカラムをフィルタする。
     * <p>
     * 自動インクリメントカラムをレコードマップから除外します。
     * <p></p>
     * 追加、更新の際に参照専用のカラムである自動インクリメントカラムをフィルタ
     * します。
     * </p>
     *
     * @param records
     * @param defs
     * @return
     */
    protected Map<String, String> filterAutoIncrementColumn(
            final Map<String, String> records,
            final Map<String, DefinitionOfColumn> defs) {
        final Map<String, String> ret = new HashMap<String, String>();
        for (final Iterator<String> ite = records.keySet().iterator(); ite
            .hasNext();) {
            final String name = ite.next();
            final DefinitionOfColumn def = defs.get(name);
            if (def.isAutoIncrement() == false) {
                ret.put(name, records.get(name));
            }
        }
        return ret;
    }

    /**
     * リポジトリからテーブルフォーム情報を取得して戻します。
     *
     * @param connectDefinitionId
     * @param tableFormIdList
     * @return
     * @throws ApplicationDomainLogicException
     */
    public Map<String, TableFormDTO> getTableFormDTOMap(
    		final String connectDefinitionId,
            final List<String> tableFormIdList) throws ApplicationDomainLogicException {
    	final Map<String, TableFormDTO> ret = new HashMap<String, TableFormDTO>();
    	for (final String tableFormId : tableFormIdList) {
    		ret.put(tableFormId, getTableFormDTO(connectDefinitionId, tableFormId));
    	}
        return ret;
    }

    /**
     * リポジトリからテーブルフォーム情報を取得して戻します。
     *
     * @param connectDefinitionId
     * @param tableFormId
     * @return
     * @throws ApplicationDomainLogicException
     */
    public TableFormDTO getTableFormDTO(final String connectDefinitionId,
            final String tableFormId) throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        final TableFormDTO ret;
        try {
            ret = dao.getTableFormDTO(connectDefinitionId, tableFormId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return ret;
    }

    /**
     * リポジトリからテーブルフォーム情報を取得して戻します。
     *
     * @param connectDefinitionId
     * @param tableFormId
     * @return
     * @throws ApplicationDomainLogicException
     */
    public TableFormDTO getTableFormDTOByConnectName(final String connectDefinitionId,
            final String tableFormId) throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        final TableFormDTO ret;
        try {
            ret = dao.getTableFormDTOByConnectName(connectDefinitionId, tableFormId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return ret;
    }

    /**
     * テーブルフォーム DAO を生成して戻す。
     *
     * @return TableFormDAO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDAO createTableFormDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * テーブルのデータベース内定義 DTO を取得して戻します。
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableId テーブル ID
     * @param connectionUserLabel 接続ユーザー表示名
     * @return
     * @throws ApplicationDomainLogicException
     */
    public Map<String, TableDefinitionDTO> getTableDefinitionDTOMap(
            final String connectDefinitionId,
            final DatabaseTypeConnectionDestination type,
            final List<String> tableIdList,
            final String connectionUserLabel)
            throws ApplicationDomainLogicException {
        final DatabaseSchemaDAO dao = createDatabaseSchemaDAO(type);
        final Map<String, TableDefinitionDTO> ret = new HashMap<String, TableDefinitionDTO>();
        try {
            dao.connect(getDbConnectInfomation(connectDefinitionId));

            for (final String tableId : tableIdList) {
            	ret.put(tableId, dao.getTableDefinition(tableId));
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        } finally {
            try {
                dao.close();
            } catch (final DAOException e) {
                getLogger().warn(e);
            }
        }
        return ret;
    }

    /**
     * テーブルのデータベース内定義 DTO を取得して戻します。
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableId テーブル ID
     * @param connectionUserLabel 接続ユーザー表示名
     * @return
     * @throws ApplicationDomainLogicException
     */
    public TableDefinitionDTO getTableDefinitionDTO(
            final String connectDefinitionId,
            TableFormDTO multiTableFormDTO,
            final DatabaseTypeConnectionDestination type,
            final String connectionUserLabel)
            throws ApplicationDomainLogicException {
        final DatabaseSchemaDAO dao = createDatabaseSchemaDAO(type);
        TableDefinitionDTO ret = new TableDefinitionDTO("");
        try {
            dao.connect(getDbConnectInfomation(connectDefinitionId));
            ret = dao.getTableDefinition(multiTableFormDTO);

        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        } finally {
            try {
                dao.close();
            } catch (final DAOException e) {
                getLogger().warn(e);
            }
        }
        return ret;
    }

    /**
     * テーブルのデータベース内定義 DTO を取得して戻します。
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableId テーブル ID
     * @return
     * @throws ApplicationDomainLogicException
     */
    public TableDefinitionDTO getTableDefinitionDTO(
            final String connectDefinitionId,
            final DatabaseTypeConnectionDestination type,
            final String tableId)
            throws ApplicationDomainLogicException {
        final DatabaseSchemaDAO dao = createDatabaseSchemaDAO(type);
        TableDefinitionDTO ret = new TableDefinitionDTO("");
        try {
            dao.connect(getDbConnectInfomation(connectDefinitionId));
            ret = dao.getTableDefinition(tableId);

        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        } finally {
            try {
                dao.close();
            } catch (final DAOException e) {
                getLogger().warn(e);
            }
        }
        return ret;
    }


    /**
     * テーブルのデータベース内定義 DTO を取得して戻します。
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableId テーブル ID
     * @param connectionUserLabel 接続ユーザー表示名
     * @return
     * @throws ApplicationDomainLogicException
     */
    public Map<String, TableDefinitionDTO> getTableDefinitionDTOLabelMap(
            final String connectDefinitionId,
            final DatabaseTypeConnectionDestination type,
            final List<String> tableIdList,
            final String connectionUserLabel)
            throws ApplicationDomainLogicException {
        final DatabaseSchemaDAO dao = createDatabaseSchemaDAO(type);
        final Map<String, TableDefinitionDTO> ret = new HashMap<String, TableDefinitionDTO>();
        try {
            dao.connect(getDbConnectInfomationByLabel(connectDefinitionId));

            for (final String tableId : tableIdList) {
            	ret.put(tableId, dao.getTableDefinition(tableId));
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        } finally {
            try {
                dao.close();
            } catch (final DAOException e) {
                getLogger().warn(e);
            }
        }
        return ret;
    }


    /**
     * テーブルのデータベース内定義 DTO を取得して戻します。
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableId テーブル ID
     * @param connectionUserLabel 接続ユーザー表示名
     * @return
     * @throws ApplicationDomainLogicException
     */
    public TableDefinitionDTO getTableDefinitionDTO(
            final String connectDefinitionId,
            final DatabaseTypeConnectionDestination type,
            final String tableId,
            final String connectionUserLabel)
            throws ApplicationDomainLogicException {
    	final List<String> tableIdList = new ArrayList<String>();
    	tableIdList.add(tableId);
    	final Map<String, TableDefinitionDTO> ret
    		= getTableDefinitionDTOMap(connectDefinitionId, type, tableIdList, connectionUserLabel);
    	return ret.get(tableId);
    }

//    /**
//     * テーブルのデータベース内定義 DTO を取得して戻します。
//     *
//     * @param connectDefinitionId 接続定義 ID
//     * @param tableId テーブル ID
//     * @param connectionUserLabel 接続ユーザー表示名
//     * @return
//     * @throws ApplicationDomainLogicException
//     */
//    public TableDefinitionDTO getTableDefinitionDTO(
//            final String connectDefinitionId,
//            TableFormDTO multiTableFormDTO,
//            final DatabaseTypeConnectionDestination type,
//            final String connectionUserLabel)
//            throws ApplicationDomainLogicException {
//    	final TableDefinitionDTO ret
//    		= getTableDefinitionDTO(connectDefinitionId, multiTableFormDTO, type, connectionUserLabel);
//    	return ret;
//    }
    /**
     * テーブルのデータベース内定義 DTO を取得して戻します。
     *
     * @param connectDefinitionId 接続定義名
     * @param tableId テーブル Lable
     * @param connectionUserLabel 接続ユーザー表示名
     * @return
     * @throws ApplicationDomainLogicException
     */
    public TableDefinitionDTO getTableDefinitionDTOLabel(
            final String connectDefinitionId,
            final DatabaseTypeConnectionDestination type,
            final String tableId,
            final String connectionUserLabel)
            throws ApplicationDomainLogicException {
    	final List<String> tableIdList = new ArrayList<String>();
    	tableIdList.add(tableId);
    	final Map<String, TableDefinitionDTO> ret
    		= getTableDefinitionDTOLabelMap(connectDefinitionId, type, tableIdList, connectionUserLabel);
    	return ret.get(tableId);
    }

    /**
     * リポジトリからデータベース接続情報 DTO を取得して戻す。
     *
     * @param connectDefinitionId
     * @return
     * @throws ApplicationDomainLogicException
     */
    protected DbConnectInfomationDTO getDbConnectInfomation(
            final String connectDefinitionId)
            throws ApplicationDomainLogicException {
        final DbConnectInfomationDAO dao = createDbConnectInfomationDAO();
        try {
            return dao.getDbConnectInfomationDTO(connectDefinitionId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * リポジトリからデータベース接続情報 DTO を取得して戻す。
     *
     * @param connectDefinitionLabel
     * @return
     * @throws ApplicationDomainLogicException
     */
    public DbConnectInfomationDTO getDbConnectInfomationByLabel(
            final String connectDefinitionId)
            throws ApplicationDomainLogicException {
        final DbConnectInfomationDAO dao = createDbConnectInfomationDAO();
        try {
            return dao.getDbConnectInfomationLableDTO(connectDefinitionId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * データベース接続情報 DAO を生成して戻す。
     *
     * @return DbConnectInfomationDAO
     * @throws ApplicationDomainLogicException
     */
    protected DbConnectInfomationDAO createDbConnectInfomationDAO()
            throws ApplicationDomainLogicException {
        try {
            return (DbConnectInfomationDAO)createDAO("DbConnectInfomationDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * データベースのテーブルデータ DAO を生成して戻す。
     *
     * @return DatabaseTableDAO
     * @throws ApplicationDomainLogicException
     */
    protected DatabaseTableDAO createDatabaseTableDAO(final DatabaseTypeConnectionDestination type)
            throws ApplicationDomainLogicException {
        try {
            return (DatabaseTableDAO)createDAO("DatabaseTableDAO", type);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * データベースのスキーマ情報 DAO を生成して戻す。
     *
     * @return DatabaseSchemaDAO
     * @throws ApplicationDomainLogicException
     */
    protected DatabaseSchemaDAO createDatabaseSchemaDAO(final DatabaseTypeConnectionDestination type)
            throws ApplicationDomainLogicException {
        try {
            return (DatabaseSchemaDAO)createDAO("DatabaseSchemaDAO", type);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * データベースのテーブルデータ DAO を生成して戻す。
     *
     * @return DatabaseTableOneRecordDAO
     * @throws ApplicationDomainLogicException
     */
    protected DatabaseTableOneRecordDAO createDatabaseTableOneRecordDAO(final DatabaseTypeConnectionDestination type)
            throws ApplicationDomainLogicException {
        try {
            return (DatabaseTableOneRecordDAO)createDAO("DatabaseTableOneRecordDAO", type);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

}
