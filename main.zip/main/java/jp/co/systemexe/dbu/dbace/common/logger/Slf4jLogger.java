/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Log4j 用のロガーオブジェクトです。
 * <p></p>
 * 
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public class Slf4jLogger implements jp.co.systemexe.dbu.dbace.common.logger.Logger {
    private final Logger logger;
    private final String className;

    /**
     * Log4jLogger の生成。
     * <p>
     * コンストラクタ。ロガーインスタンスを取得し、log4j の設定を読み込みます。
     * </p>
     */
    public Slf4jLogger(final String className) {
        this.className = className;
        this.logger = LoggerFactory.getLogger(className);
    }

    /**
     * <p>
     * このオブジェクトのカテゴリー名を戻す。
     * </p>
     * @return 
     */
    public String getCategoryName() {
        return className;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object)
     */
    public void debug(Object obj) {
        logger.debug((String) obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object, java.lang.Throwable)
     */
    public void debug(Object obj, Throwable te) {
        logger.debug((String) obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object)
     */
    public void error(Object obj) {
        logger.error((String) obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object, java.lang.Throwable)
     */
    public void error(Object obj, Throwable te) {
        logger.error((String) obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object)
     */
    public void fatal(Object obj) {
        ((Slf4jLogger) logger).fatal(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object, java.lang.Throwable)
     */
    public void fatal(Object obj, Throwable te) {
        ((Slf4jLogger) logger).fatal(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object)
     */
    public void info(Object obj) {
        logger.info((String) obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object, java.lang.Throwable)
     */
    public void info(Object obj, Throwable te) {
        logger.info((String) obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object)
     */
    public void warn(Object obj) {
        logger.warn((String) obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object, java.lang.Throwable)
     */
    public void warn(Object obj, Throwable te) {
        logger.warn((String) obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#isDebugEnabled()
     */
    public boolean isDebugEnabled() {
        return logger.isDebugEnabled();
    }
}
