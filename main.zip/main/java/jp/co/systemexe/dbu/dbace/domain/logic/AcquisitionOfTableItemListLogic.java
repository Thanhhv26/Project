/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.Iterator;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.TableItemIdListItem;
import jp.co.systemexe.dbu.dbace.domain.BaseDbAccessApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.DbConnectDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * テーブルアイテム一覧（カラム一覧）を取得する処理。
 * <p>
 * テーブルアイテム定義情報一覧を取得します。</p>
 *
 * @author EXE 相田 一英
 * @author EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class AcquisitionOfTableItemListLogic
        extends BaseDbAccessApplicationDomainLogic {

    /**
     * テーブルアイテムリスト「カラムリスト」を取得します。
     * <p>
     * データベースからカラム定義順を取得し、定義順にソートされるコレクションに
     * カラム実名とカラム仮名を設定して戻します。
     * </p>
     * 
     * @param connectDefinitionId
     * @param tableId
     * @param connectionUserLabel 接続ユーザー表示名
     * @return
     * @throws ApplicationDomainLogicException
     */
    public SortedMap<Integer, SelectOneMenuItem> getSortedColumnNameMap(
            final String connectDefinitionId, final String tableId, final String connectionUserLabel)
            throws ApplicationDomainLogicException {
        final AcquisitionOfConnectDefinitionLogic connectDefinitionLogic
            = new AcquisitionOfConnectDefinitionLogic();
        final DbConnectDefinitionDTO connectDefinitionDTO
            = connectDefinitionLogic.getConnectDefinitionDTO(connectDefinitionId);
        final TableFormDTO dto = getTableFormDTO(connectDefinitionId, tableId);
        final TableDefinitionDTO def = getTableDefinitionDTO(
            connectDefinitionId,
            connectDefinitionDTO.getDatabaseTypeConnectionDestination(),
            tableId,
            connectionUserLabel);
        final SortedMap<Integer, SelectOneMenuItem> ret = new TreeMap<Integer, SelectOneMenuItem>();
        int index = 0;
        for (final Iterator<String> ite = def.getColumnNames().values()
            .iterator(); ite.hasNext();) {
            final String name = ite.next();
            if (dto.getTableItemMap().containsKey(name)) {
                final TableItemIdListItem item = new TableItemIdListItem();
                item.setValue(name);
                item.setLabel(dto.getTableItemMap().get(name).getItemLabel());
                ret.put(index, item);
                index++;
            }
        }
        return ret;
    }

    /**
     * AcquireColumnListFromRepositoryLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public AcquisitionOfTableItemListLogic() {
        return;
    }
}
