/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.audit.dto;

import jp.co.systemexe.dbu.dbace.library.dto.BaseDto;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author van-thanh
 *
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SelectOneMenuItemDto extends BaseDto implements SelectOneMenuItem {

	private static final long serialVersionUID = 1L;

	String label;
	String value;

}
