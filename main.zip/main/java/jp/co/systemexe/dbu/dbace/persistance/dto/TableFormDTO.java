/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.web.creation.dto.OptionalDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;

/**
 * テーブルフォーム DTO。
 * <p>
 * テーブル個々に対応した画面設定（テーブルフォーム）情報を保持する DTO です。
 * </p><p>
 * 本アイテムはリポジトリの定義に従って定義されています。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class TableFormDTO {

    /**
     * テーブルフォーム ID。
     */
    private String tableFormId;

    /**
     * テーブルフォームラベル。
     */
    private String tableFormLabel;

    /**
     * 表示デフォルト（降順表示）
     */
    private boolean orderDesc;

	/**
	*
	*/
	private String type;

	/**
	*
	*/
	private String description;

	/**
	 *
	 */
	private boolean enable;

	/**
	 *
	 */
	private OptionalDto optional;

	/**
	 *
	 */
	private SortedMap<String, ApplicationRelationDTO> relationMap = new TreeMap<String, ApplicationRelationDTO>();

    /**
     * ソート情報マップ。
     */
    private SortedMap<Integer, String> sortConditionMap = new TreeMap<Integer, String>();

    /**
     * 項目 DTO マップ。
     * <p>Map&lt;カラム ID, TableItemDTO&gt;</p>
     */
    private Map<String, TableItemDTO> tableItemMap = new HashMap<String, TableItemDTO>();
    private Map<String, TableDto> tableMap = new HashMap<String, TableDto>();

    /**
     * UpdateKey リストを戻します。
     * <p>
     * 更新・追加の際に一致キーとする更新キー名リストを戻します。</p>
     *
     * @return List&lt;カラム名&gt;
     */
    public List<String> getUpdateKeyList() {
        final List<String> ret = new ArrayList<String>();
        for (final Iterator<TableItemDTO> ite = tableItemMap.values()
            .iterator(); ite.hasNext();) {
            final TableItemDTO dto = ite.next();
            if (dto.isUpdateKey()) {
                ret.add(dto.getItemId());
            }
        }
        return ret;
    }

    /**
     * ソート情報マップを戻します。
     * <p>
     * テーブルの内容を一覧表示する際のソート条件を設定したマップを戻します。
     * キー値が優先順位（小さい値が優先）、値がカラム名です。指定したカラムを
     * 昇順にソートします。
     * </p>
     *
     * @return SortedMap&lt;ソート優先順,対象カラム名&gt;
     */
    public SortedMap<Integer, String> getSortConditionMap() {
        return sortConditionMap;
    }

    /**
     * ソート情報マップを設定します。
     * <p>
     * テーブルの内容を一覧表示する際のソート条件を設定したマップを戻します。
     * キー値が優先順位（小さい値が優先）、値がカラム名です。指定したカラムを
     * 昇順にソートします。
     * </p>
     *
     * @param SortedMap<Integer,String> sortConditionMap
     */
    public void setSortConditionMap(
            final SortedMap<Integer, String> sortConditionMap) {
        this.sortConditionMap = sortConditionMap;
    }

    /**
     * テーブルフォーム ID を戻します。
     * <p>
     * テーブルフォーム ID です。データベースの実際のカラム名と等価です。</p>
     *
     * @return String
     */
    public String getTableFormId() {
        return tableFormId;
    }

    /**
     * テーブルフォーム ID を設定します。
     * <p>
     * テーブルフォーム ID です。データベースの実際のカラム名と等価です。</p>
     *
     * @param String tableFormId
     */
    public void setTableFormId(final String tableFormId) {
        this.tableFormId = tableFormId;
    }

    /**
     * テーブルフォームラベルを戻します。
     *
     * @return String
     */
    public String getTableFormLabel() {
        return tableFormLabel;
    }

    /**
     * テーブルフォームラベルを設定します。
     *
     * @param String tableFormLabel
     */
    public void setTableFormLabel(final String tableFormLabel) {
        this.tableFormLabel = tableFormLabel;
    }

    /**
     * 表示デフォルト（降順表示）を戻します。
     *
     * @return String
     */
    public boolean getOrderDesc() {
        return orderDesc;
    }

    /**
     * 表示デフォルト（降順表示）を設定します。
     *
     * @param String orderDesc
     */
    public void setOrderDesc(final boolean orderDesc) {
        this.orderDesc = orderDesc;
    }

    /**
     * 項目 DTO マップを戻します。
     *
     * @return Map&lt;カラム ID, TableItemDTO&gt;
     */
    public Map<String, TableItemDTO> getTableItemMap() {
        return tableItemMap;
    }

    /**
     * @param tableItemMap
     */
    public void setTableItemMap(Map<String, TableItemDTO> tableItemMap) {
        this.tableItemMap = tableItemMap;
    }
    /**
     * カラム名マップ。
     * <p>SortedMap&lt;インデックス番号, カラム名&gt;</p>
     */
    private SortedMap<Integer, String> columnNames = new TreeMap<Integer, String>();
    /**
     * カラム名マップを戻します。
     * <p>
     * このマップのインデックス番号がカラムの並び順になります。</p>
     *
     * @return SortedMap&lt;インデックス番号, カラム名&gt;
     */
    public SortedMap<Integer, String> getColumnNames() {
        return columnNames;
    }

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the enable
	 */
	public boolean isEnable() {
		return enable;
	}

	/**
	 * @param enable the enable to set
	 */
	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	/**
	 * @return the relationMap
	 */
	public SortedMap<String, ApplicationRelationDTO> getRelationMap() {
		return relationMap;
	}

	/**
	 * @param relationMap the relationMap to set
	 */
	public void setRelationMap(SortedMap<String, ApplicationRelationDTO> relationMap) {
		this.relationMap = relationMap;
	}

	/**
	 * @return the optional
	 */
	public OptionalDto getOptional() {
		return optional;
	}

	/**
	 * @param optional the optional to set
	 */
	public void setOptional(OptionalDto optional) {
		this.optional = optional;
	}

	/**
	 * @return the tableMap
	 */
	public Map<String, TableDto> getTableMap() {
		return tableMap;
	}

	/**
	 * @param tableMap the tableMap to set
	 */
	public void setTableMap(Map<String, TableDto> tableMap) {
		this.tableMap = tableMap;
	}

}
