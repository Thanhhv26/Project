/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.taglibs;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import jp.co.systemexe.dbu.dbace.library.util.BeanUtils;

/**
 * Function utilities for tag-lib
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
public final class TagUtils implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/** logger */
    protected static Logger logger = LoggerFactory.getLogger(BeanUtils.class);

    /**
     * Check the specified object whether existed in the specified list
     *
     * @param list the list to check
     * @param o the value to check
     *
     * @return true for existed; else false
     */
    public static boolean contains(List<Object> list, Object o) {
        return (!CollectionUtils.isEmpty(list) && list.contains(o));
	}

    /**
     * Check the specified object whether existed in the specified list
     *
     * @param list the list to check
     * @param o the value to check
     *
     * @return true for existed; else false
     */
    public static boolean containsAtLeast(List<Object> list, Object...objs) {
    	boolean contained = false;
    	if (!CollectionUtils.isEmpty(list) && !ArrayUtils.isEmpty(objs)) {
    		for(Object o : objs) {
    			contained = list.contains(o);
    			if (contained) break;
    		}
    	}
        return contained;
	}

    /**
     * Get the index of the specified object in the specified list
     *
     * @param list the list to check
     * @param o the value to check
     *
     * @return index of object or -1 if not found
     */
    public static int indexOf(List<Object> list, Object o) {
        return (CollectionUtils.isEmpty(list) ? -1 : list.indexOf(o));
	}
}
