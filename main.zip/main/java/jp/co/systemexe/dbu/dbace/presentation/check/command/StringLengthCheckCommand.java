/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;

/**
 * 文字列系の項目に対する文字列長上限チェック。
 * <p>
 * JDBC メタデータ型で VARCHAR 型のもの、CHAR 型のものに対し桁数チェックを実行
 * します。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class StringLengthCheckCommand extends BaseLogicalCheckCommand {

    /**
     * StringLengthCheckCommand の生成。
     * <p>コンストラクタ。</p>
     */
    public StringLengthCheckCommand() {
        return;
    }

    /**
     * 検査を実行します。
     * <p></p>
     *
     * @param columnId カラム名
     * @param messages 論理チェック結果メッセージ保持 DTO
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#check(java.lang.String, jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO)
     */
    @Override
    public void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
    		final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap) {
        final String value = messages.getCorrectedValue(columnId);
        if (value == null || value.equals("")) {
            return;
        }

        // TODO 設計する。
        /*
         * Oracle 9i 以降は文字セットを UTF-8 で作成すると、1～4バイト混在に
         * なってしまう。いわゆる ASCII の範囲が1バイト、通常の日本語が 3 バイト、
         * 特殊文字が 4 バイト。
         * なので、単純な計算で制限された精度内のデータか否かを知ることが出来ない！！
         * 文字セット定義及び DB バージョンをリポジトリ中に持てば計算できない
         * 事も無いが、対応すべき範囲が広すぎて（初期開発段階では）現実的で無い。
         * （対象が決まってる SI なら何と言う事も無いが、製品では...）
         *
         * 設計レベルでの解決法を真剣に検討する必要がある。
         */

    }

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * このクラスが検査対象とする条件は、
     * <ol>
     *  <li>DB 内のデータ型が JDBC メタデータで CHAR のもの。</li>
     *  <li>DB 内のデータ型が JDBC メタデータで VARCHAR のもの。</li>
     * </ol>
     * の二種類です。現状 JDBC LONGVARCHAR 型のものはファイルとして入出力、と
     * 仕様が定義されているため、長さをチェックする型は上記二つだけです。
     * </p>
     *
     * @param columnId カラム ID（＝カラム名）
     * @return true : 検査担当 / false : 担当ではない
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#isMyTask(java.lang.String)
     */
    @Override
    protected boolean isMyTask(final String columnId) {
        final DefinitionOfColumn def = getDisplayDef().getDefinitionOfColumns()
            .get(columnId);
        if (def.getJDBCMetaDataType() == JDBCMetaDataType.VARCHAR
                || def.getJDBCMetaDataType() == JDBCMetaDataType.CHAR
                || def.getJDBCMetaDataType() == JDBCMetaDataType.NVARCHAR
                || def.getJDBCMetaDataType() == JDBCMetaDataType.NCHAR) {
            return true;
        } else {
            return false;
        }
    }
}
