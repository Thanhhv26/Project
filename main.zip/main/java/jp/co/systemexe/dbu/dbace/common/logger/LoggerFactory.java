/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.logger;

/**
 * ロガーを生成するファクトリです。
 * <p>
 * 実装フレームワークに対しロガー参照を提供します。このクラスは Singleton です。
 * </p>
 * 
 * @author  EXE 相田 一英
 * @version 0.0.1
 */
public final class LoggerFactory {

    private static final LoggerFactory factory = new LoggerFactory();

    /**
     * LoggerFactory の生成。
     * <p>デフォルトコンストラクタは隠蔽しています。</p>
     */
    private LoggerFactory() {
        return;
    }

    /**
     * Logger を戻します。
     * 
     * @param className 呼び出し元クラス名。
     * @return Logger
     */
    public static Logger getLogger(final String className) {
        return factory.getLoggerInstance(className);
    }
    
    public static Logger getLogger(final Class<?> clazz) {
        return factory.getLoggerInstance(clazz.getName());
    }

    /**
     * ログ出力オブジェクトのインスタンスを戻します。
     * 
     * @param className 呼び出し元クラス名。
     * @return Logger
     */
    private Logger getLoggerInstance(final String className) {
        try {
            return new Log4jLogger(className);
        } catch (Exception e) {
            return new StdOutLogger(className);
        }
    }
}
