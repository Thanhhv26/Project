/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;

import java.io.Serializable;

import lombok.Data;

/**
 * @author  tu-lenh
 * @version 0.0.0
 */
@Data
public class ObjectNameDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String objectId;
	private String objectName;
}
