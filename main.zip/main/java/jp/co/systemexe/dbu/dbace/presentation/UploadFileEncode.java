/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.presentation;

/**
 * アップロード可能なファイルエンコード列挙体
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum UploadFileEncode {
	Windows_31J("Windows-31J", "Windows-31J"),
	SHIFT_JIS("Shift_JIS", "Shift_JIS"),
	UTF8("UTF-8", "UTF-8");
	
	/**
	 * Javaで使用する、ファイルエンコード
	 */
	private String encode;
	
	/**
	 * 画面表示用のファイルエンコード
	 */
	private String display;

	/**
	 * encode を戻します。
	 * 
	 * @return String
	 */
	public String getEncode() {
		return encode;
	}

	/**
	 * encode を設定します。
	 *
	 * @param String encode 
	 */
	public void setEncode(String encode) {
		this.encode = encode;
	}

	/**
	 * display を戻します。
	 * 
	 * @return String
	 */
	public String getDisplay() {
		return display;
	}

	/**
	 * display を設定します。
	 *
	 * @param String display 
	 */
	public void setDisplay(String display) {
		this.display = display;
	}
	
	/**
	 * 
	 * UploadFileEncode.java の生成。
	 * 
	 * @param encode
	 * @param display
	 */
	private UploadFileEncode(final String encode, final String display) {
		this.encode = encode;
		this.display = display;
	}
}
