/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseDbAccessApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.DbConnectDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * データベースの接続試験ロジック。
 * <p>
 * データベースへの接続試験を行うビジネスロジックです。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class DatabaseConnectionTestLogic
        extends BaseDbAccessApplicationDomainLogic {

    /**
     * データベースとの接続テストを実行します。
     * <p>
     * 接続に成功した場合はそのまま終了します。
     * </p><p>
     * 接続に失敗した場合は、DAO からスローされてきた例外をそのままラップし
     * ApplicationDomainLogicException をスローします。通常、画面上には
     * データベースがスローしてきた例外をそのまま表示します。
     * </p>
     *
     * @param DbConnectDefinitionDTO
     * @param connectionUserLabel 接続ユーザー表示名
     * @throws ApplicationDomainLogicException
     */
    public void testConnect(final DbConnectDefinitionDTO bean, final String connectionUserLabel)
            throws ApplicationDomainLogicException {
        final DbConnectInfomationDTO dto = new DbConnectInfomationDTO();
        dto.setDatabaseId(bean.getDatabaseId());
        dto.setPassword(bean.getPassword());
        dto.setPortId(bean.getPort());
        dto.setServerId(bean.getServerId());
        dto.setUserId(bean.getPid());
        dto.setDatabaseTypeConnectionDestination(bean.getDatabaseTypeConnectionDestination());
        dto.setUseDatabaseUrl(bean.isUseDatabaseUrl());
        dto.setDatabaseUrl(bean.getDatabaseUrl());
        dto.setInstanceName(bean.getInstanceName());
        final DatabaseSchemaDAO dao = createDatabaseSchemaDAO(bean.getDatabaseTypeConnectionDestination());
        try {
            dao.testConnect(dto);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * DatabaseConnectionTestLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public DatabaseConnectionTestLogic() {
        return;
    }
}
