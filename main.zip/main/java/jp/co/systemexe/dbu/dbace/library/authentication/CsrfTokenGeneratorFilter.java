/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.authentication;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import jp.co.systemexe.dbu.dbace.library.util.AuthenticationUtils;

/**
 * To prevent Cross-Site Request Forgery attack, I enable csrf in my spring security context.
 *
 * @author systemexe
 * @version 1.0 Nov 29, 2016
 */
@Component
public class CsrfTokenGeneratorFilter extends AbstractOncePerRequestFilter {

	/*
	 * (非 Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.common.authentication.AbstractOncePerRequestFilter#doBeforeFilter(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected boolean doBeforeFilter(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		return !StringUtils.hasText(AuthenticationUtils.generateCsrfToken(request, response, false, false));
	}
}
