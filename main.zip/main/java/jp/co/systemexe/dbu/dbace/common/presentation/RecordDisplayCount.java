/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.presentation;

/**
 * レコード表示件数を保持する列挙体
 * 
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum RecordDisplayCount {
	TEN("10"),
	TWENTY("20"),
	THIRTY("30"),
	FORTY("40"),
	FIFTY("50"),
	HUNDRED("100");
	
	private RecordDisplayCount(final String value) {
		this.value = value;
	}
	
	private String value;

	/**
	 * value を戻します。
	 * 
	 * @return String
	 */
	public String getValue() {
		return value;
	}
}
