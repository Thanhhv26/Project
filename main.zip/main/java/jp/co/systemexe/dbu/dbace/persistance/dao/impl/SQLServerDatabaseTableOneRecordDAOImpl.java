/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.sql.SQLException;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.jdbc.WebResultSetFacade;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableOneRecordDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectSqlCondition;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TypeOfRetrieval;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * データベースのテーブルデータ DAO。
 * <p>
 * 実際にデータベース内のテーブルデータにアクセスする DAO です。</p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class SQLServerDatabaseTableOneRecordDAOImpl extends SQLServerDatabaseTableDAO
        implements DatabaseTableOneRecordDAO {
    private WebResultSetFacade facade = null;
    private TableFormDTO tableFormDTO;
    private TableDefinitionDTO defDTO;

    public boolean hasNext() throws DAOException {
        try {
            return facade.next();
        } catch (SQLException e) {
            final String message = "レコードの検索処理に失敗しました。(" + e.getMessage() + ")";
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    public Map<String, String> next() throws DAOException {
        try {
            return facade.getMap(tableFormDTO.getTableItemMap(), defDTO);
        } catch (SQLException e) {
            final String message = "レコードの検索処理に失敗しました。(" + e.getMessage() + ")";
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    public void close() {
        if (facade != null) {
            facade.close();
            facade = null;
        }
        try {
            getPreparedStatement().close();
        } catch (Exception ex) {
            getLogger().warn(ex);
        }
    }

    /**
     * select を発行し結果レコードをコレクションに設定して戻します。
     * <p>
     * 条件指定に従い、一致検索或いは曖昧検索を行い、取得したレコードを
     * コレクションに設定して戻します。
     * </p><p>
     * 検索されたレコードの内、戻す範囲の先頭と、一度に戻すレコード数も指定
     * 出来ます。<br />
     * 指定された先頭位置にレコードが発見できない場合は空のコレクションを戻し
     * ます。<br />
     * 指定された先頭位置から、指定されたレコード数が存在しない場合は、存在した
     * 分だけを戻します。また、レコード数が 0 以下で指定されていた場合は、検索
     * されたレコードを指定された先頭位置から全て戻します。
     * </p><p>
     * なお、結果セットの先頭レコードへの移動のため absolute メソッドを使用して
     * いますが、このメソッドは結果セットを生成するステートメントがスクロール
     * 可能（TYPE_SCROLL_INSENSITIVE）の場合しか使用できません。
     * </p>
     *
     * @param dto レコード検索条件 DTO
     * @param form テーブルフォーム DTO
     * @param table テーブル DB 内定義 DTO
     * @return RecordSearchResultDTO レコード検索結果 DTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableOneRecordDAO#executeQuery(jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO)
     */
    public void executeQuery(
            final RecordSearchConditionDTO dto,
            final TableFormDTO form,
            final TableDefinitionDTO table) throws DAOException {
        this.tableFormDTO = form;
        this.defDTO = table;
        final SelectSqlCondition condition = createSelectSqlCondition(dto, tableFormDTO);
        if (dto.getTypeOfRetrieval() == TypeOfRetrieval.STRICTNESS) {
            facade = select(condition, true);
        } else if (dto.getTypeOfRetrieval() == TypeOfRetrieval.UNRESTRICTED) {
            condition.getWheresMap().clear();
            facade = select(condition, true);
        } else {
            try {
                getPreparedStatement().close();
            } catch (Exception ex) {
            }
            final String message = "TypeOfRetrieval enum is illegal state.";
            getLogger().fatal(message);
            throw new DAOException(message);
        }

        try {
            facade.setFetchSize(SystemProperties.getDownloadFetchSize());
        } catch (final SQLException e) {
            final String message = "レコードの検索処理に失敗しました。(" + e.getMessage() + ")";
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * DatabaseTableDAOImpl の生成。
     * <p>コンストラクタ。</p>
     */
    public SQLServerDatabaseTableOneRecordDAOImpl() {
        return;
    }


}
