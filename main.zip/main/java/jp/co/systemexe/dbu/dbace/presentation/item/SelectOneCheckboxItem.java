/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item;

/**
 * Teeda SelectOneCheckBox Item インターフェース。
 * <p>
 * Teeda HTML テンプレート内で checkbox 要素、つまりチェックボックスを使用する際に、
 * そのリスト内の値を定義するためのインターフェースです。option 要素の value
 * アトリビュートの保持値とテキスト要素の保持値の入出力インターフェースを定義
 * しています。</p>
 *
 * @author	EXE 島田 雄一郎
 * @version 0.0.0
 */
public interface SelectOneCheckboxItem {

    /**
     * option 要素の value アトリビュートの保持値を戻します。
     * <p>
     * option 要素の value アトリビュートには、通常キー値或いはインデックス番号
     * を保持させます。</p>
     * 
     * @return Boolean
     */
    public Boolean getValue();

    /**
     * option 要素の value アトリビュートの保持値を設定します。
     * <p>
     * option 要素の value アトリビュートには、通常キー値或いはインデックス番号
     * を保持させます。</p>
     * 
     * @param value Boolean
     */
    public void setValue(final Boolean value);

    /**
     * ラベル表示されるテキスト要素の保持値を戻します。
     * 
     * @return String
     */
    public String getLabel();

    /**
     * ラベル表示されるテキスト要素の保持値を設定します。
     * 
     * @param label String
     */
    public void setLabel(final String label);

}
