/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.common.controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
/**
 * Error Controller
 * @author tu-lenh
 * @version 0.0.0
 */
@RestController
@RequestMapping(value = { "/web/systemError" })
public class ErrorController {

	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index() throws Exception {
		ModelAndView mv = new ModelAndView("error/systemError");
		return mv;
	}

}
