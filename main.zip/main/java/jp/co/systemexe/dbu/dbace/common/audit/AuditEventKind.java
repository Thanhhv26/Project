package jp.co.systemexe.dbu.dbace.common.audit;

/**
 * イベント種類 列挙体
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum AuditEventKind {
    /**
     * ログイン
     */
    LOGIN("LOGIN"),
    /**
     * ログアウト
     */
    LOGOUT("LOGOUT"),
    /**
     * 参照
     */
    REFERENCE("REFERENCE"),
    /**
     * 挿入
     */
    INSERT("INSERT"),
    /**
     * 更新
     */
    UPDATE("UPDATE"),
    /**
     * 削除
     */
    DELETE("DELETE"),
    /**
     * ダウンロード
     */
    DOWNLOAD("DOWNLOAD"),
    /**
     * 画面カスタマイズ
     */
    CUSTOMIZE("CUSTOMIZE"),
    /**
     * インポート
     */
    IMPORT("IMPORT"),
    /**
     * システム管理者権限
     */
    SYSTEM_ADMINISTRATOR("SYSTEM ADMINISTRATOR"),
    /**
     * パスワード変更
     */
    CHANGE_PASSWORD("CHANGE PASSWORD"),

    /**
     * パスワード変更
     */
    CHANGE_USERNAME_PASSWORD("CHANGE USERNAME PASSWORD"),

    /**
     * Username
     */
    CHANGE_USERNAME("CHANGE USERNAME"),
    // ADD　外部認証画面の監査ログを出力の機能追加　↓
    /**
     * 未定義
     */
    UNDEFINE("UNDEFINE"),
    /**
     * 外部認証あり
     */
    EXT_AUTH_ON("ON"),
    /**
     * 外部認証なし
     */
    EXT_AUTH_OFF("OFF"),
    // ADD　外部認証画面の監査ログを出力の機能追加　↑
    /**
     * スタート（監査開始）
     */
    START("START"),
    /**
     * スタート（監査終了）
     */
    STOP("STOP"),
	
	SEARCH("SEARCH");

    private String eventKindName;
    public String getEventKindName() {
        return eventKindName;
    }

    private AuditEventKind(final String eventKindName) {
        this.eventKindName = eventKindName;
    }
}
