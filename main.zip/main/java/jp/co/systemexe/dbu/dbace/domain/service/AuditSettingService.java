/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service;

import jp.co.systemexe.dbu.dbace.web.audit.dto.FRM0530ResultDto;
import jp.co.systemexe.dbu.dbace.web.audit.json.FRM0530Param;

/**
 * @author van-thanh
 * 
 */

/**
 * processing to show data from AuditSetting.xml to screen
 * update information in AuditSetting.xml
 * 
 * ログイン: ユーザーのログイン、ログアウトを監査
 * 外部認証操作: 外部認証連携の変更を監査
 * データ操作	: テーブルへのデータ作成/編集/削除/参照を監査
 * ユーザー操作: ユーザー情報の作成/編集(権限変更含む)/削除/を監査
 * 接続定義操作: データベースへの接続設定の作成/編集/削除を監査
 * DBオブジェクト操作: オブジェクトの登録/同期/削除を監査
 * リレーション操作: リレーション操作の作成/編集/削除/参照を監査
 * 画面作成操作: オブジェクトを利用した画面の作成/編集/削除/参照を監査
 */

public interface AuditSettingService {

	/**
	 * get info from xml
	 * @return
	 */
	FRM0530ResultDto initialize();
	
	/**
	 * update info of AuditSetting.xml
	 * @param param
	 * @return
	 */
	FRM0530ResultDto doOnceSave(FRM0530Param param);

}
