/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.sql;

import java.util.HashMap;
import java.util.Map;


/**
 * 論理演算子
 * 
 * @author EXE 古賀 諭 
 * @author EXE 島田 雄一郎
 *
 */
public enum SqlWhereTableLogicalOperator {
    blank("",""),
    and("and","AND"),
    or("or","OR");
    
    private String logicalOperator;
    private String label;

    private static Map<String, SqlWhereTableLogicalOperator> map;
    private static Map<String, SqlWhereTableLogicalOperator> labelMap;
    
    static {
        map = new HashMap<String, SqlWhereTableLogicalOperator>();
        labelMap = new HashMap<String, SqlWhereTableLogicalOperator>();

        for (final SqlWhereTableLogicalOperator logicalOperator : SqlWhereTableLogicalOperator.values()) {
            map.put(logicalOperator.getLogicalOperator(), logicalOperator);
            labelMap.put(logicalOperator.getLabel(), logicalOperator);
        }
    }

    public static SqlWhereTableLogicalOperator labelOf(final String logicalOperator) {
        return labelMap.get(logicalOperator);
    }

    public static SqlWhereTableLogicalOperator logicalOperatorOf(final String logicalOperator) {
        return map.get(logicalOperator);
    }

    /**
     * @return label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @return logicalOperator
     */
    public String getLogicalOperator() {
        return logicalOperator;
    }
    
    private SqlWhereTableLogicalOperator(final String logicalOperator, final String label) {
        this.logicalOperator = logicalOperator;
        this.label = label;
    }
}
