/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectItem;
import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.ConnectDefinisionDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.ConnectDefinision;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.web.connect.dto.ConnectDto;

/**
 * 接続定義情報一覧の取得ロジック。
 * <p>
 * アプリケーションログイン画面で使用する、接続定義情報の一覧取得ロジックです。
 * </p>
 *
 * @author EXE 相田 一英
 * @version 0.0.0
 */
public class AcquisitionOfConnectDefinitionListLogic extends BaseApplicationDomainLogic {


	/**
	 * プルダウンリスト表示用の一覧リストを戻す。
	 * <p>
	 * リストの並び順は、表示用ラベル定義文字列の自然順序に従いソートします。 f
	 * </p>
	 *
	 * @return List&lt;IdSelectable&gt;
	 * @throws ApplicationDomainLogicException
	 */
	@SuppressWarnings("unchecked")
	public List<IdSelectable> getIdSelectableList(UserAuthority userAuthority) throws ApplicationDomainLogicException {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		Map<String, String> map = null;
		Map<String, String> connectDefinisionAuthorityMap = new HashMap<String, String>();
		try {
			if (userAuthority.isSystemAdministrator()) {
				map = dao.getConnectDefinisionNameMap();
			} else {
				map = dao.getConnectDefinisionNameMap();
				for (ConnectDefinisionAuthority connectDefinisionAuthority : userAuthority.getConnectDefinisionAuthoritys()) {
					if (map.get(connectDefinisionAuthority.getConnectDefinisionId()) != null) {
						connectDefinisionAuthorityMap.put(connectDefinisionAuthority.getConnectDefinisionId(), map.get(connectDefinisionAuthority.getConnectDefinisionId()));
					}
				}
			}
		} catch (final DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}

		List<Map.Entry<String, String>> entries = null;
		if (userAuthority.isSystemAdministrator()) {
			entries = new ArrayList<Map.Entry<String, String>>(map.entrySet());
		} else {
			entries = new ArrayList<Map.Entry<String, String>>(connectDefinisionAuthorityMap.entrySet());
		}
		Collections.sort(entries, new Comparator<Object>() {
			@Override
			public int compare(Object o1, Object o2) {
				Map.Entry<String, String> e1 = (Map.Entry<String, String>) o1;
				Map.Entry<String, String> e2 = (Map.Entry<String, String>) o2;
				String val1 = e1.getValue().toString();
				String val2 = e2.getValue().toString();
				return val1.compareTo(val2);
			}

		});
		final List<IdSelectable> ret = new ArrayList<IdSelectable>();
		for (Map.Entry<String, String> entry : entries) {
			IdSelectItem selectItem = new IdSelectItem(entry.getKey().toString(), entry.getValue().toString());
			selectItem.setType("");
			ret.add(selectItem);
		}

		return ret;
	}

	/**
	 * プルダウンリスト表示用の一覧リストを戻す。
	 * <p>
	 * リストの並び順は、表示用ラベル定義文字列の自然順序に従いソートします。 f
	 * </p>
	 *
	 * @return List&lt;IdSelectable&gt;
	 * @throws ApplicationDomainLogicException
	 */
	public List<IdSelectable> getIdSelectableList2() throws ApplicationDomainLogicException {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		final Map<String, String> map;
		try {
			map = dao.getConnectDefinisionNameMap();
		} catch (final DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}

		final SortedMap<String, IdSelectable> sort = new TreeMap<String, IdSelectable>();
		for (final Iterator<String> ite = map.keySet().iterator(); ite.hasNext();) {
			final String key = ite.next();
			IdSelectItem selectItem = new IdSelectItem(key, map.get(key));
			selectItem.setType("");
			sort.put(map.get(key), selectItem);
		}
		final List<IdSelectable> ret = new ArrayList<IdSelectable>();
		for (final IdSelectable item : sort.values()) {
			ret.add(item);
		}
		return ret;
	}


	/**
	 * AcquisitionOfConnectDefinitionListLogic の生成。
	 * <p>
	 * コンストラクタ。
	 * </p>
	 */
	public AcquisitionOfConnectDefinitionListLogic() {
		return;
	}

	/**
	 * 接続定義情報 DAO を生成して戻す。
	 *
	 * @return BaseDatabaseDAO
	 * @throws ApplicationDomainLogicException
	 */
	public ConnectDefinisionDAO createConnectDefinisionDAO() throws ApplicationDomainLogicException {
		try {
			return (ConnectDefinisionDAO) createDAO("ConnectDefinisionDAO");
		} catch (final DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}
	}


//	private BaseDatabaseDAO createBaseDatabaseDAO() throws ApplicationDomainLogicException {
//		try {
//			return (BaseDatabaseDAO) createDAO("BaseDatabaseDAO");
//		} catch (final DAOException e) {
//			throw new ApplicationDomainLogicException(e.getMessage(), e);
//		}
//	}

	/**
	 *
	 * @return List&lt;ConnectDefinisionEntity&gt;
	 * @throws ApplicationDomainLogicException
	 * @throws DAOException
	 */
	public Map<String, ConnectDto> getConnectDefinisionMap() throws ApplicationDomainLogicException {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		return dao.getAllConnectDefinisions();
	}

	/**
	 *
	 * @return
	 * @throws ApplicationDomainLogicException
	 * @throws DAOException
	 */
	public Boolean delete(ConnectDto connectDto) throws ApplicationDomainLogicException, DAOException {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		dao.remove(connectDto.getConnectDefinition());
		return true;
	}

	/**
	 *
	 * @return
	 * @throws ApplicationDomainLogicException
	 * @throws DAOException
	 */
	public int insert(ConnectDto connectDto) throws ApplicationDomainLogicException, DAOException {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		return dao.insert(connectDto);
	}

	/**
	 *
	 * @return
	 * @throws ApplicationDomainLogicException
	 * @throws DAOException
	 */
	public int update(ConnectDto connectDto) throws ApplicationDomainLogicException, DAOException {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		return dao.update(connectDto);
	}

	/**
	 *
	 * @return
	 * @throws ApplicationDomainLogicException
	 * @throws DAOException
	 */
	public void testConnect(ConnectDto connectDto) throws ApplicationDomainLogicException, DAOException {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		dao.testConnect(connectDto);
	}

	/**
	 * @return
	 * @throws ApplicationDomainLogicException
	 * @throws DAOException
	 */
	public List<Repository.ConnectDefinision> getConnectDefinisionList() throws ApplicationDomainLogicException  {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		return dao.getAllConnectDefinisionsList();
	}

	public TableForm getTableForm(String connectionID, String tableID) throws ApplicationDomainLogicException {
		Repository.ConnectDefinision connection = this.getConnectionByID(connectionID);
		TableForm tableForm = new TableForm();
		if(connection.getTableForms() != null && connection.getTableForms().getTableForm() != null){
			if(connection.getTableForms().getTableForm().size() > 0){
				for(int i = 0; i < connection.getTableForms().getTableForm().size(); i++){
					if(connection.getTableForms().getTableForm().get(i).getId().equals(tableID)){
						tableForm = connection.getTableForms().getTableForm().get(i);
					}
				}
			}
		}
		return tableForm;
	}

	public ConnectDefinision getConnectionByID(String connectionID) throws ApplicationDomainLogicException {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		List<Repository.ConnectDefinision> list = dao.getAllConnectDefinisionsList();
		Repository.ConnectDefinision connection = new ConnectDefinision();
		if(list.size() > 0){
			for(int i = 0; i < list.size(); i++){
				if(list.get(i).getId().equals(connectionID)){
					connection = list.get(i);
				}
			}
		}
		return connection;
	}

	/**
	 * @param connectionID
	 * @return true : exist /false : not exist
	 * @throws ApplicationDomainLogicException
	 */
	public boolean isExistConnectionByID(String connectionID) throws ApplicationDomainLogicException {
		final ConnectDefinisionDAO dao = createConnectDefinisionDAO();
		List<Repository.ConnectDefinision> list = dao.getAllConnectDefinisionsList();
		if(list.size() > 0){
			for(int i = 0; i < list.size(); i++){
				if(list.get(i).getId().equals(connectionID)){
					return true;
				}
			}
		}
		return false;
	}

	public boolean checkFormatFileRepositoryXml() throws ApplicationDomainLogicException {
		try {
			createDAO("ConnectDefinisionDAO");
		} catch (final DAOException e) {
			return false;
		}
		return true;
	}
}
