package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableLogicalOperator;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;

/**
 *
 * レコードの検索条件リスト画面要素表示用アイテム。
 * <p>
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
//@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchConditionItem implements Serializable {

    /**
     *
     */
    private String targetedTableId;

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 5980497029960013445L;

    /**
     * 比較演算子プルダンリストプロパティ
     */
    private SelectableItem[] targetedColumnIdItems;

    /**
     * 比較演算子プルダンリストプロパティ
     */
    private SelectableItem[] targetedColumnIdIsSelectItems;

    public boolean isSelect(){
    	return true;
    }

    /**
     * 条件追加可能かどうか
     * 下位互換を保つためデフォルト値はTRUEです
     */
    private boolean isaddconditionrow = true;

    /**
     * 条件削除可能かどうか
     * 下位互換を保つためデフォルト値はTRUEです
     */
    private boolean isremoveconditionrow = true;

    /**
     * 検索対象カラムID
     */
    private String targetedColumnId;

    /**
     *
     */
    private String targetedColumnIdIsSelect;

    /**
    *
    */
    private String targetedColumnIdIsSelectLabel;

    /**
     * カラム検索条件
     */
    private String targetedColumnSearchCondition;

    /**
     * 比較演算子プルダンリストプロパティ
     */
    private SelectableItem[] comparisonOperatorItems;

    /**
     * 比較演算子プルダンリスト選択プロパティ
     */
    private String comparisonOperator;

    /**
     * 論理演算子プルダウンリストプロパティ
     */
    private SelectableItem[] logicalOperatorItems;

    /**
     * 論理演算子プルダンリスト選択プロパティ
     */
    private String logicalOperator;

    /**
     * 検索条件が有効か否かを戻す。
     * <p>
     * 検索条件が評価可能かどうかを調べ結果を戻します。null 抽出が指定されて
     * いるか、検索条件値の入力があれば true、無ければ false を戻します。</p>
     *
     * @return true : 有効 / false : 無効
     */
    public boolean exist() {
        if (StringUtils.isEmpty(comparisonOperator)) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * targetedColumnSearchCondition を戻します。
     *
     * @return String
     */
    public String getTargetedColumnSearchCondition() {
        return targetedColumnSearchCondition;
    }

    /**
     * targetedColumnSearchCondition を設定します。
     *
     * @param String targetedColumnSearchCondition
     */
    public void setTargetedColumnSearchCondition(String searchCondition) {
        this.targetedColumnSearchCondition = searchCondition;
    }

	/**
     * isaddconditionrow を戻します。
     *
     * @return boolean
     */
    public boolean getIsAddConditionRow() {
		return isaddconditionrow;
	}

    /**
     * isaddconditionrow を設定します。
     *
     * @param boolean fixedCondition
     */
	public void setIsAddConditionRow(boolean isaddconditionrow) {
		this.isaddconditionrow = isaddconditionrow;
	}

	/**
     * fixedCondition を戻します。
     *
     * @return boolean
     */
    public boolean getIsRemoveConditionRow() {
		return isremoveconditionrow;
	}

    /**
     * fixedCondition を設定します。
     *
     * @param boolean fixedCondition
     */
	public void setIsRemoveConditionRow(boolean isremoveconditionrow) {
		this.isremoveconditionrow = isremoveconditionrow;
	}

	/**
     * targetedColumnId を戻します。
     *
     * @return String
     */
    public String getTargetedColumnId() {
        return targetedColumnId;
    }

    /**
     * targetedColumnId を設定します。
     *
     * @param String targetedColumnId
     */
    public void setTargetedColumnId(String targetedColumnId) {
        this.targetedColumnId = targetedColumnId;
    }

    public String getTargetedColumnIdIsSelect() {
		return targetedColumnIdIsSelect;
	}

	public void setTargetedColumnIdIsSelect(String targetedColumnIdIsSelect) {
		this.targetedColumnIdIsSelect = targetedColumnIdIsSelect;
	}

	public String getTargetedColumnIdIsSelectLabel() {
		return targetedColumnIdIsSelectLabel;
	}

	public void setTargetedColumnIdIsSelectLabel(String targetedColumnIdIsSelectLabel) {
		this.targetedColumnIdIsSelectLabel = targetedColumnIdIsSelectLabel;
	}

	/**
     * comparisonOperatorItems を戻します。
     *
     * @return SelectOneMenuItem[]
     */
    public SelectOneMenuItem[] getComparisonOperatorItems() {
        return comparisonOperatorItems;
    }

    /**
     * comparisonOperatorItems を設定します。
     *
     * @param SelectOneMenuItem[] comparisonOperatorItems
     */
    public void setComparisonOperatorItems(
    		SelectableItem[] comparisonOperatorItems) {
        this.comparisonOperatorItems = comparisonOperatorItems;
    }

    /**
     * comparisonOperator を戻します。
     *
     * @return String
     */
    public String getComparisonOperator() {
        return comparisonOperator;
    }

    /**
     * comparisonOperator を設定します。
     *
     * @param String comparisonOperator
     */
    public void setComparisonOperator(String comparisonOperator) {
        this.comparisonOperator = comparisonOperator;
    }

    /**
     * logicalOperator を戻します。
     *
     * @return String
     */
    public String getLogicalOperator() {
        return logicalOperator;
    }

    /**
     * 論理演算子に値が入力されているか否かを返します。
     *
     * @return
     */
    public boolean isEmptyLogicalOperator() {
        if (logicalOperator == null) {
            return true;
        } else {
            if (SqlWhereTableLogicalOperator.valueOf(logicalOperator)
                    == SqlWhereTableLogicalOperator.blank) {
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * logicalOperator を設定します。
     *
     * @param String logicalOperator
     */
    public void setLogicalOperator(String logicalOperator) {
        this.logicalOperator = logicalOperator;
    }

    /**
     * logicalOperatorItems を戻します。
     *
     * @return SelectOneMenuItem[]
     */
    public SelectOneMenuItem[] getLogicalOperatorItems() {
        return logicalOperatorItems;
    }

    /**
     * logicalOperatorItems を設定します。
     *
     * @param SelectOneMenuItem[] logicalOperatorItems
     */
    public void setLogicalOperatorItems(SelectableItem[] logicalOperatorItems) {
        this.logicalOperatorItems = logicalOperatorItems;
    }

    /**
     * targetedColumnIdItems を戻します。
     *
     * @return SelectOneMenuItem[]
     */
    public SelectableItem[] getTargetedColumnIdItems() {
        return targetedColumnIdItems;
    }

    /**
     * targetedColumnIdItems を設定します。
     *
     * @param SelectOneMenuItem[] targetedColumnIdItems
     */
    public void setTargetedColumnIdItems(SelectableItem[] targetedColumnIdItems) {
        this.targetedColumnIdItems = targetedColumnIdItems;
    }

	public SelectableItem[] getTargetedColumnIdIsSelectItems() {
		return targetedColumnIdIsSelectItems;
	}

	public void setTargetedColumnIdIsSelectItems(SelectableItem[] targetedColumnIdIsSelectItems) {
		this.targetedColumnIdIsSelectItems = targetedColumnIdIsSelectItems;
	}

	/**
	 * @return the targetedTableId
	 */
	public String getTargetedTableId() {
		return targetedTableId;
	}

	/**
	 * @param targetedTableId the targetedTableId to set
	 */
	public void setTargetedTableId(String targetedTableId) {
		this.targetedTableId = targetedTableId;
	}
}
