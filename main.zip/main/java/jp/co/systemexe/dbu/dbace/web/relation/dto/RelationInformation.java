/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.web.relation.dto;

import java.io.Serializable;
import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.dto.ItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDTO;

/**
 * @author  tu-lenh
 * @version 0.0.0
 */
public class RelationInformation implements Serializable {
	private static final long serialVersionUID = 1L;
	//connection id
    private String connectid;
	//Table Master,Table Detail
    private List<TableDTO> tables;
    //Column Join
    private List<ItemDTO> items;
    private String id;//YYMMDDHHSSMMZ
    private String label;//リレーション名
    private String type;//inner,left,right,outer
    
	/**
	 * connectid を戻します。
	 *
	 * @return String
	 */
	public String getConnectid() {
		return connectid;
	}

	/**
	 * connectid を設定します。
	 *
	 * @param String connectid
	 */
	public void setConnectid(String connectid) {
		this.connectid = connectid;
	}

	/**
	 * @return the tables
	 */
	public List<TableDTO> getTables() {
		return tables;
	}
	/**
	 * @param tables the tables to set
	 */
	public void setTables(List<TableDTO> tables) {
		this.tables = tables;
	}
	/**
	 * @return the items
	 */
	public List<ItemDTO> getItems() {
		return items;
	}
	/**
	 * @param items the items to set
	 */
	public void setItems(List<ItemDTO> items) {
		this.items = items;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}
	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
}
