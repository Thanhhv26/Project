/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.dto;

import java.io.Serializable;

/**
 * アプリケーションメッセージ DTO。
 * <p>
 * セッション中に保持される、サブアプリケーション間でメッセージのやりとりを行う
 * ための DTO です。
 * </p><p>
 * 本クラスに定義したプロパティは、本アプリケーション内でグローバルスコープを
 * 持った変数として取り扱えますが、無分別に項目を定義してはいけません。<br />
 * 本 DTO 内に新しいプロパティを定義する際には、他の開発メンバー及びリーダーの
 * 合意が取れた場合のみとします。
 * </p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
//@Component(instance = InstanceType.SESSION)
public final class ApplicationMessageDTO implements Serializable {

    /**
     * serialVersionUID。
     */
    private static final long serialVersionUID = -3013909354095176760L;

    /**
     * 例外メッセージ を保持します。
     * <p>画面全体で共通の領域に対するエラーメッセージ</p>
     */
    private String message;

    /**
     * 例外メッセージ を保持します。
     * <p>個別の入力項目に対するエラーメッセージ</p>
     */
    private String subMessage;

    /**
     * 例外メッセージ を戻します。
     *
     * @return String
     */
    public String getMessage() {
        return message;
    }

    /**
     * 例外メッセージ を戻します。
     *
     * @return String
     */
    public String getSubMessage() {
        return subMessage;
    }

    /**
     * 例外メッセージ を設定します。
     *
     * @param String message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * 例外メッセージ を設定します。
     *
     * @param String subMessage
     */
    public void setSubMessage(String subMessage) {
        this.subMessage = subMessage;
    }

    /**
     * exception を設定します。
     * <p>
     * 設定されたチェック例外オブジェクトより、ユーザーに対するエラー表示用のメ
     * ッセージのなかで、個別の入力項目に対するエラーメッセージ、画面全体で共通
     * の領域へのエラーメッセージを生成します。</p>
     *
     * @param Exception exception
     */
    public void setException(final Exception e) {
        e.printStackTrace();
        this.message = e.toString();
        final StringBuffer buff = new StringBuffer();
        for (int i = 0; i < 100; i++) {
            Throwable te = e.getCause();
            if (te == null) {
                break;
            }

            buff.append(te.getMessage());
            buff.append(" ; ");
        }
        this.subMessage = buff.toString();
    }

    /**
     * ApplicationMessageDTO の生成。
     * <p>コンストラクタ。</p>
     */
    public ApplicationMessageDTO() {
        return;
    }
}
