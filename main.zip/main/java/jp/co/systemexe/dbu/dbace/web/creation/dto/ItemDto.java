/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item.Cols;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item.SelectableList;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

@Data
public class ItemDto {
    protected String htmlElement;
    protected ItemDto.SelectableListDto selectableListDto;
    protected String selectableSql;
    protected String parametersSql;
    protected ItemDto.RestrictionsDto restrictionsDto;
    protected String _default;
    protected String explanation;
    protected String canPreview;
    protected String canDisplayRecordEdit;
    protected String canDisplayNamePreview;
    protected String canEditing;
    protected String isUpdateKey;
    protected String isSelectKey;
    protected String id;
    protected String label;
    protected int sortIndex;
    protected String primaryKey;
    protected String unique;
    protected String foreignKey;
    protected String dataType;
    protected String dataLength;
    protected String dataUnit;
    protected ColsDto cols;
    protected OperationDto operation;

    public ItemDto(){

    }

    public ItemDto(Item item){
    	this.setHtmlElement(item.getHtmlElement());
    	this.setSelectableListDto(new SelectableListDto(item.getSelectableList()));
    	this.setSelectableSql(item.getSelectableSql());
    	this.setParametersSql(item.getParametersSql());
    	this.setRestrictionsDto(new RestrictionsDto(item.getRestrictions()));
    	this.set_default(item.get_default());
    	this.setExplanation(item.getExplanation());
    	this.setCanPreview(item.getCanPreview());
    	this.setCanDisplayRecordEdit(item.getCanDisplayRecordEdit());
    	this.setCanDisplayNamePreview(item.getCanDisplayNamePreview());
    	this.setCanEditing(item.getCanEditing());
    	this.setIsUpdateKey(item.getIsUpdateKey());
    	this.setIsSelectKey(item.getIsSelectKey());
    	this.setId(item.getId());
    	this.setLabel(item.getLabel());
    	this.setSortIndex(item.getSortIndex());
    	this.setPrimaryKey(item.getPrimaryKey());
    	this.setUnique(item.getUnique());
    	this.setForeignKey(item.getForeignKey());
    	this.setDataType(item.getDataType());
    	this.setDataLength(item.getDataLength());
    	this.setDataUnit(item.getDataUnit());
    	this.setCols(new ColsDto(item.getCols()));
    	this.setOperation(new OperationDto(item.getOperation()));
    }

    @Data
    public static class ColsDto{
    	private List<ColsDto.ColDto> colDto;

    	public ColsDto(){

    	}

    	public ColsDto(Cols cols){
    		if(cols != null){
    			for(Item.Cols.Col item : cols.getCol()){
    				ColDto temp = new ColDto(item);
    				this.getColDto().add(temp);
    			}
    		}
    	}

    	public List<ColsDto.ColDto> getColDto(){
    		if(colDto == null){
    			colDto = new ArrayList<ColsDto.ColDto>();
    		}
    		return colDto;
    	}

        @Data
        public static class ColDto{
        	private String listNO;
        	private String tableID;
        	private String itemID;

        	public ColDto(){

        	}

        	public ColDto(Item.Cols.Col col){
        		if(col != null){
        			this.setItemID(col.getItemID());
        			this.setTableID(col.getTableID());
        			this.setListNO(col.getListNO());
        		}
        	}
        }
    }

    @Data
    public static class OperationDto{
    	private boolean select;
    	private boolean edit;
    	private boolean copy1;
    	private boolean copy2;

    	public OperationDto(){

    	}

    	public OperationDto(Item.Operation operation){
    		if(operation != null){
    			this.setSelect(operation.isSelect());
    			this.setEdit(operation.isEdit());
    			this.setCopy1(operation.isCopy1());
    			this.setCopy2(operation.isCopy2());
    		}
    	}
    }

    @Data
    public static class SelectableListDto {

        protected List<ItemDto.SelectableListDto.LiDto> liDto;

        /**
         * contructor no param
         */
        public SelectableListDto(){

        }

        /**
         * contructor with param SelectableList
         *
         * @param selectableList
         */
        public SelectableListDto(SelectableList selectableList){
        	if(selectableList != null){
        		for(SelectableList.Li item : selectableList.getLi()){
            		LiDto dto = new LiDto(item);
            		this.getLiDto().add(dto);
            	}
        	}
        }

        /**
         * when liDto is null => create new ArrayList
         *
         * @return
         */
        public List<ItemDto.SelectableListDto.LiDto> getLiDto() {
            if (liDto == null) {
            	liDto = new ArrayList<ItemDto.SelectableListDto.LiDto>();
            }
            return liDto;
        }

        public SelectableListDto(List<SelectableItem> selectableListItems){
        	if(selectableListItems != null){
        		for(SelectableItem item : selectableListItems){
            		LiDto dto = new LiDto();
            		dto.setId(item.getValue());
            		dto.setLabel(item.getLabel());
            		this.getLiDto().add(dto);
            	}
        	}
        }

        @Data
        public static class LiDto {
            protected String id;
            protected String label;

            /**
             * contructor new LiDto no param
             */
            public LiDto(){

            }

            /**
             * contructor LiDto with param is SelectableList.Li
             *
             * @param li
             */
            public LiDto(SelectableList.Li li){
            	if(li != null){
            		this.setId(li.getId());
            		this.setLabel(li.getLabel());
            	}
            }
        }

    }


    public static class RestrictionsDto {
        protected List<ItemDto.RestrictionsDto.RestrictionDto> restrictionDtoList;

        /**
         * contructor new RestrictionsDto
         */
        public RestrictionsDto(){

        }

        /**
         * new contructor with Item.Restrictions
         *
         * @param restrictions
         */
        public RestrictionsDto(Item.Restrictions restrictions){
        	if(restrictions != null){
        		for(Item.Restrictions.Restriction item : restrictions.getRestriction()){
        			ItemDto.RestrictionsDto.RestrictionDto dto =new RestrictionDto(item);
        			this.getRestrictionDtoList().add(dto);
        		}
        	}
        }

        /**
         * when get restrictionDtoList == null => contructor new list
         *
         * @return restrictionDtoList => RestrictionDto list
         */
        public List<ItemDto.RestrictionsDto.RestrictionDto> getRestrictionDtoList() {
            if (this.restrictionDtoList == null) {
            	this.restrictionDtoList = new ArrayList<ItemDto.RestrictionsDto.RestrictionDto>();
            }
            return this.restrictionDtoList;
        }

        @Data
        public static class RestrictionDto {
            protected String id;
            protected String value;

            /**
             * contructor of RestrictionDto
             */
            public RestrictionDto(){

            }

            /**
             * contructor of RestrictionDto
             *
             * @param restriction
             */
            public RestrictionDto(Item.Restrictions.Restriction restriction){
            	if(restriction != null){
            		this.setId(restriction.getId());
            		this.setValue(restriction.getValue());
            	}
            }

			public RestrictionDto(String id, String value) {
				super();
				this.id = id;
				this.value = value;
			}
        }

    }
}
