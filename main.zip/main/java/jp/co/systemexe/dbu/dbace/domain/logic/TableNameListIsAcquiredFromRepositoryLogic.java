/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectItem;
import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.web.repository.dto.GetTableDependenceDatabaseDTO;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.IdSelectTableLabeExtendConnectDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.TableLabeDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.TableLabeExtendConnectDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * リポジトリからテーブル名一覧を取得するロジック。
 * <p>
 * 一般ユーザー向けの「テーブル検索」画面要素などで利用する、リポジトリ内の
 * テーブル名一覧取得用ビジネスロジック。条件付き検索を行うためのメソッドの
 * オーバーライドも定義しています。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class TableNameListIsAcquiredFromRepositoryLogic
        extends BaseApplicationDomainLogic {

    /**
     * リポジトリ内から定義済みのテーブル名一覧リストを取得して戻します。
     * <p>
     * リポジトリ内の特定の接続定義内に定義された編集対象テーブル名の一覧を
     * リストで戻します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @return List&lt;IdSelectable&gt;
     * @throws ApplicationDomainLogicException
     */
    public List<IdSelectable> getTableNameList(final String connectDefinitionId)
            throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        final SortedMap<String, TableLabeDTO> map;
        try {
            if (dao.hasTableForms(connectDefinitionId)) {
            	map = dao.getTableNameMap(connectDefinitionId);
            } else {
            	map = new TreeMap<String, TableLabeDTO>();
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        final List<IdSelectable> ret = new ArrayList<IdSelectable>();
        for (final TableLabeDTO dto : map.values()) {
        	IdSelectItem selectItem = new IdSelectItem(dto.getId(), dto.getLabel());
        	selectItem.setType(dto.getType());
            ret.add(selectItem);
        }
        return ret;
    }

	/**
	 * @param connectDefinitionId
	 * @return
	 */
	public List<IdSelectable> getAllTableNameMap(String connectDefinitionId) throws ApplicationDomainLogicException {
		final TableFormDAO dao = createTableFormDAO();
        final SortedMap<String, TableLabeDTO> map;
        try {
            if (dao.hasTableForms(connectDefinitionId)) {
            	map = dao.getAllTableNameMap(connectDefinitionId);
            } else {
            	map = new TreeMap<String, TableLabeDTO>();
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        final List<IdSelectable> ret = new ArrayList<IdSelectable>();
        for (final TableLabeDTO dto : map.values()) {
        	IdSelectItem selectItem = new IdSelectItem(dto.getId(), dto.getLabel());
        	selectItem.setType(dto.getType());
            ret.add(selectItem);
        }
        return ret;
	}

    /**
     * Check current table is multi table
     * @param connectDefinitionId
     * @param tableFormId
     * @return boolean
     * @throws ApplicationDomainLogicException
     */
    public boolean isMultiTable(final String connectDefinitionId, final String tableFormId)
            throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();

        try {
            if (dao.hasTableForms(connectDefinitionId)) {
            	return dao.isMultiTable(connectDefinitionId, tableFormId);
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return false;
    }

    /**
     *
     * @param connectDefinitionId
     * @param tableFormId
     * @return
     * @throws ApplicationDomainLogicException
     */
    public TableFormDTO getTableFormDTO(final String connectDefinitionId, final String tableFormId)
            throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();

        try {
            if (dao.hasTableForms(connectDefinitionId)) {
            	return dao.getTableFormDTO(connectDefinitionId, tableFormId);
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return null;
    }

    /**
    *
    * @param connectDefinitionId
    * @param tableFormId
    * @return
    * @throws ApplicationDomainLogicException
    */
   public TableItemDTO getTableItemDTO(final String connectDefinitionId, final String tableFormId, final String tableItemId)
           throws ApplicationDomainLogicException {
       final TableFormDAO dao = createTableFormDAO();

       try {
           if (dao.hasTableForms(connectDefinitionId)) {
           	return dao.getTableItemDTO(connectDefinitionId, tableFormId, tableItemId);
           }
       } catch (final DAOException e) {
           throw new ApplicationDomainLogicException(e.getMessage(), e);
       }
       return null;
   }

    /**
     * リポジトリ内から定義済みのテーブル名一覧リストを取得して戻します。
     * <p>
     * リポジトリ内の特定の接続定義内に定義された編集対象テーブル名の一覧を
     * リストで戻します。</p>
     *
     * @param connectDefinitionId 接続定義名
     * @return List&lt;IdSelectable&gt;
     * @throws ApplicationDomainLogicException
     */
    public List<IdSelectable> getTableNameListByConnectName(final String connectDefinitionId)
            throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        final SortedMap<String, TableLabeDTO> map;
        try {
            if (dao.hasTableFormsByConnectName(connectDefinitionId)) {
            	map = dao.getTableNameMapByConnectName(connectDefinitionId);
            } else {
            	map = new TreeMap<String, TableLabeDTO>();
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        final List<IdSelectable> ret = new ArrayList<IdSelectable>();
        for (final TableLabeDTO dto : map.values()) {
        	IdSelectItem selectItem = new IdSelectItem(dto.getId(), dto.getLabel());
        	selectItem.setType(dto.getType());
            ret.add(selectItem);
        }
        return ret;
    }

    /**
     * @return
     * @throws ApplicationDomainLogicException
     */
    public List<IdSelectTableLabeExtendConnectDTO> getAllTableNameList(UserInfoDTO userInfoDTO) throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        final SortedMap<String, TableLabeExtendConnectDTO> map;
        try {
            	map = dao.getAllTableNameMap(userInfoDTO);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        final List<IdSelectTableLabeExtendConnectDTO> ret = new ArrayList<IdSelectTableLabeExtendConnectDTO>();
        for (String tableConnectLabel : map.keySet()) {
        	TableLabeExtendConnectDTO dto = map.get(tableConnectLabel);
            ret.add(new IdSelectTableLabeExtendConnectDTO(tableConnectLabel, dto));
        }
        return ret;
    }

    /**
     * @return
     * @throws ApplicationDomainLogicException
     */
    public List<IdSelectTableLabeExtendConnectDTO> getAllTableNameListNotExistMulti(UserInfoDTO userInfoDTO) throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        final SortedMap<String, TableLabeExtendConnectDTO> map;
        try {
            	map = dao.getAllTableNameMap(userInfoDTO);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        final List<IdSelectTableLabeExtendConnectDTO> ret = new ArrayList<IdSelectTableLabeExtendConnectDTO>();
        for (String tableConnectLabel : map.keySet()) {
        	TableLabeExtendConnectDTO dto = map.get(tableConnectLabel);
			if (null == dto.getType()) {
				ret.add(new IdSelectTableLabeExtendConnectDTO(tableConnectLabel, dto));
			}
        }
        return ret;
    }
    /**
     * @return
     * @throws ApplicationDomainLogicException
     */
    public List<IdSelectTableLabeExtendConnectDTO> getAllTableNameConnectTypeList(GetTableDependenceDatabaseDTO search,final String connectDefinitionId) throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        final SortedMap<String, TableLabeExtendConnectDTO> map;
        try {
            	map = dao.getAllTableNameConnectTypeMap(connectDefinitionId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        final List<IdSelectTableLabeExtendConnectDTO> ret = new ArrayList<IdSelectTableLabeExtendConnectDTO>();
        for (String tableConnectLabel : map.keySet()) {
        	TableLabeExtendConnectDTO dto = map.get(tableConnectLabel);
			if (!search.getTableId().equals(dto.getId()) && null == dto.getType()) {
        		ret.add(new IdSelectTableLabeExtendConnectDTO(tableConnectLabel, dto));
        	}
        }
        return ret;
    }

    /**
     * リポジトリ内から定義済みのテーブル名一覧リストを取得して戻します。
     * <p>
     * 検索条件にワイルドカードを付加してあいまい化し、リポジトリ内のテーブル名
     * リストを絞り込んで戻します。<br />
     * ラベル表示名で抽出するメソッドです。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param condition 検索条件文字列（テーブル名の一部）
     * @return List&lt;IdSelectable&gt;
     */
    public List<IdSelectable> extractTableNameFromLabel(
            final String connectDefinitionId, final String condition)
            throws ApplicationDomainLogicException {
        final List<IdSelectable> list = getTableNameList(connectDefinitionId);
        final List<IdSelectable> ret = new ArrayList<IdSelectable>();
        for (final Iterator<IdSelectable> ite = list.iterator(); ite.hasNext();) {
            final IdSelectable table = ite.next();
            if (table.getLabel().matches(".*" + condition + ".*")) {
                ret.add(table);
            }
        }
        return ret;
    }

    /**
     * リポジトリ内から定義済みのテーブル名一覧リストを取得して戻します。
     * <p>
     * 検索条件にワイルドカードを付加してあいまい化し、リポジトリ内のテーブル名
     * リストを絞り込んで戻します。<br />
     * テーブル ID（DB 内のテーブル名）で抽出するメソッドです。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param condition 検索条件文字列（テーブル名の一部）
     * @return List&lt;IdSelectable&gt;
     */
    public List<IdSelectable> extractTableNameFromId(
            final String connectDefinitionId, String condition)
            throws ApplicationDomainLogicException {
        final List<IdSelectable> list = getTableNameList(connectDefinitionId);
        final List<IdSelectable> ret = new ArrayList<IdSelectable>();
        if (StringUtils.isNotEmpty(condition)) {
        	condition = condition.toUpperCase();
        }
        for (final Iterator<IdSelectable> ite = list.iterator(); ite.hasNext();) {
            final IdSelectable table = ite.next();
            String tableId = table.getId();
			if (StringUtils.isNotEmpty(tableId)) {
				tableId = tableId.toUpperCase();
			}
            if (tableId.matches(".*\\Q" + condition + "\\E.*")) {
                ret.add(table);
            }
        }
        return ret;
    }

    /**
     * TableNameListIsAcquiredFromRepositoryLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public TableNameListIsAcquiredFromRepositoryLogic() {
        return;
    }

    /**
     * テーブルフォーム DAO を生成して戻す。
     *
     * @return TableFormDAO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDAO createTableFormDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * @param connectDefinitionName
     * @return
     * @throws ApplicationDomainLogicException
     */
    public String getConnectDefinitionIdByConnectName(final String connectDefinitionName) throws ApplicationDomainLogicException {
            final TableFormDAO dao = createTableFormDAO();
            final String ret;
            try {
                ret = dao.getConnectDefinitionIdByConnectName(connectDefinitionName);
            } catch (final DAOException e) {
                throw new ApplicationDomainLogicException(e.getMessage(), e);
            }
            return ret;
    }
}
