package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.SortedMap;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.service.SpreadsheetWriter;
import jp.co.systemexe.dbu.dbace.domain.service.impl.BigExcelWriterImpl;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * カスマイズXSSFでテーブルデータをExcelに出力します。
 * <p>
 * 出力されるExcelのファイル名は テーブル名 + 日付(yyyy/MM/dd hh:mm:ss.SSS).xlsx になります。<br />
 * また、出力されるExcelのシート名は テーブル名 となります。
 * </p>
 *
 * @author EXE Phung-Tien
 * @version 0.0.0
 */
public class OutputsToExcelUseCustomWriterWithTableDataDAO extends BaseOutputsToFileWithTableDataDAO {

	/*
	 * Excel Max行数
	 */
	private final int MAX_ROW_COUNT = 1048576;

	/**
	 * 最大出力ファイルサイズ
	 */
	private long MAX_OUTPUT_BYTES = ((long) SystemProperties.getDownloadMaximumByteForExcel()) * 1024L * 1024L;

	/**
	 * VN mode(use Custom writer)
	 */
	private BigExcelWriterImpl bigExcelWriterImpl;
	private SpreadsheetWriter spreadsheetWriter;
	/**
	 * 現在のExcel行数
	 */
	private int rowCount = 1;
	private int sheetIndex = 1;

	/**
	 * ファイルサイズをチェックする、レコード件数
	 * <p>
	 * 初期値は1000
	 * </p>
	 */
	private int checkRecordCount = 1000;

	/**
	 * データ出力件数
	 */
	private int recordCount = 0;

	/**
	 * OutputsToExcelUseCustomWriterWithTableDataDAO.java の生成。
	 *
	 */
	public OutputsToExcelUseCustomWriterWithTableDataDAO() {
		super();
	}

	@Override
	public void outputFile(
			final String tableId, 
			final SortedMap<Integer, TableItemDTO> columnId,
			final Map<String, String> columnData,
			final String dbType) throws DAOException {
		try {
			if (bigExcelWriterImpl == null) {
				getLogger().debug("download_mode: 1");
				bigExcelWriterImpl = new BigExcelWriterImpl(new File(getFilePath()));
			}
			if (bigExcelWriterImpl.getWorkbook() == null) {
				bigExcelWriterImpl.createWorkbook();

			}

			if (rowCount == 1 || rowCount >= MAX_ROW_COUNT) {
				rowCount = 1;
				final String tableName;
				if (tableId.indexOf(".") == -1) {
					tableName = tableId;
				} else {
					tableName = tableId.substring(tableId.indexOf(".") + 1);
				}

				String sheetName = tableName.length() > 10 ? tableName.substring(0, 10) : tableName;
				sheetName += "_" + sheetIndex;

				bigExcelWriterImpl.addSheets(sheetName);

				sheetIndex++;

				bigExcelWriterImpl.writeWorkbookTemplate(sheetName);

				if (spreadsheetWriter != null) {
					spreadsheetWriter.endSheet();
					spreadsheetWriter.clearBuff();
				}
				spreadsheetWriter = bigExcelWriterImpl.createSpreadsheetWriter(sheetName);

				spreadsheetWriter.beginSheet();

				createHeader(columnId, spreadsheetWriter);
			}

			createRow(columnId, columnData, spreadsheetWriter);
			//getLogger().debug(recordCount + "件目出力中");

			if (!checkFileSize()) {
				// MI-E-0147=ダウンロード件数が多すぎます。データ件数を絞り込んでください。
				final String message = MessageUtils.getMessage("MI-E-0147");
				getLogger().error(message);
				throw new DAOException(message);
			}
		} catch (Exception e) {
			throw new DAOException(e.getMessage());
		}
	}

	/**
	 * Create row use SpreadsheetWriter</br>
	 * VN mode(use XSSF, fix bug Out of memory)
	 *
	 * @param tableItemMap
	 * @param columnData
	 * @param spreadsheetWriter
	 * @throws IOException
	 */
	private void createRow(SortedMap<Integer, TableItemDTO> tableItemMap, Map<String, String> columnData,
			SpreadsheetWriter spreadsheetWriter) throws IOException {

		spreadsheetWriter.insertRow(rowCount);
		short detailCellIndex = 0;
		for (final Integer index : tableItemMap.keySet()) {
			String data = columnData.get(tableItemMap.get(index).getItemId());
			spreadsheetWriter.createCell(detailCellIndex, data == null ? "" : data);
			detailCellIndex++;
		}
		spreadsheetWriter.endRow();
		recordCount++;
		rowCount++;
	}

	/**
	 * Create header use SpreadsheetWriter</br>
	 * VN mode(use XSSF, fix bug Out of memory)
	 *
	 * @param tableItemMap
	 * @param spreadsheetWriter
	 * @throws IOException
	 */
	private void createHeader(SortedMap<Integer, TableItemDTO> tableItemMap, SpreadsheetWriter spreadsheetWriter)
			throws IOException {
		short headerCellIndex = 0;
		// insert header row
		spreadsheetWriter.insertRow(headerCellIndex);
		short columnIndex = 0;
		for (final Integer index : tableItemMap.keySet()) {
			final TableItemDTO item = tableItemMap.get(index);
			spreadsheetWriter.createCell(columnIndex, item.getItemLabel(), headerCellIndex);
			columnIndex++;
		}
		spreadsheetWriter.endRow();
	}

	@Override
	public void write() throws DAOException {
		try {
			spreadsheetWriter.endSheet();

			bigExcelWriterImpl.completeWorkbook();

			bigExcelWriterImpl.deleteTempFiles();
		} catch (IOException e) {
			getLogger().error(e.getMessage());
		}
	}

	@Override
	public int getOutputRecordCount() {

		return recordCount;
	}

	@Override
	public boolean checkFileSize() throws DAOException {
		if (recordCount >= checkRecordCount) {

			try {
				// ファイル出力するファイルパス
				String pathTempFile = "";
				pathTempFile = this.getFilePath();

				// Excelファイルの出力
				writeExcelToTempFile(pathTempFile);

				// ファイルサイズチェック
				File file = new File(pathTempFile);
				final long bytes = file.length();

				if (bytes > MAX_OUTPUT_BYTES) {
					getLogger().debug("excel file size:" + bytes + "," + MAX_OUTPUT_BYTES);
					bigExcelWriterImpl.deleteTempFiles();
					bigExcelWriterImpl.close();
					this.close();
					file.delete();
					return false;
				} else {
					checkRecordCount = (int) (MAX_OUTPUT_BYTES / (bytes / recordCount));
					getLogger().debug("checkRecordCount:" + checkRecordCount);

					// Excelファイル出力し続きます。
					continusWrite();

					return true;
				}
			} catch (final IOException e) {
				final String message = "Excelファイルの出力に失敗しました。(" + e.getMessage() + ")";
				getLogger().fatal(message, e);
				throw new DAOException(message, e);
			}
		}
		return true;

	}

	/**
	 * Excelファイル出力し続きます。
	 */
	private void continusWrite() throws DAOException {
		try {
			spreadsheetWriter.reOpenFile(bigExcelWriterImpl.getCurFileXmlPro());
		} catch (Exception e) {
			throw new DAOException(e.getMessage());
		}
	}

	/**
	 * Excelファイルの出力
	 *
	 * @param path
	 * @throws DAOException
	 */
	private void writeExcelToTempFile(String path) throws DAOException {
		try {
			spreadsheetWriter.endSheet();

			bigExcelWriterImpl.createTempFileExcelForCheckSize();

		} catch (IOException e) {
			getLogger().error(e.getMessage());
		}
	}
}
