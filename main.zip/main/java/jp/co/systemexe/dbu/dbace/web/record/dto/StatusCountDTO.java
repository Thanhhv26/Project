/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import lombok.Data;
/**
 *
 * @author tu-lenh
 * @version 1.0 Nov 29, 2016
 *
 */
@Data
public class StatusCountDTO {
	boolean isOK;
	boolean updateErrorCount;
	boolean updateSuccessCount;
	boolean insertErrorCount;
	boolean insertSuccessCount;

	public StatusCountDTO(boolean isOK, boolean updateErrorCount, boolean updateSuccessCount, boolean insertErrorCount,boolean insertSuccessCount) {
		this.isOK = isOK;
		this.updateErrorCount = updateErrorCount;
		this.updateSuccessCount = updateSuccessCount;
		this.insertErrorCount = insertErrorCount;
		this.insertSuccessCount = insertSuccessCount;
	}

}
