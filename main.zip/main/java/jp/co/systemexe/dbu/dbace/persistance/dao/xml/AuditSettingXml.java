/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;

/**
 * 監査ログ設定情報XML。
 * <p>
 * 監査ログ設定情報XMLファイルをラップした Singleton クラスです。</p>
 *
 * @author	EXE 島田 雄一郎
 * @version 0.0.0
 */
public final class AuditSettingXml {

    /**
     * インスタンス。
     */
    private static AuditSettingXml instance;

    /**
     * 監査ログ設定情報XMLファイル。
     */
    private File file;

    /**
     * リポジトリファイルのファイルパスを変更します。
     */
    public void changeAuditSettingXmlFile() {
        synchronized (AppRepository.class) {
	        this.file = SystemProperties.getAuditSettingFile();
        }
    }
    
    /**
     * このクラスのインスタンスを返します。
     * 
     * @return
     */
    public static AuditSettingXml getInstance() {
        if (instance == null) {
            synchronized (AuditSettingXml.class) {
                if (instance == null) {
                    instance = new AuditSettingXml();
                }
            }
        }
        return instance;
    }

    /**
     * inputStream を戻します。
     * 
     * @return InputStream
     */
    public final InputStream getInputStream() throws FileNotFoundException {
        return new FileInputStream(this.file);
    }

    /**
     * outputStream を戻します。
     * 
     * @return OutputStream
     * @exception FileNotFoundException
     */
    public OutputStream getOutputStream() throws FileNotFoundException {
        return new FileOutputStream(this.file);
    }

    /**
     * UserExclusiveControlXml の生成。
     * <p>デフォルトコンストラクタ隠蔽。</p>
     */
    private AuditSettingXml() {
        this.file = SystemProperties.getAuditSettingFile();
    }
}
