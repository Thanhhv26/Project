/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;

/**
 * 論理チェック結果メッセージ保持 DTO。
 * <p>
 * 論理チェックコマンドによって戻された結果メッセージを保持する DTO です。
 * 各コマンドに参照が渡され、各々のコマンドの検査結果が設定されます。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class CheckMessageDTO {

    /**
     * メッセージ領域マップ。
     * <p>Map&lt;カラム名, List&lt;メッセージ&gt;&gt;</p>
     */
    private final Map<String, List<String>> messages = new HashMap<String, List<String>>();

    /**
     * 値補正値マップ。
     * <p>Map&lt;カラム名, 書式補正値&gt;</p>
     */
    private final Map<String, String> correctedValues = new HashMap<String, String>();

    /**
     * メッセージ領域に対象カラムを追加します。
     * <p>
     * 各カラム向けのメッセージはリストで保持されます。このメソッドはカラム ID
     * から新規な領域を作成します。
     * </p><p>
     * 既に初期化された領域を再度確保しようとすると IllegalArgumentException を
     * スローします。
     * </p>
     *
     * @param columnId カラム ID（カラム名）
     * @exception IllegalArgumentException
     */
    public void appendColumn(final String columnId) {
        if (this.messages.containsKey(columnId)) {
        	// MI-E-0001={0} のメッセージ領域は、既に確保されています。
        	final String args[] = {columnId};
            throw new IllegalArgumentException(
            		MessageUtils.getMessage("MI-E-0001", args));
        }
        final List<String> list = new ArrayList<String>();
        this.messages.put(columnId, list);
    }

    /**
     * 論理チェックの結果問題があるかを確認する。
     * <p>
     * 論理チェックのメッセージが存在する、つまり結果に問題があった場合に true
     * を戻します。
     * </p><p>
     * 指定カラムのメッセージ領域が存在しなかった場合 IllegalArgumentException
     * をスローします。
     * </p>
     *
     * @param columnId
     * @return true : 問題あり / false : 問題無し
     * @exception IllegalArgumentException
     */
    public boolean hasWarning(final String columnId) {
        final List<String> list;
        if (this.messages.containsKey(columnId)) {
            list = this.messages.get(columnId);
        } else {
        	final String args[] = {columnId};
            throw new IllegalArgumentException(
            		MessageUtils.getMessage("MI-E-0002", args));
        }
        if (list.size() <= 0) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * 論理チェックの結果問題があるかを確認する。
     * <p>
     * 論理チェックのメッセージが存在する、つまり結果に問題があった場合に true
     * を戻します。
     * </p><p>
     * 指定カラムのメッセージ領域が存在しなかった場合 IllegalArgumentException
     * をスローします。
     * </p>
     *
     * @return true : 問題あり / false : 問題無し
     * @exception IllegalArgumentException
     */
    public boolean hasWarning(){
        for(final List<String> list :this.messages.values()){
            if (0 < list.size()) {
                return true;
            }
        }
        return false;
    }

    /**
     * 指定されたカラムの結果メッセージリストを戻します。
     * <p>
     * 指定されたカラムの論理チェック結果メッセージリストを戻します。このリスト
     * の内容は画面上に表示されます。
     * </p><p>
     * 指定カラムのメッセージ領域が存在しなかった場合 IllegalArgumentException
     * をスローします。
     * </p>
     *
     * @param columnId カラム ID（カラム名）
     * @return List&lt;論理チェック結果メッセージ&gt;
     * @exception IllegalArgumentException
     */
    public List<String> getMessages(final String columnId) {
        if (this.messages.containsKey(columnId)) {
            return this.messages.get(columnId);
        } else {
        	// MI-E-0002={0} のメッセージ領域が存在しません。
/*        	final String args[] = {columnId};*/
            throw new IllegalArgumentException(
            		MessageUtils.getMessage("MI-E-0002"));
        }
    }

    /**
     * 値補正値を戻します。
     * <p>
     * コマンドによって補正された値を戻します。初期値は補正前の値が設定される
     * ので、常にこの値で検査値を更新しても問題ありません。</p>
     *
     * @param columnId
     * @return
     */
    public String getCorrectedValue(final String columnId) {
        if (this.correctedValues.containsKey(columnId)) {
            return this.correctedValues.get(columnId);
        } else {
        	// MI-E-0002={0} のメッセージ領域が存在しません。
        	final String args[] = {columnId};
            throw new IllegalArgumentException(
            		MessageUtils.getMessage("MI-E-0002", args));
        }
    }

    /**
     * 値補正値を設定します。
     * <p>
     * 既に対象カラムに対する領域が確保されている場合は、既存の領域を破棄して
     * 値を登録します。</p>
     *
     * @param columnId
     * @param columnValue
     */
    public void setCorrectedValue(final String columnId,
            final String columnValue) {
        if (this.correctedValues.containsKey(columnId)) {
            this.correctedValues.remove(columnId);
        }
        this.correctedValues.put(columnId, columnValue);
    }

    /**
     * CheckMessageDTO の生成。
     * <p>コンストラクタ。</p>
     */
    public CheckMessageDTO() {
        return;
    }
}
