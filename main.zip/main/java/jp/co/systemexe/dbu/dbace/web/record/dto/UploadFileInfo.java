/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import lombok.Data;

/**
 *
 * @author bao-anh
 * @version 6.0 Feb 17, 2017
 *
 */
@Data
public class UploadFileInfo {

	private String name;
	private Integer size;
	private String type;
	private String characterEncodingType;
	private Boolean skipErrors;
	private Boolean overwriteData;
	private String lastModified;
}
