/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAONotFoundException;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;

/**
 * DatabaseTableDAO ファクトリ。
 * <p>
 * DatabaseTableDAO を一括保持するファクトリクラスです。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public final class DatabaseTableDAOFactory {
    /**
     * DatabaseTableDAO の一覧マップMap&lt;DatabaseTypeConnectionDestination,名前空間&gt;を保持します。
     * <p>
     * static initializer にてDAOをマップに登録していきます。</p>
     */
    private static Map<DatabaseTypeConnectionDestination, String> map;
    static {
        map = new HashMap<DatabaseTypeConnectionDestination, String>();
        map
            .put(DatabaseTypeConnectionDestination.Oracle,
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.OracleDatabaseTableDAOImpl");
        map
            .put(DatabaseTypeConnectionDestination.SqlServer,
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.SQLServerDatabaseTableDAOImpl");
        map
        .put(DatabaseTypeConnectionDestination.PostgreSQL,
            "jp.co.systemexe.dbu.dbace.persistance.dao.impl.PostgreSQLDatabaseTableDAOImpl");
        map
        .put(DatabaseTypeConnectionDestination.MySQL,
            "jp.co.systemexe.dbu.dbace.persistance.dao.impl.MySQLDatabaseTableDAOImpl");
/*        map
            .put(DatabaseTypeConnectionDestination.DB2,
                "jp.co.systemexe.dbu.dbace.persistance.dao.impl.DB2V9DatabaseTableDAOImpl");
*/    }

    /**
     * DatabaseTableDAO を生成して戻します。
     *
     * @param key DAO キー文字列（インターフェース名）
     * @return BaseDAO
     * @exception DAONotFoundException
     */
    public static DatabaseTableDAO createDatabaseTableDAO(final DatabaseTypeConnectionDestination type)
            throws DAONotFoundException, DAOException {
        try {
            return (DatabaseTableDAO)Class.forName(map.get(type)).newInstance();
        } catch (final ClassNotFoundException e) {
        	// MI-F-0001={0} クラスが存在しません。
        	final String args[] = {map.get(type)};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            throw new DAONotFoundException(message, e);
        } catch (final Exception e) {
        	// MI-F-0001={0} クラスが存在しません。
        	final String args[] = {type.toString()};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            throw new DAONotFoundException(message, e);
        }
    }
}
