/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service;

import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ConnectionDefinisionDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.creation.json.FRM0330JsonInsert;
import jp.co.systemexe.dbu.dbace.web.creation.json.FRM0330JsonSearch;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationInformation;

/**
 * @author van-thanh
 *
 */

/**
 *
 *
 */
public interface CreationService {

	/**
	 * get all TableForm in all connections
	 * justTableMulti = 1 => just get table multi
	 * justTableMulti = -1 => just get table normal
	 * justTableMulti = 0 => get all
	 * @param justTableMulti
	 * @return
	 */
	List<ConnectionDefinisionDto> getConnectionList(int justTableMulti,UserAuthority userAuthority);
	ConnectionDefinisionDto getConnectionById(String id, int justTableMulti,UserAuthority userAuthority);	
	ConnectionDefinisionDto getConnectionByLabel(String label, int justTableMulti,UserAuthority userAuthority);

	/**
	 * get table multi by condition search
	 *
	 * @param search
	 * @return Map<String, TableFormDto>
	 */
	Map<String, TableFormDto> getAllTableMulti(FRM0330JsonSearch search);

	/**
	 * do insert data to xml
	 *
	 * @param connectionLabel
	 * @param tableFormDtoInsert
	 * @throws DAOException
	 */
	void insertTableMulti(FRM0330JsonInsert param) throws DAOException;

	void updateTableMulti(FRM0330JsonInsert param) throws DAOException;

	void removeTableMulti(FRM0330JsonInsert param) throws DAOException;

	/**	 *
	 * @return
	 */
	Map<String, RelationInformation> getAllRelationInformationMap();

	/**
	 * @return
	 */
	List<RelationInformation> getAllRelationInformationList();

	/**
	 * check file repository.xml exist
	 * @return boolean
	 */
	boolean checkFileRepositoryExist();

	/**
	 * check table name exist
	 * @param connectionID
	 * @param tableLabel
	 * @return boolean
	 */
	boolean checkTableLabelExist(String connectionID, String tableID, String tableLabel);

	/**
	 * @return
	 */
	/*boolean checkFormatFileRepositoryXml();*/

	/**
	 * @return UserInfo
	 */
	/*UserInfo getUserInfo();*/

	/**
	 * @param connectionID
	 * @return
	 */
	/*String getDatabaseIDByConnectionID(final String connectionID);*/
	
	TableFormDto getTableFormDtoByLabel(String connectionId, String tableLabel, UserAuthority userAuthority);
	TableFormDto getTableFormDtoByID(String connectionId, String tableID, UserAuthority userAuthority);
	/**
	 * @param connectionId
	 * @param tableID
	 * @param itemID
	 * @param userAuthority
	 * @return
	 */
	ItemDto getItemByID(String connectionId, String tableID, String itemID, UserAuthority userAuthority);

}
