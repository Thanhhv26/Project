/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class SearchCriteria {
	// 接続定義Idの選択
	String connectDefinitionId;
	// 接続定義名の選択
	String connectDefinitionName;
	// テーブル名
	String conditionOfTableName;
	// 登録済
	String registered;
	// 登録済(テーブル定義変更有)
	String changed;
	// 登録済(DB から欠落)
	String warning;
	// 未登録
	String unRegistered;
	UserAuthority userAuthority;
}
