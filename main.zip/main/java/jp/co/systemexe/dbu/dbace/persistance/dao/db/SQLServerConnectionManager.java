/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.MessageFormat;

import jp.co.systemexe.dbu.dbace.persistance.dao.BaseConnectionManager;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;

import org.apache.commons.lang.StringUtils;

/**
 * SQLServerデータベース接続マネージャ。
 * <p>
 * SQLServerデータベース接続のコネクションを保持するクラスです。データベース向けの DAO に
 * 対してコネクションを提供します。
 * </p><p>
 * 本アプリケーションは DAO内で自動トランザクションを実装するため、本マネージャが
 * トランザクションも保持します。</p>
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class SQLServerConnectionManager extends BaseConnectionManager {

    /**
     * SQLServerデータベースコネクションを戻します。
     * <p>
     * Thin Driver を用いてデータベースコネクションを取得し、戻します。
     * 既にコネクションが保持されている場合はそれを戻します。<br />
     * また、初期設定として自動コミットを ON に設定しています。</p>
     *
     * @return Connection
     * @exception SQLException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.BaseConnectionManager#getConnection(jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO)
     */
    @Override
    public Connection getConnection(
            final DbConnectInfomationDTO dto)
            throws SQLException {
        Connection connection = getConnection();
        if (connection == null) {
            try {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            } catch (final ClassNotFoundException e) {
                final String message = "'com.microsoft.sqlserver.jdbc.SQLServerDriver' was not found.";
                getLogger().fatal(message, e);
                throw new SQLException(message);
            }
            connection = DriverManager.getConnection(
                createDatabaseUrl(dto) + "applicationName=QDB1",
                dto.getUserId(),
                dto.getPassword());
            connection.setAutoCommit(true);
            setConnection(connection);
        }
        return connection;
    }

    /**
     * データベース接続ＵＲＬを戻します。
     *
     * <p>
     * DB 接続情報 DTO に設定された情報より、
     * SQL Serverのデータベース接続ＵＲＬの形式で、
     * 生成したＵＲＬを戻します。<br />
     * また、ユーザがデータベース接続ＵＲＬを直に指定している
     * 場合は、そのＵＲＬを戻します。
     * </p>
     * <p>
     * 例：SQL Server 、DBサーバIP：192.168.0.0、ポート：1433、データベース名：SAMPLE_DB、インスタンス名：SAMPLE_INSTANCEの場合<br />
     * jdbc:sqlserver://192.168.0.0:1433;databaseName=SAMPLE_DB;instanceName=SAMPLE_INSTANCE;
     * </p>
     *
     * @param dto
     * @return
     */
    @Override
    public String createDatabaseUrl(
            final DbConnectInfomationDTO dto) {
        if (dto.isUseDatabaseUrl()) {
            return dto.getDatabaseUrl();
        } else {
            final MessageFormat formatter = new MessageFormat(
                dto.getDatabaseTypeConnectionDestination().getUrl());
            final String instanceName
            	= StringUtils.isEmpty(dto.getInstanceName())
            		? "" : "instanceName=" + dto.getInstanceName() + ";";

            return formatter.format(
                new Object[]{
                        dto.getServerId(),
                        dto.getPortId(),
                        dto.getDatabaseId(),
                        instanceName});
        }
    }

}
