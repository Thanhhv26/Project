/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * パスワード認証ロジック。
 * <p>
 * ユーザーID、パスワードを含み、ユーザー認証ができるか否かの確認を行うロジック
 * です。</p>
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class AuthenticationOfUserPasswordLogic
        extends BaseApplicationDomainLogic {

    /**
     * ユーザー認証を行います。
     * <p>
     * 接続定義 ID、ユーザー ID、パスワードの組み合わせでユーザーの認証を行い
     * ます。</p>
     * 
     * @param userId
     * @param password
     * @return true : 正規ユーザー / false : 非正規ユーザー
     * @throws ApplicationDomainLogicException
     */
    public boolean certifyOf(final String userId, final String password)
            throws ApplicationDomainLogicException {
        final ApplicationUserDAO dao = createApplicationUserDAO();
        try {
            return dao.certify(userId, password);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * AuthenticationOfUserPasswordLogic.java の生成。
     * <p>コンストラクタ。</p>
     * 
     */
    public AuthenticationOfUserPasswordLogic() {
        super();
    }

    /**
     * アプリケーションユーザー DAO を生成して戻す。
     * 
     * @return ApplicationUserDAO
     * @throws ApplicationDomainLogicException
     */
    private ApplicationUserDAO createApplicationUserDAO()
            throws ApplicationDomainLogicException {
        try {
            return (ApplicationUserDAO)createDAO("ApplicationUserDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

}
