/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationRelationDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.DbConnect;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Relation;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Relation.Items;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Relation.Items.Item;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Relation.Tables;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Relation.Tables.Table;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.ConnectDefinision;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.RelationInfo;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.web.relation.dto.RelationInformation;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
public class ApplicationRelationDAOImpl extends BaseRepositoryXmlDAO implements ApplicationRelationDAO {

//    private static final String DETAIL = "detail";
//	private static final String MASTER = "master";

	/* (non-Javadoc)
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationRelationDAO#getApplicationRelationDTO(java.lang.String)
     */
    public ApplicationRelationDTO getApplicationRelationDTO(final String relationId) throws DAOException {
        final ApplicationRelationDTO ret = new ApplicationRelationDTO();
        final Relation relation = searchRelation(relationId);
        List<ConnectDefinision> conectionList = new ArrayList<>();
		try {
			conectionList = (new AcquisitionOfConnectDefinitionListLogic()).getConnectDefinisionList();
		} catch (ApplicationDomainLogicException e) {
			throw new DAOException(e);
		}

        if (relation == null) {
        	// MI-E-0107=リレーションが存在しません
            throw new DAOException(MessageUtils.getMessage("MI-E-0107"));
        }
        ret.setRelationId(relation.getId());
        ret.setRelationLabel(relation.getLabel());
        ret.setRelationType(relation.getType());

        final Tables tables = relation.getTables();
        List<TableDTO> tableList = new ArrayList<TableDTO>();
        for (final Table tab : tables.getTable()) {
        	final TableDTO tableDTO = new TableDTO();
        	tableDTO.setType(tab.getType());
        	tableDTO.setConnectid(tab.getConnectid());
        	tableDTO.setTableid(tab.getTableid());
        	TableForm tableForm = this.getTableByConnectionIDTableID(conectionList, tab.getConnectid(),tab.getTableid());
        	tableDTO.setTablelabel(tableForm.getLabel());
        	tableDTO.setDatabaseTypeConnectionDestination(this.getDBTypeByConnectionID(conectionList, tab.getConnectid()).getDatabaseTypeConnectionDestination());
        	tableList.add(tableDTO);
        }
        ret.setTables(tableList);

        TableForm masterTable = this.getTableByConnectionIDTableID(conectionList, tableList.get(0).getConnectid(), tableList.get(0).getTableid());
        TableForm detailTable = this.getTableByConnectionIDTableID(conectionList, tableList.get(1).getConnectid(), tableList.get(1).getTableid());
        Map<String, jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item> itemMapMaster = this.getItemMap(masterTable);
        Map<String, jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item> itemMapDetail = this.getItemMap(detailTable);

        final Items items = relation.getItems();
        List<ItemDTO> itemList = new ArrayList<ItemDTO>();
        for (final Item ite : items.getItem()) {
        	final ItemDTO itemDTO = new ItemDTO();
        	itemDTO.setMaster(ite.getMaster());
        	jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item itemMaster = itemMapMaster.get(ite.getMaster());
        	itemDTO.setMasterLabel(itemMaster == null ? "" : itemMaster.getLabel());
        	itemDTO.setDetail(ite.getDetail());
        	jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item itemDetail = itemMapDetail.get(ite.getDetail());
        	itemDTO.setDetailLabel(itemDetail == null ? "" : itemDetail.getLabel());
        	itemList.add(itemDTO);
        }
        ret.setItems(itemList);

        return ret;
    }

    /**
	 * is Deleted Relation
	 * @return true : exist /false : not exist
	 */
	public boolean checkRelationExist(final String relationId) throws DAOException {
		final Relation relation = searchRelation(relationId);
		return relation == null ? false : true;
	}

    /* (non-Javadoc)
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationRelationDAO#save(jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo, jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO, jp.co.systemexe.dbu.dbace.presentation.UpdateDivision)
     */
    public void save(
    		//final UserInfo userInfo,
    		final ApplicationRelationDTO dto,
    		final UpdateDivision updateDivision)
    		throws DAOException {
    	RelationInfo relationInfo = getRelationInfo();

    	final Relation buff = searchRelation(relationInfo, dto.getRelationId());
    	final Relation relation;
    	if (buff == null) {
    		relation = getObjectFactory().createRelation();
//    		if(relationInfo == null){
//    			relationInfo = getObjectFactory().createRepositoryRelationInfo();
//    		}
    		relationInfo.getRelation().add(relation);
    	} else {
    		relation = buff;
    	}

    	relation.setId(dto.getRelationId());
    	relation.setLabel(dto.getRelationLabel());
    	relation.setType(dto.getRelationType());
    	//tables new
        final Tables buffTables = relation.getTables();
	    final Tables authTables;
	    if (buffTables == null) {
	    	authTables = getObjectFactory().createTables();
	    	relation.setTables(authTables);
	    } else {
	    	authTables = buffTables;
	    	authTables.getTable().clear();
	    }
	    //items new
	    final Items buffItems = relation.getItems();
	    final Items authItems;
	    if (buffItems == null) {
	    	authItems = getObjectFactory().createItems();
	    	relation.setItems(authItems);
	    } else {
	    	authItems = buffItems;
	    	authItems.getItem().clear();
	    }
	    //tables
	    //final Tables tables = relation.getTables();
	    for (final TableDTO tab : dto.getTables()) {
	    	final Table table = getObjectFactory().createTablesTable();
	    	table.setType(tab.getType());
	    	table.setConnectid(tab.getConnectid());
	    	table.setTableid(tab.getTableid());
	    	authTables.getTable().add(table);
	    }
	    //items
	    //final Items items = relation.getItems();
	    for (final ItemDTO ite : dto.getItems()) {
	    	final Item item = getObjectFactory().createItemsItem();
	    	item.setMaster(ite.getMaster());
	    	item.setDetail(ite.getDetail());
	    	authItems.getItem().add(item);
	    }
	    getRepository().setRelationInfo(relationInfo);
	    try {
	        update();
	    } catch (final DAOException e) {
	    	throw new DAOException(e);
	    }
    }

    /**
     * @param relationId
     * @throws DAOException
     */
    public void remove(final String relationId)
            throws DAOException {
    	final RelationInfo relations = getRelationInfo();

//    	if (relations == null || relations.getRelation() == null) {
//        	// // MI-E-0107=リレーションが存在しません
//            throw new DAOException(MessageUtils.getMessage("MI-E-0107"));
//        }

    	final List<Relation> list = relations.getRelation();
        for (final Iterator<Relation> ite = list.iterator(); ite.hasNext();) {
            final Relation relation = ite.next();
        	if (relation.getId().equals(relationId)) {
            	ite.remove();
                update();
                return;
        	}
        }
    }

    /**
     * @param relationId
     * @return
     * @throws DAOException
     */
    private Relation searchRelation(final String relationId) throws DAOException {
    	final RelationInfo relationInfo = getRelationInfo();
    	for (final Relation relation : relationInfo.getRelation()) {
    		if (relation.getId().equals(relationId)) {
    			return relation;
    		}
    	}
    	return null;
    }

    /**
     * @param relationInfo
     * @param relationId
     * @return
     * @throws DAOException
     */
    private Relation searchRelation(
    		final RelationInfo relationInfo,
    		final String relationId) throws DAOException {
//    	if(relationInfo == null ){
//    		return null;
//    	}
    	for (final Relation rel : relationInfo.getRelation()) {
    		if (rel.getId().equals(relationId)) {
    			return rel;
    		}
    	}
    	return null;
    }

    /**
     * リレーション名の一覧マップを戻します。
     * <p>
     * リレーション ID、リレーション名の一覧を設定した Map を戻します。
     * リレーション登録がない場合は DAOException をスローします。</p>
     *
     * @return Map&lt;リレーション ID, リレーション名&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationRelationDAO#getRelationNameMap()
     */
    public Map<String, String> getRelationNameMap() throws DAOException {
        final Map<String, String> ret = new HashMap<String, String>();
        final RelationInfo relationInfo = getRelationInfo();
//        if (relationInfo == null || relationInfo.getRelation() == null) {
//        	// MI-E-0053_1=リレーションが存在しません
//            throw new DAOException(MessageUtils.getMessage("MI-E-0053_1"));
//        }
        for (Relation rel : relationInfo.getRelation()) {
            ret.put(rel.getId(), rel.getLabel());
        }
        return ret;
    }

    /**
     * @return
     * @throws DAOException
     */
    public Map<String, RelationInformation> getRelationInformationMap()
            throws DAOException {
        final Map<String, RelationInformation> ret = new TreeMap<String, RelationInformation>();
        final RelationInfo relationInfo = getRelationInfo();
        //final AcquisitionOfTableLogic tableLogic = new AcquisitionOfTableLogic();
		List<ConnectDefinision> conectionList = new ArrayList<>();
		try {
			final AcquisitionOfConnectDefinitionListLogic logic;
			logic = new AcquisitionOfConnectDefinitionListLogic();
			conectionList = logic.getConnectDefinisionList();
		} catch (ApplicationDomainLogicException e) {
			throw new DAOException(e);
		}

//        if (relationInfo == null || relationInfo.getRelation() == null) {
//        	// MI-E-0053_1=リレーションが存在しません
//            throw new DAOException(MessageUtils.getMessage("MI-E-0053_1"));
//        }
        for (Relation rel : relationInfo.getRelation()) {
        	final RelationInformation info = new RelationInformation();
        	info.setId(rel.getId());
        	info.setLabel(rel.getLabel());
        	info.setType(rel.getType());

        	//tables
        	final Tables tables = rel.getTables();
            List<TableDTO> tableList = new ArrayList<TableDTO>();
            for (final Table tab : tables.getTable()) {
            	final TableDTO tableDTO = new TableDTO();
            	tableDTO.setType(tab.getType());
            	tableDTO.setConnectid(tab.getConnectid());
            	tableDTO.setTableid(tab.getTableid());
            	TableForm tableForm = this.getTableByConnectionIDTableID(conectionList, tab.getConnectid(),tab.getTableid());
            	tableDTO.setTablelabel(tableForm.getLabel());
            	tableDTO.setDatabaseTypeConnectionDestination(this.getDBTypeByConnectionID(conectionList, tab.getConnectid()).getDatabaseTypeConnectionDestination());
            	tableList.add(tableDTO);
            }
            info.setTables(tableList);

            //items
            TableForm masterTable = this.getTableByConnectionIDTableID(conectionList, tableList.get(0).getConnectid(), tableList.get(0).getTableid());
            TableForm detailTable = this.getTableByConnectionIDTableID(conectionList, tableList.get(1).getConnectid(), tableList.get(1).getTableid());
            Map<String, jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item> itemMapMaster = this.getItemMap(masterTable);
            Map<String, jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item> itemMapDetail = this.getItemMap(detailTable);

            final Items items = rel.getItems();
            List<ItemDTO> itemList = new ArrayList<ItemDTO>();
            for (final Item ite : items.getItem()) {
            	final ItemDTO itemDTO = new ItemDTO();
            	itemDTO.setMaster(ite.getMaster());
            	jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item itemMaster = itemMapMaster.get(ite.getMaster());
            	itemDTO.setMasterLabel(itemMaster == null ? "" : itemMaster.getLabel());
            	itemDTO.setDetail(ite.getDetail());
            	jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item itemDetail = itemMapDetail.get(ite.getDetail());
            	itemDTO.setDetailLabel(itemDetail == null ? "" : itemDetail.getLabel());
            	itemList.add(itemDTO);
            }
            info.setItems(itemList);

            ret.put(rel.getId(), info);
        }
        return ret;
    }

    /**
     * @param conections
     * @param connectID
     * @param tableID
     * @return
     */
    private TableForm getTableByConnectionIDTableID(
    		List<ConnectDefinision> conections, 
    		String connectID, 
    		String tableID){
    	ConnectDefinision connection = null;
    	//get connection
    	if(conections != null && conections.size() > 0){
    		for(ConnectDefinision item : conections){
    			if(connectID.equals(item.getId())){
    				connection = item;
    				break;
    			}
    		}
    	}
    	//get table
    	if(connection != null && connection.getTableForms() != null
    			&& connection.getTableForms().getTableForm() != null
    			&& connection.getTableForms().getTableForm().size() > 0){
    		for(TableForm item : connection.getTableForms().getTableForm()){
    			if(item.getId().equals(tableID)){
    				return item;
    			}
    		}
    	}
    	return new TableForm();
    }

    /**
     * @param table
     * @return
     */
    private Map<String, jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item> getItemMap(TableForm table){
    	Map<String, jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item> result =
    			new HashMap<String, jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item>();
    	if(table != null && table.getItem().size() > 0){
    		for(jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item item : table.getItem()){
    			result.put(item.getId(), item);
    		}
    	}
    	return result;
    }
    
    private DbConnect getDBTypeByConnectionID(List<ConnectDefinision> conections, String connectID){
    	//get connection
    	if(conections != null && conections.size() > 0){
    		for(ConnectDefinision item : conections){
    			if(connectID.equals(item.getId())){
    				return item.getDbConnect();
    			}
    		}
    	}
    	return new DbConnect();
    }
    
    public List<Relation> getRelations() throws DAOException{
    	final RelationInfo relationInfo = getRelationInfo();
//    	if (relationInfo == null || relationInfo.getRelation() == null) {
//        	// MI-E-0053_1=リレーションが存在しません
//            throw new DAOException(MessageUtils.getMessage("MI-E-0053_1"));
//        }
    	return relationInfo.getRelation();
    }

}
