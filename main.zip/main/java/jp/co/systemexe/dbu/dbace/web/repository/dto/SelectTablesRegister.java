/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import java.util.List;

import lombok.Data;
@Data
public class SelectTablesRegister {
	private String type;//check,delete
	String connectDefinitionId;
	// テーブル名の一覧
	List<TrDTO> table;
}
