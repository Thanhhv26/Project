/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.AuditUserAuthority;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationUserDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.GeneralUserOperationAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * アプリケーションユーザー情報の保存ロジック。
 * <p>
 * アプリケーションユーザー情報をリポジトリに保存します。</p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class PreservationOfAppUserLogic extends BaseApplicationDomainLogic {

    /**
     * アプリケーションユーザー情報のパスワードをリポジトリに保存します。
     * <p>
     * 引数で設定するパスワードは既に暗号化されている必要があります。</p>
     *
     * @param dto ユーザー情報 DTO
     * @param password ユーザーパスワード
     * @throws ApplicationDomainLogicException
     */
    public void savePassword(
    		final UserInfoDTO dto,
    		final String password)
            throws ApplicationDomainLogicException {
        final ApplicationUserDTO user = new ApplicationUserDTO();
        user.setUserId(dto.getId());
        user.setUserLabel(dto.getName());
        user.setAuthority(dto.getUserAuthority());
        user.setPassword(password);

        final ApplicationUserDAO dao = createApplicationUserDAO();
        try {
            dao.savePassword(user);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * アプリケーションユーザー情報のパスワードをリポジトリに保存します。
     * <p>
     * 引数で設定するパスワードは既に暗号化されている必要があります。</p>
     *
     * @param dto ユーザー情報 DTO
     * @param username,password ユーザーパスワード
     * @throws ApplicationDomainLogicException
     */
    public void saveUsernamePassword(
    		final UserInfoDTO dto,
    		final String username,
    		final String password)
            throws ApplicationDomainLogicException {
        final ApplicationUserDTO user = new ApplicationUserDTO();
        user.setUserId(dto.getId());
        user.setUserLabel(username);
        user.setAuthority(dto.getUserAuthority());
        user.setPassword(password);

        final ApplicationUserDAO dao = createApplicationUserDAO();
        try {
            dao.saveUsernamePassword(user);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * アプリケーションユーザー情報をリポジトリに保存します。
     * <p>
     * 既存の場合は更新を、未登録の場合は自動的に新規追加を行います。</p>
     *
     * @param dto ユーザー情報 DTO
     * @param password ユーザーパスワード
     * @throws ApplicationDomainLogicException
     */
    public void save(
    		final UserInfoDTO dto,
    		final UserInfoDTO beforeDTO,
    		final String password,
    		final String beforePassword,
    		final UpdateDivision updateDivision,
    		final UserInfo userInfo
    		)
            throws ApplicationDomainLogicException {
        final ApplicationUserDTO user = new ApplicationUserDTO();
        user.setUserId(dto.getId());
        user.setUserLabel(dto.getName());
        user.setAuthority(dto.getUserAuthority());
        user.setPassword(password);

        final ApplicationUserDAO dao = createApplicationUserDAO();
        AuditStatus status = AuditStatus.failure;
        try {
			// MOD 外部認証連携 機能追加 ↓
			dao.save(/*userInfo, */user, updateDivision);
			// MOD 外部認証連携 機能追加 ↑
            status = AuditStatus.success;
        } catch (final DAOException e) {
            status = AuditStatus.failure;
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        } finally {
        	outputAuditLog(
        			dto,
        			beforeDTO,
        			password,
        			beforePassword,
        			updateDivision,
        			userInfo,
        			status);
        }
    }

    /**
     * 監査ログを出力します。
     *
     * @param dto
     * @param beforeDTO
     * @param password
     * @param updateDivision
     * @param userInfo
     * @param status
     */
    private void outputAuditLog(
    		final UserInfoDTO dto,
    		final UserInfoDTO beforeDTO,
    		final String password,
    		final String beforePassword,
    		final UpdateDivision updateDivision,
    		final UserInfo userInfo,
    		final AuditStatus status) {
    	if (updateDivision == UpdateDivision.insert) {
    		OutputAuditLog.writeUserOperationLog(
    				AuditEventKind.INSERT,
    				userInfo,
    				dto.getId(),
    				status,
    				"1");
        	if (dto.getUserAuthority().isSystemAdministrator()) {
        		OutputAuditLog.writeUserAuthorityChangeLog(
        				AuditEventKind.SYSTEM_ADMINISTRATOR,
        				userInfo,
        				"",
        				dto.getId(),
        				status,
        				AuditUserAuthority.GIVE);
        	}
    	} else {
	    	if (!dto.getName().equals(beforeDTO.getName())) {
	    		OutputAuditLog.writeUserOperationLog(
	    				AuditEventKind.UPDATE,
	    				userInfo,
	    				dto.getId(),
	    				status,
	    				"1");
	    	}
			// MOD 外部認証連携 機能追加 ↓
			if (StringUtils.isNotBlank(password)) {
				if (!password.equals(beforePassword)) {
					OutputAuditLog.writeUserOperationLog(AuditEventKind.CHANGE_PASSWORD, userInfo, dto.getId(), status, "1");
				}
			}
			// MOD 外部認証連携 機能追加 ↑
	        if (beforeDTO.getUserAuthority() != null &&
	        		dto.getUserAuthority().isSystemAdministrator()
	        		!= beforeDTO.getUserAuthority().isSystemAdministrator()) {
	        	if (dto.getUserAuthority().isSystemAdministrator()) {
	        		OutputAuditLog.writeUserAuthorityChangeLog(
	        				AuditEventKind.SYSTEM_ADMINISTRATOR,
	        				userInfo,
	        				"",
	        				dto.getId(),
	        				status,
	        				AuditUserAuthority.GIVE);
	        	} else {
	        		OutputAuditLog.writeUserAuthorityChangeLog(
	        				AuditEventKind.SYSTEM_ADMINISTRATOR,
	        				userInfo,
	        				"",
	        				dto.getId(),
	        				status,
	        				AuditUserAuthority.DEPRIVATION);
	        	}
	        }
    	}

        for (final ConnectDefinisionAuthority auth
        		: dto.getUserAuthority().getConnectDefinisionAuthoritys()) {
        	final boolean isInsert;
        	final List<GeneralUserOperationAuthority> beforeOperationOuthorityList;
        	if (updateDivision == UpdateDivision.insert) {
        		beforeOperationOuthorityList = new ArrayList<GeneralUserOperationAuthority>();
        		isInsert = true;
        	} else {
        		beforeOperationOuthorityList = getGeneralUserOperationAuthorityList(
	        				beforeDTO.getUserAuthority().getConnectDefinisionAuthoritys(),
	        				auth.getConnectDefinisionId());
        		isInsert = beforeOperationOuthorityList == null ? true : false;
        	}

        	if (isInsert) {
        		// 新規登録の場合は、権限が付与されたもの全てが、権限付与となる
        		for (GeneralUserOperationAuthority operationAuth : auth.getOperationAuthority()) {
            		OutputAuditLog.writeUserAuthorityChangeLog(
            				getAuditEventKind(operationAuth),
            				userInfo,
            				auth.getConnectDefinisionId(),
            				dto.getId(),
            				status,
            				AuditUserAuthority.GIVE);
        		}
        	} else {
        		// 更新前になく、更新後に存在する場合は、権限付与
        		for (GeneralUserOperationAuthority operationAuth : auth.getOperationAuthority()) {
	        		final boolean isBeforeExist
	        			= existGeneralUserOperationAuthority(
	        					beforeOperationOuthorityList, operationAuth);
	        		if (!isBeforeExist) {
	            		OutputAuditLog.writeUserAuthorityChangeLog(
	            				getAuditEventKind(operationAuth),
	            				userInfo,
	            				auth.getConnectDefinisionId(),
	            				dto.getId(),
	            				status,
	            				AuditUserAuthority.GIVE);
	        		}
        		}

        		// 更新後になく、更新前に存在する場合は、権限剥奪
        		for (GeneralUserOperationAuthority operationAuth : beforeOperationOuthorityList) {
	        		final boolean isAfterExist
	        			= existGeneralUserOperationAuthority(
	        					auth.getOperationAuthority(), operationAuth);
	        		if (!isAfterExist) {
	            		OutputAuditLog.writeUserAuthorityChangeLog(
	            				getAuditEventKind(operationAuth),
	            				userInfo,
	            				auth.getConnectDefinisionId(),
	            				dto.getId(),
	            				status,
	            				AuditUserAuthority.DEPRIVATION);
	        		}
        		}
        	}
        }
    }

    /**
     * 指定された接続定義IDのアプリケーション操作権限を返します。
     * <p>
     * 指定された接続定義IDのアプリケーション操作権限が存在しない場合は null を返します。
     * </p>
     *
     * @param connectDefinitionAuthorityList
     * @param connectDefitionId
     * @return
     */
    private List<GeneralUserOperationAuthority> getGeneralUserOperationAuthorityList(
    		final List<ConnectDefinisionAuthority> connectDefinitionAuthorityList,
    		final String connectDefitionId) {
    	for (final ConnectDefinisionAuthority def : connectDefinitionAuthorityList) {
    		if (def.getConnectDefinisionId().equals(connectDefitionId)) {
    			return def.getOperationAuthority();
    		}
    	}
    	return null;
    }

    /**
     * 指定されたユーザー操作権限が、指定されたユーザー操作権限に存在するか否かを返します。
     *
     * @param operationAuthorityList
     * @param operationAuthority
     * @return
     */
    private boolean existGeneralUserOperationAuthority(
    		final List<GeneralUserOperationAuthority> operationAuthorityList,
    		final GeneralUserOperationAuthority operationAuthority) {
    	for (final GeneralUserOperationAuthority auth
    			: operationAuthorityList) {
    		if (auth == operationAuthority) {
    			return true;
    		}
    	}
    	return false;
    }

    /**
     * GeneralUserOperationAuthorityに対応した、AuditEventKindを返します。
     *
     * @param operationAuth
     * @return
     */
	private AuditEventKind getAuditEventKind(final GeneralUserOperationAuthority operationAuth) {
		if (operationAuth == GeneralUserOperationAuthority.INSERT) {
			return AuditEventKind.INSERT;
		} else if (operationAuth == GeneralUserOperationAuthority.UPDATE) {
			return AuditEventKind.UPDATE;
		} else if (operationAuth == GeneralUserOperationAuthority.DELETE) {
			return AuditEventKind.DELETE;
		} else if (operationAuth == GeneralUserOperationAuthority.CUSTOMIZE) {
			return AuditEventKind.CUSTOMIZE;
		} else if (operationAuth == GeneralUserOperationAuthority.IMPORT) {
			return AuditEventKind.IMPORT;
		} else if (operationAuth == GeneralUserOperationAuthority.DOWNLOAD) {
			return AuditEventKind.DOWNLOAD;
		} else if (operationAuth == GeneralUserOperationAuthority.REFERENCE) {
			return AuditEventKind.REFERENCE;
		} else {
			return null;
		}
	}

    /**
     * PreservationOfAppUserLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public PreservationOfAppUserLogic() {
        return;
    }

    /**
     * アプリケーションユーザー DAO を生成して戻す。
     *
     * @return ApplicationUserDAO
     * @throws ApplicationDomainLogicException
     */
    private ApplicationUserDAO createApplicationUserDAO()
            throws ApplicationDomainLogicException {
        try {
            return (ApplicationUserDAO)createDAO("ApplicationUserDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
