/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.authentication;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.util.WebUtils;

/**
 * To prevent locale attack
 *
 * @author systemexe
 * @version 1.0 Nov 29, 2016
 */
@Component
public class LocaleConfigurerFilter extends AbstractOncePerRequestFilter {

    /**
     * @see LocaleResolver
     */
    @Autowired
    private LocaleResolver localeResolver;

	/*
	 * (非 Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.common.authentication.AbstractOncePerRequestFilter#doBeforeFilter(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected boolean doBeforeFilter(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// セッションのタイムアウト判定を行う。
		if (localeResolver != null) {
        	Locale locale = localeResolver.resolveLocale(request);
            LocaleContextHolder.setLocale(locale);
        }

		return false;
	}

	/*
	 * (非 Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.common.authentication.AbstractOncePerRequestFilter#doAfterFilter(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
	protected void doAfterFilter(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// reset response locale and locale holder
		if (localeResolver != null) {
			// apply cookie locale
			Locale locale = LocaleContextHolder.getLocale();
			Cookie cookie = WebUtils.getCookie(request, "lang");
			if (cookie == null) {
				cookie = new Cookie("lang", locale.getLanguage());
				cookie.setPath("/");
				response.addCookie(cookie);
			}
			// apply response locale
			response.setLocale(LocaleContextHolder.getLocale());
			// reset locale holder
	        LocaleContextHolder.resetLocaleContext();
        }
	}
}
