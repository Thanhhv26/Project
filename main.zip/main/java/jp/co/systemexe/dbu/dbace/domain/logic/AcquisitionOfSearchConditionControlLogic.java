/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseSearchConditionDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.SearchConditionDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 検索条件情報の取得。
 * <p>
 * レコード検索画面における検索条件情報の取得を行うビジネスロジックです。</p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class AcquisitionOfSearchConditionControlLogic
        extends BaseApplicationDomainLogic {

    /**
     * 検索条件情報を取得します。
     *
     * <p>
     * 指定されたファイルの検索条件情報を取得します。
     * </p>
     *
     * @param filePath
     * @return
     * @throws ApplicationDomainLogicException
     */
    public List<SelectConditionItem> getSelectConditionItems(
            final String filePath)
            throws ApplicationDomainLogicException {
        final BaseSearchConditionDAO dao = new SearchConditionDAO();
        try {
            return dao.inputFile(filePath);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e);
        }
    }

    /**
     * ファイルパス、ファイル名の一覧を取得します。
     *
     * @param connectDefinitionId
     * @param tableId
     * @param userId
     * @return
     * @throws ApplicationDomainLogicException
     */
    public Map<String, String> getCommonFileNameMap(
            final String connectDefinitionId,
            final String tableId,
            final String userId)
            throws ApplicationDomainLogicException {
        final BaseSearchConditionDAO dao = new SearchConditionDAO();
        try {
            return dao.getCommonFileNameMap(connectDefinitionId, tableId, userId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e);
        }
    }

    /**
     * ファイルパス、ファイル名の一覧を取得します。
     *
     * @param connectDefinitionId
     * @param tableId
     * @param userId
     * @return
     * @throws ApplicationDomainLogicException
     */
    public Map<String, String> getUserFileNameMap(
            final String connectDefinitionId,
            final String tableId,
            final String userId)
            throws ApplicationDomainLogicException {
        final BaseSearchConditionDAO dao = new SearchConditionDAO();
        try {
            return dao.getUserFileNameMap(connectDefinitionId, tableId, userId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e);
        }
    }

    /**
     * ファイルパス、ファイル名の一覧を取得します。
     *
     * @param connectDefinitionId
     * @param tableId
     * @param userId
     * @return
     * @throws ApplicationDomainLogicException
     */
    public Map<String, String> getFileNameMap(
            final String connectDefinitionId,
            final String tableId,
            final String userId)
            throws ApplicationDomainLogicException {
        final BaseSearchConditionDAO dao = new SearchConditionDAO();
        try {
            return dao.getFileNameMap(connectDefinitionId, tableId, userId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e);
        }
    }

    /**
     * AcquisitionOfSearchConditionControlLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public AcquisitionOfSearchConditionControlLogic() {
        return;
    }
}
