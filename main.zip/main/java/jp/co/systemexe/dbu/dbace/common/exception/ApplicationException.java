/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.exception;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * アプリケーション例外の基底抽象クラス。
 * <p>アプリケーションがキャッチする独自例外は、原則このクラスを継承して作成
 * するものとします。</p>
 * <p>
 * このクラスは抽象クラスです。インスタンスを生成する事は出来ませんし、
 * スローする事も出来ません。</p>
 *
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public abstract class ApplicationException extends Exception {
    /**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    /**
     * ApplicationException の生成。
     * <p>デフォルトコンストラクタ。</p>
     */
    protected ApplicationException() {
        super();
    }

    /**
     * ApplicationException の生成。
     * <p>コンストラクタ。明示的な例外メッセージを指定してスローするための
     * コンストラクタです。</p>
     *
     * @param message 例外メッセージ文字列
     */
    protected ApplicationException(final String message) {
        super(message);
        logger.error(super.getMessage());
    }

    /**
     * ApplicationException の生成。
     * <p>コンストラクター。明示的な例外メッセージと、キャッチされた例外
     * オブジェクトを指定してスローするためのコンストラクタです。</p>
     *
     * @param message 例外メッセージ文字列
     * @param cause   例外オブジェクト
     */
    protected ApplicationException(final String message, final Throwable cause) {
        super(message, cause);
        outputLogger(cause);
    }

    /**
     * ApplicationException の生成。
     * <p>コンストラクター。キャッチされた例外オブジェクトを指定してスローする
     * ためのコンストラクタです。</p>
     *
     * @param cause
     */
    protected ApplicationException(final Throwable cause) {
        super(cause);
        outputLogger(cause);
    }

    private void outputLogger(final Throwable cause) {
        if (!cause.getClass().getName().matches("^jp\\.co\\.systemexe\\.dbu\\.dbace\\..*")) {
            final StringBuffer buff = new StringBuffer();
            buff.append(cause + "\n");
            for (final StackTraceElement element : cause.getStackTrace()) {
                buff.append("\tat " + element.toString() + "\n");
            }
            logger.error(buff.toString());
        }
    }
}
