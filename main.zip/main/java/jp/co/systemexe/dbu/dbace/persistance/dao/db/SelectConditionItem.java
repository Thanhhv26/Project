/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.db;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableComparisonOperator;
import jp.co.systemexe.dbu.dbace.common.sql.SqlWhereTableLogicalOperator;

/**
 * 検索条件指定アイテム。
 * <p>
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class SelectConditionItem implements Serializable {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = -6626678748574709628L;

    /**
     *
     */
    private String tableId;

    /**
     * カラムID
     */
    private String columnId;

    /**
     * 該当カラムに一致する値或いは曖昧な値を指定する条件です。
     */
    private String value;

    /**
     * JDBC メタデータ型。
     */
    private JDBCMetaDataType jDBCMetaDataType;

    /**
     * 比較演算子
     */
    private SqlWhereTableComparisonOperator comparisonOperator;

    /**
     * 論理演算子
     */
    private SqlWhereTableLogicalOperator logicalOperator;

    /**
     * 実テーブルのカラム型。
     */
    private String columnTypeName;

    /**
     *
     * 渡されたオブジェクトの値が同じかどうか返します。
     *
     * @param item
     * @return true：同じ false：異なる
     */
    public boolean IsEqualCondtion(SelectConditionItem item){
    	return (columnId.equals(item.getColumnId()) &&
    	        value.equals(item.getValue()) &&
    	        jDBCMetaDataType == item.getJDBCMetaDataType() &&
    	        comparisonOperator == item.getComparisonOperator() &&
    	        (SqlWhereTableLogicalOperator.blank == logicalOperator ? true : logicalOperator == item.getLogicalOperator()));
    }
    /**
     * 一致条件を戻します。
     * <p>
     * 該当カラムに一致する値或いは曖昧な値を指定する条件です。</p>
     *
     * @return String
     */
    public String getValue() {
        return value;
    }

    /**
     * 一致条件を設定します。
     * <p>
     * 該当カラムに一致する値或いは曖昧な値を指定する条件です。</p>
     *
     * @param String value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * SelectConditionItem の生成。
     * <p>コンストラクタ。</p>
     */
    public SelectConditionItem() {
        return;
    }

    /**
     * jDBCMetaDataType を戻します。
     *
     * @return JDBCMetaDataType
     */
    public JDBCMetaDataType getJDBCMetaDataType() {
        return jDBCMetaDataType;
    }

    /**
     * jDBCMetaDataType を設定します。
     *
     * @param JDBCMetaDataType metaDataType
     */
    public void setJDBCMetaDataType(JDBCMetaDataType metaDataType) {
        jDBCMetaDataType = metaDataType;
    }

    /**
     * comparisonOperator を戻します。
     *
     * @return SqlWhereTableComparisonOperator
     */
    public SqlWhereTableComparisonOperator getComparisonOperator() {
        return comparisonOperator;
    }

    /**
     * comparisonOperator を設定します。
     *
     * @param SqlWhereTableComparisonOperator comparisonOperator
     */
    public void setComparisonOperator(
            SqlWhereTableComparisonOperator comparisonOperator) {
        this.comparisonOperator = comparisonOperator;
    }

    /**
     * logicalOperator を戻します。
     *
     * @return SqlWhereTableLogicalOperator
     */
    public SqlWhereTableLogicalOperator getLogicalOperator() {
        return logicalOperator;
    }

    /**
     * logicalOperator を設定します。
     *
     * @param SqlWhereTableLogicalOperator logicalOperator
     */
    public void setLogicalOperator(SqlWhereTableLogicalOperator logicalOperator) {
        this.logicalOperator = logicalOperator;
    }

    /**
     * columnTypeName を戻します。
     *
     * @return String
     */
    public String getColumnTypeName() {
        return columnTypeName;
    }

    /**
     * columnTypeName を設定します。
     *
     * @param String columnTypeName
     */
    public void setColumnTypeName(String columnTypeName) {
        this.columnTypeName = columnTypeName;
    }

    /**
     * columnId を戻します。
     *
     * @return String
     */
    public String getColumnId() {
		if (this.tableId != null && !this.tableId.equals("")) {
			TableIdDefinition tableIdDefinition = new TableIdDefinition(this.tableId);
			return String.format("%s\".\"%s\".\"%s", tableIdDefinition.getSchem(), tableIdDefinition.getTable(),
					columnId);
		}
        return columnId;
    }

    /**
     * columnId を設定します。
     *
     * @param String columnId
     */
    public void setColumnId(String columnId) {
        this.columnId = columnId;
    }
	/**
	 * @return the tableId
	 */
	public String getTableId() {
		return tableId;
	}
	/**
	 * @param tableId the tableId to set
	 */
	public void setTableId(String tableId) {
		this.tableId = tableId;
	}
}
