/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.exception;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * アプリケーションドメインロジック例外。
 * <p>
 * アプリケーションドメイン層内で発生した例外をラップする一般例外です。
 * 本例外をキャッチした場合は、画面表示内容に例外が発生した旨表示されるか、
 * ポップアップ等でユーザーに通知されなければいけません。</p>
 *
 * @author EXE 相田 一英
 * @author EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class ApplicationDomainLogicException extends ApplicationException {
    final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = -4904515634693495480L;

    /**
     * ApplicationDomainLogicException の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param message
     */
    public ApplicationDomainLogicException(final String message) {
        super(message);
    }

    /**
     * ApplicationDomainLogicException の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param cause
     */
    public ApplicationDomainLogicException(final Throwable cause) {
        super(cause);
    }

    /**
     * ApplicationDomainLogicException の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param message
     * @param cause
     */
    public ApplicationDomainLogicException(final String message,
            final Throwable cause) {
        super(message, cause);
    }

}
