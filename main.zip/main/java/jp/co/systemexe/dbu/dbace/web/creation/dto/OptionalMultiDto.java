/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Table;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

@Data
public class OptionalMultiDto {
	private OptionalMultiDto.Insert insert;
	private OptionalMultiDto.Update update;
	private OptionalMultiDto.Copy copy;
	private OptionalMultiDto.Delete delete;

	public OptionalMultiDto() {

	}
	
	public OptionalMultiDto(Table.OptionalMulti optional) {
		if (optional != null) {
			if (optional.getInsert() != null) {
				this.setInsert(new OptionalMultiDto.Insert(
						optional.getInsert().isOverWrite(), 
						optional.getInsert().isNotAddNew()));
			}
		}
		if (optional.getUpdate() != null) {
			this.setUpdate(new OptionalMultiDto.Update(
					optional.getUpdate().isNotOverWrite(), 
					optional.getUpdate().isDelete()));
		}
		if(optional.getCopy() != null){
			this.setCopy(new OptionalMultiDto.Copy(
					optional.getCopy().isOverWrite(), 
					optional.getCopy().isNotAddNew()));
		}
		if(optional.getDelete() != null){
			this.setDelete(new OptionalMultiDto.Delete(
					optional.getDelete().isExclusion1(), 
					optional.getDelete().isExclusion2(), 
					optional.getDelete().isExclusion3()));
		}
	}

	@Data
	public static class Insert {
		private boolean overWrite;
		private boolean notAddNew;
		
		public Insert() {

		}

		public Insert(boolean overWrite, boolean notAddNew) {
			this.setOverWrite(overWrite);
			this.setNotAddNew(notAddNew);
		}
	}

	@Data
	public static class Update {
		private boolean notOverWrite;
		private boolean delete;
		
		public Update() {
		}

		public Update(boolean notOverWrite, boolean delete) {
			this.setNotOverWrite(notOverWrite);
			this.setDelete(delete);
		}
	}

	@Data
	public static class Copy {
		private boolean overWrite;
		private boolean notAddNew;
		
		public Copy() {

		}

		public Copy(boolean overWrite, boolean notAddNew) {
			this.setOverWrite(overWrite);
			this.setNotAddNew(notAddNew);
		}
	}

	@Data
	public static class Delete {
		private boolean exclusion1;
		private boolean exclusion2;
		private boolean exclusion3;
		
		public Delete() {

		}

		public Delete(boolean exclusion1, boolean exclusion2, boolean exclusion3) {
			this.setExclusion1(exclusion1);
			this.setExclusion2(exclusion2);
			this.setExclusion3(exclusion3);
		}
	}
}
