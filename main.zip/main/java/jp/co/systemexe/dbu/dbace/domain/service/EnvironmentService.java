/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.web.environment.dto.EnvironmentDto;
import jp.co.systemexe.dbu.dbace.web.environment.model.FRM0520ResultModel;

/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 jan 18, 2017
 */
public interface EnvironmentService {
	/**
	 *
	 * @param EnvironmentDto
	 * @return
	 * @throws ApplicationRuntimeException
	 */
	FRM0520ResultModel updateEnvironment(EnvironmentDto environmentDto) throws ApplicationRuntimeException;


}
