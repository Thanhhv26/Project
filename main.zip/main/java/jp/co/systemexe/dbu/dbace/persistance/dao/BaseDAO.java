/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * DAO の基底抽象クラス。
 * <p>
 * 本クラスは J2EE DAO パターンでの実装を行うための基底抽象クラスです。
 * 本プロジェクトにおいて DAO を実装する際には、原則本クラスを継承しなければ
 * いけません。</p>
 *
 * @author EXE 相田 一英
 * @author EXE 鈴木 伸祐
 * @version 0.0.0
 */
public abstract class BaseDAO {

    /**
     * ロガーインスタンスを保持します。
     */
    private final Logger logger;

    /**
     * ロガーインスタンスを戻します。
     * 
     * @return Logger
     */
    protected Logger getLogger() {
        return logger;
    }

    /**
     * BasePersistance の生成。
     * <p>コンストラクタ。</p>
     * <p>サブクラス向けのロガーの初期化を行います。</p>
     */
    protected BaseDAO() {
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
    }
}
