/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.persistance.dao.CreationDAO;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.ConnectDefinision;

/**
 * @author van-thanh
 *
 */
@Repository
public class CreationDAOImpl extends BaseRepositoryXmlDAO implements CreationDAO {

	/* 
	 * get all TableForm in all connections
	 * 
	 * (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.CreationDAO#getAllConnection()
	 */
	@Override
	public List<ConnectDefinision> getAllConnection() throws ApplicationDomainLogicException {
		final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();
		List<ConnectDefinision> result = new ArrayList<ConnectDefinision>();
		try {
			result = connectDefinitionListLogic.getConnectDefinisionList();
		} catch (ApplicationDomainLogicException e) {
			getLogger().info(e.getMessage());
			throw new ApplicationDomainLogicException(e.getMessage());
		}
		return result;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.CreationDAO#checkFormatFileRepositoryXml()
	 */
	@Override
	public boolean checkFormatFileRepositoryXml() throws ApplicationDomainLogicException {
		final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();		
		return connectDefinitionListLogic.checkFormatFileRepositoryXml();
	}

}
