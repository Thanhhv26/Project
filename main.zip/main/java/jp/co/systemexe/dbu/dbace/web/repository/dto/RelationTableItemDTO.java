/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationTableItemDTO {
	private boolean isExistTableIn;
	//master,detail
	private String type;

	/**
	 * @param isExistTableIn
	 * @param type
	 */
	public RelationTableItemDTO(boolean isExistTableIn, String type) {
		this.isExistTableIn = isExistTableIn;
		this.type = type;
	}

}