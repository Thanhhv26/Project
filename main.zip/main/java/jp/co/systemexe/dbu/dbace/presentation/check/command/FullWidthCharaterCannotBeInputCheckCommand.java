/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.ItemRestriction;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;

/**
 *
 * 全角文字入力不可チェック。
 * <p>
 * 全角数値、全角カナ、全角英語、全角記号の入力を禁じる項目用の
 * チェックコマンドです。<br />
  * </p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class FullWidthCharaterCannotBeInputCheckCommand extends BaseLogicalCheckCommand {

	/**
     * コントロールコード及び全角英字数字を定義した正規表現文字列。
     */
	private static final String REGEX = ".*[^ -~｡-ﾟ]+.*";

	/**
     * FillWidthCharateCannotBeInputCheckCommand の生成。
     * <p>コンストラクタ。</p>
     */
	public FullWidthCharaterCannotBeInputCheckCommand() {
        return;
    }

	/**
     * 検査を実行します。
     * <p>
	 * 全角数値、全角カナ、全角英語、全角記号、いわゆる「全角文字」を検出したら警告を設定します。<br />
     * 「全角文字」とは、いわゆる ASCII に含まれる符号と、日本語の全角カタカナの
     * 事です。
     * </p>
     *
     * @param columnId カラム名
     * @param messages 論理チェック結果メッセージ保持 DTO
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#check(java.lang.String, java.lang.String, jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO)
     */
	@Override
	public void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
		final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap) {
        final String value = messages.getCorrectedValue(columnId);
        if (value == null || value.equals("")) {
            return;
        }

        if (value.matches(REGEX)) {
        	//MI-E-0110={0}に全角文字は入力できません。
        	String columnLabel = tableItemMap.get(columnId).getItemLabel();
        	final String args[]={columnLabel};
            messages.getMessages(columnId).add(MessageUtils.getMessage("MI-E-0110",args));
        }
    }

	/**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * このクラスが検査対象とする条件は、
     * <ol>
     *  <li>リポジトリの入力値制約に FULL_WIDTH_CHARACTER_CANNOT_BE_INPUT 制約が存在する場合。</li>
     * </ol>
     * </p>
     *
     * @param columnId
     * @return true : 検査担当 / false : 担当ではない
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#isMyTask(java.lang.String)
     */
	@Override
	protected boolean isMyTask(final String columnId) {
        final TableItemDTO item = getDisplayDef().getItemDefinitions().get(
            columnId);
        if (item.getItemRestrictions().containsKey(
            ItemRestriction.FULL_WIDTH_CHARACTER_CANNOT_BE_INPUT)) {
            return true;
        }
        return false;
    }
}