/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.jdbc;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.util.DateUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SimpleSqlCondition;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;

/**
 * Web アプリケーション開発用結果セットラッパー。
 * <p>
 * 主に Web アプリケーション開発用の JDBC 結果セットラッパーです。カラム名と値を
 * 文字列で定義したコレクション（Map）でのデータ入出力をサポートします。
 * </p>
 * <p>
 * 内部的に JDBC メタデータを取得し、データベース中でのカラム定義（データ型）に 配慮した適正な型変換を行います。
 * </p>
 * <p>
 * 各種データベースの SQL データ型と Java データ型のマッピングに関しては <a href="http://sdc.sun.co.jp/java/docs/j2se/1.4/ja/docs/ja/guide/jdbc/getstart/mapping.html"
 * > 参考ドキュメント</a>をご参照下さい。
 * </p>
 *
 * @author EXE 相田 一英
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class WebResultSetFacade {

	/**
	 * 結果セットへの参照。
	 */
	private final ResultSet resultSet;

	/**
	 * 結果セットメタデータへの参照。
	 */
	private final ResultSetMetaData metaData;

	/**
	 * 結果セットの一行をマップに設定して戻します。
	 * <p>
	 * 結果セットの一行分のカラム名とデータを、データ型に配慮しながら文字列に 変換し、マップに設定して戻します。
	 * </p>
	 * <p>
	 * 本メソッドでは、以下のデータ型の値は取得出来ません。
	 * <ol>
	 * <li>ARRAY</li>
	 * <li>BLOB</li>
	 * <li>CLOB</li>
	 * <li>DISTINCT</li>
	 * <li>STRUCT</li>
	 * <li>REF</li>
	 * <li>JAVA_OBJECT</li>
	 * <li>BINARY</li>
	 * <li>VARBINARY</li>
	 * <li>LONGVARBINARY</li>
	 * </ol>
	 * テーブル中にこれらの型が定義されていた場合には、個別に取得方法を検討する 必要があります。
	 * </p>
	 * <p>
	 * <a href="http://sdc.sun.co.jp/java/docs/j2se/1.4/ja/docs/ja/guide/jdbc/getstart/mapping.html"
	 * > 参考ドキュメント</a>
	 * </p>
	 * <p>
	 * なお、JDBC の結果セットメタデータでは、カラムの順序は「1」から開始され ます。「0」からではありません。
	 * </p>
	 *
	 * @return ret 結果セットの一行
	 * @throws SQLException
	 */
	public Map<String, String> getMap(
			final Map<String, TableItemDTO> tableItemMap,
			final TableDefinitionDTO def) throws SQLException {
		final Map<String, String> ret = new HashMap<String, String>();
		for (int i = 0; i < this.metaData.getColumnCount(); i++) {
			final int index = i + 1;
			String name = this.metaData.getColumnLabel(index);
			
			// DEL　DBエースOracle日付対応　↓
//			final DefinedHtmlElement element = tableItemMap.get(name)
//					.getHtmlElement();
			
			//note: database alway return column name => lower case
			//=>get column name from xml
			for (Iterator<String> iterator = tableItemMap.keySet().iterator(); iterator.hasNext();) {
				String key = (String) iterator.next();
				if(key.toLowerCase().equals(name.toLowerCase())){
					name = key;
					break;
				}
			}

			JDBCMetaDataType type = null;
			if(def.getDefinitionOfColumnMap().get(name) != null){
				type = def.getDefinitionOfColumnMap().get(name).getJDBCMetaDataType();
			}	
			if(type == null){
				ret.put(name, this.resultSet.getString(index));
			}			
			
			SimpleDateFormat sdf = null;
			// DEL　DBエースOracle日付対応　↓
//				if (DefinedHtmlElement.INPUT_DATE == element) {
//					sdf = new SimpleDateFormat("yyyy/MM/dd");
//				} else if (DefinedHtmlElement.INPUT_DATETIME == element) {
//					sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
//				} else if (DefinedHtmlElement.INPUT_TIMESTAMP == element) {
//					sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
//				} else if (DefinedHtmlElement.INPUT_TIME == element) {
//					sdf = new SimpleDateFormat("HH:mm:ss");
//				}
			// DEL　DBエースOracle日付対応　↑

			if (JDBCMetaDataType.ARRAY == type || JDBCMetaDataType.BLOB == type
					|| JDBCMetaDataType.CLOB == type
					|| JDBCMetaDataType.DISTINCT == type
					|| JDBCMetaDataType.STRUCT == type
					|| JDBCMetaDataType.REF == type
					|| JDBCMetaDataType.JAVA_OBJECT == type) {

				// TODO 非対応だが、方式を検討するか...？
				ret.put(name, null);

			} else if (JDBCMetaDataType.BIGINT == type) {
				final long buff = this.resultSet.getLong(index);
				if (this.resultSet.wasNull()) {
					ret.put(name, null);
				} else {
					ret.put(name, String.valueOf(buff));
				}
			} else if (JDBCMetaDataType.VARCHAR == type
					|| JDBCMetaDataType.CHAR == type
					|| JDBCMetaDataType.NVARCHAR == type
					|| JDBCMetaDataType.NCHAR == type
					|| JDBCMetaDataType.LONGVARCHAR == type) {
				ret.put(name, this.resultSet.getString(index));
			} else if (JDBCMetaDataType.BINARY == type
					|| JDBCMetaDataType.VARBINARY == type
					|| JDBCMetaDataType.LONGVARBINARY == type) {

				// TODO バイナリ系は非対応だが、方式を検討するか...？
				ret.put(name, null);

			} else if (JDBCMetaDataType.BIT == type) {
				ret.put(name, String.valueOf(this.resultSet.getBoolean(index)));
			} else if (JDBCMetaDataType.TINYINT == type
					|| JDBCMetaDataType.SMALLINT == type) {
				final short buff = this.resultSet.getShort(index);
				if (this.resultSet.wasNull()) {
					ret.put(name, null);
				} else {
					ret.put(name, String.valueOf(buff));
				}
			} else if (JDBCMetaDataType.INTEGER == type) {
				final int buff = this.resultSet.getInt(index);
				if (this.resultSet.wasNull()) {
					ret.put(name, null);
				} else {
					ret.put(name, String.valueOf(buff));
				}
			} else if (JDBCMetaDataType.REAL == type) {
				final float buff = this.resultSet.getFloat(index);
				if (this.resultSet.wasNull()) {
					ret.put(name, null);
				} else {
					ret.put(name, this.getStringByNumericScaleIsZero(buff));
					//ret.put(name, String.valueOf(buff));
				}
			} else if (JDBCMetaDataType.DOUBLE == type
					|| JDBCMetaDataType.FLOAT == type) {
				if(def.getDefinitionOfColumnMap().get(name).getColumnTypeName().toUpperCase().equals("MONEY") 
						&& this.resultSet.getString(index) != null){
					//Check MONEY type of postgresql
					final String buff = this.resultSet.getString(index);
					if (this.resultSet.wasNull()) {
						ret.put(name, null);
					} else {
						ret.put(name, String.valueOf(buff));
						//ret.put(name, String.valueOf(buff).replaceAll("([^0-9^-])", ""));
					}
				}else{
					final double buff = this.resultSet.getDouble(index);
					if (this.resultSet.wasNull()) {
						ret.put(name, null);
					} else {
						ret.put(name, this.getStringByNumericScaleIsZero(buff));
						//ret.put(name, String.valueOf(buff));
					}
				}
			} else if (JDBCMetaDataType.DECIMAL == type
					|| JDBCMetaDataType.NUMERIC == type) {
				final BigDecimal buff = this.resultSet.getBigDecimal(index);
				if (this.resultSet.wasNull()) {
					ret.put(name, null);
				} else {
					/*String result = String.valueOf(buff);
					if(scale == 0){
						result = this.getStringByNumericScaleIsZero(buff);
					}
					ret.put(name, String.valueOf(buff));*/
					ret.put(name, String.valueOf(buff));
				}
			} else if (JDBCMetaDataType.DATE == type) {
				final java.sql.Date date = this.resultSet
						.getDate(index);
				if (this.resultSet.wasNull()) {
					ret.put(name, null);
				} else {
					if (sdf == null) {
						sdf = new SimpleDateFormat("yyyy/MM/dd");
					}
					Logger logger = LoggerFactory.getLogger(this.getClass().getName());
					logger.info(date);
					logger.info(sdf.format(date));
					ret.put(name, sdf.format(date));
				}
			} else if (JDBCMetaDataType.TIME == type) {
				final java.sql.Time time = this.resultSet.getTime(index);
				if (this.resultSet.wasNull()) {
					ret.put(name, null);
				} else {
					if (sdf == null) {
						// MOD　DBエースOracle日付対応　↓
						sdf = new SimpleDateFormat("HH:mm:ss");
//							sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
						// MOD　DBエースOracle日付対応　↑
					}
					ret.put(name, sdf.format(time));
				}
			} else if (JDBCMetaDataType.TIMESTAMP == type) {
				final java.sql.Timestamp timestamp = this.resultSet
						.getTimestamp(index);
				if (this.resultSet.wasNull()) {
					ret.put(name, null);
				} else {
					if (sdf == null) {
						sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
					}
					ret.put(name, sdf.format(timestamp));
				}
			}

		}
		return ret;
	}
	
	public String getStringByNumericScaleIsZero(final double buff){
		String result = String.valueOf(buff);
		String temp = "";
		for(int j = 0; j < result.length(); j++){
			if(result.charAt(j) == '.'){
				temp += ",";
			} else {
				temp += result.charAt(j);
			}
		}
		final double double_temp = Double.valueOf(temp.split(",")[0] + ".0");
		if(double_temp == buff){
			return temp.split(",")[0];
		}
		return result;
	}
	
	public String getStringByNumericScaleIsZero(final float buff){
		String result = String.valueOf(buff);
		String temp = "";
		for(int j = 0; j < result.length(); j++){
			if(result.charAt(j) == '.'){
				temp += ",";
			} else {
				temp += result.charAt(j);
			}
		}
		final float double_temp = Float.valueOf(temp.split(",")[0] + ".0");
		if(double_temp == buff){
			return temp.split(",")[0];
		}
		return result;
	}
	
	public String getStringByNumericScaleIsZero(final BigDecimal buff){
		String result = String.valueOf(buff);
		String temp = "";
		for(int j = 0; j < result.length(); j++){
			if(result.charAt(j) == '.'){
				temp += ",";
			} else {
				temp += result.charAt(j);
			}
		}
		final BigDecimal bigDecimal_temp = BigDecimal.valueOf(Double.valueOf(temp.split(",")[0] + ".0"));
		if(bigDecimal_temp == buff){
			return temp.split(",")[0];
		}
		return result;
	}

	public void updateMap(final SimpleSqlCondition condition)
			throws SQLException, DAOException {

		final Map<String, String> map = condition.getValuesMap();
		final Map<String, DefinedHtmlElement> tableItemMap = condition.getHtmlElement();
		final Map<String, Boolean> virtualColumns = condition.getVirtualColumns();
		final Map<String, JDBCMetaDataType> jdbcMetaDataTypeMap = condition.getJdbcMetaDataMap();
		for (int i = 0; i < this.metaData.getColumnCount(); i++) {
			final int index = i + 1;
			final String columnId = this.metaData.getColumnName(index);
			final String columnname = condition.getAliasNameMap().get(columnId.toUpperCase());
			final String value = map.get(columnname);
			final DefinedHtmlElement element = tableItemMap.get(columnname);
			final JDBCMetaDataType type = jdbcMetaDataTypeMap.get(columnname);

			final Boolean virtualColumn = virtualColumns.get(columnname);
			if (virtualColumn != null
					&& virtualColumn) {
				continue;
			}

			// ADD　DBエースOracle日付対応　↓
			boolean isPKey = condition.getWheresMap().containsKey(columnname);
			// MOD　DBエースOracle日付対応　↑
			SimpleDateFormat sdf = null;
			if (!isPKey) {
				if (DefinedHtmlElement.INPUT_DATE == element) {
					sdf = new SimpleDateFormat("yyyy/MM/dd");
				} else if (DefinedHtmlElement.INPUT_DATETIME == element) {
					sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				} else if (DefinedHtmlElement.INPUT_TIMESTAMP == element) {
					sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
				} else if (DefinedHtmlElement.INPUT_TIME == element) {
					sdf = new SimpleDateFormat("HH:mm:ss");
				}
			}
			try {
				if (JDBCMetaDataType.ARRAY == type
						|| JDBCMetaDataType.BLOB == type
						|| JDBCMetaDataType.CLOB == type
						|| JDBCMetaDataType.DISTINCT == type
						|| JDBCMetaDataType.STRUCT == type
						|| JDBCMetaDataType.REF == type
						|| JDBCMetaDataType.JAVA_OBJECT == type) {

					// TODO 非対応だが、方式を検討するか...？

				} else if (JDBCMetaDataType.BIGINT == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateLong(index, Long.valueOf(value));
					}
				} else if (JDBCMetaDataType.VARCHAR == type
						|| JDBCMetaDataType.CHAR == type
						|| JDBCMetaDataType.NVARCHAR == type
						|| JDBCMetaDataType.NCHAR == type
						|| JDBCMetaDataType.LONGVARCHAR == type) {
					if (value == null) {
						this.resultSet.updateNull(index);
					} else if (value.equals("")) {
						this.resultSet.updateString(index, "");
					} else {
						this.resultSet.updateString(index, value);
					}
				} else if (JDBCMetaDataType.BINARY == type
						|| JDBCMetaDataType.VARBINARY == type
						|| JDBCMetaDataType.LONGVARBINARY == type) {

					// TODO バイナリ系は非対応だが、方式を検討するか...？

				} else if (JDBCMetaDataType.BIT == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateBoolean(index,
								(value.equals("1") || value.equals("true")));
					}
				} else if (JDBCMetaDataType.TINYINT == type
						|| JDBCMetaDataType.SMALLINT == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateShort(index, Short.valueOf(value));
					}
				} else if (JDBCMetaDataType.INTEGER == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateInt(index, Integer.valueOf(value));
					}
				} else if (JDBCMetaDataType.REAL == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateFloat(index, Float.valueOf(value));
					}
				} else if (JDBCMetaDataType.DOUBLE == type
						|| JDBCMetaDataType.FLOAT == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else if(this.metaData.getColumnTypeName(index).toUpperCase().equals("MONEY")) {	
						String valueTemp = value == null ? "" : value;
						valueTemp = valueTemp.replaceAll("([,￥])", "");
						this.resultSet.updateBigDecimal(index, new BigDecimal(valueTemp));
					}else{
						this.resultSet.updateDouble(index, Double.valueOf(value));
					}
				} else if (JDBCMetaDataType.DECIMAL == type
						|| JDBCMetaDataType.NUMERIC == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateBigDecimal(index, new BigDecimal(
								value));
					}
				} else if (JDBCMetaDataType.DATE == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						if (sdf == null) {
							sdf = new SimpleDateFormat("yyyy/MM/dd");
						}
						final Date date = new Date(sdf.parse(value).getTime());
						this.resultSet.updateDate(index,
								new java.sql.Date(date.getTime()));
					}
				} else if (JDBCMetaDataType.TIME == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						if (sdf == null) {
							// MOD　DBエースOracle日付対応　↓
							//sdf = new SimpleDateFormat("HH:mm:ss");
							if(DateUtils.isTimeMiliFormat(value)) {
								sdf = new SimpleDateFormat("HH:mm:ss.SSS");
							} else {
								sdf = new SimpleDateFormat("HH:mm:ss");
							}
							// MOD　DBエースOracle日付対応　↑
						}
						final Date date = new Date(sdf.parse(value).getTime());
						this.resultSet.updateTime(index, new java.sql.Time(date
								.getTime()));
					}
				} else if (JDBCMetaDataType.TIMESTAMP == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						if (sdf == null) {
							sdf = new SimpleDateFormat(
									"yyyy/MM/dd HH:mm:ss.SSS");
						}
						final Date date = new Date(sdf.parse(value).getTime());
						this.resultSet.updateTimestamp(index,
								new java.sql.Timestamp(date.getTime()));
					}
				}
			} catch (final ParseException e) {
				// MI-E-0003={0}の書式が不正です。{1}形式で入力してください。
				final String args[] = { columnname, sdf.toPattern() };
				throw new DAOException(MessageUtils.getMessage("MI-E-0003", args));
			} catch (final NumberFormatException e) {
				// MI-E-0004={0}は数値で入力してください。
				final String args[] = { columnname };
				throw new DAOException(MessageUtils.getMessage("MI-E-0004", args));
			}
		}
	}

	/**
	 * マップに設定された文字列値をもとにカラム一括で結果セットを一行更新します。
	 * <p>
	 * 本メソッドでは、以下のデータ型の項目を更新する事は出来ません。
	 * <ol>
	 * <li>ARRAY</li>
	 * <li>BLOB</li>
	 * <li>CLOB</li>
	 * <li>DISTINCT</li>
	 * <li>STRUCT</li>
	 * <li>REF</li>
	 * <li>JAVA_OBJECT</li>
	 * <li>BINARY</li>
	 * <li>VARBINARY</li>
	 * <li>LONGVARBINARY</li>
	 * </ol>
	 * テーブル中にこれらの型が定義されていた場合には、個別に更新方法を検討する 必要があります。
	 * </p>
	 * <p>
	 * <a href="http://sdc.sun.co.jp/java/docs/j2se/1.4/ja/docs/ja/guide/jdbc/getstart/mapping.html"
	 * > 参考ドキュメント</a>
	 * </p>
	 * <p>
	 * なお、JDBC の結果セットメタデータでは、カラムの順序は「1」から開始され ます。「0」からではありません。
	 * </p>
	 *
	 * @param map
	 *            Map&lt;カラム名, 値&gt;
	 * @param virtualColumns
	 *            Map&lt;カラム名, バーチャルカラムか否か&gt;
	 * @throws SQLException
	 * @throws ParseException
	 *             値文字列の、データ型に合わせたパースが失敗した場合にスローします。
	 */
	public void insertMap(final SimpleSqlCondition condition)
			throws SQLException, DAOException {
		final Map<String, String> map = condition.getValuesMap();
		final Map<String, DefinedHtmlElement> tableItemMap = condition.getHtmlElement();
		final Map<String, Boolean> virtualColumns = condition.getVirtualColumns();
		final Map<String, JDBCMetaDataType> jdbcMetaDataTypeMap = condition.getJdbcMetaDataMap();
		for (int i = 0; i < this.metaData.getColumnCount(); i++) {
			final int index = i + 1;
			final String columnId = this.metaData.getColumnName(index);
			final String value = map.get(columnId);
			final DefinedHtmlElement element = tableItemMap.get(columnId);
			final JDBCMetaDataType type = jdbcMetaDataTypeMap.get(columnId);
			final String columnTypeName = this.metaData.getColumnTypeName(index);

			final Boolean virtualColumn = virtualColumns.get(columnId);
			if (virtualColumn != null
					&& virtualColumn) {
				continue;
			}

			SimpleDateFormat sdf = null;
			if (DefinedHtmlElement.INPUT_DATE == element) {
				sdf = new SimpleDateFormat("yyyy/MM/dd");
			} else if (DefinedHtmlElement.INPUT_DATETIME == element) {
				sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			} else if (DefinedHtmlElement.INPUT_TIMESTAMP == element) {
				sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
			} else if (DefinedHtmlElement.INPUT_TIME == element) {
				sdf = new SimpleDateFormat("HH:mm:ss");
			}

			try {
				if (JDBCMetaDataType.ARRAY == type
						|| JDBCMetaDataType.BLOB == type
						|| JDBCMetaDataType.CLOB == type
						|| JDBCMetaDataType.DISTINCT == type
						|| JDBCMetaDataType.STRUCT == type
						|| JDBCMetaDataType.REF == type
						|| JDBCMetaDataType.JAVA_OBJECT == type) {

					// TODO 非対応だが、方式を検討するか...？

				} else if (JDBCMetaDataType.BIGINT == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateLong(index, Long.valueOf(value));
					}
				} else if (JDBCMetaDataType.VARCHAR == type
						|| JDBCMetaDataType.CHAR == type
						|| JDBCMetaDataType.NVARCHAR == type
						|| JDBCMetaDataType.NCHAR == type
						|| JDBCMetaDataType.LONGVARCHAR == type) {
					if (value == null) {
						this.resultSet.updateNull(index);
					} else if (value.equals("")) {
						this.resultSet.updateString(index, "");
					} else {
						this.resultSet.updateString(index, value);
					}
				} else if (JDBCMetaDataType.BINARY == type
						|| JDBCMetaDataType.VARBINARY == type
						|| JDBCMetaDataType.LONGVARBINARY == type) {

					// TODO バイナリ系は非対応だが、方式を検討するか...？

				} else if (JDBCMetaDataType.BIT == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateBoolean(index,
								(value.equals("1") || value.equals("true")));
					}
				} else if (JDBCMetaDataType.TINYINT == type
						|| JDBCMetaDataType.SMALLINT == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateShort(index, Short.valueOf(value));
					}
				} else if (JDBCMetaDataType.INTEGER == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateInt(index, Integer.valueOf(value));
					}
				} else if (JDBCMetaDataType.REAL == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateFloat(index, Float.valueOf(value));
					}
				} else if (JDBCMetaDataType.DOUBLE == type
						|| JDBCMetaDataType.FLOAT == type) {					
					if (value == null || value.equals("")) {
						//data is null
						if(columnTypeName.toUpperCase().equals("MONEY")){
							//postgresql money type: data is null
							this.resultSet.updateBigDecimal(index, null);
						}else{
							this.resultSet.updateNull(index);
						}					
					}else if(columnTypeName.toUpperCase().equals("MONEY")) {
						//postgresql money type: data is not null
						final String valueTemp = value.replaceAll("([,￥])", "");
						this.resultSet.updateBigDecimal(index, new BigDecimal(valueTemp));
					}else {
						this.resultSet.updateDouble(index, Double.valueOf(value));
					}
				} else if (JDBCMetaDataType.DECIMAL == type
						|| JDBCMetaDataType.NUMERIC == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						this.resultSet.updateBigDecimal(index, new BigDecimal(
								value));
					}
				} else if (JDBCMetaDataType.DATE == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						if (sdf == null) {
							sdf = new SimpleDateFormat("yyyy/MM/dd");
						}
						final Date date = new Date(sdf.parse(value).getTime());
						this.resultSet.updateDate(index,
								new java.sql.Date(date.getTime()));
					}
				} else if (JDBCMetaDataType.TIME == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						if (sdf == null) {
							sdf = new SimpleDateFormat("HH:mm:ss");
						}
						final Date date = new Date(sdf.parse(value).getTime());
						this.resultSet.updateTime(index, new java.sql.Time(date
								.getTime()));
					}
				} else if (JDBCMetaDataType.TIMESTAMP == type) {
					if (value == null || value.equals("")) {
						this.resultSet.updateNull(index);
					} else {
						if (sdf == null) {
							sdf = new SimpleDateFormat(
									"yyyy/MM/dd HH:mm:ss.SSS");
						}
						final Date date = new Date(sdf.parse(value).getTime());
						this.resultSet.updateTimestamp(index,
								new java.sql.Timestamp(date.getTime()));
					}
				}
			} catch (final ParseException e) {
				// MI-E-0003={0}の書式が不正です。{1}形式で入力してください。
				final String args[] = { columnId, sdf.toPattern() };
				throw new DAOException(MessageUtils.getMessage("MI-E-0003", args));
			} catch (final NumberFormatException e) {
				// MI-E-0004={0}は数値で入力してください。
				final String args[] = { columnId };
				throw new DAOException(MessageUtils.getMessage("MI-E-0004", args));
			}
		}
	}

	/**
	 * 結果セットの次の行へ移動します。
	 * <p>
	 * Moves the cursor down one row from its current position. A
	 * <code>ResultSet</code> cursor is initially positioned before the first
	 * row; the first call to the method <code>next</code> makes the first row
	 * the current row; the second call makes the second row the current row,
	 * and so on.
	 * </p>
	 * <p>
	 * If an input stream is open for the current row, a call to the method
	 * <code>next</code> will implicitly close it. A <code>ResultSet</code>
	 * object's warning chain is cleared when a new row is read.
	 * </p>
	 *
	 * @return <code>true</code> if the new current row is valid;
	 *         <code>false</code> if there are no more rows
	 * @exception SQLException
	 *                if a database access error occurs
	 */
	public boolean next() throws SQLException {
		return this.resultSet.next();
	}

	/**
	 * 追加行へ移動します。
	 * <p>
	 * Moves the cursor to the insert row. The current cursor position is
	 * remembered while the cursor is positioned on the insert row. The insert
	 * row is a special row associated with an updatable result set. It is
	 * essentially a buffer where a new row may be constructed by calling the
	 * updater methods prior to inserting the row into the result set. Only the
	 * updater, getter, and insertRow methods may be called when the cursor is
	 * on the insert row. All of the columns in a result set must be given a
	 * value each time this method is called before calling insertRow. An
	 * updater method must be called before a getter method can be called on a
	 * column value.
	 * </p>
	 *
	 * @throws SQLException
	 */
	public void moveToInsertRow() throws SQLException {
		this.resultSet.moveToInsertRow();
	}

	/**
	 * 結果セット先頭に移動します。
	 * <p>
	 * Moves the cursor to the first row in this <code>ResultSet</code> object.
	 * </p>
	 *
	 * @exception SQLException
	 *                if a database access error occurs or the result set type
	 *                is <code>TYPE_FORWARD_ONLY</code>
	 * @since 1.2
	 */
	public void first() throws SQLException {
		this.resultSet.first();
	}

	/**
	 * 結果セット先頭の直前に移動します。
	 * <p>
	 * Moves the cursor to the front of this <code>ResultSet</code> object, just
	 * before the first row. This method has no effect if the result set
	 * contains no rows.
	 * </p>
	 *
	 * @exception SQLException
	 *                if a database access error occurs or the result set type
	 *                is <code>TYPE_FORWARD_ONLY</code>
	 * @since 1.2
	 */
	public void beforeFirst() throws SQLException {
		this.resultSet.beforeFirst();
	}

	/**
	 * 結果セットの指定された行へ移動します。
	 * <p>
	 * Moves the cursor to the given row number in this <code>ResultSet</code>
	 * object.
	 * </p>
	 * <p>
	 * If the row number is positive, the cursor moves to the given row number
	 * with respect to the beginning of the result set. The first row is row 1,
	 * the second is row 2, and so on.
	 * </p>
	 * <p>
	 * If the given row number is negative, the cursor moves to an absolute row
	 * position with respect to the end of the result set. For example, calling
	 * the method <code>absolute(-1)</code> positions the cursor on the last
	 * row; calling the method <code>absolute(-2)</code> moves the cursor to the
	 * next-to-last row, and so on.
	 * </p>
	 * <p>
	 * An attempt to position the cursor beyond the first/last row in the result
	 * set leaves the cursor before the first row or after the last row.
	 * </p>
	 * <p>
	 * <B>Note:</B> Calling <code>absolute(1)</code> is the same as calling
	 * <code>first()</code>. Calling <code>absolute(-1)</code> is the same as
	 * calling <code>last()</code>.
	 * </p>
	 *
	 * @param row
	 *            the number of the row to which the cursor should move. A
	 *            positive number indicates the row number counting from the
	 *            beginning of the result set; a negative number indicates the
	 *            row number counting from the end of the result set
	 * @return <code>true</code> if the cursor is on the result set;
	 *         <code>false</code> otherwise
	 * @exception SQLException
	 *                if a database access error occurs, or the result set type
	 *                is <code>TYPE_FORWARD_ONLY</code>
	 */
	public boolean absolute(int row) throws SQLException {
		return this.resultSet.absolute(row);
	}

	/**
	 * 行更新を実行します。
	 * <p>
	 * Updates the underlying database with the new contents of the current row
	 * of this <code>ResultSet</code> object. This method cannot be called when
	 * the cursor is on the insert row.
	 * </p>
	 *
	 * @exception SQLException
	 *                if a database access error occurs or if this method is
	 *                called when the cursor is on the insert row
	 * @since 1.2
	 */
	public void updateRow() throws SQLException {
		this.resultSet.updateRow();
	}

	/**
	 * 行追加を実行します。
	 * <p>
	 * Inserts the contents of the insert row into this <code>ResultSet</code>
	 * object and into the database. The cursor must be on the insert row when
	 * this method is called.
	 * </p>
	 *
	 * @exception SQLException
	 *                if a database access error occurs, if this method is
	 *                called when the cursor is not on the insert row, or if not
	 *                all of non-nullable columns in the insert row have been
	 *                given a value
	 * @since 1.2
	 */
	public void insertRow() throws SQLException {
		this.resultSet.insertRow();
	}

	/**
	 * 結果セット参照をクローズします。
	 * <p>
	 * クローズ時の例外は無視します。
	 * </p>
	 */
	public void close() {
		if (this.resultSet != null) {
			try {
				this.resultSet.close();
			} catch (final SQLException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 取得したデータの件数を返します。
	 *
	 * @return resultRowCount 取得件数
	 * @deprecated このメソッドは推奨されません。<br />
	 *             レコード件数が多い場合に、処理に時間がかかる可能性があります。 またメモリも消費するため、out of memory
	 *             が発生する可能性があります。
	 */
	@Deprecated
	public int getResultRowCount() throws SQLException {
		final int nowRow = this.resultSet.getRow();
		this.resultSet.last();
		final int resultRowCount = this.resultSet.getRow();
		if (nowRow == 0) {
			beforeFirst();
		} else {
			absolute(nowRow);
		}
		return resultRowCount;
	}

	/**
	 * WebResultSetFacade の生成。
	 * <p>
	 * コンストラクタ。
	 * </p>
	 * <p>
	 * ラップ可能な結果セットはスクロール可（TYPE_SCROLL_INSENSITIVE）、更新可能
	 * （CONCUR_UPDATABLE）なもののみです。
	 * </p>
	 * <p>
	 * 結果セット参照を受け取ると同時に、結果セットメタデータを取得して保持 します。メタデータの取得に失敗した場合例外をスローします。
	 * </p>
	 *
	 * @param resultSet
	 *            結果セット
	 * @throws SQLException
	 */
	public WebResultSetFacade(final ResultSet resultSet) throws SQLException {
		this.resultSet = resultSet;
		this.metaData = resultSet.getMetaData();
	}

	/**
	 * フェッチサイズを指定します。
	 *
	 * @param fetchSize
	 * @throws SQLException
	 */
	public void setFetchSize(final int fetchSize) throws SQLException {
		this.resultSet.setFetchSize(fetchSize);
	}
}
