/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Table;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Tables;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

@Data
public class TablesDto {
	private List<TableDto> tableDtoList;

	public TablesDto() {

	}

	public TablesDto(Tables tables) {
		if (tables != null) {
			List<Table> tableList = tables.getTable();
			List<TableDto> TableDtoList = new ArrayList<TableDto>();
			if (tableList != null) {
				for(Table item : tableList){
					TableDto dto = new TableDto(item);
					TableDtoList.add(dto);
				}
				this.tableDtoList = TableDtoList;
			}
		}
	}
	
	/**
	 * 1. new ArrayList<TableDto>()
	 * 2. sort by SortIndex
	 * @return itemDtoList
	 */
	public List<TableDto> getTableDtoList(){
		if(tableDtoList == null){
			tableDtoList = new ArrayList<TableDto>();
		}else{
			Collections.sort(tableDtoList, new Comparator<TableDto>() {
			  @Override public int compare(final TableDto o1, final TableDto o2) {
			    return o1.getListNO().compareTo(o2.getListNO());
			  }
			});
		}
		return tableDtoList;
	}
	
}
