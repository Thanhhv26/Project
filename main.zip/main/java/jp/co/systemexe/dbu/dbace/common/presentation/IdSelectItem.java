/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.presentation;

import java.io.Serializable;

/**
 * select 系要素に表示項目を追加するための一時アイテム。
 * <p>
 * 任意の値セットを IdSelectable を実装したオブジェクトに変換するための
 * 一時アイテム。
 * </p><p>
 * HTML select 要素に値セットを設定する際に、一時的に IdSelectable を実装した
 * オブジェクトに値を設定し、自動設定 API に渡すための一時的に利用するための VO
 * です。<br />
 * IdSelectable インターフェースはプレゼンテーション層に属する定義なので、
 * アプリケーションドメイン層或いはパーシステンス層のオブジェクトが実装すべき
 * ではありません（独自のエンティティクラス、或いは DTO を定義すべきです）。<br />
 * その指針に従い、かつプレゼンテーション層内で独自 DTO 或いは Bean を定義しない
 * 場合に、本オブジェクトを使用します。
 * </p>
 *
 * @author EXE 相田 一英
 * @author EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class IdSelectItem implements Serializable, IdSelectable {

    /**
     * serialVersionUID。
     */
    private static final long serialVersionUID = -4388187606733075611L;

    /**
     * id。
     * <p>HTML select 要素の value に設定される ID（キー）値。</p>
     */
    private String id;

    /**
     * label。
     * <p>HTML select 要素のラベルに設定されるキャプション値。</p>
     */
    private String label;

    private String type;

    /**
     * id を戻します。
     * <p>HTML select 要素の value に設定される ID（キー）値。</p>
     *
     * @see jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable#getId()
     */
    public String getId() {
        return id;
    }

    /**
     * label を戻します。
     * <p>HTML select 要素のラベルに設定されるキャプション値。</p>
     *
     * @see jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable#getLabel()
     */
    public String getLabel() {
        return label;
    }

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

    /**
     * IdSelectItem の生成。
     * <p>コンストラクタ。</p>
     *
     * @param id HTML select 要素の value に設定される ID（キー）値。
     * @param label HTML select 要素のラベルに設定されるキャプション値。
     */
    public IdSelectItem(final String id, final String label/*, String type*/) {
        this.id = id;
        this.label = label;
//        this.type = type;
    }
}
