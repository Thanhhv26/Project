/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.util;

import java.util.UUID;


/**
 * UUIDを生成する、キージェネレータ。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class UUIDKeyGenerator {

    /**
     * UUIDを生成して戻します。
     * 
     * <p>
     * 128bitのユニークIDの文字列を取得できます。文字列の長さは３６byteです。<br />
     * </p>
     * <p>
     * 生成例：cd80ee77-4255-4239-ab5e-166580976d1c
     * </p>
     */
    public String nextKeyValue() {
        return UUID.randomUUID().toString();
    }

}
