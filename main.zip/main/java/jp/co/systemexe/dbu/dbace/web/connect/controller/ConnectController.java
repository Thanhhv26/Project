/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.connect.controller;

import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.domain.service.ConnectionService;
import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
import jp.co.systemexe.dbu.dbace.web.connect.dto.ConnectDto;
import jp.co.systemexe.dbu.dbace.web.connect.json.FRM0500SearchParam;
import jp.co.systemexe.dbu.dbace.web.connect.model.FRM0500ResultModel;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;
import jp.co.systemexe.dbu.dbace.web.user.dto.PageInfo;

@RestController
@RequestMapping(value = "/data/connect")
public class ConnectController extends AbstractController {

	/***/
	private static final long serialVersionUID = 1L;

	/**
	 * Connection Service
	 */
	@Autowired
	private ConnectionService connectionService;

	/**
	 * Index page
	 *
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index() throws Exception {
		ModelAndView mv = new ModelAndView(PageConst.SCREEN_CONNECT);
		return mv;
	}

	/**
	 * User
	 *
	 * @return
	 */
	@RequestMapping(value = "/search", method = { RequestMethod.POST })
	public FRM0500ResultModel search(@RequestBody FRM0500SearchParam searchParam) throws Exception {
		FRM0500ResultModel searchResultDto = new FRM0500ResultModel();
		try{
			searchResultDto = connectionService.search(searchParam);
			if (searchResultDto.getResultData().size() == 0) {
				searchResultDto.getMessageInfo().add(new MessageInfo("MI-E-0087", MessageType.INFO, messageService));
			}

			if(searchParam.isFlagSearch() == true){
				OutputAuditLog.writeConnectedDefinitionLog(
						AuditEventKind.SEARCH,
						getUserInfo(),//AbstractController
						"",//connectDto.getConnectDefinition()
						AuditStatus.success,
						String.valueOf(searchResultDto.getResultData().size()));
			}
		}catch(Exception e){
			if(searchParam.isFlagSearch() == true){
				OutputAuditLog.writeConnectedDefinitionLog(
						AuditEventKind.SEARCH,
						getUserInfo(),//AbstractController
						"",//connectDto.getConnectDefinition()
						AuditStatus.failure,
						"0");
			}
		}
		return searchResultDto;
	}

	/**
	 * get info page
	 *
	 * @return PageInfo
	 */
	@RequestMapping(value = "/getInfoPage", method = { RequestMethod.POST })
	public PageInfo getInfoPage() throws Exception {
		return new PageInfo();
	}

	/**
	 * Delete Connect by connectDefinition
	 *
	 * @param connectDto
	 * @return
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public FRM0500ResultModel deleteConnect(@RequestBody ConnectDto connectDto) {
		FRM0500ResultModel resultModel = new FRM0500ResultModel();
		connectDto.setUserInfo(getUserInfo());
		try {
			// check connect exist
			final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
			if(!logic.isExistConnectionByID(connectDto.getConnectDefinition())){
				resultModel.getMessageInfo().add(new MessageInfo(MessageUtils.getMessage("MI-E-0118"), MessageType.ERROR));
				return resultModel;
			}
			if (connectionService.deleteConnect(connectDto)) {
				resultModel.getMessageInfo()
						.add(new MessageInfo("connect.delete.success", MessageType.SUCCESS, messageService));
			} else {
				resultModel.getMessageInfo()
						.add(new MessageInfo("connect.delete.failed", MessageType.ERROR, messageService));
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		return resultModel;
	}

	/**
	 * is Deleted Connect
	 * @return true : exist /false : not exist
	 */
	@RequestMapping(value = "/isDeletedConnect", method = { RequestMethod.POST })
	public boolean isDeletedConnect(@RequestBody ConnectDto param) throws Exception {
		// check connect exist
		final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		return logic.isExistConnectionByID(param.getConnectDefinition());
	}

	/**
	 * Create new connect
	 *
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public FRM0500ResultModel createConnect(@RequestBody ConnectDto connectDto) throws Exception {
		FRM0500ResultModel resultModel = new FRM0500ResultModel();
		connectDto.setUserInfo(getUserInfo());
		if (validateRequired(resultModel, connectDto)) {
			FRM0500SearchParam searchParam = new FRM0500SearchParam();
			searchParam.setConnectDefinitionName(connectDto.getConnectDefinitionName());
			resultModel = search(searchParam);
			if (resultModel.getResultData().size() > 0) {
				for (ConnectDto dto : resultModel.getResultData()) {
					if (dto.getConnectDefinitionName().equals(connectDto.getConnectDefinitionName())) {
						resultModel.getMessageInfo().add(new MessageInfo("connectDefinitionName",
								"connect.connectDefinitionName.duplicated", MessageType.ERROR, messageService));
						return resultModel;
					}
				}

			}else{
				resultModel.setMessageInfo(new ArrayList<MessageInfo>());
			}
			int affectedRows = connectionService.insertConnect(connectDto);
			if (affectedRows > 0) {
				resultModel.getMessageInfo().add(new MessageInfo("connect.create.success", MessageType.SUCCESS, messageService));
			} else {
				resultModel.getMessageInfo().add(new MessageInfo("connect.create.failed", MessageType.ERROR, messageService));
			}

		}
		return resultModel;
	}

	/**
	 * Update account
	 *
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public FRM0500ResultModel updateConnect(@RequestBody ConnectDto connectDto) throws Exception {
		FRM0500ResultModel resultModel = new FRM0500ResultModel();
		// check connect exist
		final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		if(!logic.isExistConnectionByID(connectDto.getConnectDefinition())){
			resultModel.getMessageInfo().add(new MessageInfo(MessageUtils.getMessage("MI-E-0118"), MessageType.ERROR));
			return resultModel;
		}
		connectDto.setUserInfo(getUserInfo());
		if (validateRequired(resultModel, connectDto)) {
			FRM0500SearchParam searchParam = new FRM0500SearchParam();
			searchParam.setConnectDefinitionName(connectDto.getConnectDefinitionName());
			resultModel = search(searchParam);
			if (resultModel.getResultData().size() > 0) {
				for (ConnectDto dto : resultModel.getResultData()) {
					if(!dto.getConnectDefinition().equals(connectDto.getConnectDefinition()) && dto.getConnectDefinitionName().equals(connectDto.getConnectDefinitionName())){
						resultModel.getMessageInfo()
						.add(new MessageInfo("connectDefinitionName", "connect.connectDefinitionName.duplicated", MessageType.ERROR, messageService));
						return resultModel;
					}
				}

			}else{
				resultModel.setMessageInfo(new ArrayList<MessageInfo>());
			}
			int affectedRows = connectionService.updateConnect(connectDto);
			if (affectedRows > 0) {
				resultModel.getMessageInfo()
						.add(new MessageInfo("connect.update.success", MessageType.SUCCESS, messageService));
			} else {
				resultModel.getMessageInfo()
						.add(new MessageInfo("connect.update.failed", MessageType.ERROR, messageService));
			}
		}
		return resultModel;
	}

	/**
	 * Test connection
	 *
	 * @param model
	 * @return
	 * @throws ReflectiveOperationException
	 */
	@RequestMapping(value = "/testConnect", method = RequestMethod.POST)
	public FRM0500ResultModel testConnect(@RequestBody ConnectDto connectDto) throws Exception {
		FRM0500ResultModel resultModel = new FRM0500ResultModel();
		if("editConnectForm".equals(connectDto.getFormId())){
			// check connect exist
			final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
			if(!logic.isExistConnectionByID(connectDto.getConnectDefinition())){
				resultModel.getMessageInfo().add(new MessageInfo(MessageUtils.getMessage("MI-E-0118"), MessageType.ERROR));
				return resultModel;
			}
		}
		if (validateRequired(resultModel, connectDto)) {
			try {
				connectionService.testConnect(connectDto);
				resultModel.getMessageInfo().add(new MessageInfo("connect.test.success", MessageType.SUCCESS, messageService));
			} catch (ApplicationRuntimeException e) {
				String msg = e.getMessage();
				String prefixError = "MI-E-0032:";
				if (msg.contains(prefixError)) {
					msg = msg.split(prefixError)[1];
				} else {
					prefixError = "DAOException:";
					msg = msg.split(prefixError)[1];
				}
				//msg = msg.replace("データベースの接続に失敗しました", "DB接続テストに失敗しました");
				resultModel.getMessageInfo().add(new MessageInfo(msg, MessageType.ERROR));
			}
		}
		return resultModel;
	}

	/**
	 * 保存確認、接続テストボタン押下時の 必須チェック処理を行います。
	 *
	 * @return
	 */
	public boolean validateRequired(FRM0500ResultModel resultModel, ConnectDto connectDto) {
		boolean isError = true;
		if (StringUtils.isBlank(connectDto.getConnectDefinitionName())) {
			resultModel.getMessageInfo()
					.add(new MessageInfo("connectDefinitionName", "MI-E-0500-0001", MessageType.ERROR, messageService,
							new String[] { messageService.getMessage("frm0500.connect.connectDefinitionName") }));
			isError = false;
		}

		if (StringUtils.isBlank(connectDto.getTemplateDatabaseUrl())) {
			resultModel.getMessageInfo().add(new MessageInfo("templateDatabaseUrl", "MI-E-0500-0002", MessageType.ERROR,
					messageService, new String[] { messageService.getMessage("frm0500.connect.templateDatabaseUrl") }));
			isError = false;
		}

		if (connectDto.getUseDatabaseUrl()) {
			if (StringUtils.isBlank(connectDto.getDatabaseUrl())) {
				resultModel.getMessageInfo().add(new MessageInfo("databaseUrl", "MI-E-0500-0001", MessageType.ERROR,
						messageService, new String[] { messageService.getMessage("frm0500.connect.databaseUrl") }));
				isError = false;
			}
		} else {
			if (StringUtils.isBlank(connectDto.getServerId())) {
				resultModel.getMessageInfo().add(new MessageInfo("serverId", "MI-E-0500-0001", MessageType.ERROR,
						messageService, new String[] { messageService.getMessage("frm0500.connect.serverId") }));
				isError = false;
			}

			if (StringUtils.isBlank(connectDto.getPort())) {
				resultModel.getMessageInfo().add(new MessageInfo("port", "MI-E-0500-0001", MessageType.ERROR,
						messageService, new String[] { messageService.getMessage("frm0500.connect.port") }));
				isError = false;
			}

			if (StringUtils.isBlank(connectDto.getDatabaseId())) {
				resultModel.getMessageInfo().add(new MessageInfo("databaseId", "MI-E-0500-0001", MessageType.ERROR,
						messageService, new String[] { messageService.getMessage("frm0500.connect.databaseId") }));
				isError = false;
			}
		}

		if (StringUtils.isBlank(connectDto.getPid())) {
			resultModel.getMessageInfo().add(new MessageInfo("pid", "MI-E-0500-0001", MessageType.ERROR, messageService,
					new String[] { messageService.getMessage("frm0500.connect.pid") }));
			isError = false;
		}
		if (StringUtils.isBlank(connectDto.getPassword())) {
			// MI-E-0040=パスワードを入力してください。
			resultModel.getMessageInfo().add(new MessageInfo("password", "MI-E-0500-0001", MessageType.ERROR,
					messageService, new String[] { messageService.getMessage("frm0500.connect.password") }));
			isError = false;
		}

		// 関連チェック
		if (isError) {
			if (!connectDto.getUseDatabaseUrl()) {
				if (!connectDto.getServerId().matches("[A-Za-z0-9._-]*")) {
					// MI-E-0028=サーバーIDに半角の英数字と「.」以外の文字が入力されています。
					resultModel.getMessageInfo()
							.add(new MessageInfo("serverId", "MI-E-0028", MessageType.ERROR, messageService));
					isError = false;
				}

				if (connectDto.getPort().length() > 6) {
					// MI-E-0045=ポート番号は6桁以下の数値を入力してください
					resultModel.getMessageInfo()
							.add(new MessageInfo("port", "MI-E-0045", MessageType.ERROR, messageService));
					isError = false;
				}

				if (!connectDto.getPort().matches("[0-9]*")) {
					// MI-E-0044={0}に半角の数字以外の文字が入力されています。
					resultModel.getMessageInfo().add(new MessageInfo("port", "MI-E-0044", MessageType.ERROR,
							messageService, new String[] { messageService.getMessage("frm0500.connect.port") }));
					isError = false;
				}
			}
		}

		return isError;
	}

}
