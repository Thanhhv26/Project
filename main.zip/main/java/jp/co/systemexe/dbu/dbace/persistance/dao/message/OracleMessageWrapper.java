/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.message;

import java.sql.DatabaseMetaData;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;

/**
 * オラクルのメッセージ(ORA-XXXXX)をラップした、メッセージを返します。
 * <p>
 * EASY上でラップする必要がないメッセージに
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class OracleMessageWrapper {
	/**
	 * オラクルのメッセージ(ORA-XXXXX)をラップした、メッセージを返します。
	 * <p>
	 * EASY上でラップする必要がないメッセージに
	 * </p>
	 *
	 * @param errorCode SQLException#getErrorCode
	 * @param errorMessage SQLException#getMessage
	 * @param defaultMessageId メッセージがラップされない場合に設定する、メッセージID
	 * @return
	 */
	public static String getWrapMessage(
			final int errorCode,
			final String errorMessage,
			final String defaultMessageId) {		
		if (StringUtils.isEmpty(errorMessage)) {
			return "";
		}
		final String args[] = {errorMessage};
		return MessageUtils.getMessage(defaultMessageId, args);
//		if (errorMessage.startsWith("ORA-")) {
//			OracleMessageMapping mapping
//				= OracleMessageMapping.sqlExceptionErrorCodeOf(errorCode);
//			if (mapping == OracleMessageMapping.OTHER) {
//				final String args[] = {errorMessage};
//				return MessageUtils.getMessage(defaultMessageId, args);
//			} else {
//				return MessageUtils.getMessage(mapping.getMessageId());
//			}
//		} else {
//			final String args[] = {errorMessage};
//			return MessageUtils.getMessage(defaultMessageId, args);
//		}
	}

	/**
	 * OracleのエラーIDとEASYのメッセージIDのマッピングを行う列挙体
	 *
	 * @author  EXE 島田 雄一郎
	 * @version 0.0.0
	 */
	private enum OracleMessageMapping {
		/**
		 * 一意制約違反
		 */
		ORA00001(1, "MI-E-5000"),

		/**
		 * セッションの強制終了
		 */
		ORA00028(28, "MI-E-5001"),

		/**
		 * Oracleリスナーへの接続失敗（リスナー未起動）
		 */
		ORA00107(107, "MI-E-5002"),

		/**
		 * SQL文の文法エラー
		 */
		ORA00900(900, "MI-E-5003"),

		/**
		 * 表または、ビューが存在しない
		 */
		ORA00903(903, "MI-E-5004"),

		/**
		 * 表または、ビューが存在しない
		 */
		ORA00942(942, "MI-E-5004"),

		/**
		 * ORDER BY句で指定している列名が、選択リストの複数の列と一致
		 */
		ORA00960(960, "MI-E-5005"),

		/**
		 * GROUP BY句またはORDER BY句に1001個以上
		 */
		ORA00962(962, "MI-E-5006"),

		/**
		 * SELECT句の"*"に対して、別名を指定
		 */
		ORA00965(965, "MI-E-5007"),

		/**
		 * Oracle接続時の認証エラー
		 */
		ORA01017(1017, "MI-E-5008"),

		/**
		 * ラップするメッセージ以外
		 */
		OTHER(-1, "");

	    private static Map<Integer, OracleMessageMapping> map;
	    static {
	        map = new HashMap<Integer, OracleMessageMapping>();
	        for (final OracleMessageMapping buff : values()) {
	            map.put(buff.getSqlExceptionErrorCode(), buff);
	        }
	    }

	    /**
	     * SQLExceptionのErrorCodeに応じて定義インスタンスを検索して戻します。
		 * <p>
	     * ラップするメッセージとして、登録されていないメッセージの場合は OTHER を戻します。
	     * </p>
	     *
	     * @param errorCodeOf SQLExceptionのgetErrorCode()
	     * @return OracleMessageMapping
	     * @see DatabaseMetaData
	     */
	    public static OracleMessageMapping sqlExceptionErrorCodeOf(final int errorCode) {
	        if (map.containsKey(errorCode)) {
	            return map.get(errorCode);
	        } else {
	            return OTHER;
	        }
	    }

	    /**
	     * SQLExceptionのErrorCode
	     */
		private int sqlExceptionErrorCode;

		/**
		 * EASYのメッセージID
		 */
		private String messageId;

		/**
		 * messageId を戻します。
		 *
		 * @return String
		 */
		public String getMessageId() {
			return messageId;
		}

		/**
		 * sqlExceptionErrorCode を戻します。
		 *
		 * @return int
		 */
		public int getSqlExceptionErrorCode() {
			return sqlExceptionErrorCode;
		}

		private OracleMessageMapping(
				int sqlExceptionErrorCode,
				String messageId) {
			this.sqlExceptionErrorCode = sqlExceptionErrorCode;
			this.messageId = messageId;
		}
	}
}
