/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.common.jdbc.DataTypeDBMappingWithJDBC;
import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;
import jp.co.systemexe.dbu.dbace.common.util.DefaultValueAnalysis;
import jp.co.systemexe.dbu.dbace.common.util.DefaultValueAnalysis.UpdatePattern;
import jp.co.systemexe.dbu.dbace.domain.dto.DbConnectDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfTableItemInformationLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfTableItemListWithStatusLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfTableLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.CheckSqlLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.CheckSqlParametersLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationFormComponentInfomationRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationSortColumnInfomationRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.TableNameListIsAcquiredFromRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.definition.RelationOfJdbcAndHtml;
import jp.co.systemexe.dbu.dbace.domain.service.CreationService;
import jp.co.systemexe.dbu.dbace.domain.service.ItemService;
import jp.co.systemexe.dbu.dbace.library.service.AbstractService;
import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.ItemRestriction;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.ColumnListItemForGuiSetting;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.HtmlElementItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.RestrictionsItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectConnectListDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectItemDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectItemDTOSave;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectTablesDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SortColumnEditorDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.SortDataEditorDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.TrRowDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.columnListItemDTO;
import jp.co.systemexe.dbu.dbace.web.item.dto.restrictionsDTO;
import jp.co.systemexe.dbu.dbace.web.item.model.FRM0310ResultModel;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;

/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 jan 18, 2017
 */

@Service
public class ItemServiceImpl extends AbstractService implements ItemService {

	private static final long serialVersionUID = 1L;
	@Autowired
	MessageService messageService;
	@Autowired
	CreationService creationService;

	/**
	 * 画面要素に表示する、キーカラムか否かの表示文字列を返します。
	 *
	 * @param def
	 * @return
	 */
	public String getKeyColumnLabel(final DefinitionOfColumn def) {
		if (def.isPrimaryKey()) {
			return MessageUtils.getMessageNotMessageId("MI-I-0014");
		} else if (def.isUnique()) {
			return MessageUtils.getMessageNotMessageId("MI-I-0015");
		} else if (def.isForeignKey()) {
			return MessageUtils.getMessageNotMessageId("MI-I-0016");
		}
		return "";
	}

	/**
	 * 画面要素に表示する、カラムの型の表示文字列を返します。
	 *
	 * @param def
	 * @return
	 */
	public String getColumnTypeLabel(final DefinitionOfColumn def) {
		final StringBuilder ret = new StringBuilder();
		String columnTypeName = StringUtils.isEmpty(def.getColumnTypeName()) ? "" : def.getColumnTypeName();
		ret.append(columnTypeName.toUpperCase());
		ret.append(makeSizeColumnTypeLabel(def));

		if (def.isVirtualColumns()) {
			ret.append(" ");
			ret.append("VIRTUAL");
		}

		return ret.toString();
	}

	/**
	 * 精度或いは桁数注釈の作成。
	 * <p>
	 * 精度、或いは最大桁数の定義が存在しない場合は空文字を戻します。
	 * </p>
	 *
	 * @param def
	 * @return ret 精度或いは桁数注釈
	 */
	private String makeSizeColumnTypeLabel(final DefinitionOfColumn def) {
		final String ret;
		// アプリケーション非対応
		if (!RelationOfJdbcAndHtml.metaDataTypeOf(def.getJDBCMetaDataType()).isCorrespond()) {
			return "";

			// 数値型
		} else if (isJDBCMetaDataTypeIsNumeric(def.getJDBCMetaDataType())) {
			// ORACLEの場合、NUMBERで桁数指定されていない場合は getPrecision が 0 を返す。
			// そして、10gの場合は getScale が -127 (9iは0)を返す。。。（謎
			if (def.getDefinitionOfNumericalValue().getPrecision() == 0) {
				ret = "(38,0)";
			} else {
				ret = "(" + def.getDefinitionOfNumericalValue().getPrecision() + ","
						+ def.getDefinitionOfNumericalValue().getScale() + ")";
			}

			// 日付型
		} else if (isJDBCMetaDataTypeIsDate(def.getJDBCMetaDataType())) {
			ret = "";
			// 文字列型 or バイナリ型
		} else {
			if (def.getColumnDisplayMaxSize() > 0) {
				ret = "(" + def.getColumnDisplayMaxSize() + ")";
			} else {
				ret = "";
			}
		}
		return ret;
	}

	/**
	 * 引数のJDBCMetaDataTypeが数値型が否かを返します。
	 *
	 * @param type
	 * @return
	 */
	private boolean isJDBCMetaDataTypeIsNumeric(final JDBCMetaDataType type) {
		if (type == JDBCMetaDataType.TINYINT || type == JDBCMetaDataType.SMALLINT || type == JDBCMetaDataType.INTEGER
				|| type == JDBCMetaDataType.BIGINT || type == JDBCMetaDataType.FLOAT || type == JDBCMetaDataType.REAL
				|| type == JDBCMetaDataType.DOUBLE || type == JDBCMetaDataType.NUMERIC
				|| type == JDBCMetaDataType.DECIMAL) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 引数のJDBCMetaDataTypeが日付型が否かを返します。
	 *
	 * @param type
	 * @return
	 */
	private boolean isJDBCMetaDataTypeIsDate(final JDBCMetaDataType type) {
		if (type == JDBCMetaDataType.DATE || type == JDBCMetaDataType.TIME || type == JDBCMetaDataType.TIMESTAMP) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Page クラスの初期化イベントハンドラ。
	 *
	 * @see jp.co.systemexe.bidwh3g.qdbutil.presentation.BaseTeedaPage#initialize()
	 */
	@Override
	public List<IdSelectable> doInitialize(UserAuthority userAuthority) throws ApplicationRuntimeException {
		final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
		final List<IdSelectable> connectDefinisionList;
		try {
			connectDefinisionList = logic.getIdSelectableList(userAuthority);
		} catch (final ApplicationDomainLogicException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
		return connectDefinisionList;
	}

	/**
	 * 選択された接続定義プロパティーより、接続定義のテーブル一覧情報を取得し、カ ラム一覧プルダウンリストを生成（初期化）します。
	 * </p>
	 *
	 * @return
	 */
	@Override
	public FRM0310ResultModel searchTable(SelectConnectListDTO search) throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
		Map<String, List<IdSelectable>> mapConnTable = new HashMap<String, List<IdSelectable>>();
		for (int i = 0; i < search.getConnectDefinitionIds().size(); i++) {
			String selectedConnectDefinisionId = search.getConnectDefinitionIds().get(i);
			try {
				mapConnTable.put(selectedConnectDefinisionId,
						logic.getTableNameListByConnectName(selectedConnectDefinisionId));
				resultModel.setMapConnTable(mapConnTable);
				resultModel.setStatus(true);
			} catch (ApplicationDomainLogicException e) {
				MessageInfo error = new MessageInfo();
				error = new MessageInfo("MI-E-0114",MessageType.ERROR, messageService);
				resultModel.getMessageInfo().add(error);
				resultModel.setStatus(false);
				logger.error(e.getMessage(), e);
				return resultModel;
			}
		}
		return resultModel;
	}

	/**
	 * 選択されたテーブルプロパティーより、テーブルのカラム一覧情報を取得し、カ ラム一覧プルダウンリストを生成（初期化）します。
	 * </p>
	 *
	 * @return
	 */
	@Override
	public FRM0310ResultModel searchColumn(SelectTablesDTO search, String userInfo) throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel.setStatus(true);
		try {
			final AcquisitionOfTableItemListWithStatusLogic columnLogic = new AcquisitionOfTableItemListWithStatusLogic();
			SortedMap<Integer, ColumnListItemForGuiSetting> map = null;
			try {
				map = columnLogic.getSortedColumnMapByConnectNameFromXML(search.getConnectDefinitionId(), search.getTableId(),
						userInfo);
			} catch (final ApplicationDomainLogicException e) {
				resultModel.setStatus(false);
				logger.error(e.getMessage(), e);
			}
			resultModel.setColumnListItems(new ArrayList<ColumnListItemForGuiSetting>());
			for (final Iterator<ColumnListItemForGuiSetting> ite = map.values().iterator(); ite.hasNext();) {
				final ColumnListItemForGuiSetting item = ite.next();
				final ColumnListItemForGuiSetting buff = new ColumnListItemForGuiSetting();
				buff.setConnectDefinitionId(search.getConnectDefinitionId());
				buff.setTableId(search.getTableId());
				buff.setTableLabel(search.getTableLabel());
				buff.setValue(item.getValue());
				buff.setLabel(item.getLabel());
				buff.setFieldType(item.getFieldType().toString());
				buff.setCanDisplays(item.getCanDisplays().toString());
				buff.setIsSearchKey(item.getIsSearchKey().toString());
				buff.setPrimaryKey(item.isPrimaryKey());
				buff.setSelectKey(item.isSelectKey());
				buff.setUpdateKey(item.isUpdateKey());
				buff.setParametersSql(item.getParametersSql());
				resultModel.getColumnListItems().add(buff);
			}
		} catch (final Exception e) {
			resultModel.setStatus(false);
			logger.error(e.getMessage(), e);
		}
		return resultModel;
	}

	/**
	 * Page クラスの初期化イベントハンドラ。
	 * <p>
	 * テーブルフォーム情報の編集操作はアプリケーション管理権限を持ったユーザー 以外実行出来ません。ここではセッション中の管理権限を確認し、違反していた
	 * 場合はセッション中に警告を設定し、エラー画面に遷移します。
	 * </p>
	 * <p>
	 * 権限をクリアした場合は、初期化処理としてリポジトリからの画面表示情報の 取得と画面への表示を行います。
	 * </p>
	 */
	@Override
	public FRM0310ResultModel doEditItem(SelectItemDTO search) throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel.setStatus(true);
		try {
			AcquisitionOfTableItemListWithStatusLogic statusLogic = new AcquisitionOfTableItemListWithStatusLogic();
			final TableFormDTO tableFormDTO = statusLogic.getTableFormDTOByConnectName(search.getConnectDefinitionId(), search.getTableId());
			String tableType = tableFormDTO.getType();

			AcquisitionOfTableItemInformationLogic logic = new AcquisitionOfTableItemInformationLogic();
			final TableItemDTO dto = logic.getItemInformationByConnectLable(search.getConnectDefinitionId(),
					search.getTableId(), search.getItemId());

			final columnListItemDTO buff = new columnListItemDTO();
			buff.setTableType(tableType);
			buff.setTableId(search.getTableId());
			buff.setTableLabel(search.getTableLabel());
			buff.setValue(search.getItemId());
			buff.setLabel(dto.getItemLabel());
			buff.setSortIndex(dto.getSortIndex());
			/* buff.getHtmlElementItems(); */
			buff.setHtmlElement(dto.getHtmlElement().getKey());
			final List<SelectOneMenuItem> rest = new ArrayList<SelectOneMenuItem>();
			for (Iterator<ItemRestriction> ite = Arrays.asList(ItemRestriction.values()).iterator(); ite.hasNext();) {
				ItemRestriction ir = ite.next();
				final SelectOneMenuItem item = new RestrictionsItem();
				item.setLabel(ir.getLabel());
				item.setValue(ir.getId());
				rest.add(item);
			}
			buff.setRestrictionsItems(rest);
			final List<SelectOneMenuItem> html = new ArrayList<SelectOneMenuItem>();
			for (Iterator<DefinedHtmlElement> ite = Arrays.asList(DefinedHtmlElement.values()).iterator(); ite
					.hasNext();) {
				DefinedHtmlElement def = ite.next();
				final SelectOneMenuItem item = new HtmlElementItem();
				item.setLabel(def.getLabel());
				item.setValue(def.getKey());
				html.add(item);
			}
			buff.setHtmlElementItems(html);
			// TODO 以下のロジックの場合、Enumから消えた「不要となった」独自制約に対処できない
			// 独自制約チェックボックス生成が、Enum 定義に依存している。
			// よって、相田さんの案である、selectmany の設計に切り替えるべきである。
			final Map<ItemRestriction, Boolean> restMap = dto.getItemRestrictions();
			// TODO 以下の Iterator コード、map.keySet()メソッドに切り替え
			final Collection<Entry<ItemRestriction, Boolean>> entries = restMap.entrySet();
			final List<String> serectedList = new ArrayList<String>();
			for (Iterator i = entries.iterator(); i.hasNext();) {
				Map.Entry ent = (Map.Entry) i.next();
				final ItemRestriction itemRestriction = (ItemRestriction) ent.getKey();
				serectedList.add(itemRestriction.getId());
			}
			buff.setRestrictions((String[]) serectedList.toArray(new String[0]));
			buff.setDefaultValue(dto.getDefaultValue());
			buff.setExplanation(dto.getExplanation());
			/* generateSelectOneCheckBoxs(); */
			buff.setCanPreview(String.valueOf(dto.canPreview()));
			buff.setCanDisplayRecordEdit(String.valueOf(dto.canDisplayRecordEdit()));
			buff.setCanDisplayNamePreview(String.valueOf(dto.canDisplayNamePreview()));
			buff.setCanEditing(String.valueOf(dto.canEditing()));
			buff.setIsUpdateKey(String.valueOf(dto.isUpdateKey()));
			buff.setIsSelectKey(String.valueOf(dto.isSelectKey()));
			buff.setParametersSql(dto.getParametersSql()); /*An test*/
			
			//check Correspondence
//			String connectionLabel = search.getConnectDefinitionId();
//			String tableId = search.getTableId();
//			String itemID = search.getItemId();
//			UserInfo userInfoObject = search.getUserInfo();
//			boolean isCorrespondence = this.isCorrespondence(connectionLabel, tableId, itemID, userInfoObject);
//			buff.setCorrespondence(isCorrespondence);
			String connectionLabel = search.getConnectDefinitionId();
			final String databaseType = statusLogic.getDbConnectInfomationByLabel(connectionLabel).getDatabaseTypeConnectionDestination().getDatabaseName();
			final String dataTypeDatabase = dto.getDataType();
			DataTypeDBMappingWithJDBC dataType = DataTypeDBMappingWithJDBC.getByDataTypeDatabase(databaseType, dataTypeDatabase);
			final JDBCMetaDataType metaData = JDBCMetaDataType.dataTypeOf(dataType.getDataType());
			final RelationOfJdbcAndHtml relation = RelationOfJdbcAndHtml.metaDataTypeOf(metaData);
			buff.setCorrespondence(relation.isCorrespond());
			
			buff.setSelectableListItems(Arrays.asList(dto.getSelectableItems()));
			buff.setSqlString(dto.getSqlString());
			
			/* buff.setKeyColumn(getKeyColumnLabel(definitionOfColumn)); */
			if (dto.getPrimaryKey() == true) {
				buff.setKeyColumn(MessageUtils.getMessageNotMessageId("MI-I-0014"));
			} else if (dto.getUnique() == true) {
				buff.setKeyColumn(MessageUtils.getMessageNotMessageId("MI-I-0015"));
			} else if (dto.getForeignKey() == true) {
				buff.setKeyColumn(MessageUtils.getMessageNotMessageId("MI-I-0016"));
			}
			/* buff.setColumnType(getColumnTypeLabel(definitionOfColumn)); */
			buff.setColumnType(dto.getDataType() + dto.getDataLength());
			resultModel.setItemSelect(buff);
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
			/* addPageMessage(e.getMessage()); */
			return null;
		}

		return resultModel;
	}

	/**
	 * 「既定値 の確認」ボタンのイベントハンドラ。
	 * <p>
	 * 入力された 既定値の実行結果を検証するボタンです。
	 * </p>
	 *
	 * @return 遷移先ページクラス
	 */
	@Override
	public FRM0310ResultModel doOnceDefaultValue(SelectItemDTO search, UserInfo userInfo)
			throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		final DefaultValueAnalysis compiler = new DefaultValueAnalysis(userInfo);
		resultModel.insertDefaultValue = compiler.analysis(search.getDefaultValue(), UpdatePattern.INSERT, "");
		resultModel.updateDefaultValue = compiler.analysis(search.getDefaultValue(), UpdatePattern.UPDATE,
				MessageUtils.getMessageNotMessageId("MI-I-0013"));
		// MI-I-0013=データベースに登録されている値が表示されます。
		return resultModel;
	}

	/**
	 * 「プルダウンリストに追加する」ボタンのイベントハンドラ。
	 * <p>
	 * プルダウンリストへの表示値設定リストにキー値と表示値の値セットを追加 します。<br />
	 * 追加後、入力欄はクリアします。
	 * </p>
	 *
	 * @return null
	 */
	@Override
	public FRM0310ResultModel doOnceAddRestrictionItem(SelectItemDTO search, UserInfo userInfo)
			throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel.setStatus(true);
		MessageInfo error = new MessageInfo();
		try {
			if (search.getAddedId() == null || search.getAddedId().equals("")) {
				// MI-E-0008={0}は必須入力項目です。
				resultModel.setStatus(false);
				error = new MessageInfo("MI-E-0008", MessageType.ERROR, new String[]{"frm0310.doEditItem.restrictionItemKey"},
						messageService);
				error.setId("frm0310.doEditItem.restrictionItemKey");
				resultModel.getMessageInfo().add(error);
				return resultModel;
			} else if (search.getAddedLabel() == null || search.getAddedLabel().equals("")) {
				// MI-E-0107=表示値が入力されていません。
				resultModel.setStatus(false);
				error = new MessageInfo("MI-E-0008", MessageType.ERROR, new String[]{"frm0310.doEditItem.restrictionItemValue"},
						messageService);
				error.setId("frm0310.doEditItem.restrictionItemValue");
				resultModel.getMessageInfo().add(error);
				return resultModel;
			}

			final List<TrRowDTO> items = new ArrayList<TrRowDTO>();
			/*
			 * AcquisitionOfTableItemInformationLogic logic = new
			 * AcquisitionOfTableItemInformationLogic(); final TableItemDTO dto
			 * = logic.getItemInformationByConnectLable(search.
			 * getConnectDefinitionId(), search.getTableId(),
			 * search.getItemId());
			 */
			for (TrRowDTO item : search.getSelectableListItems()) {
				if (item.getValue().equals(search.getAddedId())) {
					resultModel.setStatus(false);
					error = new MessageInfo("MI-E-0067", MessageType.ERROR, messageService);
					error.setId("frm0310.doEditItem.restrictionItemKey");
					resultModel.getMessageInfo().add(error);
					return resultModel;
				}
				items.add(item);
			}

			final TrRowDTO item = new TrRowDTO();
			item.setValue(search.getAddedId());
			item.setLabel(search.getAddedLabel());
			items.add(item);
			resultModel.setSelectableListItems(items);
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
			error = new MessageInfo(e.getMessage(), MessageType.ERROR, messageService);
			resultModel.setStatus(false);
			resultModel.getMessageInfo().add(error);
			error.setId("frm0310.doEditItem.restrictionItemKey");
		}
		return resultModel;
	}

	/**
	 * 「削除」ボタンのイベントハンドラ。
	 * <p>
	 * </p>
	 *
	 * @return 遷移先ページクラス
	 */
	@Override
	public FRM0310ResultModel doOnceDelitationRestrictionItem(SelectItemDTO search, UserInfo userInfo)
			throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel.setStatus(true);
		MessageInfo error = new MessageInfo();
		try {
			final List<TrRowDTO> items = new ArrayList<TrRowDTO>();
			/*
			 * final List<SelectOneMenuItem> items = new
			 * ArrayList<SelectOneMenuItem>();
			 */
			/* int index = 0; */
			System.out.println(search.getSelectableListItems());
			System.out.println(search.getAddedId());

			if (search.getAddedId() == null || search.getAddedId().equals("")) {
				resultModel.setSelectableListItems(null);
			} else {
				for (TrRowDTO item : search.getSelectableListItems()) {
					if (!item.getValue().equals(search.getAddedId())) {
						items.add(item);
					}
				}
				resultModel.setSelectableListItems(items);
			}

		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
			error = new MessageInfo(e.getMessage(), MessageType.ERROR, messageService);
			resultModel.setStatus(false);
			resultModel.getMessageInfo().add(error);
			error.setId("frm0310.doEditItem.restrictionItemKey");
		}
		return resultModel;
	}

	/**
	 * 「SQL の確認」ボタンのイベントハンドラ。
	 * <p>
	 * 入力された SQL 文の妥当性を検証するボタンです。
	 * </p>
	 * <p>
	 * SQL 文の指定が無い場合は、メッセージを表示して単にポストバックします。
	 * </p>
	 * <p>
	 * 入力された SQL を実際に発行し、レコードを何件か取得し表示します。検証用の ロジックが例外をスローして来た場合に問題がある、と判断します。
	 * </p>
	 *
	 * @return 遷移先ページクラス
	 */
	@Override
	public FRM0310ResultModel doOnceSqlCheck(SelectItemDTO search, UserInfo userInfo)
			throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel.setStatus(true);
		MessageInfo error = new MessageInfo();
		try {
			if (search.getSqlString() == null || search.getSqlString().equals("")) {
				// MI-E-0014=SQL 文が指定されていません。
				resultModel.setStatus(false);
				error = new MessageInfo("MI-E-0014", MessageType.ERROR, messageService);
				error.setId("frm0310.doEditItem.sqlString");
				resultModel.getMessageInfo().add(error);
				return resultModel;
			}
			String sql;
			if (search.getSqlParameters() == null || search.getSqlParameters().equals("")) {
				sql = search.getSqlString();
			} else {
				final CheckSqlParametersLogic logic = new CheckSqlParametersLogic();
				Map<String, String> map = null;
				try {
					map = logic.decode(search.getSqlParameters());
				} catch (final ApplicationDomainLogicException e) {
					resultModel.setStatus(false);
					error = new MessageInfo(e.getMessage(), MessageType.ERROR, messageService);
					error.setId("frm0310.doEditItem.sqlParameters");
					resultModel.getMessageInfo().add(error);
					return resultModel;
				}
				String buff = search.getSqlString();
				for (final Iterator<String> ite = map.keySet().iterator(); ite.hasNext();) {
					final String key = ite.next();
					buff = buff.replaceAll("'".concat(key).concat("'"), "'".concat(map.get(key)).concat("'"));
				}
				sql = buff;
			}
			final CheckSqlLogic logic = new CheckSqlLogic();
			SelectOneMenuItem[] Items = null;
			try {
				final AcquisitionOfConnectDefinitionLogic definitionLogic = new AcquisitionOfConnectDefinitionLogic();
				DbConnectDefinitionDTO dto = definitionLogic
						.getConnectDefinitionDTOByLabel(search.getConnectDefinitionId());
				sql = sql.replaceAll("\n", "\r\n");
				Items = logic.checkOf(sql, dto, userInfo);
			} catch (ApplicationDomainLogicException e) {
				resultModel.setStatus(false);
				error = new MessageInfo(e.getLocalizedMessage(), MessageType.ERROR, messageService);
				error.setId("frm0310.doEditItem.sqlString");
				resultModel.getMessageInfo().add(error);
				return resultModel;
			}
			resultModel.setQueryResultListItems(Items);
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
			resultModel.setStatus(false);
			error = new MessageInfo(e.getMessage(), MessageType.ERROR, messageService);
			resultModel.getMessageInfo().add(error);
			error.setId("frm0310.doEditItem.sqlString");
			resultModel.getMessageInfo().add(error);
			return resultModel;
		}
		// resultModel.getMessageInfo().add(error);
		return resultModel;
	}

	/**
	 * カラム制御情報をリポジトリに保存した後、画面制御情報検索画面へ遷移します。
	 * <p>
	 * Gui設定画面に戻った際に、選択されたテーブルIDを保持するためにdoFinishHoge
	 * イベントハンドラーを採用していません。手動で個別ItemsSaveをクリアーしてい ます。
	 * </p>
	 *
	 * @return
	 */
	@Override
	public FRM0310ResultModel doOnceSave(SelectItemDTOSave search,
			UserInfo userInfo) throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();

		resultModel.setStatus(true);
		MessageInfo error = new MessageInfo();
		final AcquisitionOfConnectDefinitionLogic connLogic = new AcquisitionOfConnectDefinitionLogic();
		String connId = null;
		try {
			connId = connLogic.getConnectDefinitionId(search.getConnectDefinitionId());

			if (search.getColumnLabel() == null || search.getColumnLabel().equals("")) {
				resultModel.setStatus(false);
				error = new MessageInfo("customize.doEditItem.E1-001",MessageType.ERROR, messageService);
				resultModel.getMessageInfo().add(error);
				error.setId("frm0310.doEditItem.columnLabel");
			}

			if(search.getHtmlElement() == null || search.getHtmlElement().equals(""))
			{
				final String args[] = { "frm0310.doEditItem.htmlElement" };
				resultModel.setStatus(false);
				error = new MessageInfo("MI-E-00081",MessageType.ERROR, args, messageService);
				resultModel.getMessageInfo().add(error);
				error.setId("frm0310.doEditItem.htmlElement");
			}

			if (search.getSelectableListItems() != null
					&& search.getSelectableListItems().size() != 0
					&& search.getSqlString() != null
					&& search.getSqlString().length() != 0) {
				// MI-E-0054=リストの定義は[手動でリストを定義する]、[SQL
				// でリストを定義する]のどちらか片方しか入力できません。
				error = new MessageInfo("MI-E-0054", MessageType.ERROR, search.getColumnLabel(), messageService);
				error.setId("frm0310.doEditItem.sqlString");
				resultModel.getMessageInfo().add(error);
				resultModel.setStatus(false);
			}

			/*if (search.getSqlString() != null && !search.getSqlString().equals("")) {
				String sql;
				boolean runCheckSqlStringFlg = true;
				//check param
				if (search.getSqlParameters() == null || search.getSqlParameters().equals("")) {
					sql = search.getSqlString();
				} else {
					final CheckSqlParametersLogic logic = new CheckSqlParametersLogic();
					Map<String, String> map = new HashMap<String, String>();
					try {
						map = logic.decode(search.getSqlParameters());
					} catch (final ApplicationDomainLogicException e) {
						runCheckSqlStringFlg = false;
						resultModel.setStatus(false);
						error = new MessageInfo(e.getMessage(),MessageType.ERROR, messageService);
						error.setId("frm0310.doEditItem.sqlParameters");
						resultModel.getMessageInfo().add(error);
					}
					String buff = search.getSqlString();
					for (final Iterator<String> ite = map.keySet().iterator(); ite.hasNext();) {
						final String key = ite.next();
						buff = buff.replaceAll("'".concat(key).concat("'"),"'".concat(map.get(key)).concat("'"));
					}
					sql = buff;
				}

				if(runCheckSqlStringFlg){
					final CheckSqlLogic logic = new CheckSqlLogic();
					SelectOneMenuItem[] Items = null;
					try {
						final AcquisitionOfConnectDefinitionLogic definitionLogic = new AcquisitionOfConnectDefinitionLogic();
						DbConnectDefinitionDTO dto = definitionLogic.getConnectDefinitionDTOByLabel(search.getConnectDefinitionId());
						sql = sql.replaceAll("\n", "\r\n");
						Items = logic.checkOf(sql, dto, userInfo);
					} catch (ApplicationDomainLogicException e) {
						resultModel.setStatus(false);
						error = new MessageInfo(e.getLocalizedMessage(),
								MessageType.ERROR, messageService);
						error.setId("frm0310.doEditItem.sqlString");
						resultModel.getMessageInfo().add(error);
					}
				}

			}*/
			if(resultModel.isStatus())
			{
				final PreservationFormComponentInfomationRepositoryLogic logic = new PreservationFormComponentInfomationRepositoryLogic();
				AcquisitionOfTableItemInformationLogic infologic = new AcquisitionOfTableItemInformationLogic();
				TableItemDTO ret = null;
				try {
					ret = infologic.getItemInformationByConnectLable(
							search.getConnectDefinitionId(), search.getTableId(),
							search.getItemId());
				} catch (ApplicationDomainLogicException e1) {
					e1.printStackTrace();
					resultModel.setStatus(false);
				}
				ret.setItemId(search.getItemId());
				ret.setItemLabel(search.getColumnLabel());
				ret.setHtmlElement(
						DefinedHtmlElement.keyOf(search.getHtmlElement()));
				ret.setSelectableItems(search.getSelectableListItems()
						.toArray(new SelectableItem[0]));
				ret.setSqlString(search.getSqlString());
				/*ret.setParametersSql(search.getSqlParameters());*/
				ret.getItemRestrictions().clear();
				for (restrictionsDTO item : search.getRestrictionsItems()) {
					if (item.getValueRes().equals("true")) {
						ret.getItemRestrictions()
								.put(ItemRestriction.idOf(item.getIdRes()), true);
					}
				}
				ret.setDefaultValue(search.getDefaultValue());
				ret.setExplanation(search.getExplanation());
				ret.setPreview(search.getCanPreview().equals(String.valueOf(true)));
				ret.setDisplayRecordEdit(search.getCanDisplayRecordEdit()
						.equals(String.valueOf(true)));
				ret.setDisplayNamePreview(search.getCanDisplayNamePreview()
						.equals(String.valueOf(true)));
				if (search.getCanEditing() != null) {
					ret.setEditing(
							search.getCanEditing().equals(String.valueOf(true)));
				}
				if (search.getIsUpdateKey() != null) {
					ret.setUpdateKey(
							search.getIsUpdateKey().equals(String.valueOf(true)));
				}
				if (search.getIsSelectKey() != null) {
					ret.setSelectKey(
							search.getIsSelectKey().equals(String.valueOf(true)));
				}

				if (isMultiTable(connId, search.getTableId())) {
					logic.saveMulti(connId, search.getTableId(), search);
				} else {
					logic.save(connId, search.getTableId(), search.getItemId(),ret);
				}
				OutputAuditLog.writeGuiSettingLog(AuditEventKind.UPDATE, userInfo,
						search.getConnectDefinitionId(), search.getTableLabel().replaceAll("\n", "").replaceAll("\t", ""),
						AuditStatus.success, String.valueOf(1));
				resultModel.setStatus(true);
				error = new MessageInfo("customize.doEditItem.S1-002",
						MessageType.SUCCESS, search.getColumnLabel(),
						messageService);
				resultModel.getMessageInfo().add(error);
			}
		} catch (final ApplicationDomainLogicException e) {
			e.printStackTrace();
			error = new MessageInfo(e.getLocalizedMessage(), MessageType.ERROR,
					messageService);
			OutputAuditLog.writeGuiSettingLog(AuditEventKind.UPDATE, userInfo,
					search.getConnectDefinitionId(), search.getTableLabel().replaceAll("\n", "").replaceAll("\t", ""),
					AuditStatus.failure, String.valueOf(0));
			resultModel.getMessageInfo().add(error);
			resultModel.setStatus(false);
			return resultModel;
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
			error = new MessageInfo(e.getMessage(), MessageType.ERROR,
					messageService);
			OutputAuditLog.writeGuiSettingLog(AuditEventKind.UPDATE, userInfo,
					search.getConnectDefinitionId(), search.getTableLabel().replaceAll("\n", "").replaceAll("\t", ""),
					AuditStatus.failure, String.valueOf(0));
			resultModel.getMessageInfo().add(error);
			resultModel.setStatus(false);
			return resultModel;
		}
		return resultModel;
	}

	/**
	 *
	 * @param connectDefinisionId
	 * @param tableFormId
	 * @return
	 */
	public boolean isMultiTable(final String connectDefinisionId, final String tableFormId) throws ApplicationDomainLogicException{
			final TableNameListIsAcquiredFromRepositoryLogic logic = new TableNameListIsAcquiredFromRepositoryLogic();
			return logic.isMultiTable(connectDefinisionId, tableFormId);
	}

	/**
	 * @param tableFormDTO
	 * @return
	 */
	private Map<String, TableItemDTO> getTableItemMapSorted(TableFormDTO tableFormDTO) {
		List<TableItemDTO> tableItemList=new ArrayList<>(tableFormDTO.getTableItemMap().values());
		Collections.sort(tableItemList, new Comparator<TableItemDTO>() {
			  @Override
			  public int compare(final TableItemDTO o1, final TableItemDTO o2) {
			    return o1.getSortIndex() > o2.getSortIndex() ? 1:-1;
			  }
			});
		Map<String, TableItemDTO> tableItemSortedMap = new LinkedHashMap<String, TableItemDTO>();
		for (TableItemDTO item : tableItemList){
			tableItemSortedMap.put(item.getItemId(),item);
		}
		return tableItemSortedMap;
	}

	@Override
	public FRM0310ResultModel loadSortData(SelectTablesDTO selectTablesDTO) throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel.setStatus(true);
		final AcquisitionOfTableLogic tableLogic = new AcquisitionOfTableLogic();
		final AcquisitionOfConnectDefinitionLogic connectDefinitionLogic = new AcquisitionOfConnectDefinitionLogic();

		try {
			final DbConnectDefinitionDTO connectDefinitionDTO = connectDefinitionLogic
					.getConnectDefinitionDTOByLabel(selectTablesDTO.getConnectDefinitionId());
			TableFormDTO tableFormDTO = tableLogic.getTableFormDTO(connectDefinitionDTO.getConnectDefinitionId(),
					selectTablesDTO.getTableId());
			SortDataEditorDTO dto = new SortDataEditorDTO();
			dto.setConnectDefinitionId(connectDefinitionDTO.getConnectDefinitionId());
			//sort item flow sort index
			Map<String, TableItemDTO> tableItemSortedMap = getTableItemMapSorted(tableFormDTO);
			tableFormDTO.setTableItemMap(tableItemSortedMap);

			dto.setTableFormDTO(tableFormDTO);
			resultModel.setSortDataEditorDTO(dto);
		} catch (final ApplicationDomainLogicException e) {
			resultModel.setStatus(false);
			resultModel.getMessageInfo().add(new MessageInfo(e.getLocalizedMessage(), MessageType.ERROR));
			logger.error(e.getMessage(), e);
		}
		return resultModel;
	}

	@Override
	public FRM0310ResultModel updateSortData(SortDataEditorDTO sortDataEditorDTO, UserInfo userInfo) {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel.setStatus(true);
		final AcquisitionOfTableLogic tableLogic = new AcquisitionOfTableLogic();
		final AcquisitionOfConnectDefinitionLogic connectDefinitionLogic = new AcquisitionOfConnectDefinitionLogic();
		final PreservationSortColumnInfomationRepositoryLogic logic = new PreservationSortColumnInfomationRepositoryLogic();
		try {
			final DbConnectDefinitionDTO connectDefinitionDTO = connectDefinitionLogic
					.getConnectDefinitionDTOByLabel(sortDataEditorDTO.getConnectDefinitionId());

			TableFormDTO tableFormDTO = tableLogic.getTableFormDTO(connectDefinitionDTO.getConnectDefinitionId(),
					sortDataEditorDTO.getTableFormDTO().getTableFormId());
			SortedMap<Integer, String> sortConditionMap = sortDataEditorDTO.getTableFormDTO().getSortConditionMap();
			tableFormDTO.setSortConditionMap(sortConditionMap);
			tableFormDTO.setTableFormLabel(sortDataEditorDTO.getTableFormDTO().getTableFormLabel());
			tableFormDTO.setOrderDesc(sortDataEditorDTO.getTableFormDTO().getOrderDesc());
			sortDataEditorDTO.setConnectDefinitionId(connectDefinitionDTO.getConnectDefinitionId());
			logic.update(sortDataEditorDTO.getConnectDefinitionId(), tableFormDTO);

			OutputAuditLog.writeGuiSettingLog(
					AuditEventKind.UPDATE,
					userInfo,
					sortDataEditorDTO.getConnectDefinitionId(),
					sortDataEditorDTO.getTableFormDTO().getTableFormLabel(),
					AuditStatus.success,
               		String.valueOf(1));
		} catch (final ApplicationDomainLogicException e) {
			e.printStackTrace();
			resultModel.getMessageInfo().add(new MessageInfo(e.getLocalizedMessage(), MessageType.ERROR));
			// addPageMessage(e.getLocalizedMessage());

			OutputAuditLog.writeGuiSettingLog(
					AuditEventKind.UPDATE,
					userInfo,
					sortDataEditorDTO.getConnectDefinitionId(),
					sortDataEditorDTO.getTableFormDTO().getTableFormLabel(),
					AuditStatus.failure,
               		String.valueOf(0));
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
			resultModel.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			// addPageMessage(e.getMessage());

			OutputAuditLog.writeGuiSettingLog(
					AuditEventKind.UPDATE,
					userInfo,
					sortDataEditorDTO.getConnectDefinitionId(),
					sortDataEditorDTO.getTableFormDTO().getTableFormLabel(),
					AuditStatus.failure,
               		String.valueOf(0));

		}
		return resultModel;
	}

	@Override
	public FRM0310ResultModel loadSortColumn(SelectTablesDTO selectTablesDTO) throws ApplicationRuntimeException {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel.setStatus(true);
		final AcquisitionOfTableLogic tableLogic = new AcquisitionOfTableLogic();
		final AcquisitionOfConnectDefinitionLogic connectDefinitionLogic = new AcquisitionOfConnectDefinitionLogic();

		try {
			final DbConnectDefinitionDTO connectDefinitionDTO = connectDefinitionLogic
					.getConnectDefinitionDTOByLabel(selectTablesDTO.getConnectDefinitionId());
			TableFormDTO tableFormDTO = tableLogic.getTableFormDTO(connectDefinitionDTO.getConnectDefinitionId(),
					selectTablesDTO.getTableId());
			SortColumnEditorDTO dto = new SortColumnEditorDTO();
			dto.setConnectDefinitionId(connectDefinitionDTO.getConnectDefinitionId());
			dto.setTableFormDTO(tableFormDTO);
			resultModel.setSortColumnEditorDTO(dto);
		} catch (final ApplicationDomainLogicException e) {
			resultModel.setStatus(false);
			resultModel.getMessageInfo().add(new MessageInfo(e.getLocalizedMessage(), MessageType.ERROR));
			logger.error(e.getMessage(), e);
		}
		return resultModel;
	}

	@Override
	public FRM0310ResultModel updateSortColumn(SortColumnEditorDTO sortColumnEditorDTO, UserInfo userInfo) {
		FRM0310ResultModel resultModel = new FRM0310ResultModel();
		resultModel.setStatus(true);
		final AcquisitionOfTableLogic tableLogic = new AcquisitionOfTableLogic();
		final AcquisitionOfConnectDefinitionLogic connectDefinitionLogic = new AcquisitionOfConnectDefinitionLogic();
		final PreservationSortColumnInfomationRepositoryLogic logic = new PreservationSortColumnInfomationRepositoryLogic();
		try {

			final DbConnectDefinitionDTO connectDefinitionDTO = connectDefinitionLogic
					.getConnectDefinitionDTOByLabel(sortColumnEditorDTO.getConnectDefinitionId());

			TableFormDTO tableFormDTO = tableLogic.getTableFormDTO(connectDefinitionDTO.getConnectDefinitionId(),
					sortColumnEditorDTO.getTableFormDTO().getTableFormId());
			tableFormDTO.setTableFormLabel(sortColumnEditorDTO.getTableFormDTO().getTableFormLabel());

			Map<String, TableItemDTO> updateTableItemMap = sortColumnEditorDTO.getTableFormDTO().getTableItemMap();
			for (Iterator<String> iterator = updateTableItemMap.keySet().iterator(); iterator.hasNext();) {
				String itemId = (String) iterator.next();
				if(tableFormDTO.getTableItemMap().containsKey(itemId)){
					TableItemDTO itemID = tableFormDTO.getTableItemMap().get(itemId);
					itemID.setSortIndex(updateTableItemMap.get(itemId).getSortIndex());
				}
			}


			sortColumnEditorDTO.setConnectDefinitionId(connectDefinitionDTO.getConnectDefinitionId());
			logic.update(sortColumnEditorDTO.getConnectDefinitionId(), tableFormDTO);
			OutputAuditLog.writeGuiSettingLog(
					AuditEventKind.UPDATE,
					userInfo,
					sortColumnEditorDTO.getConnectDefinitionId(),
					sortColumnEditorDTO.getTableFormDTO().getTableFormLabel(),
					AuditStatus.success,
               		String.valueOf(1));
		} catch (final ApplicationDomainLogicException e) {
			e.printStackTrace();
			resultModel.getMessageInfo().add(new MessageInfo(e.getLocalizedMessage(), MessageType.ERROR));
			// addPageMessage(e.getLocalizedMessage());

			OutputAuditLog.writeGuiSettingLog(
					AuditEventKind.UPDATE,
					userInfo,
					sortColumnEditorDTO.getConnectDefinitionId(),
					sortColumnEditorDTO.getTableFormDTO().getTableFormLabel(),
					AuditStatus.failure,
               		String.valueOf(0));
		} catch (final Exception e) {
			logger.error(e.getMessage(), e);
			resultModel.getMessageInfo().add(new MessageInfo(e.getMessage(), MessageType.ERROR));
			// addPageMessage(e.getMessage());

			OutputAuditLog.writeGuiSettingLog(
					AuditEventKind.UPDATE,
					userInfo,
					sortColumnEditorDTO.getConnectDefinitionId(),
					sortColumnEditorDTO.getTableFormDTO().getTableFormLabel(),
					AuditStatus.failure,
               		String.valueOf(0));

		}
		return resultModel;
	}
	
//	public boolean isCorrespondence(String connectionLabel, String tableID, String itemID, UserInfo userInfo) throws Exception{
//		//check Correspondence
//		TableNameListIsAcquiredFromRepositoryLogic domainLogic = new TableNameListIsAcquiredFromRepositoryLogic();
//		String connectionID = domainLogic.getConnectDefinitionIdByConnectName(connectionLabel);
//		ItemDto itemDto =  creationService.getItemByID(connectionID, tableID, itemID, userInfo.getUserAuthority());
//		if(itemDto.getCols().getColDto().size() > 0){//is multi table
//			tableID = itemDto.getCols().getColDto().get(0).getTableID();
//		}
//		final RetrievalProcessingOfRecordFromDatabaseLogic databaseLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
//		final TableDefinitionDTO tableDef = databaseLogic.getTableDefinitionDTOByConnectLabel(connectionLabel, tableID, userInfo.getId()); 
//		final ColumnDisplayDefinitionDTO definitionDTO = databaseLogic.getColumnDisplayDefinitionByConnectName(connectionLabel, tableID, tableDef, userInfo.getId());
//		final DefinitionOfColumn definitionOfColumn = definitionDTO.getDefinitionOfColumns() .get(itemID);
//		return RelationOfJdbcAndHtml.metaDataTypeOf(definitionOfColumn.getJDBCMetaDataType()).isCorrespond();
//	}
	
}
