package jp.co.systemexe.dbu.dbace.web.common.controller;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.library.service.certification.MyUserDetails;
import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import jp.co.systemexe.dbu.dbace.library.util.BeanUtils;
import jp.co.systemexe.dbu.dbace.library.util.bindeditor.CustomNumberEditor;
import jp.co.systemexe.dbu.dbace.library.util.bindeditor.TimeStampEditor;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

/**
 * Abstract rest service controller
 *
 * @author long-hai
 * @param <C>
 */
@RestController
public abstract class AbstractController implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

//	@Autowired
//	private UserInfo userInfo;

	/**
	 * slf4j
	 */
	protected final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

	/**
	 * @see MessageService
	 */
	@Autowired
	protected MessageService messageService;
	/**
	 * @see RequestMappingHandlerMapping
	 */
	@Autowired
	protected RequestMappingHandlerMapping handlerMapping;

	/**
	 * Handle exception
	 *
	 * @param e
	 */
//	@ExceptionHandler(value = { Throwable.class })
//	protected final void handleException(HttpServletRequest request, HttpServletResponse response, Throwable ex) {
//		// check for response HTML page or JSON
//		boolean responsed = false;
//		if (response != null && RequestUtils.isAjaxRequest(request)) {
//			int status = HttpStatus.INTERNAL_SERVER_ERROR.value();
//			MessageService msgSrv = messageService;
//			msgSrv = (msgSrv == null ? SpringContextHelper.findBean(MessageService.class) : msgSrv);
//			String msg = msgSrv.getMessage("500");
//
//			response.setStatus(status);
//			response.setCharacterEncoding("utf-8");
//			PrintWriter out = null;
//			try {
//				out = response.getWriter();
//				out.println(msg);
//				responsed = true;
//			} catch (IOException e) {
//			} finally {
//				if (out != null)
//					out.flush();
//				ex.printStackTrace();
//			}
//		}
//
//		// response as default
//		if (!responsed && ex != null) {
//			ex.printStackTrace();
//			throw new RuntimeException(ex);
//		}
//	}

	/*****************************************************************************
	 * パラメータコンバータ
	 *****************************************************************************/

	/**
	 * リクエストパラメータコンバータ
	 *
	 * @param binder
	 */
	@InitBinder
	@SuppressWarnings("unchecked")
	protected void initBinder(WebDataBinder binder) {
		// 一般的な日付·時刻パターン
		binder.registerCustomEditor(Timestamp.class, new TimeStampEditor("yyyy/MM/dd HH:mm"));
		// 一般的な日付·時刻パターン
		binder.registerCustomEditor(Time.class, new TimeStampEditor("HH:mm"));
		// 一般的な日付·時刻パターン
		binder.registerCustomEditor(Date.class, new TimeStampEditor("yyyy/MM/dd"));
		// 一般数パターン
		binder.registerCustomEditor(BigDecimal.class, new CustomNumberEditor(BigDecimal.class,
				NumberFormat.getInstance(LocaleContextHolder.getLocale()), Boolean.TRUE));
		// カスタム定義された日付と時刻のパターン
		Map<String, Map<Class<?>, String>> dtPatterns = this.bindTimestampPattern();
		if (!CollectionUtils.isEmpty(dtPatterns)) {
			for (final Iterator<String> it = dtPatterns.keySet().iterator(); it.hasNext();) {
				String field = it.next();
				if (StringUtils.hasText(field)) {
					for (final Iterator<Class<?>> it2 = dtPatterns.get(field).keySet().iterator(); it2.hasNext();) {
						Class<?> registType = it2.next();
						String pattern = dtPatterns.get(field).get(registType);
						if (registType != null && StringUtils.hasText(pattern)
								&& BeanUtils.isInstanceOf(registType, java.util.Date.class)) {
							binder.registerCustomEditor(registType, field, new TimeStampEditor(pattern));
						}
					}
				}
			}
		}
		// カスタム定義された数のパターン
		Map<String, Map<Class<?>, String>> numPatterns = this.bindNumberPattern();
		if (!CollectionUtils.isEmpty(numPatterns)) {
			for (final Iterator<String> it = numPatterns.keySet().iterator(); it.hasNext();) {
				String field = it.next();
				if (StringUtils.hasText(field)) {
					for (final Iterator<Class<?>> it2 = numPatterns.get(field).keySet().iterator(); it2.hasNext();) {
						Class<?> registType = it2.next();
						String pattern = numPatterns.get(field).get(registType);
						if (registType != null && StringUtils.hasText(pattern)
								&& BeanUtils.isInstanceOf(registType, Number.class)) {
							binder.registerCustomEditor(registType, field, new CustomNumberEditor(
									(Class<? extends Number>) registType, pattern, Boolean.TRUE));
						}
					}
				}
			}
		}
	}

	/**
	 * カスタム定義された日付と時刻のパターン
	 *
	 * @return キー：プロパティ名 － 値：日付と時刻のパターン
	 */
	protected Map<String, Map<Class<?>, String>> bindTimestampPattern() {
		return null;
	}

	/**
	 * カスタム定義された日付と時刻のパターン
	 *
	 * @return キー：プロパティ名 － 値：日付と時刻のパターン
	 */
	protected Map<String, Map<Class<?>, String>> bindNumberPattern() {
		return null;
	}

	/**
	 * @return logger
	 */
	public Logger getLogger(){
		return this.logger;
	}

    /**
     * @return UserInfo
     */
    public UserInfo getUserInfo(){
    	MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    	UserInfo userInfo = myUserDetails.getUserInfo();
        return userInfo;
    }

    /**
     * @return
     */
	public UserAuthority getUserAuthority() {
		MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		UserAuthority userAuthority = myUserDetails.getUserInfoDTO().getUserAuthority();
		return userAuthority;
	}

    /**
     * Return JSON string
     *
     * <p>Convert Object to JSON</p>
     * @param obj
     * @return
     */
    protected String objectToJson(Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            return "";
        }
    }

    /**
     * Return Object
     *
     * <p>Convert JSON string to Object</p>
     * @param json
     * @param targetClass
     * @return
     * @throws IOException
     */
    protected <T extends Object> T jsonToObject(String json,
            Class<T> targetClass) throws IOException {

        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

        return mapper.readValue(json, targetClass);
    }
}
