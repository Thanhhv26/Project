package jp.co.systemexe.dbu.dbace.web.creation.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.ItemMulti;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Table;
import lombok.Data;

@Data
public class TableDto {
	private String id;
	private String label;
	private String listNO;
	private String commitNO;
	private List<ItemMultiDto> itemMultiDto;
	private List<OptionalMultiDto> optionalMultiDto;

	public TableDto(){

	}

	public TableDto(Table table){
		this.setId(table.getId());
		/*this.setLabel(table.getLabel());*/
		this.setListNO(table.getListNO());
		this.setCommitNO(table.getCommitNO());
		this.setItemMultiDto(table.getItem());
		this.setOptionalMultiDto(table.getOptional());
	}

	/*itemMulti*/
	public List<ItemMultiDto> getItemMultiDto(){
		if(itemMultiDto == null){
			itemMultiDto = new ArrayList<ItemMultiDto>();
		}
		return itemMultiDto;
	}

	public void setItemMultiDto(List<ItemMulti> Items){
		if(Items != null){
			for(ItemMulti item : Items){
				ItemMultiDto itemDto = new ItemMultiDto(item);
				this.getItemMultiDto().add(itemDto);
			}
		}
	}

	/*optionalMulti*/
	public List<OptionalMultiDto> getOptionalMultiDto(){
		if(optionalMultiDto == null){
			optionalMultiDto = new ArrayList<OptionalMultiDto>();
		}
		return optionalMultiDto;
	}

	public void setOptionalMultiDto(List<Table.OptionalMulti> optionals){
		if(optionals != null){
			for(Table.OptionalMulti item : optionals){
				OptionalMultiDto dto = new OptionalMultiDto(item);
				this.getOptionalMultiDto().add(dto);
			}
		}
	}
}