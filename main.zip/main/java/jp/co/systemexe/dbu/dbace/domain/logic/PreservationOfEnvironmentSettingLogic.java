/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.Map;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.authenticator.ExtAuthSecProtocol;
import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.config.SystemPropertyKeys;
import jp.co.systemexe.dbu.dbace.common.util.SecurePwdBlowfishUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseRepositoryXmlDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.xml.AppRepository;
import jp.co.systemexe.dbu.dbace.persistance.dao.xml.AuditSettingXml;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * system.properties に設定情報を保存します。
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class PreservationOfEnvironmentSettingLogic extends BaseApplicationDomainLogic {

	private static final String EMPTY_STRING = "";
	
	/**
	 * system.properties に設定情報を保存します。
	 *
	 * @param dto
	 */
	public void savePropeties(final EnvironmentSettingDTO dto) throws ApplicationDomainLogicException {
		final Map<SystemPropertyKeys, String> prop = SystemProperties.getAllPropertiesMap();

		prop.put(SystemPropertyKeys.APP_REPOSITORY, dto.getRepositoryFilePath());
		prop.put(SystemPropertyKeys.DISPLAYED_NUMBER_OF_RECORDS, dto.getRecordDisplayCount());
		prop.put(SystemPropertyKeys.PREVIEW_COLUMN_COUNT, dto.getColumnDisplayCount());
		prop.put(SystemPropertyKeys.SEARCH_CONDITION_FILEPATH, dto.getRetrievalConditionPreservationPath());
		prop.put(SystemPropertyKeys.PULLDOWN_MAX_COUNT, dto.getPulldownDisplayMaximumCount());
		prop.put(SystemPropertyKeys.PREFETCH_SIZE, dto.getPulldownDisplayFetchSize());
		prop.put(SystemPropertyKeys.DOWNLOAD_FETCH_SIZE, dto.getFileDownloadFetchSize());
		prop.put(SystemPropertyKeys.IMPORT_TEMP_FILE_PATH, dto.getImportTempFilePath());
		prop.put(SystemPropertyKeys.AUDIT_SETTING, dto.getAuditLogFilePath());
		prop.put(SystemPropertyKeys.DOWNLOAD_MAXIMUM_BYTE_FOR_EXCEL, dto.getDownloadMaximumByteForExcel());
		prop.put(SystemPropertyKeys.DOWNLOAD_MAXIMUM_BYTE_FOR_CSV, dto.getDownloadMaximumByteForCsv());
		prop.put(SystemPropertyKeys.IMPORT_MAXIMUM_BYTE_FOR_EXCEL, dto.getImportMaximumByteForExcel());
		prop.put(SystemPropertyKeys.IMPORT_MAXIMUM_BYTE_FOR_CSV, dto.getImportMaximumByteForCsv());
		prop.put(SystemPropertyKeys.IMPORT_MAXIMUM_BYTE_FOR_TSV, dto.getImportMaximumByteForTsv());
		prop.put(SystemPropertyKeys.SEARCH_MAX_RECORD_COUNT, dto.getSearchMaxRecordCount());
		prop.put(SystemPropertyKeys.SEARCH_COMPARISON_OPERATOR_ORDER, dto.getSearchComparisonOperatorOrder());

		// ADD ライセンス認証と外部認証連携の機能追加 ↓
		if (StringUtils.isNotEmpty(dto.getLicenseKey())) {
			prop.put(SystemPropertyKeys.LICENSE_KEY, dto.getLicenseKey());
		} else {
			prop.put(SystemPropertyKeys.LICENSE_KEY, EMPTY_STRING);
		}
		if (StringUtils.isNotEmpty(dto.getLicenseCnt())) {
			prop.put(SystemPropertyKeys.LICENSE_CNT, dto.getLicenseCnt());
		} else {
			prop.put(SystemPropertyKeys.LICENSE_CNT, "0");
		}
		prop.put(SystemPropertyKeys.EXT_AUTH, dto.getExtAuth());
		if (dto.getAuthServerType() == null) {
			prop.put(SystemPropertyKeys.AUTH_SERVER_TYPE, EMPTY_STRING);
		} else {
			prop.put(SystemPropertyKeys.AUTH_SERVER_TYPE, dto.getAuthServerType().getKey());
		}
		if (StringUtils.isNotEmpty(dto.getAuthServerId())) {
			prop.put(SystemPropertyKeys.AUTH_SERVER_ID, dto.getAuthServerId());
		} else {
			prop.put(SystemPropertyKeys.AUTH_SERVER_ID, EMPTY_STRING);
		}
		if (StringUtils.isNotEmpty(dto.getAuthServerPort())) {
			prop.put(SystemPropertyKeys.AUTH_SERVER_PORT, dto.getAuthServerPort());
		} else {
			prop.put(SystemPropertyKeys.AUTH_SERVER_PORT, EMPTY_STRING);
		}
		if (StringUtils.isNotEmpty(dto.getAuthServerBaseDomain())) {
			prop.put(SystemPropertyKeys.AUTH_SERVER_BASE_DOMAIN, dto.getAuthServerBaseDomain());
		} else {
			prop.put(SystemPropertyKeys.AUTH_SERVER_BASE_DOMAIN, EMPTY_STRING);
		}
		if (StringUtils.isNotEmpty(dto.getAuthServerProtocol())) {
			prop.put(SystemPropertyKeys.AUTH_SERVER_PROTOCOL, dto.getAuthServerProtocol());
		} else {
			prop.put(SystemPropertyKeys.AUTH_SERVER_PROTOCOL, EMPTY_STRING);
		}
		if (StringUtils.isNotEmpty(dto.getAuthServerSecurity())) {
			prop.put(SystemPropertyKeys.AUTH_SERVER_SECURITY, dto.getAuthServerSecurity());
		} else {
			prop.put(SystemPropertyKeys.AUTH_SERVER_SECURITY, ExtAuthSecProtocol.SIMPLE.getValue());
		}
		if (StringUtils.isNotEmpty(dto.getAuthServerTimeout())) {
			prop.put(SystemPropertyKeys.AUTH_SERVER_TIMEOUT, dto.getAuthServerTimeout());
		} else {
			prop.put(SystemPropertyKeys.AUTH_SERVER_TIMEOUT, EMPTY_STRING);
		}
		if (dto.getAuthServerUserIdentify() == null) {
			prop.put(SystemPropertyKeys.AUTH_SERVER_USER_IDENTIFY, EMPTY_STRING);
		} else {
			prop.put(SystemPropertyKeys.AUTH_SERVER_USER_IDENTIFY, dto.getAuthServerUserIdentify().getKey());
		}
		if (StringUtils.isNotEmpty(dto.getAuthConnectUsername())) {
			prop.put(SystemPropertyKeys.AUTH_CONNECT_USERNAME, dto.getAuthConnectUsername());
		} else {
			prop.put(SystemPropertyKeys.AUTH_CONNECT_USERNAME, EMPTY_STRING);
		}
		if (StringUtils.isNotEmpty(dto.getAuthConnectPwd())) {
			if (dto.isNotEncryptAuthConnectPwd()) {
				prop.put(SystemPropertyKeys.AUTH_CONNECT_PWD, dto.getAuthConnectPwd());
			} else {
				// パスワードをblowfishで暗号化した値を保存
				SecurePwdBlowfishUtils pwdEncryptBlowfish = new SecurePwdBlowfishUtils();
				BaseRepositoryXmlDAO baseRepositoryXmlDAO = new BaseRepositoryXmlDAO() {};
				prop.put(SystemPropertyKeys.AUTH_CONNECT_PWD, pwdEncryptBlowfish.encrypt(dto.getAuthConnectPwd(),baseRepositoryXmlDAO.openSesame()));
				pwdEncryptBlowfish = null;
			}
		} else {
			prop.put(SystemPropertyKeys.AUTH_CONNECT_PWD, EMPTY_STRING);
		}
		// ADD ライセンス認証と外部認証連携の機能追加 ↑
		try {
			SystemProperties.save(prop);
		} catch (final DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}

		AuditSettingXml.getInstance().changeAuditSettingXmlFile();
		AppRepository.getInstance().changeAppRepositoryFile();
	}

}
