/*
 * @(#)PageConst.java 1.0 Aug 7, 2015 Copyright 2015 by SystemEXE Inc. All
 * rights reserved.
 */
package jp.co.systemexe.dbu.dbace.web.common;

/**
 * @author THANH TRUC(thanh-truc@system-exe.com.vn)
 * @version 6.0 Dec 12, 2016
 */
public class PageConst {
	/*
	 * ログイン
	 */
	public static final String SCREEN_LOGIN = "FRM0000";
	/**
	 * メニュー
	 */
	public static final String SCREEN_DASHBOARD = "main/FRM0100";
	/**
	 * 個人プロファイル
	 */
	public static final String SCREEN_PROFILE= "profile/FRM0600";
	/**
	 * システム管理
	 */
	public static final String SCREEN_CONNECT= "connect/FRM0500";
	public static final String SCREEN_AUDIT = "audit/FRM0530";
	public static final String SCREEN_ENVIRONMENT = "environment/FRM0520";
	/**
	 * ユーザー外部認証設定
	 */
	public static final String SCREEN_EXTERNAL_AUTHENTICATION = "externalAuthentication/FRM0510";
	/**
	 * ユーザー管理
	 */
	public static final String SCREEN_USER= "user/FRM0400";
	/**
	 * オブジェクト管理
	 */
	public static final String SCREEN_OBJECT_SETTING = "object/FRM0300";
	public static final String SCREEN_OBJECT_RELATION = "relation/FRM0320";
	public static final String SCREEN_OBJECT_CREATION = "creation/FRM0330";
	/**
	 * 項目
	 */
	public static final String SCREEN_ITEM = "item/FRM0310";
	/**
	 * データ操作
	 */
	public static final String SCREEN_RECORD_LIST = "record/FRM0200";
	public static final String SCREEN_RECORD_LIST_ALL_TABLE = "record/FRM0201";
	public static final String SCREEN_RECORD_ADD_NEW = "record/FRM0210";
	public static final String SCREEN_RECORD_EDIT = "record/FRM0220";
	public static final String SCREEN_RECORD_COPY = "record/FRM0230";
	public static final String SCREEN_RECORD_VIEW = "record/FRM0240";
	public static final String SCREEN_RECORD_DELETE = "record/FRM0250";
	public static final String SCREEN_RECORD_DOWNLOAD = "record/FRM0260";
	public static final String SCREEN_RECORD_UPLOAD = "record/FRM0270";

}