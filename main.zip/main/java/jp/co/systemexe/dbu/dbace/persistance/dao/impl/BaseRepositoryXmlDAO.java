/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.BaseDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.xml.AppRepository;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.ObjectFactory;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.ConnectDefinision;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.LoginUsers;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.RelationInfo;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForms;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;

/**
 * XML リポジトリ専用の DAO 実装用基底抽象クラスです。
 * <p>
 * 本アプリケーションでは、XML ファイルへのアクセスに JAXB を使用しています。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public abstract class BaseRepositoryXmlDAO extends BaseDAO {

    /**
     * XML のエンティティクラスを配置したパッケージ。
     */
    private static final String ENTITY_PACKAGE = "jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository";

    /**
     * XML に出力するロケーション。
     */
    protected static final String SCHEMA_LOCATION = "http://www.system-exe.co.jp/dbu/dbace/Schema repository.xsd";

    private static final SortedMap<Integer, Byte> openSesame = new TreeMap<Integer, Byte>();
    static {
        openSesame.put(8, (byte)65);
        openSesame.put(11, (byte)50);
        openSesame.put(2, (byte)100);
        openSesame.put(13, (byte)83);
        openSesame.put(5, (byte)56);
        openSesame.put(7, (byte)56);
        openSesame.put(9, (byte)109);
        openSesame.put(3, (byte)114);
        openSesame.put(15, (byte)56);
        openSesame.put(1, (byte)85);
        openSesame.put(10, (byte)118);
        openSesame.put(0, (byte)102);
        openSesame.put(12, (byte)109);
        openSesame.put(14, (byte)122);
        openSesame.put(6, (byte)76);
        openSesame.put(4, (byte)121);
    }

    /**
     * appRepository を保持します。
     */
    private AppRepository appRepository;

    /**
     * XML ファイルのルート要素「repository」を保持します。
     */
    private Repository repository;

    /**
     * 専用のオブジェクトファクトリの保持。
     */
    private ObjectFactory objectFactory = new ObjectFactory();

    /**
     * appRepository を設定します。
     *
     * @param AppRepository appRepository
     */
    public final void setAppRepository(final AppRepository appRepository) {
        this.appRepository = appRepository;
    }

    /**
     * repository を戻します。
     * <p>
     * プログラマが意識するリポジトリの実体です。</p>
     *
     * @return Repository
     */
    protected Repository getRepository() {
        return repository;
    }

    /**
     * 接続定義 ID から接続定義情報要素を検索して戻します。
     * <p>
     * 接続定義 ID 文字列から接続定義情報 XML 要素を検索し、オブジェクトの参照を
     * 戻します。発見出来なかった場合は null を戻します。</p>
     *
     * @param id
     * @return ConnectDefinision
     */
    protected ConnectDefinision searchConnectDefinision(final String id) {
        final List<ConnectDefinision> list = this.repository
            .getConnectDefinision();
        for (final Iterator<ConnectDefinision> ite = list.iterator(); ite
            .hasNext();) {
            final ConnectDefinision def = ite.next();
            if (def.getId().equals(id)) {
                return def;
            }
        }
        return null;
    }

    /**
     * 接続定義 Label から接続定義情報要素を検索して戻します。
     * <p>
     * 接続定義 ID 文字列から接続定義情報 XML 要素を検索し、オブジェクトの参照を
     * 戻します。発見出来なかった場合は null を戻します。</p>
     *
     * @param Label
     * @return ConnectDefinision
     */
    protected ConnectDefinision searchConnectDefinisionName(final String id) {
        final List<ConnectDefinision> list = this.repository
            .getConnectDefinision();
        for (final Iterator<ConnectDefinision> ite = list.iterator(); ite
            .hasNext();) {
            final ConnectDefinision def = ite.next();
            if (def.getLabel().equals(id)) {
                return def;
            }
        }
        return null;
    }

    /**
     * @return ConnectDefinisionの一覧
     */
    public List<ConnectDefinision> getConnectDefinisionList() {
        final List<ConnectDefinision> list = this.repository.getConnectDefinision();
        return list;
    }

    //ADD ライセンス認証 機能追加　↓
    /**
     * リポジトリXMLに登録されているテーブルリスト[重複は除く] を戻します。
     *
     * @return Map
     */
    protected Map<String, ConnectDefinision> distinctByConnectDefinision() {
    	Map<String, ConnectDefinision> map = new HashMap<String, ConnectDefinision>();
    	// get all list current connection of xml
    	final List<ConnectDefinision> list = this.repository.getConnectDefinision();
        for (ConnectDefinision codef : list) {
        	// connect using url to setting
        	if(codef.getDbConnect().getDatabaseUrl().isUse()) {
        		// set url is key
        		String key = codef.getDbConnect().getDatabaseUrl().getUrl();
        		// case is new connection
        		if(!map.containsKey(key)) {
        			map.put(key, codef);
        		} else {
        			// get all list table form of codef
        			TableForms tblForms = codef.getTableForms();
        			// get list table form of map
        			TableForms mapTblForms = map.get(key).getTableForms();
        			if(mapTblForms == null) {
        				map.get(key).setTableForms(tblForms);
        				continue;
        			}
        			List<TableForm> tableFormListOfMap = mapTblForms.getTableForm();
        			List<TableForm> listTemp = new ArrayList<TableForm>();
        			listTemp.addAll(tableFormListOfMap);

        			if(tblForms != null && tblForms.getTableForm().size() > 0) {
        				for(TableForm tbl : tblForms.getTableForm()) {// form of xml
        						if(!checkTableExisted(tbl, listTemp)) {
            						tableFormListOfMap.add(tbl);
            					}
        				}
        			}
        		}
        	} else {
        		// set "server_id+port+database_id+instanceName" is key
				String key = codef.getDbConnect().getServer().getId()
						.concat(codef.getDbConnect().getPort().getValue())
						.concat(codef.getDbConnect().getDatabase().getId())
						.concat(codef.getDbConnect().getInstanceName() == null ? "" : codef.getDbConnect().getInstanceName());
				// case is new connection
        		if(!map.containsKey(key)) {
        			map.put(key, codef);
        		} else {
        			// get all list table form of codef
        			TableForms tblForms = codef.getTableForms();
        			// get list table form of map
        			TableForms mapTblForms = map.get(key).getTableForms();
        			if(mapTblForms == null) {
        				map.get(key).setTableForms(tblForms);
        				continue;
        			}
        			List<TableForm> tableFormListOfMap = mapTblForms.getTableForm();
        			List<TableForm> listTemp = new ArrayList<TableForm>();
        			listTemp.addAll(tableFormListOfMap);

        			if(tblForms != null && tblForms.getTableForm().size() > 0) {
        				for(TableForm tbl : tblForms.getTableForm()) {// form of xml
        					if(!checkTableExisted(tbl, listTemp)) {
        						tableFormListOfMap.add(tbl);
        					}
        				}
        			}
        		}
        	}
        }
    	return map;
    }

    /**
     *
     * @param tbl
     * @param list
     * @return
     */
    private boolean checkTableExisted(TableForm tbl, List<TableForm> list) {
    	boolean existed = false;
    	for(TableForm mapTbl : list) {// form of map
			if(tbl.getId().equals(mapTbl.getId())) {
				existed = true;
				break;
			}
		}
    	return existed;
    }

    /**
    *
    * @param tbl
    * @param list
    * @return
    */
   private boolean checkTableExisted(SelectOneMenuItem item, List<TableForm> list) {
   	boolean existed = false;
   	for(TableForm tbl : list) {
   		if(item.getValue().equals(tbl.getId())) {
				existed = true;
				break;
			}
		}
   	return existed;
   }

    /**
     * リポジトリXMLに登録されているテーブル数[重複は除く] を戻します。
     *
     * @return Integer
     */
    public int countNumberOfTableHasRegisted() {
    	int cnt = 0;
    	for (ConnectDefinision item : distinctByConnectDefinision().values()) {
    		if(item.getTableForms() != null) {
    			for (int i = 0; i < item.getTableForms().getTableForm().size(); i++) {
    				TableForm tableForm = item.getTableForms().getTableForm().get(i);
    				if(StringUtils.isEmpty(tableForm.getType())){
    					cnt = cnt + 1;
    				}
				}

    		}
    	}
    	return cnt;
    }

    /**
     * 画面に今回登録するテーブル数 を戻します。
     *
     * @return Integer
     */
    public int countNumberOfTableIsAddNew(String selectedConnectDefinisionId, SelectOneMenuItem[] confirmTableItems) {
    	int cnt = 0;
    	ConnectDefinision currentConn = searchConnectDefinision(selectedConnectDefinisionId);
    	for (SelectOneMenuItem item : confirmTableItems) {
    		for(ConnectDefinision conn : distinctByConnectDefinision().values()) {
    			if(conn.getTableForms() == null || currentConn.getId().equals(conn.getId())) {
    				continue;
    			} else if(!checkTableExisted(item, conn.getTableForms().getTableForm())) {
    				cnt++;
    				break;
    			}
    		}
    	}
    	return cnt;
    }
    //ADD ライセンス認証 機能追加　↑

    /**
     * リポジトリXMLより、ユーザー情報一覧を取得します。
     * <p>
     *
     * @return LoginUsers ログインユーザー情報
     */
    protected LoginUsers getLoginUsers() {
    	return this.repository.getLoginUsers();
    }

    /**
     * @return
     */
    protected RelationInfo getRelationInfo() {
    	return this.repository.getRelationInfo();
    }

    /**
     * オブジェクトファクトリを戻します。
     * <p>
     * アプリケーションリポジトリ内のオブジェクト定義を保持する専用のオブジェクト
     * ファクトリ参照を戻します。</p>
     *
     * @return {@link ObjectFactory}
     */
    protected ObjectFactory getObjectFactory() {
        return objectFactory;
    }

    /**
     * リポジトリを更新する。
     *
     * @throws DAOException
     */
    protected void update() throws DAOException {
        final Marshaller m = createMarshaller();
        try {
            m.marshal(repository, appRepository.getOutputStream());
        } catch (final JAXBException e) {
        	// MI-F-0019=リポジトリXMLファイルの解析中にエラーが発生しました。
            final String message = MessageUtils.getMessage("MI-F-0019");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        } catch (final FileNotFoundException e) {
        	// MI-F-0014=リポジトリXMLファイルが存在しません。
            final String message = MessageUtils.getMessage("MI-F-0014");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * 初期化処理。
     * <p>
     * アプリケーションリポジトリデータの読み込みを行い、DAO の初期化処理を実行
     * します。</p>
     *
     * @throws DAOException
     */
    public void init() throws DAOException {
        final Unmarshaller um = createUnmarshaller();
        try {
            final InputStream stream = this.appRepository.getInputStream();
            this.repository = (Repository)um.unmarshal(stream);
        } catch (final JAXBException e) {
        	// MI-F-0019=リポジトリXMLファイルの解析中にエラーが発生しました。
            final String message = MessageUtils.getMessage("MI-F-0019");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        } catch (final FileNotFoundException e) {
        	// MI-F-0014=リポジトリXMLファイルが存在しません。
            final String message = MessageUtils.getMessage("MI-F-0014");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
    }

    public String openSesame() {
        byte[] array = new byte[openSesame.size()];
        for (int i = 0; i < openSesame.size(); i++) {
            array[i] = openSesame.get(i);
        }
        try {
            return new String(array, "US-ASCII");
        } catch (final UnsupportedEncodingException e) {
            getLogger().warn(e);
            return "";
        }
    }

    /**
     * BaseRepositoryXmlDAO の生成。
     * <p>コンストラクタ。</p>
     */
    public BaseRepositoryXmlDAO() {
        return;
    }

    /**
     * Unmarshaller を生成して戻す。
     * <p>
     * Unmarshaller は XML ファイルの読み込みに使用するオブジェクトです。</p>
     * <p>
     * アプリケーションリポジトリ XML ファイルのスキーマ定義を保持した
     * Unmarshaller を生成して戻します。</p>
     *
     * @return
     * @throws DAOException
     */
    private final Unmarshaller createUnmarshaller() throws DAOException {
        final JAXBContext context;
        try {
            context = JAXBContext.newInstance(ENTITY_PACKAGE);
        } catch (final JAXBException e) {
        	// MI-F-0001={0} クラスが存在しません。
        	final String args[] = {ENTITY_PACKAGE};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
        final Unmarshaller ret;
        try {
            ret = context.createUnmarshaller();
        } catch (final JAXBException e) {
        	// MI-F-0019=リポジトリXMLファイルの解析中にエラーが発生しました。
            final String message = MessageUtils.getMessage("MI-F-0019");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }

    /**
     * Marshaller を生成して戻す。
     * <p>
     * Marshaller は、XML への書き込みに使用するオブジェクトです。</p>
     * <p>
     * アプリケーションリポジトリ XML ファイルのスキーマ定義を保持した
     * Marshaller を生成して戻します。</p>
     *
     * @return
     * @throws DAOException
     */
    private final Marshaller createMarshaller() throws DAOException {
        final JAXBContext context;
        try {
            context = JAXBContext.newInstance(ENTITY_PACKAGE);
        } catch (final JAXBException e) {
        	// MI-F-0001={0} クラスが存在しません。
        	final String args[] = {ENTITY_PACKAGE};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
        final Marshaller ret;
        try {
            ret = context.createMarshaller();
            ret.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            ret.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            ret.setProperty(Marshaller.JAXB_SCHEMA_LOCATION, SCHEMA_LOCATION);
        } catch (final JAXBException e) {
        	// MI-F-0019=リポジトリXMLファイルの解析中にエラーが発生しました。
            final String message = MessageUtils.getMessage("MI-F-0019");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }
}
