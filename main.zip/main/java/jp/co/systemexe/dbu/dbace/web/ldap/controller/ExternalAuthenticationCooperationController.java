package jp.co.systemexe.dbu.dbace.web.ldap.controller;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.authenticator.AuthByLDAP;
import jp.co.systemexe.dbu.dbace.common.authenticator.ExtAuthValue;
import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.util.SecurePwdBlowfishUtils;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfEnvironmentSetting;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfEnvironmentSettingLogic;
import jp.co.systemexe.dbu.dbace.library.service.certification.MyUserDetails;
import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseRepositoryXmlDAO;
import jp.co.systemexe.dbu.dbace.presentation.AdLdapServerType;
import jp.co.systemexe.dbu.dbace.presentation.LdapUserServerIdentify;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
import jp.co.systemexe.dbu.dbace.web.environment.dto.EnvironmentDto;
import jp.co.systemexe.dbu.dbace.web.environment.model.FRM0520ResultModel;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;

@RestController
@RequestMapping(value = "/system/externalauthentication")
public class ExternalAuthenticationCooperationController extends AbstractController {

	/***/
	private static final long serialVersionUID = 1L;

	/**
	 * @see MessageService
	 */
	@Autowired
	protected MessageService messageService;

	/**
	 * Index page
	 *
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index() throws Exception {
		return new ModelAndView(PageConst.SCREEN_EXTERNAL_AUTHENTICATION);
	}

	/**
	 * Load ExternalAuthenticationCooperation
	 *
	 * @param model
	 * @return
	 * @throws ReflectiveOperationException
	 */
	@RequestMapping(value = "/load", method = RequestMethod.POST, produces = "application/json")
	public FRM0520ResultModel loadExternalAuthenticationCooperation(@RequestBody EnvironmentDto environmentDto) {
		FRM0520ResultModel resultModel = new FRM0520ResultModel();
		// システムプロパティに入力した外部認証接続情報を保存実行
		final AcquisitionOfEnvironmentSetting setting = new AcquisitionOfEnvironmentSetting();
		final EnvironmentSettingDTO dtoEnvBk = setting.getAllProperties();
		environmentDto.setExtAuth(dtoEnvBk.getExtAuth());
		environmentDto.setAuthServerId(dtoEnvBk.getAuthServerId());
		environmentDto.setAuthServerPort(dtoEnvBk.getAuthServerPort());
		environmentDto.setAuthServerBaseDomain(dtoEnvBk.getAuthServerBaseDomain());
		environmentDto.setAuthServerTimeout(dtoEnvBk.getAuthServerTimeout());
		environmentDto.setAdLdapServerType(dtoEnvBk.getAuthServerType() != null ? dtoEnvBk.getAuthServerType().getKey() : null);
		environmentDto.setLdapUserServerIdentify(dtoEnvBk.getAuthServerUserIdentify() != null ? dtoEnvBk.getAuthServerUserIdentify().getKey() : null);
		if (AdLdapServerType.AD.equals(AdLdapServerType.keyOf(dtoEnvBk.getAuthServerUserIdentify() != null ? dtoEnvBk.getAuthServerUserIdentify().getKey() : null))) {
			environmentDto.setLdapUserServerIdentify(null);
		}
		// ADD 外部認証画面の監査ログを出力の機能追加 ↑
		environmentDto.setAuthConnectUsername(dtoEnvBk.getAuthConnectUsername());
		environmentDto.setAuthConnectPwd(dtoEnvBk.getAuthConnectPwd());

		resultModel.getResultData().add(environmentDto);

		return resultModel;
	}

	/**
	 * Edit ExternalAuthenticationCooperation
	 *
	 * @param model
	 * @return
	 * @throws ReflectiveOperationException
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST, produces = "application/json")
	public FRM0520ResultModel updateExternalAuthenticationCooperation(@RequestBody EnvironmentDto environmentDto) {
		FRM0520ResultModel resultModel = new FRM0520ResultModel();
		BaseRepositoryXmlDAO baseRepositoryXmlDAO = new BaseRepositoryXmlDAO() {};
		if (ExtAuthValue.OFF.getValue().equals(environmentDto.getExtAuth())
				|| validateRequired(resultModel, environmentDto)) {

			// システムプロパティに入力した外部認証接続情報を保存実行
			final AcquisitionOfEnvironmentSetting setting = new AcquisitionOfEnvironmentSetting();
			final EnvironmentSettingDTO dtoEnvBk = setting.getAllProperties();

			// 外部認証: ON check AD/LDAP
			if (ExtAuthValue.ON.getValue().equals(environmentDto.getExtAuth())) {
				// 入力チェック成功：AD/LDAPサーバーとの接続テストを実行する
				AuthByLDAP authByLDAP = new AuthByLDAP();
				authByLDAP.setAuthServerType(environmentDto.getAdLdapServerType());
				authByLDAP.setAuthServerId(environmentDto.getAuthServerId());
				authByLDAP.setAuthServerPort(environmentDto.getAuthServerPort());
				authByLDAP.setAuthDomain(environmentDto.getAuthServerBaseDomain());
				authByLDAP.setAuthServerProtocol(SystemProperties.getAuthServerProtocol());
				authByLDAP.setAuthServerSecurity(SystemProperties.getAuthServerSecurity());
				authByLDAP.setAuthServerTimeout(environmentDto.getAuthServerTimeout());
				authByLDAP.setAuthServerUserIdentify(environmentDto.getLdapUserServerIdentify());
				authByLDAP.setUsername(environmentDto.getAuthConnectUsername());

				if (StringUtils.isNotEmpty(environmentDto.getAuthConnectPwd())) {
					if(!dtoEnvBk.getAuthConnectPwd().equals(environmentDto.getAuthConnectPwd())){
						authByLDAP.setPassword(environmentDto.getAuthConnectPwd());
					}else{
						SecurePwdBlowfishUtils pwdEncryptBlowfish = new SecurePwdBlowfishUtils();
						authByLDAP.setPassword(pwdEncryptBlowfish.decrypt(environmentDto.getAuthConnectPwd(), baseRepositoryXmlDAO.openSesame()));
					}
				}

				try {
					boolean isConnLdap = authByLDAP.connect();
					if (!isConnLdap) {
						final String args[] = {
								AdLdapServerType.keyOf(environmentDto.getAdLdapServerType()).getServerName() };

						MessageInfo message = new MessageInfo("MI-E-0049", MessageType.ERROR, args, messageService);

						resultModel.getMessageInfo()
								.add(message);
						getLogger().fatal(message.getErrorString(), new ApplicationDomainLogicException(message.getErrorString()));
						return resultModel;
					}
				} catch (ApplicationException e) {
					e.printStackTrace();
					final String args[] = {
							AdLdapServerType.keyOf(environmentDto.getAdLdapServerType()).getServerName() };
					MessageInfo message = new MessageInfo("MI-E-0049", MessageType.ERROR, args, messageService);

					resultModel.getMessageInfo()
							.add(message);
					getLogger().fatal(message.getErrorString(), new ApplicationDomainLogicException(message.getErrorString()));
					return resultModel;
				}
			}


			dtoEnvBk.setExtAuth(environmentDto.getExtAuth());
			dtoEnvBk.setAuthServerId(environmentDto.getAuthServerId());
			dtoEnvBk.setAuthServerPort(environmentDto.getAuthServerPort());
			dtoEnvBk.setAuthServerBaseDomain(environmentDto.getAuthServerBaseDomain());
			dtoEnvBk.setAuthServerTimeout(environmentDto.getAuthServerTimeout());
			dtoEnvBk.setAuthServerType(AdLdapServerType.keyOf(environmentDto.getAdLdapServerType()));
			dtoEnvBk.setAuthServerUserIdentify(
					LdapUserServerIdentify.keyOf(environmentDto.getLdapUserServerIdentify()));
//			if (ExtAuthValue.OFF.getValue().equals(environmentDto.getExtAuth())) {
//				 setAdLdapServerType(adLdapServerTypeHidden);
//				 setLdapUserServerIdentify(ldapUserServerIdentifyHidden);
//			}
//			// ADD 外部認証画面の監査ログを出力の機能追加 ↓
//			else {
//				if (AdLdapServerType.AD.equals(AdLdapServerType.keyOf(environmentDto.getAdLdapServerType()))) {
//					dtoEnvBk.setAuthServerUserIdentify(null);
//				}
//			}
			if (AdLdapServerType.AD.equals(AdLdapServerType.keyOf(environmentDto.getAdLdapServerType()))) {
				dtoEnvBk.setAuthServerUserIdentify(null);
			}
			// ADD 外部認証画面の監査ログを出力の機能追加 ↑
			dtoEnvBk.setAuthConnectUsername(environmentDto.getAuthConnectUsername());
			if (StringUtils.isNotEmpty(environmentDto.getAuthConnectPwd())) {
				if(!dtoEnvBk.getAuthConnectPwd().equals(environmentDto.getAuthConnectPwd())){
					dtoEnvBk.setAuthConnectPwd(environmentDto.getAuthConnectPwd());
				}else{
					SecurePwdBlowfishUtils pwdEncryptBlowfish = new SecurePwdBlowfishUtils();
					dtoEnvBk.setAuthConnectPwd(pwdEncryptBlowfish.decrypt(environmentDto.getAuthConnectPwd(), baseRepositoryXmlDAO.openSesame()));
				}
			}else{
				dtoEnvBk.setAuthConnectPwd(null);
			}

			final PreservationOfEnvironmentSettingLogic logic = new PreservationOfEnvironmentSettingLogic();
			AuditEventKind auditKind = AuditEventKind.UNDEFINE;
			// ADD 外部認証画面の監査ログを出力の機能追加
			UserInfo userInfo = getUserInfo();
			try {
				// ADD 外部認証画面の監査ログを出力の機能追加 ↓
				if (ExtAuthValue.OFF.getValue().equals(dtoEnvBk.getExtAuth())) {
					auditKind = AuditEventKind.EXT_AUTH_OFF;
				} else if (ExtAuthValue.ON.getValue().equals(dtoEnvBk.getExtAuth())) {
					auditKind = AuditEventKind.EXT_AUTH_ON;
				} else {
					auditKind = AuditEventKind.UNDEFINE;
				}
				logic.savePropeties(dtoEnvBk);
				resultModel.getMessageInfo().add(new MessageInfo("MI-I-0019",
						MessageType.SUCCESS, messageService));
				//refresh principal for menu
				MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
				myUserDetails.setExtAuth(dtoEnvBk.getExtAuth());

				OutputAuditLog.writeExtAuthLog(auditKind, userInfo, dtoEnvBk.getAuthServerId(),
						dtoEnvBk.getAuthServerType() == null ? StringUtils.EMPTY
								: dtoEnvBk.getAuthServerType().getKey(),
						dtoEnvBk.getAuthServerBaseDomain(), dtoEnvBk.getAuthServerUserIdentify() == null
								? StringUtils.EMPTY : dtoEnvBk.getAuthServerUserIdentify().getKey(),
						AuditStatus.success);
			} catch (ApplicationDomainLogicException e) {
				// addPageMessage(e);
				resultModel.getMessageInfo().add(new MessageInfo("externalAuthenticationCooperation.update.failed",
						MessageType.ERROR, messageService));
				getLogger().fatal(e.getMessage(), e);
				OutputAuditLog.writeExtAuthLog(auditKind, userInfo, dtoEnvBk.getAuthServerId(),
						dtoEnvBk.getAuthServerType() == null ? StringUtils.EMPTY
								: dtoEnvBk.getAuthServerType().getKey(),
						dtoEnvBk.getAuthServerBaseDomain(), dtoEnvBk.getAuthServerUserIdentify() == null
								? StringUtils.EMPTY : dtoEnvBk.getAuthServerUserIdentify().getKey(),
						AuditStatus.failure);
				// ADD 外部認証画面の監査ログを出力の機能追加 ↑
				return resultModel;
			}
		}
		return resultModel;
	}

	/**
     * 保存確認、接続テストボタン押下時の
     * 必須チェック処理を行います。
     * @return
     */
	public boolean validateRequired(FRM0520ResultModel resultModel, EnvironmentDto environmentDto) {
		boolean isError = true;
		if (StringUtils.isBlank(environmentDto.getAdLdapServerType())) {
			resultModel.getMessageInfo().add(new MessageInfo("adLdapServerType", "MI-E-0500-0002", MessageType.ERROR,
					messageService, new String[] {
							messageService.getMessage("frm0510.externalAuthenticationCooperation.serverType") }));
			isError = false;
		}

		if (StringUtils.isBlank(environmentDto.getAuthServerId())) {
			resultModel.getMessageInfo().add(new MessageInfo("authServerId", "MI-E-0500-0002", MessageType.ERROR,
					messageService, new String[] { messageService.getMessage("frm0510.externalAuthenticationCooperation.authServerId") }));
			isError = false;
		}

		if (StringUtils.isBlank(environmentDto.getAuthServerPort())) {
			resultModel.getMessageInfo().add(new MessageInfo("authServerPort", "MI-E-0500-0001", MessageType.ERROR,
					messageService, new String[] { messageService.getMessage("frm0510.externalAuthenticationCooperation.authServerPort") }));
			isError = false;
		}

		if (StringUtils.isBlank(environmentDto.getAuthServerTimeout())) {
			resultModel.getMessageInfo().add(new MessageInfo("authServerTimeout", "MI-E-0500-0001", MessageType.ERROR,
					messageService, new String[] { messageService.getMessage("frm0510.externalAuthenticationCooperation.authServerTimeout") }));
			isError = false;
		}

		if (StringUtils.isBlank(environmentDto.getAuthServerBaseDomain())) {
			if (AdLdapServerType.AD.equals(AdLdapServerType.keyOf(environmentDto.getAdLdapServerType()))) {
				resultModel.getMessageInfo()
				.add(new MessageInfo("authServerBaseDomain", "MI-E-0500-0001", MessageType.ERROR, messageService,
						new String[] { messageService.getMessage("frm0510.externalAuthenticationCooperation.authServerBaseDomain.AD") }));
				isError = false;
			}else if (AdLdapServerType.LDAP.equals(AdLdapServerType.keyOf(environmentDto.getAdLdapServerType()))) {
				resultModel.getMessageInfo()
				.add(new MessageInfo("authServerBaseDomain", "MI-E-0500-0001", MessageType.ERROR, messageService,
						new String[] { messageService.getMessage("frm0510.externalAuthenticationCooperation.authServerBaseDomain.LDAP") }));
				isError = false;
			}else{
				resultModel.getMessageInfo()
				.add(new MessageInfo("authServerBaseDomain", "MI-E-0500-0001", MessageType.ERROR, messageService,
						new String[] { messageService.getMessage("frm0510.externalAuthenticationCooperation.authServerBaseDomain.LDAP") }));
				isError = false;
			}
		}

		if ((StringUtils.isBlank(environmentDto.getAdLdapServerType()) || AdLdapServerType.LDAP.getKey().equals(environmentDto.getAdLdapServerType())) && StringUtils.isBlank(environmentDto.getLdapUserServerIdentify())) {
			resultModel.getMessageInfo()
					.add(new MessageInfo("ldapUserServerIdentify", "MI-E-0500-0002", MessageType.ERROR, messageService,
							new String[] { messageService.getMessage("frm0510.externalAuthenticationCooperation.ldapUserServerIdentify") }));
			isError = false;
		}
		if (StringUtils.isBlank(environmentDto.getAuthConnectUsername())) {
			// MI-E-0040=パスワードを入力してください。
			resultModel.getMessageInfo().add(new MessageInfo("authConnectUsername", "MI-E-0500-0001", MessageType.ERROR,
					messageService, new String[] { messageService.getMessage("frm0510.externalAuthenticationCooperation.authConnectUsername") }));
			isError = false;
		}
		if (StringUtils.isBlank(environmentDto.getAuthConnectPwd())) {
			// MI-E-0040=パスワードを入力してください。
			resultModel.getMessageInfo().add(new MessageInfo("authConnectPwd", "MI-E-0500-0001", MessageType.ERROR,
					messageService, new String[] { messageService.getMessage("frm0510.externalAuthenticationCooperation.authConnectPwd") }));
			isError = false;
		}

		// 関連チェック
		if (isError) {
			if (environmentDto.getAuthServerPort().length() > 5) {
				// MI-E-0045=ポート番号は6桁以下の数値を入力してください
				 resultModel.getMessageInfo().add(new MessageInfo("authServerPort",
				 "MI-E-0045", MessageType.ERROR, messageService));
				isError = false;
			}
			if (!environmentDto.getAuthServerPort().matches("[A-Za-z0-9._-]*")) {
				// MI-E-0028=サーバーIDに半角の英数字と「.」以外の文字が入力されています。
				 resultModel.getMessageInfo().add(new MessageInfo("authServerPort",
				 "MI-E-0028", MessageType.ERROR, messageService));
				isError = false;
			}
			if (!environmentDto.getAuthServerPort().matches("[0-9]*")) {
				// MI-E-0044={0}に半角の数字以外の文字が入力されています。
				 resultModel.getMessageInfo().add(new MessageInfo("authServerPort",
				 "MI-E-0044", MessageType.ERROR, messageService, new
				 String[]{messageService.getMessage("frm0510.externalAuthenticationCooperation.authServerPort")}));
				isError = false;
			}
			if (environmentDto.getAuthServerTimeout().length() > 5) {
				// MI-E-0045=ポート番号は6桁以下の数値を入力してください
				 resultModel.getMessageInfo().add(new MessageInfo("authServerTimeout",
				 "MI-E-0045", MessageType.ERROR, messageService));
				isError = false;
			}
			if (!environmentDto.getAuthServerTimeout().matches("[A-Za-z0-9._-]*")) {
				// MI-E-0028=サーバーIDに半角の英数字と「.」以外の文字が入力されています。
				 resultModel.getMessageInfo().add(new MessageInfo("authServerTimeout",
				 "MI-E-0028", MessageType.ERROR, messageService));
				isError = false;
			}
			if (!environmentDto.getAuthServerTimeout().matches("[0-9]*")) {
				// MI-E-0044={0}に半角の数字以外の文字が入力されています。
				 resultModel.getMessageInfo().add(new MessageInfo("authServerTimeout",
				 "MI-E-0044", MessageType.ERROR, messageService, new
				 String[]{messageService.getMessage("frm0510.externalAuthenticationCooperation.authServerTimeout")}));
				isError = false;
			}
		}

		return isError;
	}

}
