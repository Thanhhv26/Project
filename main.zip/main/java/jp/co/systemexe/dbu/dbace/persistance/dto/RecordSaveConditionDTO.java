/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.util.HashMap;
import java.util.Map;

/**
 * レコード保存条件 DTO。
 * <p>
 * レコードの更新、新規追加の際の保存条件を保持する DTO です。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class RecordSaveConditionDTO {

    /**
     * 接続定義 ID。
     */
    private String connectDefinitionId;

    /**
     * テーブル ID。
     */
    private String tableId;

    /**
     * 保存条件マップ。
     * <p>
     * Map&l;プライマリキーカラム名, 一致条件&gt;<br />
     * 追加の際には評価されません。</p>
     */
    private Map<String, String> conditions = new HashMap<String, String>();

    /**
     * connectDefinitionId を戻します。
     * 
     * @return String
     */
    public String getConnectDefinitionId() {
        return connectDefinitionId;
    }

    /**
     * connectDefinitionId を設定します。
     *
     * @param String connectDefinitionId 
     */
    public void setConnectDefinitionId(String connectDefinitionId) {
        this.connectDefinitionId = connectDefinitionId;
    }

    /**
     * tableId を戻します。
     * 
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * tableId を設定します。
     *
     * @param String tableId 
     */
    public void setTableId(String tableId) {
        this.tableId = tableId;
    }

    /**
     * 保存条件マップを戻します。
     * <p>
     * 追加の際には評価されません。</p>
     * 
     * @return Map&l;プライマリキーカラム名, 一致条件&gt;
     */
    public Map<String, String> getConditions() {
        return conditions;
    }
    
    public void setConditions(Map<String, String> conditions) {
        this.conditions = conditions;
    }

    /**
     * RecordSaveConditionDTO の生成。
     * <p>コンストラクタ。</p>
     */
    public RecordSaveConditionDTO() {
        return;
    }
}
