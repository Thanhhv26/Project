/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * データベースのテーブルデータ DAO。
 * <p>
 * 実際にデータベース内のテーブルデータにアクセスする DAO です。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public interface DatabaseTableOneRecordDAO {

    /**
     * データベースとの接続を確立します。
     * <p>
     * 既に接続されている場合は例外をスローします。</p>
     *
     * @param dto DbConnectInfomationDTO
     * @exception DAOException
     */
    public void connect(final DbConnectInfomationDTO dto) throws DAOException;

    /**
     * データベースとの接続を閉じます。
     *
     */
    public void close();

    /**
     * select を発行し結果レコードをコレクションに設定して戻します。
     * <p>
     * 条件指定に従い、一致検索或いは曖昧検索を行い、取得したレコードを
     * コレクションに設定して戻します。
     * </p><p>
     * 検索されたレコードの内、戻す範囲の先頭と、一度に戻すレコード数も指定
     * 出来ます。<br />
     * 指定された先頭位置にレコードが発見できない場合は空のコレクションを戻し
     * ます。<br />
     * 指定された先頭位置から、指定されたレコード数が存在しない場合は、存在した
     * 分だけを戻します。また、レコード数が 0 以下で指定されていた場合は、検索
     * されたレコードを指定された先頭位置から全て戻します。
     * </p>
     *
     * @param dto レコード検索条件 DTO
     * @param form テーブルフォーム DTO
     * @param table テーブル DB 内定義 DTO
     * @return RecordSearchResultDTO レコード検索結果 DTO
     * @throws DAOException
     */
    public void executeQuery(
            final RecordSearchConditionDTO dto,
            final TableFormDTO form,
            final TableDefinitionDTO table) throws DAOException;

    /**
     * 次のレコードがあるか否かを返します。
     *
     * @return
     * @throws DAOException
     */
    public boolean hasNext() throws DAOException;

    /**
     *
     * @return
     * @throws DAOException
     */
    public Map<String, String> next() throws DAOException;

    /**
     * テーブル検索時の条件文を返します。
     *
     * @return
     */
    public String getSearchCondition();
}
