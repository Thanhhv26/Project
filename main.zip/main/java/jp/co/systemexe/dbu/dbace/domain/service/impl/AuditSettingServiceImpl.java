/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import jp.co.systemexe.dbu.dbace.common.audit.AuditCategories;
import jp.co.systemexe.dbu.dbace.common.audit.AuditFileUnit;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfAuditSettingLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfAuditSettingLogic;
import jp.co.systemexe.dbu.dbace.domain.service.AuditSettingService;
import jp.co.systemexe.dbu.dbace.library.service.AbstractService;
import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.audit.dto.AuditCategoryItem;
import jp.co.systemexe.dbu.dbace.web.audit.dto.FRM0530ResultDto;
import jp.co.systemexe.dbu.dbace.web.audit.json.FRM0530Param;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;

/**
 * @author van-thanh
 *
 */

/**
 * processing to show data from AuditSetting.xml to screen
 * update information in AuditSetting.xml
 *
 * ログイン: ユーザーのログイン、ログアウトを監査
 * 外部認証操作: 外部認証連携の変更を監査
 * データ操作	: テーブルへのデータ作成/編集/削除/参照を監査
 * ユーザー操作: ユーザー情報の作成/編集(権限変更含む)/削除/を監査
 * 接続定義操作: データベースへの接続設定の作成/編集/削除を監査
 * DBオブジェクト操作: オブジェクトの登録/同期/削除を監査
 * リレーション操作: リレーション操作の作成/編集/削除/参照を監査
 * 画面作成操作: オブジェクトを利用した画面の作成/編集/削除/参照を監査
 */

@Service
public class AuditSettingServiceImpl extends AbstractService implements AuditSettingService {

	private static final long serialVersionUID = 1L;

//	@Autowired
//	private UserInfo userInfo;

	/*
	 * get info from xml
	 *
	 * (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.AuditSettingService#initialize()
	 */
	@Override
	public FRM0530ResultDto initialize() {
		FRM0530ResultDto result = new FRM0530ResultDto();
		result.setMessageInfoList(new ArrayList<MessageInfo>());

		final AcquisitionOfAuditSettingLogic logic = new AcquisitionOfAuditSettingLogic();
	    final AuditSettingDTO dto;
	    try {
	        try {
	            dto = logic.getAuditSetting();
	        } catch (final ApplicationDomainLogicException e) {
	        	String str = e.toString();
	        	if(e.toString().contains(MessageUtils.getMessage("FRM0220.wrong.format.compare"))){//fomat
	        		str = MessageUtils.getMessage("FRM0220.wrong.format");
	        	}else if(e.toString().contains(MessageUtils.getMessage("FRM0220.not.exist.compare"))){//exist
	        		str = MessageUtils.getMessage("FRM0220.not.exist");
	        	}else if(e.toString().contains(MessageUtils.getMessage("FRM0220.auditlog.permission.compare"))){//not permission
	        		str = MessageUtils.getMessage("FRM0220.auditlog.permission");
	        	}
	        	result.getMessageInfoList().add(new MessageInfo(str, MessageType.ERROR));
	            return result;
	        }

	        result.setBeforeAuditSettingDTO(dto);

	        List<AuditCategoryItem> items = new ArrayList<AuditCategoryItem>();
	        for (AuditCategories category : AuditCategories.values()) {
	        	if (!category.isEnable()) {
	        		continue;
	        	}

	            AuditCategoryItem item = new AuditCategoryItem();
	            item.setAuditName(category.name());
	            item.setAuditCategoryDispName(category.getCategoryDispName());
	            item.setAuditCategoryExplanation(category.getCategoryExplanation());

	            for (Integer index : dto.getCategoryMap().keySet())  {
	                if (AuditCategories.valueOf(dto.getCategoryMap().get(index))
	                        == category) {
	                    item .setSelectedAuditCategory(true);
	                    break;
	                }
	            }

	            items.add(item);
	        }
	        result.setAuditCategoryItems(items.toArray(new AuditCategoryItem[0]));

	        List<SelectOneMenuItem> auditLogFileUnitItems = new ArrayList<SelectOneMenuItem>();
	        for (AuditFileUnit unit : AuditFileUnit.values()) {
	            final SelectOneMenuItem item = new SelectableItem();
	            item.setValue(unit.name());
	            item.setLabel(unit.getUnitName());
	            auditLogFileUnitItems.add(item);
	        }
	        result.setAuditLogFileUnitItems(auditLogFileUnitItems);

	        result.setAuditLogFileSize(String.valueOf(dto.getFileSize()));
	        result.setAuditLogFileUnit(dto.getFileUnit());
	        result.setAuditLogFileRotation(String.valueOf(dto.getFileRotation()));
	        result.setAuditLogFileOutput(dto.getFilePath());
	    } catch (final Exception e) {
	    	result.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
	        return result;
	    }
	    return result;
	}

	/*
	 * update info of AuditSetting.xml
	 *
	 * (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.domain.service.AuditSettingService#doOnceSave(jp.co.systemexe.dbu.dbace.web.audit.json.FRM0530Param)
	 */
	@Override
	public FRM0530ResultDto doOnceSave(FRM0530Param param) {
		FRM0530ResultDto result = new FRM0530ResultDto();
		result.setMessageInfoList(new ArrayList<MessageInfo>());
		try {
            final AuditSettingDTO dto = new AuditSettingDTO();

            int count = 0;
            for (AuditCategoryItem item : param.getAuditCategoryItems()) {
                if (item.isSelectedAuditCategory()) {
                    dto.getCategoryMap().put(count, item.getAuditName());
                    count++;
                }
            }
            dto.getCategoryMap().put(count, AuditCategories.AUDIT_SETTING.name());

            dto.setFileSize(Long.valueOf(param.getAuditLogFileSize()));
            dto.setFileUnit(param.getAuditLogFileUnit());
            dto.setFileRotation(Integer.valueOf(param.getAuditLogFileRotation()));
            dto.setFilePath(param.getAuditLogFileOutput());

            final PreservationOfAuditSettingLogic logic = new PreservationOfAuditSettingLogic();
            try {
                logic.checkAuditFile(dto.getFilePath());
                logic.save(param.getBeforeAuditSettingDTO(), dto, param.getUserInfo());
            } catch (final ApplicationDomainLogicException e) {
            	String str = e.toString();
	        	if(e.toString().contains(MessageUtils.getMessage("FRM0220.wrong.format.compare"))){//fomat
	        		str = MessageUtils.getMessage("FRM0220.wrong.format");
	        	}else if(e.toString().contains(MessageUtils.getMessage("FRM0220.not.exist.compare"))){//exist
	        		str = MessageUtils.getMessage("FRM0220.not.exist");
	        	}else if(e.toString().contains(MessageUtils.getMessage("FRM0220.auditlog.permission.compare"))){//not permission
	        		str = MessageUtils.getMessage("FRM0220.auditlog.permission");
	        	}
            	result.getMessageInfoList().add(new MessageInfo(str, MessageType.ERROR));
                return result;
            }
        } catch (final Exception e) {
        	result.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
            return result;
        }

        // MI-I-0009=監査ログ情報の設定を保存しました。
		result.getMessageInfoList().add(new MessageInfo(MessageUtils.getMessage("MI-I-0009"), MessageType.SUCCESS));
        return result;
	}


}
