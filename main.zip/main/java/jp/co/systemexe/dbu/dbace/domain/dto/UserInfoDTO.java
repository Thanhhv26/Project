/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import java.io.Serializable;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;

/**
 * ユーザー情報 DTO。
 * <p>
 * ユーザー情報を保持する DTO です。なお、パスワードは保持しません。</p>
 *
 * @author EXE 島田 雄一郎
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
//@Component(instance=InstanceType.SESSION)
public class UserInfoDTO implements Serializable{
    /**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
     * ユーザー ID。
     */
    private String id;

    /**
     * ユーザー名。
     */
    private String name;

    /**
     * ユーザー権限。
     */
    private UserAuthority userAuthority;

    /**
     * 現在保持している、ユーザー情報のユーザーがアプリケーション管理者
     * (画面カスタマイズ権限を持つか)否かを返します。
     * <p>
     * 指定された、接続定義に対してアプリケーション管理者権限を持つ場合は、
     * true を返します。
     */
    private boolean isApplicationAdministrator;

    /**
     * 現在保持している、ユーザー情報のユーザーがアプリケーション管理者
     * (画面カスタマイズ権限を持つか)否かを返します。
     * <p>
     * 指定された、接続定義に対してアプリケーション管理者権限を持つ場合は、
     * true を返します。
     */
    private Map<String, Boolean> applicationAdministratorMap;

    /**
     * id を戻します。
     *
     * @return String
     */
    public String getId() {
        return id;
    }

    /**
     * id を設定します。
     *
     * @param String id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * name を戻します。
     *
     * @return String
     */
    public String getName() {
        return name;
    }

    /**
     * name を設定します。
     *
     * @param String name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * userAuthority を戻します。
     *
     * @return UserAuthority
     */
    public UserAuthority getUserAuthority() {
        return userAuthority;
    }

    /**
     * userAuthority を設定します。
     *
     * @param UserAuthority userAuthority
     */
    public void setUserAuthority(UserAuthority userAuthority) {
        this.userAuthority = userAuthority;
    }

    /**
     * 現在保持している、ユーザー情報のユーザーがシステム管理者か
     * 否かを返します。
     *
     * @return boolean
     */
    public boolean isSystemAdministrator() {
    	return this.userAuthority.isSystemAdministrator();
    }

    /**
     * 現在保持している、ユーザー情報のユーザーがアプリケーション管理者
     * (画面カスタマイズ権限を持つか)否かを返します。
     * <p>
     * 接続定義に対して、1つでもアプリケーション管理者権限を持つ場合は、
     * true を返します。
     * </p>
     *
     * @return boolean
     */
    public boolean isApplicationAdministrator() {
    	return isApplicationAdministrator;
    }

    /**
     * 現在保持している、ユーザー情報のユーザーがアプリケーション管理者
     * (画面カスタマイズ権限を持つか)否かを返します。
     * <p>
     * 指定された、接続定義に対してアプリケーション管理者権限を持つ場合は、
     * true を返します。
     * </p>
     *
     * @return boolean
     */
    public boolean isApplicationAdministrator(final String connectDefinisionId) {
    	if (applicationAdministratorMap.containsKey(connectDefinisionId)) {
        	return applicationAdministratorMap.get(connectDefinisionId);
    	} else {
    		return false;
    	}
    }

	/**
	 * applicationAdministratorMap を設定します。
	 *
	 * @param Map<String,Boolean> applicationAdministratorMap
	 */
	public void setApplicationAdministratorMap(
			Map<String, Boolean> applicationAdministratorMap) {
		this.applicationAdministratorMap = applicationAdministratorMap;
	}

	/**
	 * isApplicationAdministrator を設定します。
	 *
	 * @param boolean isApplicationAdministrator
	 */
	public void setApplicationAdministrator(boolean isApplicationAdministrator) {
		this.isApplicationAdministrator = isApplicationAdministrator;
	}

	/**
	 * applicationAdministratorMap を戻します。
	 *
	 * @return Map<String,Boolean>
	 */
	public Map<String, Boolean> getApplicationAdministratorMap() {
		return applicationAdministratorMap;
	}
}
