package jp.co.systemexe.dbu.dbace.web.creation.dto;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.ItemMulti;
import lombok.Data;

@Data
public class ItemMultiDto {
	/*Attribute*/
	private String id;
	/*private String label;*/
	/*Element*/
	private boolean isUpdateKey;
	private boolean isSelectKey;
	private boolean primaryKey;
	private boolean unique;
	private boolean foreignKey;
	private String dataType;
	private String dataLength;
	private String dataUnit;
    /**
     * JDBC メタデータ型。
     */
    private JDBCMetaDataType jDBCMetaDataType;

	public ItemMultiDto(){

	}

	public ItemMultiDto(ItemMulti itemMulti){
		if(itemMulti != null){
			/*Attribute*/
			this.setId(itemMulti.getId());
			/*this.setLabel(itemMulti.getLabel());*/
			/*Element*/
			this.setUpdateKey(itemMulti.isUpdateKey());
			this.setSelectKey(itemMulti.isSelectKey());
			this.setPrimaryKey(itemMulti.isPrimaryKey());
			this.setUnique(itemMulti.isUnique());
			this.setForeignKey(itemMulti.isForeignKey());
			this.setDataType(itemMulti.getDataType());
			this.setDataLength(itemMulti.getDataLength());
			this.setDataUnit(itemMulti.getDataUnit());
		}
	}
}
