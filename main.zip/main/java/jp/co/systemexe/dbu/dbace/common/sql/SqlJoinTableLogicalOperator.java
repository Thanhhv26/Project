/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.sql;

import java.util.HashMap;
import java.util.Map;


/**
 * 論理演算子
 *
 * @author EXE 古賀 諭
 * @author EXE 島田 雄一郎
 *
 */
public enum SqlJoinTableLogicalOperator {
	on("on","ON"),
	innerjoin("INNER JOIN", "innerjoin"),
	leftouterjoin("LEFT OUTER JOIN", "leftouterjoin"),
	rightouterjoin("RIGHT OUTER JOIN", "rightouterjoin"),
	fullouterjoin("FULL OUTER JOIN", "fullouterjoin");

    private String logicalOperator;
    private String label;

    private static Map<String, SqlJoinTableLogicalOperator> map;
    private static Map<String, SqlJoinTableLogicalOperator> labelMap;

    static {
        map = new HashMap<String, SqlJoinTableLogicalOperator>();
        labelMap = new HashMap<String, SqlJoinTableLogicalOperator>();

        for (final SqlJoinTableLogicalOperator logicalOperator : SqlJoinTableLogicalOperator.values()) {
            map.put(logicalOperator.getLogicalOperator(), logicalOperator);
            labelMap.put(logicalOperator.getLabel(), logicalOperator);
        }
    }

    public static SqlJoinTableLogicalOperator labelOf(final String logicalOperator) {
        return labelMap.get(logicalOperator);
    }

    public static SqlJoinTableLogicalOperator logicalOperatorOf(final String logicalOperator) {
        return map.get(logicalOperator);
    }

    /**
     * @return label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @return logicalOperator
     */
    public String getLogicalOperator() {
        return logicalOperator;
    }

    private SqlJoinTableLogicalOperator(final String logicalOperator, final String label) {
        this.logicalOperator = logicalOperator;
        this.label = label;
    }
}
