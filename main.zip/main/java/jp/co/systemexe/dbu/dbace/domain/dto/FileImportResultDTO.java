/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import java.io.Serializable;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200UploadResultModel;

/**
 * データの一括処理において、行ったデータの処理件数、エラーとなった情報を保持するDTO
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class FileImportResultDTO implements Serializable {
	/**
	 * <code>serialVersionUID</code> のコメント。
	 */
	private static final long serialVersionUID = -8735328962619885500L;

	/**
	 * 総件数
	 */
	private int totalCount;

	/**
	 * 総件数
	 */
	private int validateErrorCount;

	/**
	 * 登録処理成功件数
	 */
	private int insertSuccessCount;

	/**
	 * 更新処理成功件数
	 */
	private int updateSuccessCount;

	/**
	 * 登録処理失敗件数
	 */
	private int insertErrorCount;

	/**
	 * 更新処理失敗件数
	 */
	private int updateErrorCount;

	/**
	 * 各行毎のエラーを保持するマップ
	 */
	private SortedMap<Integer, String> errorMessage;

	/**
	 * 各行毎のエラーメッセージ、行数を保持するプロパティ
	 */
	private List<ResultMessageItem> resultMessageItems;
	
	private FRM0200UploadResultModel resultModel;
	/**
	 * resultMessageItems を戻します。
	 *
	 * @return List<ResultMessageItem>
	 */
	public List<ResultMessageItem> getResultMessageItems() {
		return resultMessageItems;
	}

	/**
	 * resultMessageItems を設定します。
	 *
	 * @param List<ResultMessageItem> resultMessageItems
	 */
	public void setResultMessageItems(List<ResultMessageItem> resultMessageItems) {
		this.resultMessageItems = resultMessageItems;
	}

	/**
	 * totalCount を戻します。
	 *
	 * @return int
	 */
	public int getTotalCount() {
		return totalCount;
	}
	/**
	 * totalCount を設定します。
	 *
	 * @param int totalCount
	 */
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	/**
	 * validateErrorCount を戻します。
	 *
	 * @return int
	 */
	public int getValidateErrorCount() {
		return validateErrorCount;
	}
	/**
	 * validateErrorCount を設定します。
	 *
	 * @param int validateErrorCount
	 */
	public void setValidateErrorCount(int validateErrorCount) {
		this.validateErrorCount = validateErrorCount;
	}
	/**
	 * insertSuccessCount を戻します。
	 *
	 * @return int
	 */
	public int getInsertSuccessCount() {
		return insertSuccessCount;
	}
	/**
	 * insertSuccessCount を設定します。
	 *
	 * @param int insertSuccessCount
	 */
	public void setInsertSuccessCount(int insertSuccessCount) {
		this.insertSuccessCount = insertSuccessCount;
	}
	/**
	 * updateSuccessCount を戻します。
	 *
	 * @return int
	 */
	public int getUpdateSuccessCount() {
		return updateSuccessCount;
	}
	/**
	 * updateSuccessCount を設定します。
	 *
	 * @param int updateSuccessCount
	 */
	public void setUpdateSuccessCount(int updateSuccessCount) {
		this.updateSuccessCount = updateSuccessCount;
	}
	/**
	 * insertErrorCount を戻します。
	 *
	 * @return int
	 */
	public int getInsertErrorCount() {
		return insertErrorCount;
	}
	/**
	 * insertErrorCount を設定します。
	 *
	 * @param int insertErrorCount
	 */
	public void setInsertErrorCount(int insertErrorCount) {
		this.insertErrorCount = insertErrorCount;
	}
	/**
	 * updateErrorCount を戻します。
	 *
	 * @return int
	 */
	public int getUpdateErrorCount() {
		return updateErrorCount;
	}
	/**
	 * updateErrorCount を設定します。
	 *
	 * @param int updateErrorCount
	 */
	public void setUpdateErrorCount(int updateErrorCount) {
		this.updateErrorCount = updateErrorCount;
	}
	/**
	 * errorMessage を戻します。
	 *
	 * @return SortedMap<Integer,String>
	 */
	public SortedMap<Integer, String> getErrorMessage() {
		return errorMessage;
	}

	/**
	 * コンストラクタ
	 */
	public FileImportResultDTO() {
		errorMessage = new TreeMap<Integer, String>();
	}

	public FRM0200UploadResultModel getResultModel() {
		return resultModel;
	}

	public void setResultModel(FRM0200UploadResultModel resultModel) {
		this.resultModel = resultModel;
	}
}
