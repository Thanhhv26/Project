/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.TableIdDefinition;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * データベースのスキーマ情報 DAO。
 * <p>
 * データベースのテーブル名一覧やテーブルスキーマ情報へのアクセスを行う DAO です。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class OracleDatabaseSchemaDAOImpl extends BaseDatabaseDAO
        implements DatabaseSchemaDAO {

	/**
	 * テーブルのバーチャルカラムの名前を戻す
	 *
	 * @param TableIdDefinition
	 * @return columnName（バーチャルカラム）
     * @throws DAOException
	 */
	private List<String> tableCheckVirtualColumn(final TableIdDefinition id)
		throws DAOException {

		final StringBuilder sql = new StringBuilder();
        sql.append("SELECT");
        sql.append(" COLUMN_NAME");
        sql.append(" FROM");
        sql.append(" ALL_TAB_COLS");
        sql.append(" WHERE");
        sql.append(" OWNER	= '" + id.getSchem() + "'");
        sql.append(" AND	TABLE_NAME	= '" + id.getTable() + "'");
        sql.append(" AND    VIRTUAL_COLUMN  ='YES'");

        getLogger().debug(sql.toString());

        final PreparedStatement st = getPreparedStatement(sql.toString());
        ResultSet rs = null;
        final List<String> columnName = new ArrayList<String>();

        try {
            rs = st.executeQuery();

            while (rs.next()) {
            	columnName.add(rs.getString("COLUMN_NAME"));
            }
    		return columnName;
        } catch (SQLException e) {
        	final String message = MessageUtils.getMessage("MI-E-0150");
        	getLogger().error(message, e);
        	throw new DAOException(message, e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                }
            }
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException e) {
                }
            }
        }
	}

    /**
     * テーブルの定義情報を取得します。
     * <p>
     * テーブルのカラム詳細情報 DTO を取得して戻します。</p>
     *
     * @param tableId テーブル ID（スキーマ名.テーブル名）
     * @return TableDefinitionDTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO#getTableDefinition(java.lang.String)
     */
    public TableDefinitionDTO getTableDefinition(final String tableId)
            throws DAOException {

        final DatabaseMetaData meta;
        try {
            meta = getDatabaseMetaData();
        } catch (final SQLException e) {
        	// MI-E-0031=データベースのメタデータ取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0031");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }

        final TableIdDefinition id = new TableIdDefinition(tableId);
        try {
            checkTableName(id, meta);
        } catch (SQLException e) {
            throw new DAOException(e.getMessage());
        }

        final SortedMap<Integer, String> columns = getColumnNames(id, meta);
        final TableDefinitionDTO ret = createDefaultTableDefinitionDTO(id,
            columns);
        ret.setView(isView(meta, id));
        setPrimaryKeysToTableDefinitionDTO(meta, id, ret);
        setFkKeysToTableDefinitionDTO(meta, id, ret);
        setUniqueColumnToTableDefinitionDTO(meta, id, ret);
        ret.getColumnNames().putAll(columns);
        setColumnTypeNames(meta, id, ret);
        setResultSetMetaDataToTableDefinitionDTO(id, ret);
        setRemarks(meta, id, ret);

        ret.outputDebugLog();

        return ret;
    }
//
//    /**
//    *
//    */
//	@Override
//	public TableDefinitionDTO getTableDefinition(TableFormDTO tableFormDTO) throws DAOException {
//		final DatabaseMetaData meta;
//		try {
//			meta = getDatabaseMetaData();
//		} catch (final SQLException e) {
//			// MI-E-0031=データベースのメタデータ取得に失敗しました。
//			final String message = MessageUtils.getMessage("MI-E-0031");
//			getLogger().error(message, e);
//			throw new DAOException(message, e);
//		}
//
//		int index = 0;
//		if (isMultiTable(tableFormDTO.getType())) {
//			final TableDefinitionDTO multiTableDefinitionDTO = new TableDefinitionDTO(tableFormDTO.getTableFormId());
//			for (Iterator<TableItemDTO> iterator = tableFormDTO.getTableItemMap().values().iterator(); iterator.hasNext();) {
//				TableItemDTO tableItemDTO = (TableItemDTO) iterator.next();
//				// In case tableItemDTO has childs col
//				if(tableItemDTO.isRoot()){
//					final DefinitionOfColumn columnDef = new DefinitionOfColumn(tableItemDTO.getItemId());
//					columnDef.setTableId(tableItemDTO.getTableId());
//
//					columnDef.setPrimaryKey(tableItemDTO.getPrimaryKey());
//					columnDef.setUnique(tableItemDTO.getUnique());
//					columnDef.setForeignKey(tableItemDTO.getForeignKey());
//
//					columnDef.setColumnTypeName(tableItemDTO.getDataType());
//					columnDef.setNotNull(false);
//					//columnDef.setColumnDisplayMaxSize(Integer.valueOf(tableItemDTO.getDataLength()));
//
//					multiTableDefinitionDTO.getColumnNames().put(index, tableItemDTO.getItemId());
//					multiTableDefinitionDTO.getDefinitionOfColumnMap().put(tableItemDTO.getItemId(), columnDef);
//					index++;
//				}else{
//					final TableIdDefinition id = new TableIdDefinition(tableItemDTO.getTableId());
//					String name = getColumnName(id, meta, tableItemDTO.getItemId());
//					if (name != null) {
//						String colName = formatColumnMultiTable(tableItemDTO.getTableId(), name);
//						final DefinitionOfColumn columnDef = new DefinitionOfColumn(name);
//			            columnDef.setTableId(tableItemDTO.getTableId());
//
//			            setPrimaryKeys(meta, id, columnDef);
//						setFkKeys(meta, id, columnDef);
//						setUniqueColumn(meta, id, columnDef);
//						setColumnTypeNames(meta, id, columnDef);
//						setResultSetMetaData(id, columnDef);
//						setRemarks(meta, id, columnDef);
//
//			            multiTableDefinitionDTO.getColumnNames().put(index, colName);
//						multiTableDefinitionDTO.getDefinitionOfColumnMap().put(colName, columnDef);
//						index++;
//					}
//				}
//
//			}
//
//
//			multiTableDefinitionDTO.setView(false);
//			multiTableDefinitionDTO.outputDebugLog();
//			return multiTableDefinitionDTO;
//		} else {
//			return getTableDefinition(tableFormDTO.getTableFormId());
//		}
//	}



    /**
     * 結果セットメタデータからカラムの精度等の情報を DTO に設定。
     * <p></p>
     *
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setResultSetMetaDataToTableDefinitionDTO(
            final TableIdDefinition id, final TableDefinitionDTO dto)
            throws DAOException {
        final StringBuffer columnSql = new StringBuffer();
        for (final Iterator<Integer> ite = dto.getColumnNames().keySet()
            .iterator(); ite.hasNext();) {
            final int index = ite.next();
            columnSql.append("\"" + dto.getColumnNames().get(index) + "\"");
            columnSql.append(",");
        }
        columnSql.deleteCharAt(columnSql.length() - 1);
        final String sql = "select " + columnSql.toString() + " from "
                + String.format("\"%s\".\"%s\"", id.getSchem(), id.getTable()) + " where 1=2";
        final PreparedStatement statement = getPreparedStatement(sql);
        final ResultSet rs;
        try {
            rs = statement.executeQuery();
        } catch (final SQLException e) {
        	// MI-E-0071=結果セットの取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0071");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }

        try {
            //Oracle11gだったら、Listに入れて、バーチャルカラムの名前を取得します。
            final DatabaseMetaData metaDatabase = getDatabaseMetaData();
            List<String> listVirtualColumnName = new ArrayList<String>();
            // 2016/04/11　機能 #1424：テスト実施[DB-ACE01号機 上]のバグを修正します。↓
            //if(metaDatabase.getDatabaseMajorVersion() == 11){
            if(metaDatabase.getDatabaseMajorVersion() >= 11){
           	// 2016/04/11　機能 #1424：テスト実施[DB-ACE01号機 上]のバグを修正します。↑
            	listVirtualColumnName = tableCheckVirtualColumn(id);
            }

            final ResultSetMetaData meta = rs.getMetaData();
            for (int i = 1; i <= meta.getColumnCount(); i++) {
                final String name = meta.getColumnName(i);
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                    .get(name);

                def.setColumnDisplayMaxSize(meta.getColumnDisplaySize(i));
                if (meta.getPrecision(i) == 0) {
                    def.getDefinitionOfNumericalValue().setPrecision(
                        def.getColumnDisplayMaxSize());
                    def.getDefinitionOfNumericalValue().setScale(0);
                } else {
                    def.getDefinitionOfNumericalValue().setPrecision(
                        meta.getPrecision(i));
                    def.getDefinitionOfNumericalValue().setScale(meta.getScale(i));
                }
                def.setAutoIncrement(meta.isAutoIncrement(i));

                def.setJDBCMetaDataType(
                		getJDBCMetaDataType(meta.getColumnType(i), def));

                def.setVirtualColumns(listVirtualColumnName.contains(name));

                if (meta.isNullable(i) == ResultSetMetaData.columnNullable) {
                    def.setNotNull(false);
                } else {
                    def.setNotNull(true);
                }
                //char , byte : 例：VARCHAR2(11 CHAR) || VARCHAR2(11 BYTE)
                String dataUnit = getColumnDataUnit(id.getSchem(),id.getTable(), name);
                if(dataUnit!=null && "B".equalsIgnoreCase(dataUnit)){
                	def.setDataUnit("BYTE");
                } else  if(dataUnit!=null && "C".equalsIgnoreCase(dataUnit)){
                	def.setDataUnit("CHAR");
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0024=カラム情報の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0024");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                statement.close();
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    /**
     * @param schem
     * @param table
     * @param column
     * @return
     * @throws SQLException
     * @throws DAOException
     */
	private String getColumnDataUnit(String schem, String table, String column)
			throws SQLException, DAOException {
		String temp = "SELECT CHAR_USED";
		// String temp1 = " FROM DBA_TAB_COLUMNS";
		String temp1 = " FROM ALL_TAB_COLS";
		String temp2 = " WHERE OWNER='" + schem + "' AND TABLE_NAME = '" + table
				+ "' AND COLUMN_NAME = '" + column + "'";
		String sql = temp.concat(temp1).concat(temp2);
		final PreparedStatement st = getPreparedStatement(sql);
		ResultSet rs = null;
		String dataUnit = "";
		try {
			rs = st.executeQuery();
			while (rs.next()) {
				dataUnit = rs.getString("CHAR_USED");
			}
			return dataUnit;
		} catch (SQLException e) {
			final String message = MessageUtils.getMessage("MI-E-0150");
			getLogger().error(message, e);
			throw new DAOException(message, e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
				}
			}
			if (st != null) {
				try {
					st.close();
				} catch (SQLException e) {
				}
			}
		}
	}

    /**
     * java.typesのカラム型より、JDBCMetaDataTypeを返します。
     * <p>
     * DBの実カラム型がDATEの場合は、JDBCMetaDataType.TIMESTAMPを返します。
     * </p>
     *
     * @param javaSqlTypes
     * @param def
     * @return
     */
    private JDBCMetaDataType getJDBCMetaDataType(
    		final int javaSqlTypes,
    		final DefinitionOfColumn def) {
    	final String columnType = def.getColumnTypeName().toUpperCase();
    	if (columnType.equals("DATE")) {
    		return JDBCMetaDataType.TIMESTAMP;
    	} else {
    		return JDBCMetaDataType.dataTypeOf(javaSqlTypes);
    	}
    }

    /**
     * DB メタデータからユニーク制約の情報を読み込み DTO に設定する。
     * <p>
     * ユニークインデックスが定義されている場合は、そのカラムが主キーであると
     * 副次的に判定します。<br />
     * プライマリキー制約によって主キーを定義している場合は、この制約が存在
     * しない場合が（多々）あります。
     * </p>
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setUniqueColumnToTableDefinitionDTO(
            final DatabaseMetaData meta, final TableIdDefinition id,
            final TableDefinitionDTO dto) throws DAOException {
        if (dto.isView()) {
            return;
        }

        final StringBuilder sql = new StringBuilder();
        sql.append("SELECT");
        sql.append("  B.COLUMN_NAME AS COLUMN_NAME");
        sql.append(" FROM");
        sql.append("  ALL_CONSTRAINTS A,");
        sql.append("  ALL_CONS_COLUMNS B");
        sql.append(" WHERE");
        sql.append("    A.OWNER      = '" + id.getSchem() + "'");
        sql.append("    AND    A.TABLE_NAME      = '" + id.getTable() + "'");
        sql.append("    AND    A.CONSTRAINT_TYPE IN ('U')");
        sql.append("    AND    A.TABLE_NAME      = B.TABLE_NAME(+)");
        sql.append("    AND    A.CONSTRAINT_NAME = B.CONSTRAINT_NAME(+)");

        getLogger().debug(sql.toString());

        final PreparedStatement st = getPreparedStatement(sql.toString());
        ResultSet rs = null;
        try {
            rs = st.executeQuery();

            while (rs.next()) {
            	final String name = rs.getString("COLUMN_NAME");
            	if (name != null && name.equals("") == false) {
            		final DefinitionOfColumn def = dto
            		.getDefinitionOfColumnMap().get(name);
            		def.setUnique(true);
            	}
            }
        } catch (SQLException e) {
        	// MI-E-0018=ユニークキー（Unique Key)の取得に失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0018");
        	getLogger().error(message, e);
        	throw new DAOException(message, e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                }
            }
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException e) {
                }
            }
        }
    }

    /**
     * Viewか否か
     *
     * @param meta
     * @param id
     * @param dto
     * @return
     * @throws DAOException
     */
    private boolean isView(
            final DatabaseMetaData meta,
            final TableIdDefinition id)
            throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getTables(null, id.getSchem(), id.getTable(), new String[]{"VIEW"});
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (final SQLException e) {
        	// MI-E-0019=VIEW情報の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0019");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    /**
     * DB メタデータから外部キーの情報を読み込み DTO に設定する。
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setFkKeysToTableDefinitionDTO(final DatabaseMetaData meta,
            final TableIdDefinition id, final TableDefinitionDTO dto)
            throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getImportedKeys(null, id.getSchem(), id.getTable());
            while (rs.next()) {
                dto.getDefinitionOfColumnMap().get(
                    rs.getString("FKCOLUMN_NAME")).setForeignKey(true);
            }
        } catch (final SQLException e) {
        	// MI-E-0006=外部キー(Foreign Key)の取得に失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0006");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    /**
     * DB メタデータからプライマリキーの情報を読み込み DTO に設定する。
     * <p>
     * プライマリキーで主キーが定義されている場合は、同時にユニークフラグも ON
     * しておきます。</p>
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setPrimaryKeysToTableDefinitionDTO(
            final DatabaseMetaData meta, final TableIdDefinition id,
            final TableDefinitionDTO dto) throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getPrimaryKeys(null, id.getSchem(), id.getTable());
            while (rs.next()) {
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                    .get(rs.getString("COLUMN_NAME"));
                def.setPrimaryKey(true);
                def.setUnique(true);
            }
        } catch (final SQLException e) {
        	// MI-E-0010=データベースに操作対象のオブジェクトが存在しません
            final String message = MessageUtils.getMessage("MI-E-0010");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    /**
     * カラム名の一覧を取得して Map に設定して戻します。
     *
     * @param id
     * @return
     * @throws DAOException
     */
    private SortedMap<Integer, String> getColumnNames(
    		final TableIdDefinition id,
    		final DatabaseMetaData meta)
            throws DAOException {
        final SortedMap<Integer, String> ret = new TreeMap<Integer, String>();
        try {
            final ResultSet rs = meta.getColumns(null, id.getSchem(), id
                .getTable(), null);
            int index = 1;
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                ret.put(index, name);
                index++;
            }
            rs.close();
        } catch (final SQLException e) {
        	// MI-E-0025=カラム名の一覧取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0025");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }

    /**
     * カラム名一覧からテーブル定義 DTO を生成して戻します。
     *
     * @param idDef
     * @param columnNames
     * @return
     */
    private TableDefinitionDTO createDefaultTableDefinitionDTO(
            final TableIdDefinition idDef,
            final Map<Integer, String> columnNames) {
        final TableDefinitionDTO ret = new TableDefinitionDTO(idDef.getTable());
        for (final Iterator<String> ite = columnNames.values().iterator(); ite
            .hasNext();) {
            final String name = ite.next();
            final DefinitionOfColumn columnDef = new DefinitionOfColumn(name);
            columnDef.setTableId(idDef.getTableId());
            ret.getDefinitionOfColumnMap().put(name, columnDef);
        }
        return ret;
    }

    /**
     * テーブル名の一覧を取得して戻す。
     * <p>
     * 現在接続を確立しているデータベース内の、アクセス可能なテーブル名の一覧を
     * 取得して戻します。
     * </p><p>
     * テーブル名の前方はスキーマ名で修飾されています。
     * <code>(スキーマ名).(テーブル名)</code>
     * </p>
     *
     * @return List&lt;(スキーマ名).(テーブル名)&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO#getTableNameList()
     */
    public List<String> getTableNameList(String condition) throws DAOException {
        final List<String> ret = new ArrayList<String>();
        try {
            final DatabaseMetaData meta = getDatabaseMetaData();
            final String[] tps = {"TABLE", "VIEW"};
            ResultSet rs;
            if (StringUtils.isNotEmpty(condition)) {
            	condition = condition.toUpperCase();
            }
			if (StringUtils.isNotEmpty(condition)) {
				if (condition.contains(".")) {
					final String[] schemaTable = condition.split("\\.");
					String schema, table;
					if (schemaTable.length == 0) {
						rs = meta.getTables(null, "%", "%", tps);
					} else {
						if (schemaTable.length == 2) {
							schema = schemaTable[0];
							table = schemaTable[1];
						} else {
							schema = schemaTable[0];
							table = "";
						}
						if (StringUtils.isEmpty(table)) {
							rs = meta.getTables(null, schema, "%", tps);
						} else {
							rs = meta.getTables(null, schema, table + "%", tps);
						}
					}
				} else {
					// オブジェクト名 : デフォルトの検索テーブル
					rs = meta.getTables(null, "%", "%" + condition + "%", tps);
					if (!rs.isBeforeFirst()) {//no data -->search schema
						rs = meta.getTables(null, "%" + condition + "%", "%", tps);
					}
				}
			} else {
				rs = meta.getTables(null, "%", "%", tps);
			}
            final Set<String> recycleTable;

            if (meta.getDatabaseMajorVersion() == 9) {
                recycleTable = new HashSet<String>();
            } else {
                recycleTable = getRecyclebin("TABLE");
            }

            while (rs.next()) {
                final String schem = rs.getString("TABLE_SCHEM");
                final String table = rs.getString("TABLE_NAME");
                if (SystemSchema.isSystemSchema(schem)) {
                	continue;
                }
                if (recycleTable.contains(table)) {
                    continue;
                }
                if (schem == null || schem.equals("")) {
                	if (StringUtils.isNotEmpty(condition)) {
                		 if (table.matches(".*\\Q" + condition + "\\E.*")) {
                			ret.add(table);
                         }
                	} else {
                		ret.add(table);
                	}
                } else {
                	String schemTable = schem.concat(".").concat(table);
                	if (StringUtils.isNotEmpty(condition)) {
                		if (schemTable.matches(".*\\Q" + condition + "\\E.*")) {
                      	  ret.add(schemTable);
                        }
                	} else {
                		ret.add(schemTable);
                	}
                }
            }
            rs.close();
            return ret;
        } catch (final SQLException e) {
        	// MI-E-0035=テーブル名の一覧取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0035");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * テーブルがゴミ箱（リサイクルビン）に存在するかを返します。
     * <p>
     * Oracleより、PURGEオプションを付けずに削除(DROP)されたテーブルは
     * 削除されずにゴミ箱（リサイクルビン）に格納されるため、Oracle専用のコマンド。
     * </p>
     * TODO:9i以下のORACLEでこのSQLを使用した場合に、エラーになる可能性があるかどうか検証。
     *
     * @param tableName
     * @param type
     * @return boolean true:リサイクルビンに存在する、false:存在しない
     * @throws SQLException
     */
    private Set<String> getRecyclebin (
            final String type)
            throws DAOException, SQLException {
        final StringBuffer sql = new StringBuffer();
        sql.append("SELECT OBJECT_NAME");
        sql.append(" FROM RECYCLEBIN");
        sql.append(" WHERE TYPE = '" + type + "'");

        PreparedStatement statement = null;
        ResultSet rs = null;
        try {
            statement = getPreparedStatement(sql.toString());
            rs = statement.executeQuery();

            final Set<String> ret = new HashSet<String>();
            while (rs.next()) {
                ret.add(rs.getString("OBJECT_NAME"));
            }
            return ret;
        } catch (final DAOException e) {
            throw e;
        } catch (final SQLException e) {
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }

            if (statement != null) {
                statement.close();
            }
        }
    }

    /**
     * データベース固有のデータ型を返します。
     *
     * </p>
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setColumnTypeNames(
            final DatabaseMetaData meta,
            final TableIdDefinition id,
            final TableDefinitionDTO dto)
            throws DAOException {
        try {
            final ResultSet rs = meta.getColumns(null, id.getSchem(), id.getTable(), "%");
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                final String type = rs.getString("TYPE_NAME");
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap().get(name);
                if(def != null){
                	//「decimal() identity」 => 「decimal」
                	final String custom = customIdentityColumnTypeName(type);
                	def.setColumnTypeName(custom);
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0123=カラムのデータ型の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0123");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * カラムのコメント(REMARKS)を設定します。
     * <p>SQL ServerはJDBC経由でコメントが取得できない。<br />
     * また、コメントが格納されているデータ型がsql_variant型（JDBC未対応）のため、
     * SQLでも取得不可能なため、nullを返します。
     *
     * </p>
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setRemarks(
            final DatabaseMetaData meta,
            final TableIdDefinition id,
            final TableDefinitionDTO dto)
            throws DAOException {
        try {
            final ResultSet rs = meta.getColumns(null, id.getSchem(), id.getTable(), "%");
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                    .get(name);
                def.setRemarks(getRemarks(id.getSchem(), id.getTable(), name));
            }
        } catch (final SQLException e) {
        	// MI-E-0022=カラムのコメント(REMARKS)取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0022");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * Oracle用カラムのコメント(REMARKS)を取得します。
     *
     * @param schem
     * @param table
     * @param column
     * @return
     * @throws DAOException
     * @throws SQLException
     */
    private String getRemarks(
            final String schem,
            final String table,
            final String column)
            throws DAOException,SQLException {
        final StringBuffer sql = new StringBuffer();
        sql.append("SELECT COMMENTS");
        sql.append(" FROM ALL_COL_COMMENTS");
        sql.append(" WHERE OWNER = '" + schem + "'");
        sql.append(" AND TABLE_NAME = '" + table + "'");
        sql.append(" AND COLUMN_NAME = '" + column + "'");
        final PreparedStatement st = getPreparedStatement(sql.toString());
        ResultSet rs = null;
        try {
            rs = st.executeQuery();

            if (rs.next()) {
                return rs.getString("COMMENTS");
            }
            return null;

        } catch (SQLException e) {
            throw e;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
        }

    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseDatabaseDAO#createSelectWheresString(java.util.SortedMap)
     */
    @Override
    protected String createSelectWheresClause(SortedMap<Integer, SelectConditionItem> wheresMap) {
        // TODO 自動生成されたメソッド・スタブ
        return null;
    }

    /**
     * DatabaseSchemaDAOImpl の生成。
     * <p>コンストラクタ。</p>
     */
    public OracleDatabaseSchemaDAOImpl() {
        return;
    }

    /**
     * システムスキーマを定義した列挙体
     *
     * @author  EXE 島田 雄一郎
     * @version 0.0.0
     */
    private enum SystemSchema {
    	ANONYMOUS,
    	CTXSYS,
    	DBSNMP,
    	DIP,
    	DMSYS,
    	EXFSYS,
    	LBACSYS,
    	MDDATA,
    	MDSYS,
    	MGMT_VIEW,
    	OLAPSYS,
    	ORDPLUGINS,
    	ORDSYS,
    	OUTLN,
    	SH,
    	SI_INFORMTN_SCHEMA,
    	SYS,
    	SYSMAN,
//    	SYSTEM,
    	WMSYS,
    	WKPROXY,
    	WK_TEST,
    	WKSYS,
    	XDB;

    	private static Set<String> set;
    	static {
    		set = new HashSet<String>();
    		for (SystemSchema schema : SystemSchema.values()) {
    			set.add(schema.name());
    		}
    	}

    	/**
    	 * 引数のスキーマ名がシステムスキーマか否かを返します。
    	 *
    	 * @param schema
    	 * @return
    	 */
    	public static boolean isSystemSchema(final String schema) {
    		return set.contains(schema);
    	}
    }

    @Override
    protected String ignoreNullColumns(final List<String> columns, final String columnType) {
//    	final StringBuffer columnsBuff = new StringBuffer();
//		final StringBuffer bracketsBuff = new StringBuffer();
//		String dbFunc = "NVL";
//		//case 1 column : ISNULL(col1,null)
//		if (colList.size() == 1) {
//			columnsBuff.append(dbFunc);
//			columnsBuff.append("(");
//			columnsBuff.append(colList.get(0));
//			columnsBuff.append(", ");
//			columnsBuff.append("null");
//			bracketsBuff.append(")");
//			columnsBuff.append(bracketsBuff);
//			return columnsBuff.toString();
//		}
//		//case >= 2 column
//		int index = 0;
//		for (String name : colList) {
//			if (columnsBuff.length() > 0) {
//				columnsBuff.append(", ");
//			}
//			if(index >= colList.size() - 1){
//				columnsBuff.append(name);
//				break;
//			} else {
//				columnsBuff.append(dbFunc);
//				columnsBuff.append("(");
//				columnsBuff.append(name);
//			}
//			bracketsBuff.append(")");
//			index++;
//		}
//		columnsBuff.append(bracketsBuff);
//		return columnsBuff.toString();
    	return null;
	}

	@Override
	protected String createFuncCheckNullSelectWheresClause(SelectConditionItem item) {
		// TODO Auto-generated method stub
		return null;
	}
}
