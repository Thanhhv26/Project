/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author bao-anh
 *
 */

@Data
public class FRM0200DataResultModel {
	private String connectDefinisionId;
	private String tableId;
	private String tableLabel;
	boolean typeTable;
	private List<MessageInfo> messageInfo;

	public FRM0200DataResultModel() {
		messageInfo = new ArrayList<MessageInfo>(){
			@Override
			public boolean add(MessageInfo e) {
				// TODO Auto-generated method stub
				boolean flag = false;
				for (Iterator<MessageInfo> iterator = messageInfo.iterator(); iterator.hasNext();) {
					MessageInfo messageInfo2 = (MessageInfo) iterator.next();
					if(messageInfo2.getErrorString().equals(e.getErrorString()))
					{
						flag = true;
						break;
					}
				}
				if(!flag)
				{
					return super.add(e);
				}
				return false;
			}
		};
	}
	boolean status;
    public ColumnAttributeItem[] columnAttributeItems;
}
