/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author bao-anh
 *
 */

@Data
public class FRM0200ResultModel {
	private String connectDefinisionId;
	private String tableId;
	private String tableLabel;
	private Boolean isMultiTable = false;

	private ColumnDisplayDefinitionDTO columnsDisplayDefinition;

	private boolean permissionReference = false;
	private boolean permissionCopy = false; // for one record in grid
	private boolean permissionRemove = false; // for one record in grid
	private boolean permissionInsert = false; // for one record in grid
	private boolean permissionUpdate = false; // for one record in grid
	private boolean permissionUpload = false;
	private boolean permissionDownload = false;


	private boolean permissionDeleteFirst = false; // button delete first
	private boolean permissionDeleteSecond = false; // button delete second
	private boolean permissionDeleteThird = false; // button delete third

	private String deleteFirstLabel = "削除1"; // button delete first
	private String deleteSecondLabel = "削除2"; // button delete second
	private String deleteThirdLabel = "削除3"; // button delete third

	/**
	 *
	 */
	private List<MessageInfo> messageInfo;

	/**
	 *
	 */
	public FRM0200ResultModel() {
		messageInfo = new ArrayList<MessageInfo>();
	}
}
