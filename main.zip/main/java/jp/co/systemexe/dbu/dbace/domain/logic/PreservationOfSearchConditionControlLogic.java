/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseSearchConditionDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.SearchConditionDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.OutputSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 検索条件XML用のアプリケーションユーザー情報の保存ロジック。
 * <p>
 * 検索条件情報を、検索条件XMLに保存します。</p>
 *
 * @author	EXE 島田 雄一郎
 * @version 0.0.0
 */
public class PreservationOfSearchConditionControlLogic extends BaseApplicationDomainLogic {

    /**
     * 検索条件情報を検索条件XMLに保存します。
     * <p>
     * 既存の場合は更新を、未登録の場合は自動的に新規追加を行います。</p>
     * 
     * @param dto ユーザー情報 DTO
     * @param password ユーザーパスワード
     * @throws ApplicationDomainLogicException
     */
    public void save(final OutputSearchConditionDTO outputSearchConditionDTO)
            throws ApplicationDomainLogicException {
        final BaseSearchConditionDAO dao = new SearchConditionDAO();
        try {
            dao.outputFile(outputSearchConditionDTO);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e);
        }
    }

    /**
     * PreservationOfSearchConditionControlLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public PreservationOfSearchConditionControlLogic() {
        return;
    }
}
