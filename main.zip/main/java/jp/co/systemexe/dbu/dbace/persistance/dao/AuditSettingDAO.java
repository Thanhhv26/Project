/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

/**
 * 監査ログ設定情報XML DAO 用のインターフェースクラス。
 * <p>
 * 監査ログ設定情報XMLの入出力インターフェースの定義です。</p>
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public interface AuditSettingDAO {

    /**
     * 監査ログ設定情報 DTO を戻します。
     *
     * @return AuditSettingDTO
     * @throws DAOException
     */
    public AuditSettingDTO getAuditSettingDTO()
            throws DAOException;

    /**
     * 監査ログ設定情報を保存します。
     *
     * @param auditSettingDTO 監査ログ設定情報 DTO
     * @throws DAOException
     */
    public void save(
            final AuditSettingDTO beforeAuditSettingDTO,
            final AuditSettingDTO auditSettingDTO,
            final UserInfo userInfo
            ) throws DAOException;
}
