/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;

import lombok.Data;

/**
 * テーブル名 DTO。
 * <p>
 * テーブルID、テーブル名を保持する DTO です。
 * </p>
 *
 * @author  tu-lenh
 * @version 0.0.0
 */
@Data
public class TableConnectRelationDTO {
	String id;
	String action;
	GetTableDependenceDatabaseDTO tableConnect1;
	GetTableDependenceDatabaseDTO tableConnect2;
}
