package jp.co.systemexe.dbu.dbace.web.common;

/**
 * The common application constants
 *
 * @author long-hai
 *
 */
public abstract class AppConst {
	/** the records number per page **/
	public static final int RECORDS_PER_PAGE = 15;
	public static final String REQUEST_ACCEPT_JSON_HEADER = "Accept=application/json";
	public static final String REQUEST_JSON_PRODUCE = "application/json";
	
	public static final String MULTI_TABLE = "multi-table";
	
	public static final String ACTION_INSERT = "insert";
	public static final String ACTION_EDIT = "edit";
	public static final String ACTION_VIEW = "view";
	public static final String ACTION_COPY = "copy";
	public static final String ACTION_SEARCH = "search";
	
	public static final String RELATION_TABLE_MASTER = "master";
	public static final String RELATION_TABLE_DETAIL = "detail";
	
	public static final Integer NULL_ONLY = 0;
	public static final Integer NULL_VARIABLE = 1;
	public static final Integer NULL_FIXED = 2;
}
