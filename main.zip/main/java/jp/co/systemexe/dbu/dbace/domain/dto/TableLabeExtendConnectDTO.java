/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * テーブル名 DTO。
 * <p>
 * テーブルID、テーブル名を保持する DTO です。
 * </p>
 *
 * @author  tu-lenh
 * @version 0.0.0
 */
@Getter
@Setter
public class TableLabeExtendConnectDTO {
    /**
     * テーブルID
     */
    private String id;

    /**
     * テーブル名
     */
    private String label;
    /*
     * type:table or multi
     */
    private String type;

    /**
     * ConnectDefinision Id
     */
    private String connectDefinisionId;
    /**
     * ConnectDefinision Label
     */
    private String connectDefinisionLabel;
    
    private String databaseTypeConnectionDestination;
}
