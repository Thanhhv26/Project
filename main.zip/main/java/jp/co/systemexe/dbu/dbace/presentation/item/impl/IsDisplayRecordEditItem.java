/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneRadioItem;

/**
 * 登録・編集時表示設定のラジオボタン表示用アイテム。
 * <p>
 * </p>
 *
 * @author	EXE 島田 雄一郎
 * @version 0.0.0
 */
public class IsDisplayRecordEditItem implements SelectOneRadioItem, Serializable {

    /**
	 * <code>serialVersionUID</code> のコメント。
	 */
	private static final long serialVersionUID = -6639156507182057952L;

	/**
     * 登録編集時表示設定名称。
     * <p>ユーザーが定義する登録・編集時表示設定に付けた表示用名称です。</p>
     */
    private String label;
    /**
     * 一覧表示設定 ID。
     * <p>システム内部で扱われる ID です。</p>
     */
    private String value;

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getLabel()
     */
    public String getLabel() {
        return label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getValue()
     */
    public String getValue() {
        return value;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setLabel(java.lang.String)
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setValue(int)
     */
    public void setValue(String value) {
        this.value = value;
    }
}
