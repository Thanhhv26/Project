/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.common.controller;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ResponseBody;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.library.util.RequestUtils;
import jp.co.systemexe.dbu.dbace.web.common.dto.ErrorJson;

/**
 * エラークラス。
 * <p>
 * サーバからHTTPステータス302又はHTTPステータス500を返す場合
 *「システムエラー画面に遷移する」
 * </p>
 * @author tu-lenh
 * @version 0.0.0
 */
@ControllerAdvice
public class ErrorHandler {

	final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    /**
     * GET 場合:URLとHTTPステータス302(リダイレクト)を返し, システムエラー画面に強制的に遷移させる。
     * POST 場合:URLとHTTPステータス500(リダイレクト)を返し、システムエラー画面に強制的に遷移させる。
     */
    @org.springframework.web.bind.annotation.ExceptionHandler({ Exception.class })
    @ResponseBody
    public ErrorJson handleError(HttpServletRequest request, HttpServletResponse response, Exception e) {
    	 // エラーの内容をログ出力
        logger.fatal(e.getMessage(), e);
        // リダイレクト先のURLを設定する処理。
    	if (RequestUtils.isAjaxRequest(request)) {//Post
    		ErrorJson errJson = new ErrorJson();
    		errJson.setErrorUrl("/web/systemError");
    		//HTTPステータス500
    		response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
    		return errJson;
    	} else {//Get
    		try {
    			//HTTPステータス302
				response.sendRedirect(request.getContextPath() + "/web/systemError");
			} catch (IOException ioe) {
				logger.fatal(ioe.getMessage(), ioe);
			}
    		return null;
    	}
    }

}
