/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.util.BlowfishUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.DbConnectInfomationDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.DbConnect;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.ConnectDefinision;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;

/**
 * データベースへの接続情報 DAO。
 * <p>
 * リポジトリに対するデータベース接続情報入出力 DAO です。</p>
 * <p>
 * パスワードの暗号化・復号化は DAO の内部で自動的に実行されます。</p>
 *
 * @author　EXE 鈴木 伸祐
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public class DbConnectInfomationDAOImpl extends BaseRepositoryXmlDAO
        implements DbConnectInfomationDAO {

    /**
     * DB 接続情報 DTO を戻します。
     * <p>
     * 接続定義 ID を指定し、リポジトリから DB 接続情報 DTO を取得して戻します。
     * </p>
     *
     * @param connectDefinisionId 接続定義 ID
     * @return DbConnectInfomationDTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DbConnectInfomationDAO#getDbConnectInfomationDTO(java.lang.String)
     */
    public DbConnectInfomationDTO getDbConnectInfomationDTO(
            final String connectDefinisionId) throws DAOException {
        final DbConnectInfomationDTO ret = new DbConnectInfomationDTO();
        final DbConnect db = searchConnectDefinision(connectDefinisionId)
            .getDbConnect();

        if (db == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }

        ret.setServerId(db.getServer().getId());
        ret.setDatabaseId(db.getDatabase().getId());
        ret.setDatabaseLabel(db.getDatabase().getLabel());
        ret.setPortId(db.getPort().getValue());
        ret.setUserId(db.getUser().getId());
        ret.setDatabaseTypeConnectionDestination(DatabaseTypeConnectionDestination.keyOf(db.getDatabaseTypeConnectionDestination()));
        ret.setUseDatabaseUrl(db.getDatabaseUrl().isUse());
        ret.setDatabaseUrl(db.getDatabaseUrl().getUrl());
        ret.setInstanceName(db.getInstanceName());
        try {
            ret.setPassword(BlowfishUtils.decrypt4b64(openSesame(), db
                .getPassword()));
        } catch (final Exception e) {
        	// MI-F-0010=パスワードの複合化に失敗しました。
            final String message = MessageUtils.getMessage("MI-F-0010");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }


    /**
     * DB 接続情報 DTO を戻します。
     * <p>
     * 接続定義 ID を指定し、リポジトリから DB 接続情報 DTO を取得して戻します。
     * </p>
     *
     * @param connectDefinisionId 接続定義 ID
     * @return DbConnectInfomationDTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DbConnectInfomationDAO#getDbConnectInfomationDTO(java.lang.String)
     */
    public DbConnectInfomationDTO getDbConnectInfomationLableDTO(
            final String connectDefinisionId) throws DAOException {
        final DbConnectInfomationDTO ret = new DbConnectInfomationDTO();
        final DbConnect db = searchConnectDefinisionName(connectDefinisionId)
            .getDbConnect();

        if (db == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }

        ret.setServerId(db.getServer().getId());
        ret.setDatabaseId(db.getDatabase().getId());
        ret.setPortId(db.getPort().getValue());
        ret.setUserId(db.getUser().getId());
        ret.setDatabaseTypeConnectionDestination(DatabaseTypeConnectionDestination.keyOf(db.getDatabaseTypeConnectionDestination()));
        ret.setUseDatabaseUrl(db.getDatabaseUrl().isUse());
        ret.setDatabaseUrl(db.getDatabaseUrl().getUrl());
        ret.setInstanceName(db.getInstanceName());
        try {
            ret.setPassword(BlowfishUtils.decrypt4b64(openSesame(), db
                .getPassword()));
        } catch (final Exception e) {
        	// MI-F-0010=パスワードの複合化に失敗しました。
            final String message = MessageUtils.getMessage("MI-F-0010");
            getLogger().fatal(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }

    /**
     * DB 接続情報を保存します。
     * <p>
     * リポジトリに DB 接続情報を保存します。リポジトリ内に対象要素が存在しない
     * 場合には、明示的に要素を作成します。
     * </p><p>
     * パスワード文字列はプレゼンテーション層内で暗号化されて設定されます。
     * 従って、本メソッド内では暗号化処理の実装がありません。
     * </p>
     *
     * @param connectDefinisionId 接続定義 ID
     * @param dto DbConnectInfomationDTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DbConnectInfomationDAO#save(java.lang.String, jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO)
     */
    public void save(final String connectDefinisionId,
            final DbConnectInfomationDTO dto) throws DAOException {

        final ConnectDefinision def = searchConnectDefinision(connectDefinisionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        if (def.getDbConnect() == null) {
            def.setDbConnect(getObjectFactory().createDbConnect());
        }
        final DbConnect db = def.getDbConnect();

        if (db.getDatabase() == null) {
            db.setDatabase(getObjectFactory().createDbConnectDatabase());
        }
        db.getDatabase().setId(dto.getDatabaseId());

        if (db.getServer() == null) {
            db.setServer(getObjectFactory().createDbConnectServer());
        }
        db.getServer().setId(dto.getServerId());

        if (db.getUser() == null) {
            db.setUser(getObjectFactory().createDbConnectUser());
        }
        db.getUser().setId(dto.getUserId());

        if (db.getPort() == null) {
            db.setPort(getObjectFactory().createDbConnectPort());
        }
        db.getPort().setValue(dto.getPortId());
        db.setPassword(dto.getPassword());
        db.setDatabaseTypeConnectionDestination(dto.getDatabaseTypeConnectionDestination().getKey());
        db.setInstanceName(dto.getInstanceName());

        if (db.getDatabaseUrl() == null) {
            db.setDatabaseUrl(getObjectFactory().createDbConnectDatabaseUrl());
        }
        db.getDatabaseUrl().setUse(dto.isUseDatabaseUrl());
        db.getDatabaseUrl().setUrl(dto.getDatabaseUrl());

        update();
    }

    /**
     * DbConnectInfomationDAOImpl の生成。
     * <p>コンストラクタ。</p>
     *
     * @throws DAOException
     */
    public DbConnectInfomationDAOImpl() {
        super();
    }
}
