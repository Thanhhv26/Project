/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.util.bindeditor;

import java.beans.PropertyEditorSupport;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.util.StringUtils;

import jp.co.systemexe.dbu.dbace.common.util.DateUtils;
import jp.co.systemexe.dbu.dbace.library.util.BeanUtils;
import lombok.Getter;
import lombok.Setter;

/**
 * @see java.sql.Timestamp データ型エディタ
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
public class TimeStampEditor extends PropertyEditorSupport {

	@Getter
	@Setter
	private String pattern;

	@Getter
	@Setter
	private boolean allowEmpty;

	/**
	 * 初期化
	 * @param pattern
	 */
	public TimeStampEditor(String pattern) {
		this(pattern, true);
	}
	public TimeStampEditor(String pattern, boolean allowEmpty) {
		this.setAllowEmpty(allowEmpty);
		this.setPattern(pattern);
	}

	/*
	 * (Non-Javadoc)
	 * @see java.beans.PropertyEditorSupport#getAsText()
	 */
	@Override
	public String getAsText() {
		return (!BeanUtils.isInstanceOf(super.getValue(), Date.class)
				? null : DateUtils.formatDateTime(this.getPattern(), (Date) super.getValue()));
	}

	/*
	 * (Non-Javadoc)
	 * @see java.beans.PropertyEditorSupport#setAsText(java.lang.String)
	 */
	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		if (this.isAllowEmpty() && !StringUtils.hasText(text)) {
			setValue(null);
		}
		else {
			try {
				SimpleDateFormat dateFormat = new SimpleDateFormat(this.getPattern());
				Date parsedDate = dateFormat.parse(text);
				super.setValue(new java.sql.Timestamp(parsedDate.getTime()));
			}
			catch (Exception e) {
				throw new IllegalArgumentException(
						"Could not parse date: " + e.getMessage() + " by the specified pattern [" + this.getPattern() + "]", e);
			}
		}
	}
}
