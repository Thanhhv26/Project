/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import java.util.HashMap;
import java.util.Map;

/**
 * ファイルアップロード可能なファイルの種類を定義した列挙体
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum UploadFileType {
	EXCEL("xls", '\u0000'),
	NEWEXCEL("xlsx", '\u0000'),
	CSV("csv", ','),
	TSV("tsv", '\t');

	/**
	 * 拡張子プロパティ
	 */
	private String extension;
	
	/**
	 * 区切り文字(CSV、TSV用)
	 */
	private char delimiter;
	
	private static Map<String, UploadFileType> map;
	static {
		map = new HashMap<String, UploadFileType>();
		for (final UploadFileType type : UploadFileType.values()) {
			map.put(type.extension, type);
		}
	}

	/**
	 * 拡張子より判定した、ファイル形式を返します。
	 * <p>
	 * 非対応の拡張子の場合は、null を返します。
	 * </p>
	 * 
	 * @param extension
	 * @return
	 */
	public static UploadFileType extensionOf(final String extension) {
		return map.get(extension);
	}

	/**
	 * extension を戻します。
	 * 
	 * @return String
	 */
	public String getExtension() {
		return extension;
	}

	/**
	 * extension を設定します。
	 *
	 * @param String extension 
	 */
	public void setExtension(String extension) {
		this.extension = extension;
	}

	/**
	 * delimiter を戻します。
	 * 
	 * @return char
	 */
	public char getDelimiter() {
		return delimiter;
	}

	/**
	 * delimiter を設定します。
	 *
	 * @param char delimiter 
	 */
	public void setDelimiter(char delimiter) {
		this.delimiter = delimiter;
	}
	
	/**
	 * 
	 * UploadFileType.java の生成。
	 * 
	 * @param extension
	 */
	private UploadFileType(final String extension, final char delimiter) {
		this.extension = extension;
		this.delimiter = delimiter;
	}
}
