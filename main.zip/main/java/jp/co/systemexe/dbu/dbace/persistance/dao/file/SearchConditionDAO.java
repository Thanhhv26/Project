/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dto.OutputSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * 検索条件ファイル入出力の基底抽象クラス。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class SearchConditionDAO extends BaseSearchConditionDAO {

    /**
     * ファイルを読み込みます。
     *
     * @param tableId テーブル名
     * @param def 項目表示定義 DTO
     * @param dto レコード検索結果 DTO
     * @param outputStream
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseSearchConditionDAO#inputFile(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public List<SelectConditionItem> inputFile(
            final String filePath)
            throws DAOException {
        final List<SelectConditionItem> ret = new ArrayList<SelectConditionItem>();
        FileInputStream inFile = null;
        ObjectInputStream inObject = null;
        try {
            inFile = new FileInputStream(filePath);
            inObject = new ObjectInputStream(inFile);

            while (true) {
                final SelectConditionItem item
                    = (SelectConditionItem)inObject.readObject();
                ret.add(item);
            }
        } catch (final FileNotFoundException e) {
            // 検索条件が保存されていない場合は、ファイル無し
        } catch (final EOFException e) {
            // 読み込み終了
        } catch (final IOException e) {
        	// MI-E-0074=検索条件の読込に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0074");
            getLogger().fatal(message, e);
            throw new DAOException(message);
        } catch (final ClassNotFoundException e) {
        	// MI-E-0074=検索条件の読込に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0074");
            getLogger().fatal(message, e);
            throw new DAOException(message);
        } finally {
            if (inObject != null) {
                try {
                    inObject.close();
                } catch (final IOException e) {
                }
            }
            if (inFile != null) {
                try {
                    inFile.close();
                } catch (final IOException e) {
                }
            }
        }
        return ret;
    }

    /**
     * ファイル出力を行います。
     *
     * @param tableId テーブル名
     * @param def 項目表示定義 DTO
     * @param dto レコード検索結果 DTO
     * @param outputStream
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseSearchConditionDAO#outputFile(java.lang.String, java.lang.String, java.lang.String, java.util.List)
     */
    @Override
    public void outputFile(
            final OutputSearchConditionDTO outputSearchConditionDTO)
            throws DAOException {
        FileOutputStream outFile = null;
        ObjectOutputStream outObject = null;
        makeDir(outputSearchConditionDTO);

        try {
            outFile = new FileOutputStream(
                createFileName(outputSearchConditionDTO), false);
            outObject = new ObjectOutputStream(outFile);


            for (final SelectConditionItem item
                    : outputSearchConditionDTO.getList()) {
                outObject.writeObject(item);
            }
        } catch (final IOException e) {
        	// MI-E-0124=検索条件の保存に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0124");
            getLogger().fatal(message, e);
            throw new DAOException(message);
        } finally {
            if (outObject != null) {
                try {
                    outObject.close();
                } catch (final IOException e) {
                }
            }
            if (outFile != null) {
                try {
                    outFile.close();
                } catch (final IOException e) {
                }
            }
        }
    }

    /**
     * 検索条件を保存するディレクトリを作成します。
     *
     * @param outputSearchConditionDTO
     */
    private void makeDir(
            final OutputSearchConditionDTO outputSearchConditionDTO)
            throws DAOException {
        final File file = new File(createFileDir(outputSearchConditionDTO));


        if (!file.exists()) {
            if (!file.mkdirs()) {
            	// MI-F-0008=検索条件を保存する、ディレクトリの作成に失敗しました。
                final String message = MessageUtils.getMessage("MI-F-0008");
                getLogger().fatal(message);
                throw new DAOException(message);
            }
        }
    }

    /**
     * ファイル名（フルパス）を生成します
     *
     * @param outputSearchConditionDTO
     * @return
     */
    private String createFileName(
            final OutputSearchConditionDTO outputSearchConditionDTO) {
        if (outputSearchConditionDTO.isUpdate()) {
            return outputSearchConditionDTO.getUpdateFilePath();
        } else {
            final StringBuffer fileName = new StringBuffer();
            fileName.append(createFileDir(outputSearchConditionDTO));
            fileName.append(outputSearchConditionDTO.getFileName());

            return fileName.toString();
        }
    }

    /**
     * ファイルディレクトリを生成します。
     *
     * @param outputSearchConditionDTO
     * @return
     */
    private String createFileDir(
            final OutputSearchConditionDTO outputSearchConditionDTO) {
        return createFileDir(
            outputSearchConditionDTO.getConnectDefinitionId(),
            outputSearchConditionDTO.getTableId(),
            outputSearchConditionDTO.getUserId(),
            outputSearchConditionDTO.isCommon());
    }

    /**
     * ファイルディレクトリを生成します。
     *
     * @param outputSearchConditionDTO
     * @return
     */
    private String createFileDir(
            final String connectDefinitionId,
            final String tableId,
            final String userId,
            final boolean isCommon) {
        final StringBuffer fileDir = new StringBuffer();
        fileDir.append(SystemProperties.getSearchConditionFilePath());
        fileDir.append("/");
        fileDir.append(connectDefinitionId);
        fileDir.append("/");
        fileDir.append(tableId);
        fileDir.append("/");

        if (!isCommon) {
            fileDir.append(userId);
            fileDir.append("/");
        }

        return fileDir.toString();
    }

    /**
     * 共通検索条件ファイル一覧を取得します。
     *
     * @param connectDefinitionId
     * @param tableId
     * @param userId
     * @return Map<String, String> ファイルパス、ファイル名
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseSearchConditionDAO#getFileNameMap(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public Map<String, String> getCommonFileNameMap(
        final String connectDefinitionId,
        final String tableId,
        final String userId) throws DAOException {
        final Map<String, String> ret = new HashMap<String, String>();
        final File commonFiles[] = getFileList(
            createFileDir(connectDefinitionId, tableId, userId, true));
        for (final File file : commonFiles) {
            if(file.isFile()) {
                ret.put(file.getAbsolutePath(), file.getName());
            }
        }
        return ret;
    }

    /**
     * ユーザー検索条件ファイル一覧を取得します。
     *
     * @param connectDefinitionId
     * @param tableId
     * @param userId
     * @return Map<String, String> ファイルパス、ファイル名
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseSearchConditionDAO#getFileNameMap(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public Map<String, String> getUserFileNameMap(
        final String connectDefinitionId,
        final String tableId,
        final String userId) throws DAOException {
        final Map<String, String> ret = new HashMap<String, String>();
        final File userFiles[] = getFileList(
            createFileDir(connectDefinitionId, tableId, userId, false));
        for (final File file : userFiles) {
            if(file.isFile()) {
                ret.put(file.getAbsolutePath(), file.getName());
            }
        }
        return ret;
    }

    /**
     * ファイル一覧を取得します。
     *
     * @param connectDefinitionId
     * @param tableId
     * @param userId
     * @return Map<String, String> ファイルパス、ファイル名
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseSearchConditionDAO#getFileNameMap(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public Map<String, String> getFileNameMap(
        final String connectDefinitionId,
        final String tableId,
        final String userId) throws DAOException {
        final Map<String, String> ret = new HashMap<String, String>();
        ret.putAll(getCommonFileNameMap(
        		connectDefinitionId,
        		tableId,
        		userId));
        ret.putAll(getUserFileNameMap(
        		connectDefinitionId,
        		tableId,
        		userId));
        return ret;
    }

    /**
     * ファイルリストを取得します。
     *
     * @param filePath
     * @return
     */
    private File[] getFileList(
            final String filePath) {
        final File dir = new File(filePath);
        final File[] ret = dir.listFiles();
        return ret == null ? new File[0] : ret;
    }
}
