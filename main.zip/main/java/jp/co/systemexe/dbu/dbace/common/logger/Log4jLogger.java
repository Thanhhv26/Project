/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.logger;

import org.apache.log4j.Logger;

/**
 * Log4j 用のロガーオブジェクトです。
 * <p></p>
 * 
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public class Log4jLogger
        implements jp.co.systemexe.dbu.dbace.common.logger.Logger {
    private final Logger logger;
    private final String className;

    /**
     * Log4jLogger の生成。
     * <p>
     * コンストラクタ。ロガーインスタンスを取得し、log4j の設定を読み込みます。
     * </p>
     */
    public Log4jLogger(final String className) {
        this.className = className;
        this.logger = Logger.getLogger(className);
    }

    /**
     * <p>
     * このオブジェクトのカテゴリー名を戻す。
     * </p>
     * @return 
     */
    public String getCategoryName() {
        return className;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object)
     */
    public void debug(Object obj) {
        logger.debug(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#debug(java.lang.Object, java.lang.Throwable)
     */
    public void debug(Object obj, Throwable te) {
        logger.debug(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object)
     */
    public void error(Object obj) {
        logger.error(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#error(java.lang.Object, java.lang.Throwable)
     */
    public void error(Object obj, Throwable te) {
        logger.error(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object)
     */
    public void fatal(Object obj) {
        logger.fatal(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#fatal(java.lang.Object, java.lang.Throwable)
     */
    public void fatal(Object obj, Throwable te) {
        logger.fatal(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object)
     */
    public void info(Object obj) {
        logger.info(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#info(java.lang.Object, java.lang.Throwable)
     */
    public void info(Object obj, Throwable te) {
        logger.info(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object)
     */
    public void warn(Object obj) {
        logger.warn(obj);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#warn(java.lang.Object, java.lang.Throwable)
     */
    public void warn(Object obj, Throwable te) {
        logger.warn(obj, te);
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.stdg.common.lib.logger.Logger#isDebugEnabled()
     */
    public boolean isDebugEnabled() {
        return logger.isDebugEnabled();
    }
}
