package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.SelectableListDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.RestrictionsDto.RestrictionDto;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectItemDTOSave;
import jp.co.systemexe.dbu.dbace.web.item.dto.restrictionsDTO;

/**
 * 画面制御情報の保存処理。
 * <p>
 * 画面制御情報をリポジトリに対して更新します。</p>
 *
 * @author EXE 鈴木 伸祐
 * @author EXE 六本木 圭
 * @version 0.0.0
 */

public class PreservationFormComponentInfomationRepositoryLogic
        extends BaseApplicationDomainLogic {

    /**
     * 画面制御情報の保存処理。
     * <p>
     * 画面制御情報をリポジトリに対して更新します。</p>
     *
     * @param connectDefinitionId 接続定義ID
     * @param tableFormId テーブルフォームID
     * @param columnId カラムID
     * @param tableItemDto テーブル項目情報DTO
     * @throws ApplicationDomainLogicException
     */
    public void save(final String connectDefinitionId,
            final String tableFormId, final String columnId,
            final TableItemDTO tableItemDto)
            throws ApplicationDomainLogicException {

        final TableFormDAO dao = createTableFormDAO();
        final TableFormDTO tableFormDto;
        try {
            tableFormDto = dao
                .getTableFormDTO(connectDefinitionId, tableFormId);
            if (tableFormDto == null) {
            	// MI-E-0033=テーブル情報が存在しません。
                throw new ApplicationDomainLogicException(
                		MessageUtils.getMessage("MI-E-0033"));
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        tableFormDto.getTableItemMap().put(columnId, tableItemDto);
        try {
        		dao.save(connectDefinitionId, tableFormDto);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

    }

    /**
	 * @param connectDefinitionId
	 * @param tableFormMultiTableId
	 * @return
	 * @throws DAOException
	 */
	public TableFormDto getTableMulti(String connectDefinitionId, String tableFormMultiTableId) throws ApplicationDomainLogicException {
		// TODO Auto-generated method stub
		AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
		try {
			TableFormDAO tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
			TableFormDto dto = new TableFormDto();
			dto.setId(tableFormMultiTableId);
			TableForm tableForm = tableFormDAO.getTargetTableFormMulti(connectDefinitionId, dto);
			return new TableFormDto(tableForm);
		} catch (ApplicationDomainLogicException | DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}
	}

    /**
     * @param connectDefinitionId
     * @param tableFormId
     * @param retMulti
     * @throws ApplicationDomainLogicException
     */
    public void saveMulti(String connectDefinitionId, String tableFormId, SelectItemDTOSave search)
            throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        TableFormDto tableFormDto = getTableMulti(connectDefinitionId,tableFormId);
        if (tableFormDto != null && tableFormDto.getId() == null) {
        	// MI-E-0033=テーブル情報が存在しません。
            throw new ApplicationDomainLogicException(MessageUtils.getMessage("MI-E-0033"));
        }
        try {
        	for(int i=0;i < tableFormDto.getItemDtoList().size();i++){
        		ItemDto itemDto = tableFormDto.getItemDtoList().get(i);
        		if(itemDto.getId().equals(search.getItemId())){
        			setItemChange(itemDto,search);
        			break;
        		}
        	}
        	dao.saveTableMulti(connectDefinitionId, tableFormDto);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

    }

    /**
	 * @param search
	 * @return
	 */
	private void setItemChange(ItemDto retMulti,SelectItemDTOSave search) {
		//set info change
		retMulti.setId(search.getItemId());
		retMulti.setLabel(search.getColumnLabel());
		retMulti.setHtmlElement(search.getHtmlElement());
		retMulti.setSelectableListDto(new SelectableListDto(search.getSelectableListItems()));
		retMulti.setSelectableSql(search.getSqlString());
		if (retMulti.getRestrictionsDto() != null && retMulti.getRestrictionsDto().getRestrictionDtoList() != null) {
			retMulti.getRestrictionsDto().getRestrictionDtoList().clear();
		}
		for (restrictionsDTO item : search.getRestrictionsItems()) {
			if (item.getValueRes().equals("true")) {
				retMulti.getRestrictionsDto().getRestrictionDtoList().add(new RestrictionDto(item.getIdRes(), "true"));
			}
		}
		retMulti.setParametersSql(search.getSqlParameters());
		retMulti.set_default(search.getDefaultValue());
		retMulti.setExplanation(search.getExplanation());
		retMulti.setCanPreview(search.getCanPreview());
		retMulti.setCanDisplayRecordEdit(search.getCanDisplayRecordEdit());
		retMulti.setCanDisplayNamePreview(search.getCanDisplayNamePreview());
		if (search.getCanEditing() != null) {
			retMulti.setCanEditing(search.getCanEditing());
		}
		if (search.getIsUpdateKey() != null) {
			retMulti.setIsUpdateKey(search.getIsUpdateKey());
		}
		if (search.getIsSelectKey() != null) {
			retMulti.setIsSelectKey(search.getIsSelectKey());
		}
	}

    /**
     * PreservationFormComponentInfomationRepositoryLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public PreservationFormComponentInfomationRepositoryLogic() {
        return;
    }

    /**
     * テーブルフォーム DAO を生成して戻す。
     *
     * @return TableFormDAO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDAO createTableFormDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

}
