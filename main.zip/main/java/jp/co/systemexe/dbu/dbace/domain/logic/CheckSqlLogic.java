package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.DbConnectDefinitionDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAOFactory;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;

/**
 * プルダウンリスト表示値取得用の SQL 文の妥当性検証ロジック。
 * <p>
 * プルダウンリストに表示するためのユーザー定義 SQL 文の妥当性を検証するビジネス
 * ロジックです。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @author EXE 相田 一英
 * @author EXE 鈴木 伸祐
 * @author EXE 六本木 圭
 * @version 0.0.0
 */
public class CheckSqlLogic extends BaseApplicationDomainLogic {

    /**
     * SQL 文を実際に実行し、得られたレコードをリストに設定して戻します。
     * <p>
     * 得られた結果セット（コレクションに設定された）に対し、プルダウンリスト
     * 表示に使用できるかどうかの妥当性を検証します。<br />
     * 検証事項は以下の通り。
     * <ol>
     *  <li>SQL 文が空である。</li>
     *  <li>文の先頭が「select」以外で開始している。</li>
     *  <li>キーに値が設定されている事（null 或いは空文字が存在しない）。</li>
     *  <li>取得件数が 0 では無い。</li>
     *  <li>取得件数が 1,000 以下である。</li>
     * </ol>
     * なお、結果セットは SortedMap に設定されて DAO から戻ってくるため、
     * キーの重複はもともと発生しません。また、カラム数が二つに満たない場合は
     * DAO が例外をスローします。
     * </p>
     *
     * @param sql SQL文
     * @param dto データベース接続定義情報 DTO
     * @param connectionUserLabel 接続ユーザー表示名
     * @throws ApplicationDomainLogicException 独自例外定義
     */
    public SelectOneMenuItem[] checkOf(final String sql,
            final DbConnectDefinitionDTO dto,
            final UserInfo userInfo
            )
            throws ApplicationDomainLogicException {
        if (sql == null || sql.equals("")) {
        	// MI-E-0014=SQL 文が指定されていません。
            throw new ApplicationDomainLogicException(
            		MessageUtils.getMessage("MI-E-0014"));
        }
        if (sql.trim().replace(System.getProperty("line.separator"), " ").matches("^[sS][eE][lL][eE][cC][tT].*") == false) {
        	// MI-E-0011=入力されたSQL文は、select文ではありません。
            throw new ApplicationDomainLogicException(
            		MessageUtils.getMessage("MI-E-0011"));
        }
        final SelectOneMenuItem[] ret = getResut(sql, dto, userInfo);
        if (ret == null || ret.length <= 0) {
        	// MI-E-0059=レコードの取得件数が 0 件です。
            throw new ApplicationDomainLogicException(MessageUtils.getMessage("MI-E-0059"));
        }
        final int pulldownMaxCount = SystemProperties.getPulldownMaxCount();
        if (ret.length > pulldownMaxCount) {
        	// MI-E-0058=レコードの取得件数が {0} 件を超えています。
        	final String args[] = {String.valueOf(pulldownMaxCount)};
            throw new ApplicationDomainLogicException(
            		MessageUtils.getMessage("MI-E-0058", args));
        }
        for (final SelectOneMenuItem item : ret) {
            final String key = item.getValue();
            if (key == null || key.equals("")) {
            	// MI-E-0008={0}は必須入力項目です。
            	final String args[] = {"キー値"};
                throw new ApplicationDomainLogicException(
                        MessageUtils.getMessage("MI-E-0008", args));
            }
        }
        return ret;
    }

    /**
     * SQL 文を実際に実行し、得られたレコードをマップに設定して戻します。
     *
     * @param sql
     * @param def
     * @param connectionUserLabel 接続ユーザー表示名
     * @return SelectOneMenuItem
     * @throws ApplicationDomainLogicException
     */
    private SelectOneMenuItem[] getResut(final String sql,
            final DbConnectDefinitionDTO def,
            final UserInfo userInfo
            )
            throws ApplicationDomainLogicException {
        final DbConnectInfomationDTO dto = new DbConnectInfomationDTO();
        dto.setDatabaseId(def.getDatabaseId());
        dto.setPassword(def.getPassword());
        dto.setPortId(def.getPort());
        dto.setServerId(def.getServerId());
        dto.setUserId(def.getPid());
        dto.setDatabaseTypeConnectionDestination(def.getDatabaseTypeConnectionDestination());
        dto.setUseDatabaseUrl(def.isUseDatabaseUrl());
        dto.setDatabaseUrl(def.getDatabaseUrl());
        dto.setInstanceName(def.getInstanceName());

        DatabaseTableDAO dao = null;
        final SelectOneMenuItem[] ret;
        try {
            dao = DatabaseTableDAOFactory.createDatabaseTableDAO(def.getDatabaseTypeConnectionDestination());
            dao.connect(dto);
            ret = dao.getSelectableMap(sql);

        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        } finally {
            try {
            	if (dao != null) {
            		dao.close();
            	}
            } catch (final DAOException e) {
                throw new ApplicationDomainLogicException(e.getMessage(), e);
            }
        }
        return ret;
    }

    /**
     * CheckSqlLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public CheckSqlLogic() {
        super();
    }
}