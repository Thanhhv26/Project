/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.UUID;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportResultDTO;

/**
 * データ一括インポートにおける、エラーメッセージ情報ファイル入出力
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class FileImportResultDAO extends BaseFileImportResultDAO {

    /**
     * ファイルを削除します。読み込みます。
     *
     * @param fileName ファイル名
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseFileImportResultDAO#deleteFile(java.lang.String)
     */
    @Override
    public void deleteFile(final String fileName) {
        final String filePath =
        	SystemProperties.getImportTempFilePath() + File.separator + fileName;
        final File file = new File(filePath);
        file.delete();
    }

    /**
     * ファイルを読み込みます。
     *
     * @param fileName ファイル名
     * @return FileImportResultDTO
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseFileImportResultDAO#inputFile(java.lang.String)
     */
    @Override
    public FileImportResultDTO inputFile(final String fileName)
            throws DAOException {
        FileInputStream inFile = null;
        ObjectInputStream inObject = null;
        try {
            final String filePath =
            	SystemProperties.getImportTempFilePath() + File.separator + fileName;
            inFile = new FileInputStream(filePath);
            inObject = new ObjectInputStream(inFile);

            while (true) {
            	return (FileImportResultDTO)inObject.readObject();
            }
        } catch (final FileNotFoundException e) {
        	// MI-E-0145=データの一括登録(更新)の後処理に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0145");
            getLogger().fatal(message, e);
            throw new DAOException(message);
        } catch (final EOFException e) {
            // 読み込み終了
        } catch (final IOException e) {
        	// MI-E-0145=データの一括登録(更新)の後処理に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0145");
            getLogger().fatal(message, e);
            throw new DAOException(message);
        } catch (final ClassNotFoundException e) {
        	// MI-E-0145=データの一括登録(更新)の後処理に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0145");
            getLogger().fatal(message, e);
            throw new DAOException(message);
        } finally {
            if (inObject != null) {
                try {
                    inObject.close();
                } catch (final IOException e) {
                }
            }
            if (inFile != null) {
                try {
                    inFile.close();
                } catch (final IOException e) {
                }
            }
        }
        return new FileImportResultDTO();
    }

    /**
     * ファイル出力を行います。
     *
     * @param dto
     * @return filePath ファイル名
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseFileImportResultDAO#outputFile(FileImportResultDTO)
     */
    @Override
    public String outputFile(
            final FileImportResultDTO dto)
            throws DAOException {
        FileOutputStream outFile = null;
        ObjectOutputStream outObject = null;

        final String fileName = UUID.randomUUID().toString();
        final String filePath =
        	SystemProperties.getImportTempFilePath() + File.separator + fileName;
        //create directory if not exist
        File file = new File(filePath);
        file.getParentFile().mkdirs();
        try {
            outFile = new FileOutputStream(filePath, false);
            outObject = new ObjectOutputStream(outFile);
            outObject.writeObject(dto);
        } catch (final IOException e) {
        	// MI-E-0145=データの一括登録(更新)の後処理に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0145");
            getLogger().fatal(message, e);
            throw new DAOException(message);
        } finally {
            if (outObject != null) {
                try {
                    outObject.close();
                } catch (final IOException e) {
                }
            }
            if (outFile != null) {
                try {
                    outFile.close();
                } catch (final IOException e) {
                }
            }
        }

        return fileName;
    }
}
