/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * 日付の様式の妥当性をチェックするユーティリティクラス。
 *
 * @author EXE 島田 雄一郎
 *
 */
public class DateCheckUtility {
    /**
     * 日付の様式の妥当性をチェックする・メソッド。
     *
     * @param value チェック対象日付情報。
     * @param pattern 日付と時刻のフォーマットを記述するパターン(java.text.SimpleDateFormat参照)。
     * @return true: 妥当 / false:妥当ではない。
     */
    public static final boolean isDateStyleCheck(
            final String value,
            final String pattern) {
        final SimpleDateFormat format = new SimpleDateFormat(pattern);
        format.setLenient(false);
        try {
            format.parse(value);
        } catch (final ParseException e) {
            return false;
        }
        return true;
    }
}
