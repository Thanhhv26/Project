/**
 * @Copyright - 2015 SystemEXE-VN
 */
package jp.co.systemexe.dbu.dbace.common.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;

/**
 * @author tu-lenh
 *
 */
public class ValidlkAuthenticationPrincipalInputRequiredException extends AuthenticationException implements IUtilException {
	private final Logger logger = LoggerFactory.getLogger(ValidlkAuthenticationPrincipalInputRequiredException.class);
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public ValidlkAuthenticationPrincipalInputRequiredException(String message) {
		super(message);
		logger.error(message);
	}

	/**
	 * Constructor.
	 */
	public ValidlkAuthenticationPrincipalInputRequiredException(String message, Throwable cause) {
		super(message, cause);
		logger.error(message, cause);
	}

}
