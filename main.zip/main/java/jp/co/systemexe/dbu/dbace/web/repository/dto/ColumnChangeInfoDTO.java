/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class ColumnChangeInfoDTO {
	private String actionColumn;
	private String userId;
	private String connectDefinitionId;
	private String tableId;
	private String itemId;
	private String dataType;
	private String dataLength;
	private String dataUnit;

	/**
	 * @param actionColumn
	 * @param userId
	 * @param connectDefinitionId
	 * @param tableId
	 * @param itemId
	 * @param dataType
	 * @param dataLength
	 * @param dataUnit
	 */
	public ColumnChangeInfoDTO(String actionColumn, String userId, String connectDefinitionId, String tableId,
			String itemId, String dataType, String dataLength, String dataUnit) {
		this.actionColumn = actionColumn;
		this.userId = userId;
		this.connectDefinitionId = connectDefinitionId;
		this.tableId = tableId;
		this.itemId = itemId;
		this.dataType = dataType;
		this.dataLength = dataLength;
		this.dataUnit = dataUnit;
	}

}