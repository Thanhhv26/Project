/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.Map;
import java.util.SortedMap;

import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.domain.dto.TableLabeDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.TableLabeExtendConnectDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;

/**
 * テーブルフォーム DAO。
 * <p>
 * リポジトリ内の、各テーブルに対応した画面設定（テーブルフォーム）情報への
 * DAO です。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public interface TableFormDAO {

    /**
     * テーブルフォーム情報の登録があるか否かを戻します。
     * <p>
     * テーブルフォーム情報が一件以上登録されていれば true を、一件も無ければ
     * false を戻します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @return true : 登録あり / false : 登録なし
     * @throws DAOException
     */
    public boolean hasTableForms(final String connectDefinitionId)
            throws DAOException;
    /**
     * テーブルフォーム情報の登録があるか否かを戻します。
     * <p>
     * テーブルフォーム情報が一件以上登録されていれば true を、一件も無ければ
     * false を戻します。</p>
     *
     * @param connectDefinitionLabel 接続定義名
     * @return true : 登録あり / false : 登録なし
     * @throws DAOException
     */
    public boolean hasTableFormsByConnectName(final String connectDefinitionId)
            throws DAOException;

    /**
     * テーブル名の一覧マップを戻します。
     * <p>
     * リポジトリに設定済みのテーブル名一覧を戻します。なお、テーブルフォーム ID
     * はテーブル名と同じ値です。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @return TableLabeDTO テーブル名リスト
     * @throws DAOException 独自定義例外
     */
    public SortedMap<String, TableLabeDTO> getTableNameMap(final String connectDefinitionId)
            throws DAOException;
    public SortedMap<String, TableLabeDTO> getAllTableNameMap(final String connectDefinitionId)
            throws DAOException;
    public SortedMap<String, TableLabeDTO> getTableNameMapByConnectName(final String connectDefinitionId)
            throws DAOException;
    SortedMap<String, TableForm> getTableFormsMapByConnectName(final String connectDefinitionId)
    		throws DAOException;
    public boolean isMultiTable(final String connectDefinitionId, final String tableFormId)
            throws DAOException;
    public SortedMap<String, TableLabeExtendConnectDTO> getAllTableNameMap(UserInfoDTO userInfoDTO) throws DAOException;
    public SortedMap<String, TableLabeExtendConnectDTO> getAllTableNameConnectTypeMap(final String connectDefinitionId) throws DAOException;
    /**
     * テーブルフォーム DTO を戻します。
     * <p>
     * 接続定義 ID、テーブルフォーム IDの組み合わせで、リポジトリから、
     * 各テーブルに対応した、画面上での制御情報を保持したテーブルフォーム DTO を
     * 取得して戻します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブルフォーム ID
     * @return TableFormDTO テーブルフォーム DTO
     * @throws DAOException 独自定義例外
     */
    public TableFormDTO getTableFormDTO(final String connectDefinitionId,
            final String tableFormId) throws DAOException;

    public TableItemDTO getTableItemDTO(final String connectDefinitionId,
            final String tableFormId, final String tableItemId) throws DAOException;

    public TableForm getTargetTableFormMulti(final String connectDefinitionId,
            final TableFormDto dto) throws DAOException ;
    public Map<String,TableForm> getAllTableFormMulti(final String connectDefinitionId) throws DAOException;

    /**
     * テーブルフォーム DTO を戻します。
     * <p>
     * 接続定義 ID、テーブルフォーム IDの組み合わせで、リポジトリから、
     * 各テーブルに対応した、画面上での制御情報を保持したテーブルフォーム DTO を
     * 取得して戻します。</p>
     *
     * @param connectDefinitionlabel 接続定義 Label
     * @param tableFormId テーブルフォーム ID
     * @return TableFormDTO テーブルフォーム DTO
     * @throws DAOException 独自定義例外
     */
    public TableFormDTO getTableFormDTOByConnectName(final String connectDefinitionId,
            final String tableFormId) throws DAOException;
    /**
     * テーブルフォーム DTO を保存します。
     * <p>
     * 接続定義 ID、テーブルフォーム DTO の組み合わせで、リポジトリに、
     * 各テーブルに対応した、画面上での制御情報を保持したテーブルフォーム DTO を
     * 保存します。
     * </p><p>
     * 既登録の情報であれば上書きを、未登録情報であれば新規に追加します。
     * </p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param dto テーブルフォーム DTO
     * @throws DAOException 独自定義例外
     */
    public void save(final String connectDefinitionId, final TableFormDTO dto)
            throws DAOException;

    /**
     * テーブルフォームを削除します。
     * <p>
     * リポジトリ内のテーブルフォーム要素を削除します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブルフォーム ID（＝スキーマ名.テーブル名）
     * @throws DAOException DAO 例外
     */
    public void remove(final String connectDefinitionId,
            final String tableFormId) throws DAOException;

    public void saveTableMulti(final String connectDefinitionId, final TableFormDto dto)
            throws DAOException;

    public String getConnectDefinitionIdByConnectName(final String connectDefinitionName) throws DAOException;
}
