/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseDbTransactionAbstractDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.InputDto;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;

/**
 * データベースのレコード更新ロジック。
 * <p>
 * </p>
 *
 * @author EXE 相田 一英
 * @version 0.0.0
 */
public class RecordDeleteProcessingOfDatabaseLogic extends BaseDbTransactionAbstractDomainLogic {
	private UserInfo userInfo;
	private List<RecordSearchConditionDTO> listRecordDeleteConditionDTO = new ArrayList<RecordSearchConditionDTO>();

	public RecordDeleteProcessingOfDatabaseLogic(UserInfo userInfo){
		this.userInfo = userInfo;
	}

	public void addProcess(RecordSearchConditionDTO recordDeleteConditionDTO) {
		listRecordDeleteConditionDTO.add(recordDeleteConditionDTO);
	}

	public boolean hasProcesses(){
		return listRecordDeleteConditionDTO.size() > 0;
	}

	@Override
	protected void doBusinessLogic(InputDto inputDto, DatabaseTableDAO databaseTableDAO)
			throws ApplicationDomainLogicException, DAOException {
		final RetrievalProcessingOfRecordFromDatabaseLogic recordLogic = new RetrievalProcessingOfRecordFromDatabaseLogic();
		// ③RDBへのデータメンテナンスを処理順(CommitNO)の降順で行う。トランザクションの開始
		for (RecordSearchConditionDTO recordDeleteConditionDTO : listRecordDeleteConditionDTO) {
			try{
			TableDefinitionDTO tableDefinitionDTO = recordLogic.getTableDefinitionDTO(recordDeleteConditionDTO.getConnectDefinitionId(), recordDeleteConditionDTO.getTableId(), userInfo.getId());
			databaseTableDAO.doDelete(recordDeleteConditionDTO, tableDefinitionDTO, recordDeleteConditionDTO.getTableId(), userInfo);
			}catch (DAOException e) {
				// 処理の途中でエラーとなった場合は、ロールバックを行い、「XXX(テーブル表示名)の(DELETE)処理でエラーになりました。」とエラーメッセージを出力。
				// DELETEのそれぞれの結果が「1」以外がある場合、ロールバックを行い、「XXXテーブルのキー設定が不正です。」とエラーメッセージを出力。
				String[] args = { recordDeleteConditionDTO.getTableLabel() };
				String errorString = MessageUtils.getMessage("FRM0200.delete.E1-002", args);
				throw new ApplicationDomainLogicException(errorString);
			}
		}
	}

}
