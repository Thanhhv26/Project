/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.relation.dto;

import java.util.List;

import lombok.Data;

/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationCreateInfoDTO {
	String relationId;
	String relationName;
    String joinType;
	// connect A
	String connectDefinitionId;
	// Schema A
	String schema;
	// Table A
	String table;
	String tableLabel;
	// list column and column reference
	List<RelationCreateColumnNameDefDTO> columnNameDefList;
	// connect B
	String connectDefinitionIdR;
	// Schema B
	String schemaR;
	// Table B
	String tableR;
	String tableRLabel;
	String colJoinsAddLength;
}
