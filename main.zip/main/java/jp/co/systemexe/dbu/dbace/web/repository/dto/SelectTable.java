/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import lombok.Data;
@Data
public class SelectTable {
	// テーブルId
	String tableId;
	// テーブル名
	String tableName;
	// リポジトリ登録・未登録
	String status;
}
