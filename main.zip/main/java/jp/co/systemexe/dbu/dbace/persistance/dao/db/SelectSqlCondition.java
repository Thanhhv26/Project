/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.db;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;
import lombok.Getter;
import lombok.Setter;

/**
 * 検索用の複雑な検索条件を保持する VO。
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class SelectSqlCondition {

    /**
     * 対象テーブル名。
     */
    private String tableId;

    /**
     * normal or multi table
     */
    private String type;

    /**
     * 更新値マップ。
     */
    private Map<String, String> valuesMap = new HashMap<String, String>();

    /**
     * All columns in table form
     */
    private Map<String, TableItemDTO> columnsMap = new HashMap<String, TableItemDTO>();

    /**
     *
     */
    private SortedMap<String, ApplicationRelationDTO> joinsMap = new TreeMap<String, ApplicationRelationDTO>();

    /**
     * 条件値マップ。
     */
    private SortedMap<Integer, SelectConditionItem> wheresMap = new TreeMap<Integer, SelectConditionItem>();

    /**
     * 並び順マップ。
     */
    private SortedMap<Integer, String> ordersMap = new TreeMap<Integer, String>();

    /**
     *
     */
    private Map<String, TableDto> tablesMap = new HashMap<String, TableDto>();

    /**
     * 並び順の昇順フラグ。
     * <p>true : 昇順（デフォルト） / false : 降順</p>
     */
    private boolean orderAsc = true;
    
    /**
     * index => begin select
     */
    @Getter
    @Setter
    private int offSet;
    
	/**
	 * number of records
	 */
    @Getter
    @Setter
	private int limit;

    /**
     * 並び順の昇順フラグを戻します。
     * <p>true : 昇順（デフォルト） / false : 降順</p>
     *
     * @return boolean
     */
    public boolean isOrderAsc() {
        return orderAsc;
    }

    /**
     * 並び順の昇順フラグを設定します。
     * <p>true : 昇順（デフォルト） / false : 降順</p>
     *
     * @param boolean orderAsc
     */
    public void setOrderAsc(boolean orderAsc) {
        this.orderAsc = orderAsc;
    }

    /**
     * 対象テーブル名を戻します。
     *
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * 対象テーブル名を設定します。
     *
     * @param String tableId
     */
    public void setTableId(String tableId) {
        this.tableId = tableId;
    }

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

    /**
     * 更新値マップを戻します。
     *
     * @return Map&lt;カラム名,更新値&gt;
     */
    public Map<String, String> getValuesMap() {
        return valuesMap;
    }

    /**
     * 更新値を追加します。
     *
     * @param columnName カラム名
     * @param value 更新値
     */
    public void addValues(final String columnName, final String value) {
        valuesMap.put(columnName, value);
    }

    /**
     * 条件値マップを戻します。
     *
     * @return Map&lt;カラム名,条件値アイテム&gt;
     */
    public SortedMap<Integer, SelectConditionItem> getWheresMap() {
        return wheresMap;
    }

    /**
     * 条件値マップを追加します。
     * <p>
     * カラム名 = A で表現される単純な条件しか指定できません。</p>
     *
     * @param columnName カラム名
     * @param item 条件値アイテム
     */
    public void addWheres(final Integer index,
            final SelectConditionItem item) {
        wheresMap.put(index, item);
    }

    /**
     * ordersMap を戻します。
     *
     * @return SortedMap<Integer,String>
     */
    public SortedMap<Integer, String> getOrdersMap() {
        return ordersMap;
    }

    /**
     * 並び順マップに項目を追加します。
     * <p>
     * index で指定した順番に order by がかかります。</p>
     *
     * @param index 昇順並び優先順
     * @param columnName カラム名
     */
    public void addOrders(final int index, final String columnName) {
        ordersMap.put(index, columnName);
    }

    /**
     * SelectSqlCondition の生成。
     * <p>コンストラクタ。</p>
     */
    public SelectSqlCondition() {
        return;
    }

	/**
	 * @return the joinsMap
	 */
	public SortedMap<String, ApplicationRelationDTO> getJoinsMap() {
		return joinsMap;
	}

	/**
	 *
	 * @param relationId
	 * @param relationInformation
	 */
    public void addRelation(final String relationId, final ApplicationRelationDTO relationInformation) {
    	joinsMap.put(relationId, relationInformation);
    }

    /**
     *
     * @param columnId
     * @param tableItemDTO
     */
    public void addColumn(final String columnId, final TableItemDTO tableItemDTO) {
    	columnsMap.put(columnId, tableItemDTO);
    }

	/**
	 * @return the columnsMap
	 */
	public Map<String, TableItemDTO> getColumnsMap() {
		return columnsMap;
	}

	/**
	 * @param columnsMap the columnsMap to set
	 */
	public void setColumnsMap(Map<String, TableItemDTO> columnsMap) {
		this.columnsMap = columnsMap;
	}

	/**
	 * @return the tablesMap
	 */
	public Map<String, TableDto> getTablesMap() {
		return tablesMap;
	}

	/**
	 * @param tablesMap the tablesMap to set
	 */
	public void setTablesMap(Map<String, TableDto> tablesMap) {
		this.tablesMap = tablesMap;
	}


}
