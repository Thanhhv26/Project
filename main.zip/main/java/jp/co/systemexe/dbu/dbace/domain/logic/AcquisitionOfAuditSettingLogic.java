/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.AuditSettingDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 監査ログ設定情報の取得処理。
 * <p>
 * 監査ログ設定情報の編集のため、監査ログ設定情報XMLから監査ログ設定情報を取得します。</p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class AcquisitionOfAuditSettingLogic
        extends BaseApplicationDomainLogic {
    
    /**
     * 監査ログ設定情報を戻す。
     * <p>
     * 画面への表示のために、監査ログ設定情報を取得して戻します。</p>
     * 
     * @return 監査ログ設定情報
     * @throws ApplicationDomainLogicException
     * @throws DAOException 
     */
    public AuditSettingDTO getAuditSetting()
            throws ApplicationDomainLogicException, DAOException {
        final AuditSettingDAO auditSettingDAO = createAuditSettingDAO();
        return auditSettingDAO.getAuditSettingDTO();
    }

    /**
     * AcquisitionOfAuditSettingLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public AcquisitionOfAuditSettingLogic() {
        return;
    }

    /**
     * 監査ログ設定情報 DAO を生成して戻す。
     * 
     * @return AuditSettingDAO
     * @throws ApplicationDomainLogicException
     */
    private AuditSettingDAO createAuditSettingDAO()
            throws ApplicationDomainLogicException {
        try {
            return (AuditSettingDAO)createDAO("AuditSettingDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
