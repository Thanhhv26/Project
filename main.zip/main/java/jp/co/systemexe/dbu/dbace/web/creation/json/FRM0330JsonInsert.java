package jp.co.systemexe.dbu.dbace.web.creation.json;

import java.io.Serializable;
import java.util.List;

import org.springframework.security.core.context.SecurityContextHolder;

import jp.co.systemexe.dbu.dbace.library.service.certification.MyUserDetails;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.web.creation.dto.OptionalDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import lombok.Data;

@Data
public class FRM0330JsonInsert implements Serializable {

	private static final long serialVersionUID = 1L;

	private OptionalDto optionalDto;

	private TableFormDto tableFormDto;

	/*check key*/
	private String connectionId;
	private List<String> tableAndItems;
	private List<String> itemLabels;

    //object insert, update, copy, view
	private String actionUIRD;
	private String connectionIdUIRD;
	private TableFormDto tableUIRD;

    //object delete
	private String d_connectionID;
	private String d_tableID;
	private String d_tableLabel;
	
	private UserAuthority userAuthority;    
	private UserInfo userInfo;
	
	/**
     * @return UserInfo
     */
    public UserInfo getUserInfo(){
    	if(userInfo == null){
    		MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        	userInfo = myUserDetails.getUserInfo();
    	}
        return userInfo;
    }
    
    /**
     * @return
     */
	public UserAuthority getUserAuthority() {
		if(userAuthority == null){
			MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			userAuthority = myUserDetails.getUserInfoDTO().getUserAuthority();
		}		
		return userAuthority;
	}
}
