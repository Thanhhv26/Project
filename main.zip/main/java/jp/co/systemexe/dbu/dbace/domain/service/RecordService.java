/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service;

import java.util.List;

//import org.springframework.web.bind.annotation.RequestBody;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportResultDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.IdSelectTableLabeExtendConnectDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.record.dto.DownloadFileInfo;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DataParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DataResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DeleteParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DeleteResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200DownloadResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200LoadParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200LoadResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200SearchParam;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200SearchResultModel;
import jp.co.systemexe.dbu.dbace.web.record.dto.SelectTargetedColumnSearchCondition;

/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 Mar 15, 2017
 */
public interface RecordService {

	/**
	 * Load record from(Use in edit, view, copy & delete sub screen)
	 * @param loadParam
	 * @return FRM0200LoadResultModel
	 * @author bao-anh
	 */
	public FRM0200LoadResultModel doLoadRecord(FRM0200LoadParam loadParam)throws ApplicationDomainLogicException;

	/**
	 * Load list table name(include single & multi tables)
	 * @return List<IdSelectTableLabeExtendConnectDTO>
	 * @author bao-anh
	 */
	public List<IdSelectTableLabeExtendConnectDTO> getAllTableList(UserInfoDTO userInfoDTO) throws ApplicationDomainLogicException;

	/**
	 * Download file
	 * @param param
	 * @param response
	 * @param result
	 * @author bao-anh
	 */
	public FRM0200DownloadResultModel doDownload(DownloadFileInfo param)throws ApplicationDomainLogicException;
	/**
	 * Delete record in RDB.
	 * @param deleteParam
	 * @return FRM0200DeleteResultModel
	 * @author bao-anh
	 */
	public FRM0200DeleteResultModel doOnceDelete(FRM0200DeleteParam deleteParam)throws ApplicationDomainLogicException;

	/**
	 * Load data list for the field dropdown.
	 * @param searchParam
	 * @return List<SelectableItem>
	 * @author bao-anh
	 */
	public List<SelectableItem> doSearchSelectObjectList(SelectTargetedColumnSearchCondition searchParam)throws ApplicationDomainLogicException;

	/**
	 * Search data for single & multi table
	 * @param searchParam
	 * @return
	 * @author bao-anh
	 */
	public FRM0200SearchResultModel doSearchData(FRM0200SearchParam searchParam)throws ApplicationDomainLogicException;
	/**
	 * Init search data screen for single & multi table
	 * @param searchParam
	 * @return FRM0200SearchResultModel
	 * @author bao-anh
	 */
	public FRM0200SearchResultModel doInitSearch(FRM0200SearchParam searchParam)throws ApplicationDomainLogicException;


	/**
	 *
	 * @param searchParam
	 * @return
	 * @author bao-anh
	 */
	public FRM0200SearchResultModel doOutputSearchCondition(FRM0200SearchParam searchParam) throws ApplicationDomainLogicException;

	/**
	 *
	 */
	public FRM0200DownloadResultModel validateDownload(DownloadFileInfo param) throws ApplicationDomainLogicException;
	/**
	 *
	 * @param EnvironmentDto
	 * @return
	 * @throws ApplicationRuntimeException
	 */
	public FRM0200DataResultModel doInsertTable(FRM0200DataParam model) throws ApplicationDomainLogicException;
	public FRM0200DataResultModel doOnceSaveDataTable(FRM0200DataParam model) throws ApplicationDomainLogicException;
	public FileImportResultDTO importFile(String connectDefinisionId,
			String tableId,
			String fileUploadPath,
			String characterEncodingType,
			boolean skipErrors,
			boolean overwriteData,UserInfo userInfo)  throws ApplicationDomainLogicException;
	public FileImportResultDTO importFileMultiTable(String connectDefinisionId,
			String tableId,
			String fileUploadPath,
			String characterEncodingType,
			boolean skipErrors,
			boolean overwriteData,UserInfo userInfo)  throws ApplicationDomainLogicException;

	public FRM0200DataResultModel getColumnSelectPulldownOnchange(FRM0200DataParam model) throws ApplicationDomainLogicException;
	
	/**
	 * get connection infomation => infomation which connect to database
	 * 
	 * @param connectionId
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public DbConnectInfomationDTO getDbConnectInfomationDTO(final String connectionId) throws ApplicationDomainLogicException;
	
	/**
	 * @param searchParam
	 * @return
	 */
	public RecordSearchConditionDTO getRecordSearchConditionDTO(final FRM0200SearchParam searchParam);
	
	/**
	 * @param searchParam
	 * @return
	 * @throws ApplicationDomainLogicException
	 */
	public TableFormDTO getTableFormDTO(final FRM0200SearchParam searchParam) throws ApplicationDomainLogicException;
}
