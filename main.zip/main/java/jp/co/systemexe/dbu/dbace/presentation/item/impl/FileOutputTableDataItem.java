/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;

/**
 * テーブルデータファイル出力形式表示用の Item クラスです。
 * <p>
 * SelectOneMenuItem インターフェースを実装した、リストアイテムクラスです。
 * </p><p>
 * ItemsSave を使用した HTML 中への永続化のため Serializable インターフェースを
 * 実装しています。
 * </p>
 *
 * @author	EXE 島田 雄一郎
 * @version 0.0.0
 */
public class FileOutputTableDataItem implements SelectOneMenuItem, Serializable {

    /**
     * <code>serialVersionUID</code>。
     */
    private static final long serialVersionUID = 2709691944868903868L;

    /**
     * テーブルデータファイル出力形式表示名を保持します。
     */
    private String label;

    /**
     *  テーブルデータファイル出力形式 を保持します。
     */
    private String value;

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getLabel()
     */
    public String getLabel() {
        return label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getValue()
     */
    public String getValue() {
        return value;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setLabel(java.lang.String)
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setValue(int)
     */
    public void setValue(String value) {
        this.value = value;
    }
}
