/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import java.util.HashMap;
import java.util.Map;

/**
 * リポジトリ登録・未登録、DBから欠落定義 enum。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum RegisteredInRepository {
    REGISTERED("registered", "registered.value", true),
    CHANGED("changed", "changed.value", true),
    WARNING("warning", "warning.value", true),
    UN_REGISTERED("un_registered", "un_registered.value", true),
    ;

    private final String key;
    private final String value;
    private final boolean visible;

    private static Map<String, RegisteredInRepository> map;
    static {
        map = new HashMap<String, RegisteredInRepository>();
        for (final RegisteredInRepository buff : values()) {
            map.put(buff.getKey(), buff);
        }
    }

    public static RegisteredInRepository keyOf(final String key) {
        if (map.containsKey(key)) {
            return map.get(key);
        } else {
            return null;
        }
    }

    /**
     * key を戻します。
     *
     * @return String
     */
    public String getKey() {
        return key;
    }
    /**
     * value を戻します。
     *
     * @return String
     */
    public String getValue() {
        return value;
    }

    /**
     * visible を戻します。
     *
     * @return boolean
     */
    public boolean isVisible() {
        return visible;
    }

    private RegisteredInRepository(
            final String key,
            final String value,
            final boolean visible) {
        this.key = key;
        this.value = value;
        this.visible = visible;
    }

}
