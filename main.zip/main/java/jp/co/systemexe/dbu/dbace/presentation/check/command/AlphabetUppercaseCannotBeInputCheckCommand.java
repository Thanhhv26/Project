/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.ItemRestriction;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;

/**
 * アルファベット大文字入力不可チェック。
 * <p>
 * アルファベット大文字入力を禁じる項目用のチェックコマンドです。</p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class AlphabetUppercaseCannotBeInputCheckCommand extends BaseLogicalCheckCommand {

    /**
     * 「アルファベット大文字」の範囲定義正規表現文字列。
     */
    private static final String REGEX = ".*[A-ZＡ-Ｚ]+.*";

    /**
     * AlphabetCannotBeInputCheckCommand の生成。
     * <p>コンストラクタ。</p>
     */
    public AlphabetUppercaseCannotBeInputCheckCommand() {
        return;
    }

    /**
     * 検査を実行します。
     * <p>
     * アルファベット大文字を検出した場合、警告を
     * 設定した上で、アルファベット大文字を除外した補正値を設定します。
     * </p><p>
     * null または空文字だった場合は検査を行いません。</p>
     *
     * @param columnId カラム名
     * @param messages 論理チェック結果メッセージ保持 DTO
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#check(java.lang.String, jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO)
     */
    @Override
    public void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
 		final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap) {
        final String value = messages.getCorrectedValue(columnId);
        if (value == null || value.equals("")) {
            return;
        }
        if (value.matches(REGEX)) {
        	// MI-E-0020={0}に{1}は入力できません。
        	String columnLabel = tableItemMap.get(columnId).getItemLabel();
        	final String args[] = {columnLabel,"アルファベット大文字"};
            messages.getMessages(columnId).add(
            		MessageUtils.getMessage("MI-E-0020", args));
        }
    }

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * このクラスが検査対象とする条件は、
     * <ol>
     *  <li>リポジトリの入力値制約に ALPHABET_CANNOT_BE_INPUT 制約が存在する場合。</li>
     * </ol>
     * </p>
     *
     * @param columnId
     * @return true : 検査担当 / false : 担当ではない
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#isMyTask(java.lang.String)
     */
    @Override
    protected boolean isMyTask(final String columnId) {
        final TableItemDTO item = getDisplayDef().getItemDefinitions().get(
            columnId);
        if (item.getItemRestrictions().containsKey(
            ItemRestriction.ALPHABET_UPPERCASE_CANNOT_BE_INPUT)) {
            return true;
        } else {
            return false;
        }
    }
}
