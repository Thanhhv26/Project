package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 画面制御情報の取得処理。
 * <p>
 * 接続定義情報の編集のため、リポジトリから画面制御情報を取得します。</p>
 *
 * @author EXE 鈴木 伸祐
 * @author EXE 六本木 圭
 * @version 0.0.0
 */
public class AcquisitionOfTableItemInformationLogic
        extends BaseApplicationDomainLogic {

    /**
     * テーブル項目定義情報を戻します。
     * <p>
     * 指定されたテーブルの各項目の、情報を取得し、DTO にて返します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブル ID
     * @param columnId カラム ID
     * @return TableItemDTO
     * @throws ApplicationDomainLogicException
     */
    public TableItemDTO getItemInformation(final String connectDefinitionId,
            final String tableFormId, final String columnId)
            throws ApplicationDomainLogicException {
        final TableFormDTO form = getTableFormDTO(connectDefinitionId,
            tableFormId);
        if (form == null) {
        	// MI-E-0033=テーブル情報が存在しません。
            throw new ApplicationDomainLogicException(
            		MessageUtils.getMessage("MI-E-0033"));
        }
        final TableItemDTO ret = form.getTableItemMap().get(columnId);
        return ret;
    }

    /**
     * テーブル項目定義情報を戻します。
     * <p>
     * 指定されたテーブルの各項目の、情報を取得し、DTO にて返します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブル ID
     * @param columnId カラム ID
     * @return TableItemDTO
     * @throws ApplicationDomainLogicException
     */
    public TableItemDTO getItemInformationByConnectLable(final String connectDefinitionId,
            final String tableFormId, final String columnId)
            throws ApplicationDomainLogicException {
        final TableFormDTO form = getTableFormDTOByConnectLable(connectDefinitionId,
            tableFormId);
        if (form == null) {
        	// MI-E-0033=テーブル情報が存在しません。
            throw new ApplicationDomainLogicException(
            		MessageUtils.getMessage("MI-E-0033"));
        }
        final TableItemDTO ret = form.getTableItemMap().get(columnId);
        return ret;
    }

    /**
     * リポジトリからテーブルフォーム情報を取得して戻します。
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブル ID
     * @return TableFormDTO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDTO getTableFormDTO(final String connectDefinitionId,
            final String tableFormId) throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        final TableFormDTO ret;
        try {
            ret = dao.getTableFormDTO(connectDefinitionId, tableFormId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return ret;
    }

    /**
     * リポジトリからテーブルフォーム情報を取得して戻します。
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブル ID
     * @return TableFormDTO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDTO getTableFormDTOByConnectLable(final String connectDefinitionId,
            final String tableFormId) throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        final TableFormDTO ret;
        try {
            ret = dao.getTableFormDTOByConnectName(connectDefinitionId, tableFormId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return ret;
    }

    /**
     * AcquisitionOfTableItemInformationLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public AcquisitionOfTableItemInformationLogic() {
        return;
    }

    /**
     * テーブルフォーム DAO を生成して戻す。
     *
     * @return TableFormDAO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDAO createTableFormDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
