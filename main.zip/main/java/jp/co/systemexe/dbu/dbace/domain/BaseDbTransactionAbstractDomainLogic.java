/**
 * Copyright(C) 2017 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.InputDto;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * This class execute business logic with connect transaction
 *
 * @author lam-son
 *
 */
public abstract class BaseDbTransactionAbstractDomainLogic extends BaseDbAccessApplicationDomainLogic {

	/**
	 * ロガーへの参照を保持します。
	 */
	private final Logger logger;

    /**
     * Constructor.
     */
    public BaseDbTransactionAbstractDomainLogic() {
        super();
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
    }

	/**
	 * User implement to execute business logic
	 *
	 * @param inputDto
	 * @param databaseTableDAO
	 *
	 * @throws ApplicationDomainLogicException
	 * @throws DAOException
	 */
	protected abstract void doBusinessLogic(final InputDto inputDto, final DatabaseTableDAO databaseTableDAO)
			throws ApplicationDomainLogicException, DAOException;

	/**
	 * @param dbConnectInfomationDTO
	 * @throws ApplicationDomainLogicException
	 */
	/*public void execute(final DbConnectInfomationDTO dbConnectInfomationDTO) throws ApplicationDomainLogicException {
		DatabaseTableDAO databaseTableDAO = null;
		boolean isSuccess = false;
        try {
			databaseTableDAO = super.createDatabaseTableDAO(dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
			databaseTableDAO.connectWithTransaction(dbConnectInfomationDTO);
			// Do business logic
        	doBusinessLogic(null, databaseTableDAO);
            isSuccess = true;
		} catch (DAOException e) {
			logger.error(e.getMessage(), e);
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} finally {
			if (databaseTableDAO != null) {
				try {
					if (isSuccess == true) {
						databaseTableDAO.commit();
					} else {
						databaseTableDAO.rollback();
					}
				} catch (DAOException e) {
					// nothing
				} finally {
					try {
						databaseTableDAO.close();
					} catch (DAOException e) {
						// nothing
					}
				}
			}
        }
	}*/

	/**
	 * @param inputDto
	 * @throws ApplicationDomainLogicException
	 */
	public void execute(final InputDto inputDto) throws ApplicationDomainLogicException {
		DatabaseTableDAO databaseTableDAO = null;
		boolean isSuccess = false;
        try {
        	final DbConnectInfomationDTO dbConnectInfomationDTO = inputDto.getDbConnectInfomationDTO();
			databaseTableDAO = super.createDatabaseTableDAO(dbConnectInfomationDTO.getDatabaseTypeConnectionDestination());
			databaseTableDAO.connectWithTransaction(dbConnectInfomationDTO);
			// Do business logic
        	doBusinessLogic(inputDto, databaseTableDAO);
            isSuccess = true;
		} catch (DAOException e) {
			logger.error(e.getMessage(), e);
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		} finally {
			if (databaseTableDAO != null) {
				try {
					if (isSuccess == true) {
						databaseTableDAO.commit();
					} else {
						databaseTableDAO.rollback();
					}
				} catch (DAOException e) {
					// nothing
				} finally {
					try {
						databaseTableDAO.close();
					} catch (DAOException e) {
						// nothing
					}
				}
			}
        }
	}
}
