/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.connect.model;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.web.connect.dto.ConnectDto;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author bao-anh
 *
 */

@Data
public class FRM0500ResultModel {
	private List<ConnectDto> resultData;

	private List<MessageInfo> messageInfo;

	public FRM0500ResultModel() {
		resultData = new ArrayList<ConnectDto>();
		messageInfo = new ArrayList<MessageInfo>();
	}
}
