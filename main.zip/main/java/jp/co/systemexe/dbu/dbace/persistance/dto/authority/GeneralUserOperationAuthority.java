/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto.authority;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;

/**
 * 一般ユーザーのアプリケーション操作権限定義 enum。
 * <p>
 * 一般ユーザーに対する、アプリケーション操作権限の定義列挙体です。テーブルに
 * 対する権限ではなく、特定のユーザーに対してアプリケーションそのものの操作を
 * 制限するための権限情報です。
 * </p><p>
 * 具体的には、本権限情報はユーザー権限情報に対してコレクションとして保持され、
 * 更新権限を持たないユーザーは「保存」ボタンが押せない、追加権限を持たない
 * ユーザーは「新規追加」ボタンが押せない、削除権限を持たないユーザーは「削除」
 * ボタンが押せない、といった操作制限がかかります。
 * </p>
 *
 * @author EXE 島田 雄一郎
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public enum GeneralUserOperationAuthority implements IdSelectable {
	CUSTOMIZE("customize", "画面カスタマイズ"),
	REFERENCE("reference", "参照"),
    INSERT("insert", "登録"),
    UPDATE("update", "更新"),
    DELETE("delete", "削除"),
    DOWNLOAD("download", "ダウンロード"),
    COPY("copy", "複写"),
    IMPORT("import", "インポート");

    private static Map<String, GeneralUserOperationAuthority> map;
    static {
        map = new HashMap<String, GeneralUserOperationAuthority>();
        for (final GeneralUserOperationAuthority buff : values()) {
            map.put(buff.getId(), buff);
        }
    }

    /**
     * 内部に定義された権限の一覧リストを戻します。
     *
     * @return List&lt;GeneralUserOperationAuthority&gt;
     */
    public static List<GeneralUserOperationAuthority> getValuesList() {
        final List<GeneralUserOperationAuthority> ret = new ArrayList<GeneralUserOperationAuthority>();
        for (final GeneralUserOperationAuthority buff : values()) {
            ret.add(buff);
        }
        return ret;
    }

    /**
     * ID に対応した権限オブジェクトを戻します。
     * <p>
     * 未定義権限の場合は null を戻します。</p>
     *
     * @param id
     * @return GeneralUserOperationAuthority
     */
    public static GeneralUserOperationAuthority idOf(final String id) {
        if (map.containsKey(id)) {
            return map.get(id);
        } else {
            return null;
        }
    }

    private final String id;
    private final String label;

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable#getId()
     */
    public String getId() {
        return id;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable#getLabel()
     */
    public String getLabel() {
        return label;
    }

    /**
     * GeneralUserOperationAuthority の生成。
     * <p>コンストラクタ。</p>
     *
     * @param id 権限 ID
     * @param label 権限表示名
     */
    private GeneralUserOperationAuthority(final String id, final String label) {
        this.id = id;
        this.label = label;
    }
}
