/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.audit.json;

import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.web.audit.dto.AuditCategoryItem;
import jp.co.systemexe.dbu.dbace.web.audit.dto.SelectOneMenuItemDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author van-thanh
 *
 */

@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0530Param {

	AuditSettingDTO beforeAuditSettingDTO;
    AuditCategoryItem[] auditCategoryItems;
    List<SelectOneMenuItem> auditLogFileUnitItems;
    String auditLogFileSize;
    String auditLogFileUnit;
    String auditLogFileRotation;
    String auditLogFileOutput;

    SelectOneMenuItemDto[] auditLogFileUnitItems_temp;
    UserInfo userInfo;
}
