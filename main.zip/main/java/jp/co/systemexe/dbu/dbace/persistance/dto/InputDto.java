package jp.co.systemexe.dbu.dbace.persistance.dto;

import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

public interface InputDto {

	/**
	 * DBの接続情報
	 */
	void setDbConnectInfomationDTO(DbConnectInfomationDTO dbConnectInfomationDTO);
	DbConnectInfomationDTO getDbConnectInfomationDTO();

	/**
	 * Userの接続情報
	 */
	void setUserInfo(UserInfo userInfo);
	UserInfo getUserInfo();

    /**
     * テーブルのデータベース内定義情報
     */
    void setTableDefinitionDTO(TableDefinitionDTO tableDef);
    TableDefinitionDTO getTableDefinitionDTO();

    /**
     * テーブル個々に対応した画面設定（テーブルフォーム）情報
     */
    void setTableFormDTO(TableFormDTO tableForm);
    TableFormDTO getTableFormDTO();
}
