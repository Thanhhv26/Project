/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.util;

import java.io.Serializable;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
public final class Constants implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * CSRF-XSRF-TOKEN
	 */
	public static final String HEADER_CSRF_TOKEN = "DBACE-CSRF-TOKEN";
	public static final String COOKIE_CSRF_TOKEN = "DBACE-CSRF-TOKEN-COOKIE";
	/**
	 * AJAX request header
	 */
	public static final String AJAX_REQUEST_IDENTIFIER = "XMLHttpRequest";
	public static final String AJAX_REQUEST_HEADER = "X-Requested-With";

	/**
	 * Constant
	 */
	public static final String CONST_STATUS_OK = "OK";
	public static final String CONST_STATUS_NG = "NG";

}
