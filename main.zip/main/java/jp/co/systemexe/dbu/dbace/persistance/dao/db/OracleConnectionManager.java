/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import jp.co.systemexe.dbu.dbace.persistance.dao.BaseConnectionManager;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;

/**
 * Oracleデータベース接続マネージャ。
 * <p>
 * Oracleデータベース接続のコネクションを保持するクラスです。データベース向けの DAO に
 * 対してコネクションを提供します。
 * </p><p>
 * 本アプリケーションは DAO内で自動トランザクションを実装するため、本マネージャが
 * トランザクションも保持します。</p>
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class OracleConnectionManager extends BaseConnectionManager {

    /**
     * oracleデータベースコネクションを戻します。
     * <p>
     * Thin Driver を用いてデータベースコネクションを取得し、戻します。
     * 既にコネクションが保持されている場合はそれを戻します。<br />
     * また、初期設定として自動コミットを ON に設定しています。</p>
     *
     * @param dto 接続定義情報
     * @param connectionUserLabel 接続ユーザー（ログインユーザー表示名）
     * @return Connection
     * @exception SQLException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.BaseConnectionManager#getConnection(jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO, java.lang.String)
     */
    @Override
    public Connection getConnection(
            final DbConnectInfomationDTO dto)
            throws SQLException {
        final long start = System.currentTimeMillis();
        Connection connection = getConnection();
        if (connection == null) {
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
            } catch (final ClassNotFoundException e) {
                final String message = "'oracle.jdbc.driver.OracleDriver' was not found.";
                getLogger().fatal(message, e);
                throw new SQLException(message);
            }
            final Properties props = new Properties();
            props.put("user", dto.getUserId());
            props.put("password", dto.getPassword());
            props.put("oracle.jdbc.RetainV9LongBindBehavior","true");
            connection = DriverManager.getConnection(
                createDatabaseUrl(dto),
                props);
            connection.setAutoCommit(true);
            setConnection(connection);
        }

        if (getLogger().isDebugEnabled()) {
            getLogger().debug("Connection acquisition time :" + (System.currentTimeMillis() - start));
        }

        return connection;
    }
}
