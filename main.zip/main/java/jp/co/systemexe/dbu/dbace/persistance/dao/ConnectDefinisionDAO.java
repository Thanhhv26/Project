/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dto.ConnectDefinisionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository;
import jp.co.systemexe.dbu.dbace.web.connect.dto.ConnectDto;

/**
 * 接続定義情報 DAO。
 * <p>
 * リポジトリに対する接続定義情報 DAO です。</p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public interface ConnectDefinisionDAO {

    /**
     * 接続定義名の一覧マップを取得して戻します。
     * <p>
     * リポジトリに設定済みの接続定義名の一覧マップを戻します</p>
     *
     * @return Map&lt;接続定義 ID, 接続定義ラベル&gt;
     * @throws DAOException 独自定義例外
     */
    public Map<String, String> getConnectDefinisionNameMap()
            throws DAOException;

    /**
     * 接続定義情報 DTO を戻します。
     * <p>
     * リポジトリから接続定義情報 DTO を取得して戻します。ID に該当する DTO が
     * 存在しない場合は null を戻します。</p>
     *
     * @return ConnectDefinisionDTO
     * @throws DAOException 独自定義例外
     */
    public ConnectDefinisionDTO getConnectDefinisionDTO(
            final String connectDefinitionId) throws DAOException;

    /**
     * 接続定義情報 DTO を戻します。
     * <p>
     * リポジトリから接続定義情報 DTO を取得して戻します。LABEL に該当する DTO が
     * 存在しない場合は null を戻します。</p>
     *
     * @return ConnectDefinisionDTO
     * @throws DAOException 独自定義例外
     */
    public ConnectDefinisionDTO getConnectDefinisionDTOByLable(
            final String connectDefinitionId) throws DAOException;
    /**
     * 接続定義情報を保存します。
     * <p>
     * 接続定義情報 DTO の内容をリポジトリに保存します。既存の場合はラベル等の
     * 更新を、新規の場合は新しい接続定義情報要素を作成（新規追加）します。</p>
     *
     * @param dto ConnectDefinisionDTO
     * @throws DAOException 独自定義例外
     */
    public void save(final ConnectDefinisionDTO dto) throws DAOException;

    /**
     * 接続定義情報を削除します。
     * <p>
     * 接続定義情報をリポジトリから完全に削除します。</p>
     *
     * @param connectDefinitionId
     * @throws DAOException 独自定義例外
     */
    public void remove(final String connectDefinitionId) throws DAOException;

    /**
     *
     * @return
     */
	public Map<String, ConnectDto> getAllConnectDefinisions() ;

	/**
	 *
	 * @param newConnectDto
	 * @return
	 * @throws DAOException
	 */
	public int insert(final ConnectDto newConnectDto) throws DAOException;

	/**
	 *
	 * @param newConnectDto
	 * @return
	 * @throws DAOException
	 */
	public int update(final ConnectDto newConnectDto) throws DAOException;

	/**
	 *
	 * @param newConnectDto
	 * @return
	 * @throws DAOException
	 */
	public void testConnect(final ConnectDto newConnectDto) throws DAOException;

	List<Repository.ConnectDefinision> getAllConnectDefinisionsList();

}
