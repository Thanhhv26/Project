/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import java.util.HashMap;
import java.util.Map;

/**
 * 「Y」「N」の二文字で true / false の boolean を表現したカラム用の入力値定義
 * 列挙体。
 * <p>
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum YesNo {
    YES("Y", true), NO("N", false);

    private final String key;
    private final boolean flag;

    /**
     * テーブル中に実際に保存されるキー文字列を戻します。
     * 
     * @return
     */
    public String getKey() {
        return this.key;
    }

    private static Map<String, YesNo> map;
    static {
        map = new HashMap<String, YesNo>();
        for (final YesNo buff : values()) {
            map.put(buff.getKey(), buff);
        }
    }

    public static YesNo keyOf(final String key) {
        if (map.containsKey(key)) {
            return map.get(key);
        } else {
            return null;
        }
    }

    /**
     * flag を戻します。
     * 
     * @return boolean
     */
    public boolean isFlag() {
        return this.flag;
    }

    /**
     * 保持した boolean 値に応じた "true" / "false" 文字列を戻します。
     * 
     * @return
     */
    public String toBooleanString() {
        return String.valueOf(this.flag);
    }

    private YesNo(final String key, final boolean flag) {
        this.key = key;
        this.flag = flag;
    }
}
