/**
 * Copyright(C) 2006 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.exception;

/**
 * データチェック例外。
 * <p>何らかのデータチェックを行った際にスローする例外です。</p>
 *
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public final class CheckException extends ApplicationException {
    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = 799242356553694765L;

    /**
     * CheckException の生成。
     * <p>コンストラクターです。チェック処理内で、問題が例外によって検出された
     * 場合はこちらのコンストラクターを使用します。</p>
     *
     * @param message メッセージです。
     * @param cause   実際の例外オブジェクトです。
     */
    public CheckException(final String message, final Throwable cause) {
        super(message, cause);
    }

    /**
     * CheckException の生成。
     * <p>コンストラクターです。通常の明示的なデータチェックの場合は、この
     * コンストラクタを使用します。プログラムで検出された問題点をメッセージに
     * 設定し、チェック例外をスローします。</p>
     *
     * @param message メッセージです。
     */
    public CheckException(final String message) {
        super(message);
    }
}
