package jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TablesDto;
import lombok.Data;

/*<tables>
	<table id="dbo.Customer" label="dbo.Customer" ListNO=1 CommitNO=1>
	  <item id="CustomerID" label="CustomerID">
	    <isUpdateKey>false</isUpdateKey>
	    <PrimaryKey>true</PrimaryKey>
	    <Unique>true</Unique>
	    <ForeignKey>true</ForeignKey>
	    <DataType>varchar</DataType>
	    <DataLength>50</DataLength>
	    <DataUnit>byte</DataUnit>
	  </item>
	  <optional>
	    <insert OverWrite="false" NotAddNew="false" />
	    <update NotOverWrite="false" Delete="false" />
	    <copy OverWrite="false" NotAddNew="false" />
	    <delete Exclusion1="false" Exclusion2="false" Exclusion3="false" />
	  </optional>
	</table>
	<table id="dbo.order" label="dbo.order" ListNO=2 CommitNO=2>
	  <item id="OrderID" label="OrderID" >
	    <isUpdateKey>true</isUpdateKey>
	    <PrimaryKey>true</PrimaryKey>
	    <Unique>true</Unique>
	    <ForeignKey>true</ForeignKey>
	    <DataType>varchar</DataType>
	    <DataLength>50</DataLength>
	    <DataUnit>byte</DataUnit>
	  </item>
	  <optional>
	    <insert OverWrite="false" NotAddNew="false" />
	    <update NotOverWrite="false" Delete="false" />
	    <copy OverWrite="false" NotAddNew="false" />
	    <delete Exclusion1="false" Exclusion2="false" Exclusion3="false" />
	  </optional>
	</table>
</tables>*/

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "table"
})
@XmlRootElement(name = "tables")
@Data
public class Tables {
	@XmlElement
	private List<Table> table;
	
	public Tables(){
		
	}
	
	public Tables(TablesDto tablesDto){
		for(TableDto item : tablesDto.getTableDtoList()){
			Table table = new Table(item);
			this.getTable().add(table);
		}
	}
	
	public List<Table> getTable(){
		if(table == null){
			table = new ArrayList<Table>();
		}
		return table;
	}
}
