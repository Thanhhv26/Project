/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSessionBindingEvent;

import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.GeneralUserOperationAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;

/**
 * ユーザー情報。
 * <p>
 * ユーザー情報を保持する VO です。アプリケーション実行中、セッション中に永続化
 * されるオブジェクトです。</p>
 *
 * @author  EXE 鈴木 伸祐
 * @author  EXE 島田 雄一郎
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
//@Component(instance = InstanceType.SESSION)
//@Component
//@Scope("session")
public class UserInfo implements Serializable /*implements Serializable, HttpSessionBindingListener*/ {

    /**
     * 直列化（シリアライズ）のための UID。
     * <p>ちなみに、クラス名 ctrl + 1 で生成メニューが開きます。</p>
     */
    private static final long serialVersionUID = 4202733404524737394L;

    /**
     * ユーザー ID。
     */
    private String id;

    /**
     * ユーザー権限。
     *
     * @see UserAuthority
     */
    private UserAuthority userAuthority;

    /**
     * 接続定義名称。
     */
    private String connectName;

    /**
     * ユーザー名称。
     */
    private String name;

    /**
     * クライアントIPアドレス
     */
    private String clientIpAddress;

    /**
     * DB Access Utility サーバーIPアドレス
     */
    private String serverName;

    /**
     * 現在保持している、ユーザー情報のユーザーがアプリケーション管理者
     * (画面カスタマイズ権限を持つか)否かを返します。
     * <p>
     * 指定された、接続定義に対してアプリケーション管理者権限を持つ場合は、
     * true を返します。
     */
    private boolean isApplicationAdministrator;

    /**
     * 現在保持している、ユーザー情報のユーザーがアプリケーション管理者
     * (画面カスタマイズ権限を持つか)否かを返します。
     * <p>
     * 指定された、接続定義に対してアプリケーション管理者権限を持つ場合は、
     * true を返します。
     */
    private Map<String, Boolean> applicationAdministratorMap;

    /// メニュー用変数
	/**
	 * 画面カスタマイズ権限があるか否か
	 */
	private boolean isGuiCustomize;

	/**
	 * データの編集権限があるか否か
	 */
	private boolean isDataEdit;

	/**
	 * データのインポート権限があるか否か
	 */
	private boolean isDataImport;

    /**
     * ユーザー ID を戻します。
     * <p>
     * アプリケーション内で定義されるユーザー ID を戻します。</p>
     *
     * @return String
     */
    public String getId() {
        return id;
    }

    /**
     * ユーザー ID を設定します。
     * <p>
     * アプリケーション内で定義されるユーザー ID を設定します。</p>
     *
     * @param String id
     */
    public void setId(final String id) {
        this.id = id;
    }

    /**
     * ユーザー権限を戻します。
     * <p>
     * アプリケーション内で定義されるユーザー権限情報オブジェクトを戻します。</p>
     *
     * @return UserAuthority
     */
    public UserAuthority getUserAuthority() {
        return userAuthority;
    }

    /**
     * ユーザー権限を設定します。
     * <p>
     * アプリケーション内で定義されるユーザー権限情報オブジェクトを設定します。</p>
     *
     * @param UserAuthority userAuthority
     */
    public void setUserAuthority(final UserAuthority userAuthority) {
        this.userAuthority = userAuthority;
    }

    /**
     * 接続定義名称 を戻します。
     *
     * @return String
     */
    public String getConnectName() {
        return connectName;
    }

    /**
     * 接続定義名称 を設定します。
     *
     * @param String connectName
     */
    public void setConnectName(String connectName) {
        this.connectName = connectName;
    }

    /**
     * GUI 表示用のユーザー名を戻します。
     *
     * @return String
     */
    public String getName() {
        return name;
    }

    /**
     * GUI 表示用のユーザー名を設定します。
     *
     * @param String name
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * 一般ユーザーに対するアプリケーション操作権限リストを戻します。
     * <p>
     * 一般ユーザー以外の権限者の場合は、常に全ての権限を戻します（つまり、
     * 評価の必要がありません）。
     * </p><p>
     * 逆に言えば、一般ユーザーの場合は本オブジェクトの初期化の際に、リポジトリ
     * 内に保持された操作権限リストを読み込んで本リストに追加しなければなりません。
     * </p>
     *
     * @return List<GeneralUserOperationAuthority>
     */
    public List<GeneralUserOperationAuthority> getGeneralUserOperationAuthorityList(
    		final String connectDefinisionId) {
    	for (final ConnectDefinisionAuthority def
    			: userAuthority.getConnectDefinisionAuthoritys()) {
    		if (def.getConnectDefinisionId().equals(connectDefinisionId)) {
    			return def.getOperationAuthority();
    		}
    	}

    	return new ArrayList<GeneralUserOperationAuthority>();
    }

    /**
     * UserInfo の生成。
     * <p>コンストラクタ。</p>
     */
    public UserInfo() {
        return;
    }

    /**
     * セッション開始時の処理
     * <p>
     * 特に何も行いません。
     * </p>
     */
    public void valueBound (HttpSessionBindingEvent event) {
        return;
    }

    /**
     * セッション終了時の処理
     * <p>
     * 現在ログインしているユーザーのログアウト処理を行います。
     * </p>
     */
    public void valueUnbound (HttpSessionBindingEvent event) {
    	return;
    }

    /**
     * clientIpAddress を戻します。
     *
     * @return String
     */
    public String getClientIpAddress() {
        return clientIpAddress;
    }

    /**
     * clientIpAddress を設定します。
     *
     * @param String clientIpAddress
     */
    public void setClientIpAddress(String clientIpAddress) {
        this.clientIpAddress = clientIpAddress;
    }

    /**
     * serverName を戻します。
     *
     * @return String
     */
    public String getServerName() {
        return serverName;
    }

    /**
     * serverName を設定します。
     *
     * @param String serverName
     */
    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    /**
     * 現在保持している、ユーザー情報のユーザーがシステム管理者か
     * 否かを返します。
     *
     * @return boolean
     */
    public boolean isSystemAdministrator() {
    	if (this.userAuthority == null) {
    		return false;
    	} else {
    		return this.userAuthority.isSystemAdministrator();
    	}
    }

    /**
     * 現在保持している、ユーザー情報のユーザーがアプリケーション管理者
     * (画面カスタマイズ権限を持つか)否かを返します。
     * <p>
     * 接続定義に対して、1つでもアプリケーション管理者権限を持つ場合は、
     * true を返します。
     * </p>
     *
     * @return boolean
     */
    public boolean isApplicationAdministrator() {
    	return isApplicationAdministrator;
    }

    /**
     * 現在保持している、ユーザー情報のユーザーがアプリケーション管理者
     * (画面カスタマイズ権限を持つか)否かを返します。
     * <p>
     * 指定された、接続定義に対してアプリケーション管理者権限を持つ場合は、
     * true を返します。
     * </p>
     *
     * @return boolean
     */
    public boolean isApplicationAdministrator(final String connectDefinisionId) {
    	if (applicationAdministratorMap.containsKey(connectDefinisionId)) {
        	return applicationAdministratorMap.get(connectDefinisionId);
    	} else {
    		return false;
    	}
    }

	/**
	 * applicationAdministratorMap を設定します。
	 *
	 * @param Map<String,Boolean> applicationAdministratorMap
	 */
	public void setApplicationAdministratorMap(
			Map<String, Boolean> applicationAdministratorMap) {
		this.applicationAdministratorMap = applicationAdministratorMap;
	}

	/**
	 * isApplicationAdministrator を設定します。
	 *
	 * @param boolean isApplicationAdministrator
	 */
	public void setApplicationAdministrator(boolean isApplicationAdministrator) {
		this.isApplicationAdministrator = isApplicationAdministrator;
	}

	/**
	 * isGuiCustomize を戻します。
	 *
	 * @return boolean
	 */
	public boolean isGuiCustomize() {
		return isGuiCustomize;
	}

	/**
	 * isGuiCustomize を設定します。
	 *
	 * @param boolean isGuiCustomize
	 */
	public void setGuiCustomize(boolean isGuiCustomize) {
		this.isGuiCustomize = isGuiCustomize;
	}

	/**
	 * isDataEdit を戻します。
	 *
	 * @return boolean
	 */
	public boolean isDataEdit() {
		return isDataEdit;
	}

	/**
	 * isDataEdit を設定します。
	 *
	 * @param boolean isDataEdit
	 */
	public void setDataEdit(boolean isDataEdit) {
		this.isDataEdit = isDataEdit;
	}

	/**
	 * isDataImport を戻します。
	 *
	 * @return boolean
	 */
	public boolean isDataImport() {
		return isDataImport;
	}

	/**
	 * isDataImport を設定します。
	 *
	 * @param boolean isDataImport
	 */
	public void setDataImport(boolean isDataImport) {
		this.isDataImport = isDataImport;
	}

}