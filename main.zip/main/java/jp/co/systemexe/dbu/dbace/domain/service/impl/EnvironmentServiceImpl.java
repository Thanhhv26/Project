/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.common.util.LicenseKeyUtils;
import jp.co.systemexe.dbu.dbace.common.util.SecurePwdBlowfishUtils;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfEnvironmentSetting;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfEnvironmentSettingLogic;
import jp.co.systemexe.dbu.dbace.domain.service.EnvironmentService;
import jp.co.systemexe.dbu.dbace.library.service.AbstractService;
import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseRepositoryXmlDAO;
import jp.co.systemexe.dbu.dbace.web.environment.dto.EnvironmentDto;
import jp.co.systemexe.dbu.dbace.web.environment.model.FRM0520ResultModel;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;
/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 jan 18, 2017
 */
@Service
public class EnvironmentServiceImpl extends AbstractService implements EnvironmentService {

	private static final long serialVersionUID = 1L;
	private static final String UNLIMITED_JA = "無制限";
	@Autowired
	MessageService messageService;
	@Override
	public FRM0520ResultModel updateEnvironment(EnvironmentDto environmentDto) throws ApplicationRuntimeException {
		FRM0520ResultModel resultDto = new FRM0520ResultModel();
		BaseRepositoryXmlDAO baseRepositoryXmlDAO = new BaseRepositoryXmlDAO() {};
		//ADD ライセンス認証 機能追加　↓
		final AcquisitionOfEnvironmentSetting setting = new AcquisitionOfEnvironmentSetting();
		final EnvironmentSettingDTO dtoEnvBk = setting.getAllProperties();
		final EnvironmentSettingDTO dto = new EnvironmentSettingDTO();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		dto.setLicenseKey(environmentDto.getLicenseKey());
		dto.setLicenseCnt(LicenseKeyUtils.getCnt(environmentDto.getLicenseKey(), baseRepositoryXmlDAO.openSesame()));
		//ADD ライセンス認証 機能追加　↑
		dto.setRepositoryFilePath(dtoEnvBk.getRepositoryFilePath());
		dto.setRecordDisplayCount(environmentDto.getRecordDisplayCount());
		dto.setColumnDisplayCount(environmentDto.getColumnDisplayCount());
		dto.setRetrievalConditionPreservationPath(dtoEnvBk.getRetrievalConditionPreservationPath());
		dto.setPulldownDisplayMaximumCount(environmentDto.getPulldownDisplayMaximumCount());
		dto.setPulldownDisplayFetchSize(environmentDto.getPulldownDisplayFetchSize());
		dto.setFileDownloadFetchSize(environmentDto.getFileDownloadFetchSize());
		dto.setAuditLogFilePath(dtoEnvBk.getAuditLogFilePath());
		dto.setImportTempFilePath(dtoEnvBk.getImportTempFilePath());
		dto.setDownloadMaximumByteForExcel(environmentDto.getDownloadMaximumByteForExcel());
		dto.setDownloadMaximumByteForCsv(environmentDto.getDownloadMaximumByteForCsv());
		dto.setImportMaximumByteForExcel(environmentDto.getImportMaximumByteForExcel());
		dto.setImportMaximumByteForCsv(environmentDto.getImportMaximumByteForCsv());
		dto.setImportMaximumByteForTsv(environmentDto.getImportMaximumByteForTsv());
		dto.setSearchMaxRecordCount(environmentDto.getSearchMaxRecordCount());
		dto.setSearchComparisonOperatorOrder(environmentDto.getSearchComparisonOperatorOrder());
		//ADD ライセンス認証 機能追加　↓
		dto.setExtAuth(dtoEnvBk.getExtAuth());
		dto.setAuthServerType(dtoEnvBk.getAuthServerType());
		dto.setAuthServerId(dtoEnvBk.getAuthServerId());
		dto.setAuthServerPort(dtoEnvBk.getAuthServerPort());
		dto.setAuthServerTimeout(dtoEnvBk.getAuthServerTimeout());
		dto.setAuthServerBaseDomain(dtoEnvBk.getAuthServerBaseDomain());
		dto.setAuthServerUserIdentify(dtoEnvBk.getAuthServerUserIdentify());
		dto.setAuthConnectUsername(dtoEnvBk.getAuthConnectUsername());
		SecurePwdBlowfishUtils pwdDecryptBlowfish = new SecurePwdBlowfishUtils();
		dto.setAuthConnectPwd(pwdDecryptBlowfish.decrypt(dtoEnvBk.getAuthConnectPwd(), baseRepositoryXmlDAO.openSesame()));
		pwdDecryptBlowfish = null;
		dto.setAuthServerProtocol(dtoEnvBk.getAuthServerProtocol());
		dto.setAuthServerSecurity(dtoEnvBk.getAuthServerSecurity());
		dto.setSearchComparisonOperatorOrder(dtoEnvBk.getSearchComparisonOperatorOrder());
		dto.setColumnDisplayCount(dtoEnvBk.getColumnDisplayCount());

		final PreservationOfEnvironmentSettingLogic logic = new PreservationOfEnvironmentSettingLogic();
		try {
			logic.savePropeties(dto);
			//call initialize show licenseCnt latest
			final AcquisitionOfEnvironmentSetting logicLatest = new AcquisitionOfEnvironmentSetting();
			final EnvironmentSettingDTO dtoLicenseCntLatest = logicLatest.getAllProperties();
			//ライセンス数が「Unlimited」文字の場合、「無制限」を表示
			if (StringUtils.isNotEmpty(dto.getLicenseCnt()) && LicenseKeyUtils.UNLIMITED.equalsIgnoreCase(dtoLicenseCntLatest.getLicenseCnt())) {
				environmentDto.setLicenseCnt(UNLIMITED_JA);
			} else {
				//他の文字列の場合、原則数値を表
				environmentDto.setLicenseCnt(dto.getLicenseCnt());
			}
			messageInfoList.add(new MessageInfo("MI-I-0018", MessageType.SUCCESS, messageService));
			resultDto.getResultData().add(environmentDto);
			resultDto.setMessageInfo(messageInfoList);

		} catch (final ApplicationDomainLogicException e) {
			 resultDto.getMessageInfo().add(new MessageInfo(e, MessageType.ERROR));
	         return resultDto;
		}
		return resultDto;
	}
}
