/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.domain.BaseDbTransactionAbstractDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.InputDto;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordEditInputDto;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSaveConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * データベースへのレコード追加処理ロジック。
 * <p>
 * データベースにレコードを追加します。
 * </p>
 *
 * @author EXE 相田 一英
 * @version 0.0.0
 */
public class RecordAdditionProcessingToDatabaseLogic extends BaseDbTransactionAbstractDomainLogic {
	public RecordAdditionProcessingToDatabaseLogic() {
	}

	/**
	 * 指定されたテーブルにレコードを追加します。
	 * <p>
	 * DB メタデータを取得し、DB 側で定義されている各カラムのデータ型情報に配慮 したレコード追加を実行します。<br />
	 * 自動インクリメントフィールドを検知した場合、対象カラムを追加対象から除外 します。
	 * </p>
	 *
	 * @param connectDefinitionId
	 *            接続定義 ID
	 * @param tableId
	 *            テーブル ID（テーブル名）
	 * @param records
	 *            レコード保持コレクション
	 * @param connectionUserLabel
	 *            接続ユーザー表示名
	 * @throws ApplicationDomainLogicException
	 */
	/**
	 * @throws ApplicationDomainLogicException
	 */
	@Override
	protected void doBusinessLogic(InputDto inputdto, DatabaseTableDAO databaseTableDAO)
			throws ApplicationDomainLogicException, DAOException {
		RecordEditInputDto inputDto = (RecordEditInputDto) inputdto;
		final RecordSaveConditionDTO dto = new RecordSaveConditionDTO();
		dto.setConnectDefinitionId(inputDto.getConnectDefinitionId());
		dto.setTableId(inputDto.getTableId());

		final Map<String, String> map = filterAutoIncrementColumn(inputDto.getColumnMap(), inputDto.getRecordEditorInformationDTO().getTableDef().getDefinitionOfColumnMap());
		databaseTableDAO.doInsert(map, dto, inputDto.getRecordEditorInformationDTO().getTableDef(),inputDto.getTableFormDto().getTableItemMap(),
				inputdto.getDbConnectInfomationDTO().getDatabaseId(), inputdto.getUserInfo());
	}
}
