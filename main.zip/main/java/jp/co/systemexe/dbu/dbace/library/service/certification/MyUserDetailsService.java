/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.service.certification;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.exception.BackupRepositoryException;
import jp.co.systemexe.dbu.dbace.common.exception.ContentRepositoryInvalidException;
import jp.co.systemexe.dbu.dbace.common.exception.IncorrectupAuthenticationPrincipalInputRequiredException;
import jp.co.systemexe.dbu.dbace.common.exception.LKAuthenticationPrincipalInputRequiredException;
import jp.co.systemexe.dbu.dbace.common.exception.NotexpiredlkAuthenticationPrincipalInputRequiredException;
import jp.co.systemexe.dbu.dbace.common.exception.PAuthenticationPrincipalInputRequiredException;
import jp.co.systemexe.dbu.dbace.common.exception.RepositoryNotExistException;
import jp.co.systemexe.dbu.dbace.common.exception.UAuthenticationPrincipalInputRequiredException;
import jp.co.systemexe.dbu.dbace.common.exception.ValidlkAuthenticationPrincipalInputRequiredException;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.util.LicenseKeyUtils;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfEnvironmentSetting;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfUserAuthorityLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.BackUpOfRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfEnvironmentSettingLogic;
import jp.co.systemexe.dbu.dbace.library.service.AbstractService;
import jp.co.systemexe.dbu.dbace.persistance.dao.impl.BaseRepositoryXmlDAO;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

/**
 * @author tu-lenh
 * @version 0.0.0
 */
public class MyUserDetailsService extends AbstractService implements UserDetailsService {
	private static final long serialVersionUID = 1L;
	/*
	 * input : user name : password : license key
	 * return MyUserDetails
	 */
	public UserDetails loadUserByUsername(String input) throws UsernameNotFoundException {
		String[] split = input.split("¬");
		String username = split[0];
		String password = split[1];
		String isShowLicenseKey = split[2];
		String licenseKey = split[3];
		String clientIpAddress = split[4];
		String serverName = split[5];
		BaseRepositoryXmlDAO baseRepositoryXmlDAO = new BaseRepositoryXmlDAO() {};
		if (Boolean.valueOf(isShowLicenseKey)) {
			if (StringUtils.isEmpty(licenseKey)) {
				outputLoginAuditLog(new UserInfoDTO(), false, clientIpAddress, serverName);
				throw new LKAuthenticationPrincipalInputRequiredException(licenseKey);
			} else if (!LicenseKeyUtils.isValidFormat(licenseKey, baseRepositoryXmlDAO.openSesame())) {
				throw new ValidlkAuthenticationPrincipalInputRequiredException(licenseKey);
			} else if (!LicenseKeyUtils.isNotExpired(licenseKey, baseRepositoryXmlDAO.openSesame())) {
				throw new NotexpiredlkAuthenticationPrincipalInputRequiredException(licenseKey);
			}
		}
		// ユーザーIDチェック
		if (StringUtils.isEmpty(username)) {
			outputLoginAuditLog(new UserInfoDTO(), false, clientIpAddress, serverName);
			throw new UAuthenticationPrincipalInputRequiredException(username);
		}
		// パスワードチェック
		if (StringUtils.isEmpty(password)) {
			outputLoginAuditLog(new UserInfoDTO(), false, clientIpAddress, serverName);
			throw new PAuthenticationPrincipalInputRequiredException(password);
		}
		final AcquisitionOfUserAuthorityLogic logic = new AcquisitionOfUserAuthorityLogic();
		UserInfoDTO dto = null;
		try {
			dto = logic.getUserInfoDTO(username, password);
		} catch (ApplicationDomainLogicException e) {
			getLogger().fatal(e.getMessage(), e);
			outputLoginAuditLog(dto == null ? new UserInfoDTO() : dto, false, clientIpAddress, serverName);
			// MI-F-0019=リポジトリXMLファイルの解析中にエラーが発生しました。
			String messXmlContentInvalid = MessageUtils.getMessage("MI-F-0019");
			// MI-F-0014=リポジトリXMLファイルが存在しません。
			String messXmlNotFound = MessageUtils.getMessage("MI-F-0014");
			if (e.getMessage() != null && e.getMessage().contains(messXmlNotFound)) {
				throw new RepositoryNotExistException(messXmlNotFound);
			} else if (e.getMessage() != null && e.getMessage().contains(messXmlContentInvalid)) {
				throw new ContentRepositoryInvalidException(messXmlContentInvalid);
			} else {
				throw new IncorrectupAuthenticationPrincipalInputRequiredException(username + password);
			}
		}
		// checkLoginUser
		final BackUpOfRepositoryLogic backUpOfRepositoryLogic = new BackUpOfRepositoryLogic();
		if (dto.isSystemAdministrator()) {
			// TODO:アプリケーション管理者の場合に、リポジトリをバックアップするか要検討
			try {
				backUpOfRepositoryLogic.buckUpReposiotry();
			} catch (ApplicationDomainLogicException e) {
				getLogger().fatal(e.getMessage(), e);
				outputLoginAuditLog(new UserInfoDTO(), false, clientIpAddress, serverName);
				// リポジトリXMLバックアップファイルの出力に失敗しました。
				throw new BackupRepositoryException(MessageUtils.getMessage("MI-F-000001"));
			}
		}
		// Save license key
		// Save license cnt
		// Get current instance of system configuration
		// Change the license key and license count
		// Save to System.propertise
		AcquisitionOfEnvironmentSetting env = new AcquisitionOfEnvironmentSetting();
		EnvironmentSettingDTO currentDto = env.getAllProperties();
		if (Boolean.valueOf(isShowLicenseKey)) {
			currentDto.setLicenseCnt(LicenseKeyUtils.getCnt(licenseKey, baseRepositoryXmlDAO.openSesame()) + "");
			currentDto.setLicenseKey(licenseKey);
		}
		PreservationOfEnvironmentSettingLogic saveLogic = new PreservationOfEnvironmentSettingLogic();
		try {
			currentDto.setNotEncryptAuthConnectPwd(true);
			saveLogic.savePropeties(currentDto);
		} catch (ApplicationDomainLogicException e) {
			getLogger().fatal(e.getMessage(), e);
			throw new ValidlkAuthenticationPrincipalInputRequiredException(MessageUtils.getMessage("MI-F-000002"));
		}
		String extAuth = currentDto.getExtAuth();
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		MyUserDetails myUserDetails = new MyUserDetails(dto.getId(), dto.getName(), password, authorities);
		myUserDetails.setUserInfoDTO(dto);
		myUserDetails.setExtAuth(extAuth);
		myUserDetails.setClientIpAddress(clientIpAddress);
		myUserDetails.setServerName(serverName);
		UserInfo userInfo = new UserInfo();
		userInfo.setId(dto.getId());
		userInfo.setName(dto.getName());
		userInfo.setServerName(serverName);
		userInfo.setApplicationAdministrator(dto.isApplicationAdministrator());
		userInfo.setApplicationAdministratorMap(dto.getApplicationAdministratorMap());
		userInfo.setClientIpAddress(clientIpAddress);
		userInfo.setUserAuthority(dto.getUserAuthority());
		myUserDetails.setUserInfo(userInfo);
		// login success
		outputLoginAuditLog(dto, true, clientIpAddress, serverName);
		// final String args[] = { dto.getId() };
		// getLogger().info(MessageUtils.getMessage("MI-I-0005", args));
		return myUserDetails;
	}

	/**
	 * ログイン成否のログを出力します。
	 *
	 * @param isSuccess
	 */
	private void outputLoginAuditLog(final UserInfoDTO dto, final boolean isSuccess, final String clientIpAddress,
			final String serverName) {
		final UserInfo userInfo = new UserInfo();
		userInfo.setClientIpAddress(clientIpAddress);
		userInfo.setServerName(serverName);
		userInfo.setId(dto.getId());
		userInfo.setName(dto.getName());
		OutputAuditLog.writeLoginLogoutLog(AuditEventKind.LOGIN, userInfo, serverName,
				isSuccess ? AuditStatus.success : AuditStatus.failure);
	}
}