/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import au.com.bytecode.opencsv.CSVReader;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.UploadFileType;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.ColsDto.ColDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;

/**
 * CSV(TSV)ファイルを読み込みます。
 * <p>
 * CSV読み込み時は、区切り文字を ","、
 * TSV読み込み時は、区切り文字を "\t"、として読み込みます。
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class InputToCsvOrTsvDAO extends BaseInputFileDAO {
	/**
	 * CSV(TSV)ファイルリーダー
	 */
    private CSVReader reader = null;

    /**
     * カラムIDのリスト
     */
    private String[] columnIdList = null;

    /**
     * カラムデータのリスト
     */
    private String[] nextColumnData = null;

    /**
     * ファイル読込後の後始末を行います。
     * <p>
     * CSVReaderのクローズを行います。
     * </p>
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseInputFileDAO#close()
     */
    @Override
    public void close() {
        if (reader != null) {
            try {
                reader.close();
            } catch (final IOException e) {
            	// MI-E-0131=ファイルのクローズに失敗しました。
                getLogger().warn(MessageUtils.getMessage("MI-E-0131"), e);
            }
        }
    }

    /**
     * ヘッダレコード(カラムIDのリスト)を返します。
     *
     * @return
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseInputFileDAO#getColumnIdList()
     */
    @Override
    public List<String> getColumnIdList() throws DAOException {
        if (columnIdList == null
        		|| columnIdList.length == 0) {
        	// MI-E-0132=ファイルにヘッダデータ（カラムID）が存在しません。
        	final String message = MessageUtils.getMessage("MI-E-0132");
        	getLogger().error(message);
        	throw new DAOException(message);
        }

        if (columnIdList.length == 1
        		&& StringUtils.isEmpty(columnIdList[0])) {
        	// MI-E-0132=ファイルにヘッダデータ（カラムID）が存在しません。
        	final String message = MessageUtils.getMessage("MI-E-0132");
        	getLogger().error(message);
        	throw new DAOException(message);
        }

        final List<String> ret = new ArrayList<String>();
        for (final String data : columnIdList) {
            final String columnId = getColumnId(data);
        	if (columnId.equals("")) {
            	// MI-E-0133=ファイルに設定されているカラム名({0})が、テーブルに存在しません。
            	final String args[] = {data};
            	final String message = MessageUtils.getMessage("MI-E-0133", args);
            	getLogger().error(message);
            	throw new DAOException(message);
            }
        	ret.add(columnId);
        }

        final List<String> keyList = getTableForm().getUpdateKeyList();
        for (final String pkey : keyList) {
            if (!ret.contains(pkey)) {
            	// MI-E-0134=ファイルに更新時のキーカラムが設定されていません。(キーカラム：{0})
            	final String args[] = {pkey};
            	final String message = MessageUtils.getMessage("MI-E-0134", args);
            	getLogger().error(message);
            	throw new DAOException(message);
            }
        }
        return ret;
    }

    @Override
	public Map<String,Integer> getMultiColumnIdList(Map<String, TableItemDTO> tableItemMap,List<String> columnIdListTemp,TableDto tableDto) throws DAOException {
    	if (columnIdList == null
        		|| columnIdList.length == 0) {
        	// MI-E-0132=ファイルにヘッダデータ（カラムID）が存在しません。
        	final String message = MessageUtils.getMessage("MI-E-0132");
        	getLogger().error(message);
        	throw new DAOException(message);
        }
        if (columnIdList.length == 1
        		&& StringUtils.isEmpty(columnIdList[0])) {
        	// MI-E-0132=ファイルにヘッダデータ（カラムID）が存在しません。
        	final String message = MessageUtils.getMessage("MI-E-0132");
        	getLogger().error(message);
        	throw new DAOException(message);
        }
        final Map<String,Integer> ret = new HashMap<String,Integer>();
        int cellCount = 0;
        for (final String data : columnIdList) {
            final String columnId = getColumnId(data);
            if (StringUtils.isNotEmpty(columnId)) {
            	ret.put(columnId, cellCount);
			}
        	cellCount++;
        }
        final List<String> keyList = getTableForm().getUpdateKeyList();
        for (final String pkey : keyList) {
            if (!ret.containsKey(pkey)) {
            	// MI-E-0134=ファイルに更新時のキーカラムが設定されていません。(キーカラム：{0})
            	final String args[] = {pkey};
            	final String message = MessageUtils.getMessage("MI-E-0134", args);
            	getLogger().error(message);
            	throw new DAOException(message);
            }
        }
        final Map<String,Integer> columnIdMapTemp = new HashMap<String,Integer>();
		for (String colTbl : columnIdListTemp) {
			int indexData = findIndexDataInColumnHeader(tableDto,colTbl,ret,tableItemMap);
			if (indexData != -1) {
				columnIdMapTemp.put(colTbl, indexData);
			}
		}
        return columnIdMapTemp;
	}

    /**
     * @param tableDto
     * @param colTbl
     * @param ret
     * @return
     */
    private int findIndexDataInColumnHeader(TableDto tableDto, String colTbl, Map<String, Integer> ret,Map<String, TableItemDTO> tableItemMap) {
    	for (String col : ret.keySet()) {
			if (colTbl.equals(col)) {
				return ret.get(col);
			} else {
				//column on csv : ID_U
				//list column tables-->table-->item : ID
				//List<ItemMultiDto> itemMultiDtoList = tableDto.getItemMultiDto();
				//find table , item in cols : ID_U{ID_U,ID}
				//tableItemMap : tableForm-->item-->cols
				TableItemDTO tableItemDTO = tableItemMap.get(col);
				Map<String, ColDto> colDtos= tableItemDTO.getCols();
				for(String  no:colDtos.keySet()){
					ColDto colDto = colDtos.get(no);
					if(colDto.getTableID().equals(tableDto.getId()) && colDto.getItemID().equals(colTbl)){
						return ret.get(col);
					}
				}
			}
		}
		return -1;
	}

	/**
     * 次のレコードが存在するか否かを返します。
     *
     * @return
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseInputFileDAO#hasNext()
     */
    @Override
    public boolean hasNext() throws DAOException {
        try {
            nextColumnData = reader.readNext();
        } catch (final IOException e) {
        	// MI-E-0137=ファイルの読込みに失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0137");
        	getLogger().error(message, e);
            throw new DAOException(message, e);
        }

        if (nextColumnData == null) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * カラムのデータを返します。
     *
     * @param columnIdList
     * @return
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseInputFileDAO#readNext(java.util.List)
     */
    @Override
    public Map<String,String> read(List<String> columnIdList) {
        final Map<String, String> ret = new HashMap<String, String>();
        if (nextColumnData == null) {
        	return ret;
        }
        for (int i = 0; i < columnIdList.size(); i++) {
        	String data = null;
        	try{
        		data = nextColumnData[i];
                ret.put(columnIdList.get(i), data);
        	} catch(Exception e) {
        	}
        }
        return ret;
    }

	@Override
	public Map<String, String> readMulti(Map<String, Integer> columnIdMap) throws ApplicationDomainLogicException {
		final Map<String, String> ret = new HashMap<String, String>();
        if (nextColumnData == null) {
        	return ret;
        }
        for(String col:columnIdMap.keySet()){
        	int cellCount = columnIdMap.get(col);
        	try{
            	String data = nextColumnData[cellCount];
                ret.put(col, data);
        	} catch(Exception e) {
        		// MI-E-0151=更新対象のデータが存在しません。
//				final String message = MessageUtils.getMessage("MI-E-0151");
//	        	getLogger().error(message, e);
//	            throw new ApplicationDomainLogicException(message, e);
        	}
        }
        return ret;
//		if (columnIdMap.size() == ret.size()) {
//			return ret;
//		}
//		return new HashMap<String, String>();
	}

    /**
     * コンストラクタ
     *
     * @param stream
     * @param tableForm
     * @throws DAOException
     */
    public InputToCsvOrTsvDAO(
            InputStream stream,
    		final UploadFileType fileType,
            final String fileEncode,
            final TableFormDTO tableForm)
            throws DAOException {
        super(tableForm);
        try {
			try {
				stream = removeInputStreamBOM(stream,fileEncode);
			} catch (Exception e) {
				 // MI-E-0135=指定したエンコードは使用できません。
	        	final String message = MessageUtils.getMessage("MI-E-0135");
	        	getLogger().error(message, e);
	            throw new DAOException(message, e);
			}
        	reader = new CSVReader(new InputStreamReader(stream, fileEncode), fileType.getDelimiter());
        } catch (final UnsupportedEncodingException e) {
            // MI-E-0135=指定したエンコードは使用できません。
        	final String message = MessageUtils.getMessage("MI-E-0135");
        	getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        try {
            columnIdList = reader.readNext();
        } catch (final IOException e) {
        	// MI-E-0137=ファイルの読込みに失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0137");
        	getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * @param inputStream
     * @param charSet
     * @return
     * @throws Exception
     */
    private InputStream removeInputStreamBOM(InputStream inputStream, String charSet) throws Exception {
			    // 文字コードを判断
			    if (!"UTF-8".equals(charSet.toUpperCase()))
			        return inputStream;

			    // 入力ストリームがマークをサーポットするかどうかを判断
			    if (!inputStream.markSupported()) {
			        inputStream = new BufferedInputStream(inputStream);
			    }
			    // 入力ストリームの現在の位置にマークを付ける
			    inputStream.mark(3);
			    if (inputStream.available() >= 3) {
			        byte bomCode[] = { 0, 0, 0 };
			        // BOMのコードを取得
			        inputStream.read(bomCode, 0, 3);

			        // UTF-8(BOM付きを判断)
			        if (bomCode[0] != (byte) 0xEF || bomCode[1] != (byte) 0xBB
			                        || bomCode[2] != (byte) 0xBF) {
			            // 先頭まで巻き戻す
			            inputStream.reset();
			        }
			    }
			    // UTF-8のBOMを除いた入力ストリームを戻る
			    return inputStream;
    }
}
