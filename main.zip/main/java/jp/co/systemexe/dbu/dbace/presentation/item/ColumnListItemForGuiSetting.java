/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item;

import java.io.Serializable;

/**
 * Teeda ForEach Item。
 * <p>
 * 画面情報設定カラムアイテム。</p>
 * <p>
 * Teeda HTML テンプレート内で foreach 用リストを使用する際に、そのリスト内の値
 * を定義するためのクラスです。</p>
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class ColumnListItemForGuiSetting implements Serializable {

    /**
     * <code>serialVersionUID</code> のコメント。
     */
    private static final long serialVersionUID = -7054311444815262669L;

    /**
     * ConnectDefinition ID を保持します。
     * <p>システム内部で扱われる 接続定義 ID です。</p>
     */
    private String connectDefinitionId;

    /**
     * Table ID を保持します。
     * <p>システム内部で扱われる テーブル ID です。</p>
     */
    private String tableId;
    /**
     * Table Label を保持します。
     * <p>システム内部で扱われる テーブル Label です。</p>
     */
    private String tableLabel;

    /**
     * Item ID を保持します。
     * <p>システム内部で扱われる カラム ID です。</p>
     */
    private String value;

    /**
     * Item 表示名「仮名」を保持します。
     * <p>ユーザーが定義するテーブルIDに付けた表示用名称です。</p>
     */
    private String label;

    /**
     * 本カラムを表示する際のHTML要素タイプを保持します。
     */
    private String fieldType;

    /**
     * 本カラムが一覧表示か否かのステータスを保持します。
     */
    private String canDisplays;

    /**
     * 本カラムが検索キーか否かのステータスを保持します。
     */
    private String isSearchKey;


    private boolean primaryKey;

    private boolean updateKey;

    private boolean selectKey;

    private String parametersSql;
    
    private boolean correspondence;
    
	public String getParametersSql() {
		return parametersSql;
	}

	public void setParametersSql(String parametersSql) {
		this.parametersSql = parametersSql;
	}

	/**
	 * @return the connectDefinitionId
	 */
	public String getConnectDefinitionId() {
		return connectDefinitionId;
	}

	/**
	 * @param connectDefinitionId the connectDefinitionId to set
	 */
	public void setConnectDefinitionId(String connectDefinitionId) {
		this.connectDefinitionId = connectDefinitionId;
	}

    /**
     * tableId を戻します。
     *
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * tableId を設定します。
     *
     * @param String tableId
     */
    public void setTableId(String tableId) {
        this.tableId = tableId;
    }

	/**
	 * @return the tableLabel
	 */
	public String getTableLabel() {
		return tableLabel;
	}

	/**
	 * @param tableLabel the tableLabel to set
	 */
	public void setTableLabel(String tableLabel) {
		this.tableLabel = tableLabel;
	}

    /**
     * value を戻します。
     *
     * @return String
     */
    public String getValue() {
        return value;
    }

    /**
     * value を設定します。
     *
     * @param String value
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * label を戻します。
     *
     * @return String
     */
    public String getLabel() {
        return label;
    }

    /**
     * label を設定します。
     *
     * @param String label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * fieldType を戻します。
     *
     * @return String
     */
    public String getFieldType() {
        return fieldType;
    }

    /**
     * fieldType を設定します。
     *
     * @param String fieldType
     */
    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

    /**
     * canDisplays を戻します。
     *
     * @return String
     */
    public String getCanDisplays() {
        return canDisplays;
    }

    /**
     * canDisplays を設定します。
     *
     * @param String canDisplays
     */
    public void setCanDisplays(String canDisplays) {
        this.canDisplays = canDisplays;
    }

    /**
     * isSearchKey を戻します。
     *
     * @return String
     */
    public String getIsSearchKey() {
        return isSearchKey;
    }

    /**
     * isSearchKey を設定します。
     *
     * @param String isSearchKey
     */
    public void setIsSearchKey(String isSearchKey) {
        this.isSearchKey = isSearchKey;
    }

    public boolean isPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(boolean primaryKey) {
		this.primaryKey = primaryKey;
	}

	public boolean isUpdateKey() {
		return updateKey;
	}

	public void setUpdateKey(boolean isUpdateKey) {
		this.updateKey = isUpdateKey;
	}

	public boolean isSelectKey() {
		return selectKey;
	}

	public void setSelectKey(boolean isSelectKey) {
		this.selectKey = isSelectKey;
	}


	/**
     * ColumnListItemForGuiSetting.java の生成。
     * <p>コンストラクタ。</p>
     *
     */
    public ColumnListItemForGuiSetting() {
        super();
    }

	public boolean isCorrespondence() {
		return correspondence;
	}

	public void setCorrespondence(boolean correspondence) {
		this.correspondence = correspondence;
	}
}
