/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

@Data
public class RelationsDto {
	private List<RelationsDto.RelationDto> relationDtoList;

	public RelationsDto(){

	}

	public RelationsDto(TableForm.Relations relations){
		if(relations != null){
			List<RelationsDto.RelationDto> relationListTemp = new  ArrayList<RelationsDto.RelationDto>();
			for(TableForm.Relations.Relation item : relations.getRelation()){
				relationListTemp.add(new RelationsDto.RelationDto(item.getId(), item.getListNO()));
			}
			this.setRelationDtoList(relationListTemp);
		}
	}

	public List<RelationsDto.RelationDto> getRelationDtoList(){
		if(relationDtoList == null){
			relationDtoList = new ArrayList<RelationsDto.RelationDto>();
		}
		return relationDtoList;
	}

	@Data
	public static class RelationDto {
		private String id;
		private String label;
		private String listNO;

		public RelationDto() {

		}

		public RelationDto(String id, String listNO) {
			this.setId(id);
			this.setListNO(listNO);
		}
	}

}
