/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.io.File;
import java.io.IOException;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.AuditSettingDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

/**
 * 監査ログ設定情報の保存ロジック。
 * <p>
 * 監査ログ設定情報を監査ログ設定情報XMLに更新するための処理です。</p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class PreservationOfAuditSettingLogic
        extends BaseApplicationDomainLogic {

    /**
     * 指定された、ファイルパスが作成可能かどうかを判定します。
     * <p>
     * 指定されたファイルが存在した場合は、何も行いません。<br />
     * 指定されたファイルのディレクトリが存在しない場合は、作成します。
     * </p>
     *
     * @param filePath
     */
    public void checkAuditFile(final String filePath)
            throws ApplicationDomainLogicException {
        final File file = new File(filePath);
        try {
            if (!file.exists()) {
                final String parentDirectory
                    = file.getCanonicalFile().getParent();
                if (parentDirectory != null) {
                    final File parent = new File(parentDirectory);
                    if (parent.exists()
                            || parent.mkdirs()) {
                        file.createNewFile();
                    } else {
                    	// MI-E-0042=監査ログファイルを出力する、フォルダの作成に失敗しました。
                    	final String message = MessageUtils.getMessage("MI-E-0042");
                    	getLogger().error(message);
                        throw new ApplicationDomainLogicException(message);
                    }
                } else {
                    file.createNewFile();
                }
            }
        } catch (final IOException e) {
        	// MI-E-0041=監査ログファイルの作成に失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0041");
        	getLogger().error(message, e);
            throw new ApplicationDomainLogicException(message);
        } catch (final Exception e) {
        	// MI-E-0041=監査ログファイルの作成に失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0041");
        	getLogger().error(message, e);
            throw new ApplicationDomainLogicException(message);
        }
    }

    /**
     * 監査ログ設定情報を監査ログ設定情報XMLに保存し、Log4Jの設定を更新します。
     *
     * @param dto AuditSettingDTO
     * @throws ApplicationDomainLogicException
     */
    public void save(
            final AuditSettingDTO beforeDto,
            final AuditSettingDTO dto,
            final UserInfo userInfo
            )
            throws ApplicationDomainLogicException {
        final AuditSettingDAO dao = createAuditSettingDAO();
        try {
            dao.save(beforeDto, dto, userInfo);
        } catch (final DAOException e) {
           throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

        final ChangeAuditLogLogic logic = new ChangeAuditLogLogic();
        logic.changeAuditLog(dto);
    }

    /**
     * PreservationOfConnectDefinitionLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public PreservationOfAuditSettingLogic() {
        return;
    }

    /**
     * 監査ログ設定情報 DAO を生成して戻す。
     *
     * @return AuditSettingDAO
     * @throws ApplicationDomainLogicException
     */
    private AuditSettingDAO createAuditSettingDAO()
            throws ApplicationDomainLogicException {
        try {
            return (AuditSettingDAO)createDAO("AuditSettingDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getCause().getMessage(), e);
        }
    }
}
