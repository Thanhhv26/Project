/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.common.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * Blowfish アルゴリズムによる暗号化・復号化ユーティリティ。
 * <p>
 * Blowfish アルゴリズムにより暗号化・復号化を行うためのユーティリティクラスです。
 * </p><p>
 * 本クラスは final です。サブクラスの作成は許可されません。</p>
 *
 * @author	EXE 相田 一英
 * @author EXE 六本木 圭
 * @version 0.0.0
 */
public final class BlowfishUtils {

    private static String BLOW_FISH = "Blowfish";
    private static String ENCODE = "UTF-8";

    /**
     * 文字列を暗号化しエンコードして戻す。
     * <p>
     * 対象の文字列を暗号化した後、Base64 エンコードを行い返します。
     * </p>
     * @param key 鍵文字列
     * @param text 暗号化対象文字列
     * @return 暗号化文字列
     * @throws Exception
     */
    public final static String encrypt2b64(final String key, final String text)
            throws IOException, UnsupportedEncodingException,IllegalBlockSizeException,
            InvalidKeyException, NoSuchAlgorithmException, BadPaddingException,
            NoSuchPaddingException, UnsupportedEncodingException{

            return new String(Base64.encodeBase64(encrypt(key, text), false));
    }

    /**
     * 暗号化文字列を復号化して戻す。
     * <p>
     * 対象の文字列を複合化、Base64 デコードを行い返します。
     * </p>
     * @param key 鍵文字列
     * @param shaText 復号化対象文字列
     * @return 復号後文字列
     * @throws Exception
     */
    public final static String decrypt4b64(final String key,
            final String shaText) throws IOException, UnsupportedEncodingException,IllegalBlockSizeException,
            InvalidKeyException, NoSuchAlgorithmException, BadPaddingException,
            NoSuchPaddingException, UnsupportedEncodingException{

            return decrypt(key, Base64.decodeBase64((shaText).getBytes(ENCODE)));
    }

    /**
     * 文字列の暗号化。
     * <p>
     * 文字列の暗号化を行います。実行の際、対象文字列の他に、暗号化に使用する
     * 秘密鍵を必要とします。
     * 秘密鍵となる文字列は、本クラスには定義されておらず、定義位置、方式は
     * クライアントに依存します。
     * </p>
     * @param key 鍵文字列
     * @param text 暗号化対象文字列
     * @return 暗号化文字列
     * @throws IllegalBlockSizeException InvalidKeyException NoSuchAlgorithmException
     *          BadPaddingException NoSuchPaddingException UnsupportedEncodingException
     */
    public final static byte[] encrypt(final String key, final String text)
            throws IllegalBlockSizeException, InvalidKeyException,
            NoSuchAlgorithmException, BadPaddingException,
            NoSuchPaddingException, UnsupportedEncodingException {
        final SecretKeySpec sksSpec = new SecretKeySpec(key.getBytes(ENCODE),
                BLOW_FISH);
        final Cipher cipher = Cipher.getInstance(BLOW_FISH);
        cipher.init(Cipher.ENCRYPT_MODE, sksSpec);
        return cipher.doFinal(text.getBytes(ENCODE));
    }

    /**
     * 文字列の複合化
     *
     * <P>
     * 文字列の複合化を行います。実行の際、複合に使用する、秘密鍵を
     * 必要とします。
     * 秘密鍵となる文字列は、本クラスには定義されておらず、定義位置、方式は
     * クライアントに依存します。
     * </P>
     * @param key 鍵文字列
     * @param encrypted 復号化対象文字列
     * @return 復号後文字列
     * @throws IllegalBlockSizeException InvalidKeyException NoSuchAlgorithmException
     *          BadPaddingException NoSuchPaddingException UnsupportedEncodingException
     */
    public final static String decrypt(final String key, byte[] encrypted)
            throws IllegalBlockSizeException, InvalidKeyException,
            NoSuchAlgorithmException, BadPaddingException,
            NoSuchPaddingException, UnsupportedEncodingException {
        final SecretKeySpec sksSpec = new SecretKeySpec(key.getBytes(ENCODE),
                BLOW_FISH);
        final Cipher cipher = Cipher.getInstance(BLOW_FISH);
        cipher.init(Cipher.DECRYPT_MODE, sksSpec);
        return new String(cipher.doFinal(encrypted));
    }

    /**
     * BlowfishUtils の生成。
     * <p>デフォルトコンストラクタ隠蔽。</p>
     */
    private BlowfishUtils() {
        return;
    }

    // ADD ライセンス認証と外部認証連携の機能追加 ↓
    /**
     * パスワード文字が伏字にする
     *
     * @param pwd
     * @return String
     */
    public static String showSecretPwd(final String pwd) {
    	String strSecret = "";
    	for(int i = 0; i < pwd.length(); i++) {
    		strSecret += "●";
    	}
    	return strSecret;
    }
 	// ADD ライセンス認証と外部認証連携の機能追加 ↑
}
