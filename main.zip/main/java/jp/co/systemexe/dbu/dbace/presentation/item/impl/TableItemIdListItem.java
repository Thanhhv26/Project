/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;

/**
 * テーブル Item「カラム」名リスト表示用の Item クラスです。
 * <p>
 * SelectOneMenuItem インターフェースを実装した、リストアイテムクラスです。
 * </p><p>
 * ItemsSave を使用した HTML 中への永続化のため Serializable インターフェースを
 * 実装しています。
 * </p>
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class TableItemIdListItem implements Serializable, SelectOneMenuItem {

    /**
     * serialVersionUID を保持します。
     */
    private static final long serialVersionUID = 2637857840715069404L;

    /**
     * Item ID を保持します。 <p>システム内部で扱われる テーブル ID です。</p>
     */
    private String value;

    /**
     * Item 表示名「仮名」を保持します。
     * <p>ユーザーが定義するテーブルIDに付けた表示用名称です。</p>
     */
    private String label;

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getLabel()
     */
    public String getLabel() {
        return this.label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#getValue()
     */
    public String getValue() {
        return this.value;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setLabel(java.lang.String)
     */
    public void setLabel(final String label) {
        this.label = label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem#setValue(java.lang.String)
     */
    public void setValue(final String value) {
        this.value = value;
    }

    /**
     * TableItemIdListItem の生成。
     * <p>コンストラクタ。</p>
     */
    public TableItemIdListItem() {
        super();
    }

}
