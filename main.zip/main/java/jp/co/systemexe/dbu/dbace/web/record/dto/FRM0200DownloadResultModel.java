/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author bao-anh
 *
 */

@Data
public class FRM0200DownloadResultModel {
	private String connectDefinisionId;
	private String tableId;

	private String filePath;
	private String fileName;



	private List<MessageInfo> messageInfo;

	public FRM0200DownloadResultModel() {
		messageInfo = new ArrayList<MessageInfo>();
	}
}
