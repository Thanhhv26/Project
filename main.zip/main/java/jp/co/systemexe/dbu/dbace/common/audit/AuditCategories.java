/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.audit;

/**
 * 監査カテゴリ 列挙体。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum AuditCategories {
   /**
     * ログイン・ログアウト
     */
    LOGIN_LOGOUT("LOGIN/LOGOUT", "ログイン", "ユーザーのログイン、ログアウトを監査", true),
    /**
     * 外部認証操作
     */
    EXTERNAL_AUTHENTICATION("AUDIT", "外部認証操作", "外部認証連携の変更を監査", true),
    /**
     * データ操作
     */
    EXCUTE("EXCUTE", "データ操作", "テーブルへのデータ作成/編集/削除/参照を監査 ", true),
    /**
     * ユーザ操作
     */
    USER_OPERATION("USER OPERATION", "ユーザー操作", "ユーザー情報の作成/編集(権限変更含む)/削除/を監査", true),
    /**
     * ユーザ権限操作
     */
    USER_AUTHORITY_CHANGE("USER AUTHORITY CHANGE", "ユーザー権限操作", "ユーザーの権限変更を監査します", false),
    /**
     * 接続定義
     */
    CONNECTED_DEFINITION("CONNECTED DEFINITION", "接続定義操作", "データベースへの接続設定の作成/編集/削除を監査", true),
    /**
     * 画面制御
     */
    GUI_SETTING("GUI SETTING", "画面設定操作", "DB エース メンテナンスエディションの画面設定の変更を監査", true),
    /**
     * 監査ログ設定
     */
    AUDIT_SETTING("AUDIT SETTING", "監査ログ設定操作", "監査ログ設定の変更を監査します", false),
    /**
     * DBオブジェクト操作
     */
	OBJECT_OPERATION("OBJECT OPERATION", "DBオブジェクト操作", "オブジェクトの登録/同期/削除を監査", false),
	/**
     * リレーション操作
     */
	RELATION("RELATION", "リレーション操作", "リレーション操作の作成/編集/削除/参照を監査", true),
	/**
     * 画面作成操作
     */
	MAKE_VIEW("MAKE VIEW", "画面作成操作", "オブジェクトを利用した画面の作成/編集/削除/参照を監査", true);

    private String categoryLogName;
    public String getCategoryLogName() {
        return categoryLogName;
    }

    private String categoryDispName;
    public String getCategoryDispName() {
        return categoryDispName;
    }

    private String categoryExplanation;
    public String getCategoryExplanation() {
        return categoryExplanation;
    }

    private boolean enable;
    public boolean isEnable() {
        return enable;
    }

    private AuditCategories(
            final String categoryLogName,
            final String categoryDispName,
            final String categoryExplanation,
            final boolean enable) {
        this.categoryLogName = categoryLogName;
        this.categoryDispName = categoryDispName;
        this.categoryExplanation = categoryExplanation;
        this.enable = enable;
    }

}
