/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;
import jp.co.systemexe.dbu.dbace.common.util.LicenseKeyUtils;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfEnvironmentSetting;
import jp.co.systemexe.dbu.dbace.domain.logic.CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.DeletionProcessingOfTableFromRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.RetrievalProcessingOfRecordFromDatabaseLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.TableNameListIsAcquiredFromDatabaseLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.TableNameListIsAcquiredFromRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.TableRegistrationToRepositoryLogic;
import jp.co.systemexe.dbu.dbace.domain.service.CreationService;
import jp.co.systemexe.dbu.dbace.library.util.Constants;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.presentation.CharacterOfSystemFixation;
import jp.co.systemexe.dbu.dbace.presentation.RegisteredInRepository;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectTableItemForReposiotrySetting;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.ConnectDefinitionListItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.TableIdListItem;
import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.repository.dto.ChangeColumnInfoDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.DeleteInfoDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.DeleteResultModel;
import jp.co.systemexe.dbu.dbace.web.repository.dto.FRM0300ResultModel;
import jp.co.systemexe.dbu.dbace.web.repository.dto.ObjectSyncronizeDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.RelationScreenDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.RelationScreenForDeleteDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SearchCriteria;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SelectTable;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SelectTableItemForReposiotrySettingAndMessage;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SelectTablesAndItemList;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SelectTablesDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SelectTablesRegister;
import jp.co.systemexe.dbu.dbace.web.repository.dto.SynchrInfoDTO;
import jp.co.systemexe.dbu.dbace.web.repository.dto.TdTableId;
import jp.co.systemexe.dbu.dbace.web.repository.dto.TdTableName;
import jp.co.systemexe.dbu.dbace.web.repository.dto.TrDTO;
import jp.co.systemexe.dbu.dbace.web.repository.model.ChangeColumnItem;
import jp.co.systemexe.dbu.dbace.web.repository.model.ColumnChangePresence;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;
import jp.co.systemexe.dbu.dbace.web.user.dto.PageInfo;

/**
 * リポジトリ情報構築画面要素ページクラス。
 * <p>
 * リポジトリ情報設定クラスです。リポジトリへのテーブルの追加登録、
 * 登録の削除を行います。
 * </p><p>
 * 登録の際には、データベース内のテーブルメタデータを元に、リポジトリ内の画面
 * 項目定義情報の初期化を行います。<br />
 * 具体的には各項目の HTML 要素型やプライマリキー属性の付加などの初期値割り振り
 * を行います。
 * </p>
 *
 * @author tu-lenh
 * @version 0.0.0
 */
@RestController
@RequestMapping(value = "/data")
public class RepositoryController extends AbstractController {
	private static final long serialVersionUID = 1L;
	@Autowired
	CreationService creationService;
	/**
	 * get info page
	 * @return view
	 */
	@RequestMapping(value = "/getInfoPage", method = { RequestMethod.POST })
	public PageInfo getInfoPage() throws Exception {
		return new PageInfo();
	}

	@RequestMapping(value="/repository",method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index(Model model) throws Exception {
		ModelAndView mv = new ModelAndView(PageConst.SCREEN_OBJECT_SETTING);
		model.addAttribute("connectDefinitionIdItems", initDataForConnectDefinitionItems());
		return mv;
	}

	@RequestMapping(value = "/repository/getsearchresult",method = RequestMethod.POST )
	 public @ResponseBody SelectTableItemForReposiotrySettingAndMessage doOnceValueTableSearch(@RequestBody SearchCriteria search) {
		SelectTableItemForReposiotrySettingAndMessage selectTableItemForReposiotrySettingAndMessage= new SelectTableItemForReposiotrySettingAndMessage();
		final boolean isCheckboxRegesterd = Boolean.valueOf(search.getRegistered());
    	final boolean isCheckboxUnRegesterd = Boolean.valueOf(search.getUnRegistered());
    	final boolean isCheckboxChanged =Boolean.valueOf(search.getChanged());
    	final boolean isCheckboxWarnning = Boolean.valueOf(search.getWarning());
    	List<SelectTableItemForReposiotrySetting> selectTableItems;
    	String conditionOfTableName = search.getConditionOfTableName();
    	String selectedConnectDefinisionId = search.getConnectDefinitionId();
    	String userId = getUserInfo().getId();
    	if (StringUtils.isEmpty(selectedConnectDefinisionId)) {
        	// MI-E-0064=接続定義を選択してください
        	String message = MessageUtils.getMessage("MI-E-0064");
        	selectTableItemForReposiotrySettingAndMessage.setStatus(Constants.CONST_STATUS_NG);
        	selectTableItemForReposiotrySettingAndMessage.setMessage(message);
        	selectTableItemForReposiotrySettingAndMessage.setSelectTableItemForReposiotrySettingList(new ArrayList<SelectTableItemForReposiotrySetting>());
            return selectTableItemForReposiotrySettingAndMessage;
        }
			try {
	            final List<IdSelectable> repList;
	            final List<String> tableList;
	            final String condition;
	            try {/* リポジトリXML上に登録されているテーブル一覧を取得*/
	                condition = getFilterdConditionOfTableName(conditionOfTableName);
	                final TableNameListIsAcquiredFromRepositoryLogic repository = new TableNameListIsAcquiredFromRepositoryLogic();
	                if (condition.equals("")) {																				//検索条件が空
	                    repList = repository.getTableNameList(selectedConnectDefinisionId);
	                } else {																								//検索条件
	                    repList = repository.extractTableNameFromId(selectedConnectDefinisionId, condition);
	                }
	            } catch (final ApplicationDomainLogicException e) {
	            	OutputAuditLog.writeGuiSettingLog(
		            		AuditEventKind.SEARCH,
		            		getUserInfo(),
		            		search.getConnectDefinitionId(),
		            		search.getConditionOfTableName(),//tableId
		            		AuditStatus.failure,
		               		String.valueOf(0));
	                throw new ApplicationDomainLogicException(e);
	            }
	            try {/* 対象DB上のテーブル一覧を取得 */
	                final TableNameListIsAcquiredFromDatabaseLogic database = new TableNameListIsAcquiredFromDatabaseLogic();
	                if (condition.equals("")) {																				//検索条件が空
	                    tableList = database.getTableNameList(selectedConnectDefinisionId,condition,userId );
	                } else {																								//検索条件入力あり
	                    tableList = database.getTableNameList(selectedConnectDefinisionId,condition,userId);
	                }
	            } catch (final ApplicationDomainLogicException e) {
	            	selectTableItemForReposiotrySettingAndMessage.setStatus(Constants.CONST_STATUS_NG);
	            	selectTableItemForReposiotrySettingAndMessage.setMessage(e.getMessage());
	            	selectTableItemForReposiotrySettingAndMessage.setSelectTableItemForReposiotrySettingList(new ArrayList<SelectTableItemForReposiotrySetting>());
	            	OutputAuditLog.writeGuiSettingLog(
		            		AuditEventKind.SEARCH,
		            		getUserInfo(),
		            		search.getConnectDefinitionId(),
		            		search.getConditionOfTableName(),//tableId
		            		AuditStatus.failure,
		               		String.valueOf(0));
	                return selectTableItemForReposiotrySettingAndMessage;
	            }
	            final List<SelectTableItemForReposiotrySetting> itemList//最終的に一覧に使用するリスト
	            	= new ArrayList<SelectTableItemForReposiotrySetting>();

	            if (isCheckboxRegesterd || isCheckboxUnRegesterd || isCheckboxChanged) {									//登録済み・未登録・テーブル定義変更有
	            	Map<String, Boolean> isDifferenceMap
	            	= new HashMap<String, Boolean>();
	            	if (isCheckboxRegesterd || isCheckboxChanged) {															//登録済み・テーブル定義変更有
	            		final List<String> tableIdList = new ArrayList<String>();
	            		for (final IdSelectable rep : repList) {															//リポジトリXML上のテーブル一覧情報を変数に設定
	                		if (tableList != null && tableList.size() > 0 && tableList.contains(rep.getId())) {															//リポジトリXML上にもDB上にも存在するテーブルのとき
	                			tableIdList.add(rep.getId());																//テーブル一覧情報へんすう
	                		}
	            		}
	                	final CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic logic = new CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic();
	                	isDifferenceMap = logic.isDifferenceMap(selectedConnectDefinisionId,tableIdList,userId);
	                }
		            for (final String tableId : tableList) {						//DB上のテーブル一覧数分だけ繰り返す
		                final SelectTableItemForReposiotrySetting buff
		                	= searchRepository(
		                			repList,
		                			tableId,
		                			isDifferenceMap,
		                			isCheckboxRegesterd,
		                			isCheckboxUnRegesterd,
		                			isCheckboxChanged);
		                if (buff != null) {
		                    itemList.add(buff);
		                }
		            }
	            }

	            if (isCheckboxWarnning) {											//DBから欠落チェックがある場合
	            	for (IdSelectable buff : repList) {								//XMLファイル上の登録数分だけ繰り返す
	            		if (tableList!=null && tableList.size() >= 0 && tableList.contains(buff.getId()) == false) {			//XMLファイルに登録されているのにDBから取得したテーブル一覧に未存在のとき
	            			final SelectTableItemForReposiotrySetting item = new SelectTableItemForReposiotrySetting();
	            			item.setValue(buff.getId());							//IDを設定
	            			item.setLabel(buff.getLabel());							//表示を設定
	            			item.setTableRegisteredInRepository(					//状態（DBから欠落）を設定
	            					messageService.getMessage(RegisteredInRepository.WARNING.getValue()));
	            			itemList.add(item);										//一覧表示に追加
	            		}
	            	}
	            }
	            selectTableItems = itemList;
	            if (itemList.size() == 0) {
	            	// MI-E-0063=該当のレコードが存在しません。
	            	String message = MessageUtils.getMessage("MI-E-0063");
	            	selectTableItemForReposiotrySettingAndMessage.setStatus(Constants.CONST_STATUS_OK);
	            	selectTableItemForReposiotrySettingAndMessage.setMessage(message);
	            	selectTableItemForReposiotrySettingAndMessage.setSelectTableItemForReposiotrySettingList(new ArrayList<SelectTableItemForReposiotrySetting>());
	                return selectTableItemForReposiotrySettingAndMessage;
	            }
	        } catch (final Exception e) {
	            getLogger().error(e);
	            selectTableItemForReposiotrySettingAndMessage.setStatus(Constants.CONST_STATUS_NG);
	            selectTableItemForReposiotrySettingAndMessage.setMessage(e.getMessage());
	            selectTableItemForReposiotrySettingAndMessage.setSelectTableItemForReposiotrySettingList(new ArrayList<SelectTableItemForReposiotrySetting>());
	            OutputAuditLog.writeGuiSettingLog(
	            		AuditEventKind.SEARCH,
	            		getUserInfo(),
	            		search.getConnectDefinitionId(),
	            		search.getConditionOfTableName(),//tableId
	            		AuditStatus.failure,
	               		String.valueOf(0));
                return selectTableItemForReposiotrySettingAndMessage;
	        }
			selectTableItemForReposiotrySettingAndMessage.setStatus(Constants.CONST_STATUS_OK);
			selectTableItemForReposiotrySettingAndMessage.setMessage(Constants.CONST_STATUS_OK);
			selectTableItemForReposiotrySettingAndMessage.setSelectTableItemForReposiotrySettingList(selectTableItems);
			OutputAuditLog.writeGuiSettingLog(
            		AuditEventKind.SEARCH,
            		getUserInfo(),
            		search.getConnectDefinitionId(),
            		"",//tableId
            		AuditStatus.success,
               		String.valueOf(selectTableItemForReposiotrySettingAndMessage.getSelectTableItemForReposiotrySettingList().size()));
			return selectTableItemForReposiotrySettingAndMessage;
	 }

	/**
    *
    * リポジトリ内の登録リストからテーブル名を検索し、対応するオブジェクトを戻す。
    * <p>
    * リポジトリ内に存在しない場合は新規に SelectTableItemForReposiotrySetting オブジェクトを生成し、
    * データベーステーブル名を設定して戻します。</p>
    * <p>
    * リポジトリ登録済・未登録の表示列に「登録済、未登録、DBから欠落」の文言
    * を補完して戻します。</p>
    *
    * @return
    */
   private SelectTableItemForReposiotrySetting searchRepository(
           final List<IdSelectable> list,
           final String tableId,
           final Map<String, Boolean> isDifferenceMap,
           final boolean isCheckboxRegesterd,
           final boolean isCheckboxUnRegesterd,
           final boolean isCheckboxChanged)
   		throws ApplicationDomainLogicException {
       IdSelectable ids = null;
       for (final IdSelectable rep : list) {
           if (rep.getId().equals(tableId)) {
               ids = rep;
               break;
           }
       }
       if (ids == null) {
           if (isCheckboxUnRegesterd) {																				//未登録チェックあり
               final SelectTableItemForReposiotrySetting setting = new SelectTableItemForReposiotrySetting();
               setting.setValue(tableId);
//               setting.setLabel(tableId);
               setting.setTableRegisteredInRepository(
            		   messageService.getMessage(messageService.getMessage(RegisteredInRepository.UN_REGISTERED.getValue())));
               return setting;
           } else {
               return null;
           }
       } else {
           if (isCheckboxRegesterd || isCheckboxChanged) {																//登録済またはテーブル定義変更有
           	final RegisteredInRepository status
           		= isDifferenceMap.get(tableId) ?
           				RegisteredInRepository.CHANGED : RegisteredInRepository.REGISTERED;
           	if ((isCheckboxRegesterd && status == RegisteredInRepository.REGISTERED)								//登録済
           			|| (isCheckboxChanged && status == RegisteredInRepository.CHANGED)) {
           		final SelectTableItemForReposiotrySetting setting = new SelectTableItemForReposiotrySetting();
                   setting.setValue(tableId);
                   //setting.setLabel(ids.getLabel() + "(" + tableId + ")");
                   setting.setLabel(ids.getLabel());
                   setting.setTableRegisteredInRepository(messageService.getMessage(status.getValue()));
                   return setting;
               } else {
           		return null;
           	}
           } else {
               return null;
           }
       }
   }

    /**
     * 検索用テーブル名からブランクや ASCII 制御文字を除去して戻します。
     * @return String
     */
    private String getFilterdConditionOfTableName(String conditionOfTableName) {
        if (conditionOfTableName == null) {
            return "";
        }
        return "".concat(conditionOfTableName.trim());
    }

	@RequestMapping(value = "/repository/checktablevalid",method = RequestMethod.POST )
	 public @ResponseBody Map<String,String> doOnceAddRepositoryInformation(@RequestBody SelectTablesAndItemList selectTablesAndItemList) {
		Map<String,String> resultMessage = new HashMap<String,String>();
		boolean isChecked = false;
		List<SelectTable> selectTables = selectTablesAndItemList.getSelectTables();
		List<SelectTableItemForReposiotrySetting> itemList=selectTablesAndItemList.getItemList();

		for (SelectTable selectTbl : selectTables) {
			isChecked = true;
			for (SelectTableItemForReposiotrySetting item : itemList) {
				if(selectTbl.getTableId().equals(item.getValue()) && item.getTableRegisteredInRepository().equals(messageService.getMessage(RegisteredInRepository.REGISTERED.getValue()))){
					// MI-E-0090=選択したオブジェクトに既に登録済みのオブジェクトがございます。登録し直す場合は一度リポジトリから削除し、再度追加操作を実行して下さい
					String message = MessageUtils.getMessage("MI-E-0089_1");
					resultMessage.put("table",message);
					return resultMessage;
				}
				if(selectTbl.getTableId().equals(item.getValue()) && item.getTableRegisteredInRepository().equals(messageService.getMessage(RegisteredInRepository.WARNING.getValue()))){
					// MI-E-0089=選択したオブジェクトに DB 内から欠落しているオブジェクトがございます。削除以外の操作は出来ません。
					String message = MessageUtils.getMessage("MI-E-0089_3");
					resultMessage.put("table", message);
					return resultMessage;
				}
				if(selectTbl.getTableId().equals(item.getValue()) && item.getTableRegisteredInRepository().equals(messageService.getMessage(RegisteredInRepository.CHANGED.getValue()))){
					// MI-E-0142=選択したオブジェクトに オブジェクト定義に変更があるオブジェクトがございます。同期、削除以外の操作は出来ません。
					String message = MessageUtils.getMessage("MI-E-0089_2");
					resultMessage.put("table", message);
					return resultMessage;
				}
			}
		}
        if (!isChecked) {
        	// MI-E-0096=追加・削除・同期の対象となるオブジェクトを選択して下さい。
        	String message1 = MessageUtils.getMessage("MI-E-0096_1");
			resultMessage.put("table", message1);
			return resultMessage;
        }
        resultMessage.put("table", Constants.CONST_STATUS_OK);
		return resultMessage;
	 }

	 /**
     * 「オブジェクト情報の同期」ボタンのイベントハンドラ。
     * <p>
     * リポジトリ情報の同期画面要素へ遷移します。</p>
     * <p>
     * 事前に選択されたテーブルがテーブル定義変更有であるかのチェックを行い、
     * テーブル定義変更有以外の場合はメッセージを出力してポストバックします。</p>
     *
     * @return Map<String,String>
     */
	@RequestMapping(value = "/repository/checktablesyncvalid",method = RequestMethod.POST )
	 public @ResponseBody Map<String,String> doOnceSynchronizeRepositoryInformation(@RequestBody SelectTablesAndItemList selectTablesAndItemList) throws Exception {
		Map<String,String> resultMessage = new HashMap<String,String>();
		int checkedCount = 0;
		List<SelectTable> selectTables = selectTablesAndItemList.getSelectTables();
		List<SelectTableItemForReposiotrySetting> itemList=selectTablesAndItemList.getItemList();

		for (SelectTable selectTbl : selectTables) {
			checkedCount++;
			for (SelectTableItemForReposiotrySetting item : itemList) {
				if(selectTbl.getTableId().equals(item.getValue()) && item.getTableRegisteredInRepository().equals(messageService.getMessage(RegisteredInRepository.UN_REGISTERED.getValue()))){
					// MI-E-0095=選択したオブジェクトに既に未登録オブジェクトがございます。同期操作は実行出来ません。
					String message = MessageUtils.getMessage("MI-E-0095_1");
					resultMessage.put("table", message);
					return resultMessage;
				}
				if(selectTbl.getTableId().equals(item.getValue()) && item.getTableRegisteredInRepository().equals(messageService.getMessage(RegisteredInRepository.WARNING.getValue()))){
					// MI-E-0089=選択したオブジェクトに DB 内から欠落しているオブジェクトがございます。削除以外の操作は出来ません。
					String message = MessageUtils.getMessage("MI-E-0089_4");
					resultMessage.put("table", message);
					return resultMessage;
				}
			}
		}
        if (checkedCount == 0) {
            // MI-E-0096=追加・削除・同期の対象となるオブジェクトを選択して下さい。
        	String message2 = MessageUtils.getMessage("MI-E-0096_2");
			resultMessage.put("table", message2);
 			return resultMessage;
        } else if (checkedCount != 1) {
        	// MI-E-0143=複数オブジェクトが選択されました。同期処理は1オブジェクト毎にしか行えません。1オブジェクトを選択してください。
        	String message = MessageUtils.getMessage("MI-E-0143");
        	resultMessage.put("table", message);
        	return resultMessage;
        }
        //is Deleted Object
		if (!isDeletedObject(selectTablesAndItemList)) {
			String message = MessageUtils.getMessage("MI-E-0116");
			resultMessage.put("table", Constants.CONST_STATUS_NG);
			resultMessage.put("message", message);
			resultMessage.put("isDeletedObject", "true");
			return resultMessage;
		}
       resultMessage.put("table", Constants.CONST_STATUS_OK);
	   return resultMessage;
	 }

	@RequestMapping(value = "/repository/checktabledelvalid",method = RequestMethod.POST )
	 public @ResponseBody Map<String,String> doOnceDeleteRepositoryInformation(@RequestBody SelectTablesAndItemList selectTablesAndItemList) throws Exception {
		Map<String,String> resultMessage = new HashMap<String,String>();
		List<SelectTable> selectTables = selectTablesAndItemList.getSelectTables();
		List<SelectTableItemForReposiotrySetting> itemList=selectTablesAndItemList.getItemList();
		if (selectTables != null && selectTables.size() == 0) {
        	// MI-E-0096=追加・削除・同期の対象となるオブジェクトを選択して下さい。
        	String message3 = MessageUtils.getMessage("MI-E-0096_3");
			resultMessage.put("table", message3);
			return resultMessage;
        }
        for (SelectTable selectTbl : selectTables) {
			for (SelectTableItemForReposiotrySetting item : itemList) {
				if(selectTbl.getTableId().equals(item.getValue())
						&& item.getTableRegisteredInRepository().equals(messageService.getMessage(RegisteredInRepository.UN_REGISTERED.getValue()))){
					//MI-E-0091=選択したオブジェクトに既に未登録オブジェクトがございます。削除操作は実行出来ません。
					String message = MessageUtils.getMessage("MI-E-0091_1");
					resultMessage.put("table",message);
					return resultMessage;
				}
			}
		}
        //is Deleted Object
		if (!isDeletedObject(selectTablesAndItemList)) {
			String message = MessageUtils.getMessage("MI-E-0116");
			resultMessage.put("table", Constants.CONST_STATUS_NG);
			resultMessage.put("message", message);
			resultMessage.put("isDeletedObject", "true");
			return resultMessage;
		}
      resultMessage.put("table", Constants.CONST_STATUS_OK);
	   return resultMessage;
	 }

	/**
	 * is Deleted Object
	 * @return true : exist /false : not exist
	 */
	public boolean isDeletedObject(SelectTablesAndItemList param) throws Exception {
		// check object exist
		List<SelectTable> selectTables = param.getSelectTables();
		for (SelectTable selectTbl : selectTables) {
			TableFormDto check = creationService.getTableFormDtoByID(param.getConnectDefinitionId(),selectTbl.getTableId(), getUserAuthority());
			// if check === null => check.getId() is error and
			// =>ApplicationDomainLogicException
			if (check == null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * is Deleted Object
	 * @return true : exist /false : not exist
	 */
	public boolean isDeletedObjectDel(SelectTablesRegister param) throws Exception {
		// check object exist
		List<TrDTO> selectTables = param.getTable();
		for (TrDTO selectTbl : selectTables) {
			TableFormDto check = creationService.getTableFormDtoByID(param.getConnectDefinitionId(),selectTbl.getTdTableId().getValue(), getUserAuthority());
			// if check === null => check.getId() is error and
			// =>ApplicationDomainLogicException
			if (check == null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @return
	 */
	private List<SelectOneMenuItem> initDataForConnectDefinitionItems(){
		try {
			List<SelectOneMenuItem> connectDefinitionItems = new ArrayList<SelectOneMenuItem>();
	        final AcquisitionOfConnectDefinitionListLogic logic = new AcquisitionOfConnectDefinitionListLogic();
	        UserAuthority userAuthority =  getUserAuthority();
	        for (final Iterator<IdSelectable> ite = logic.getIdSelectableList(userAuthority).listIterator(); ite.hasNext();) {
	            final IdSelectable def = ite.next();
	            if (def.getId().equals(
	                CharacterOfSystemFixation.SYSTEM.getCode()) == false) {
	                final ConnectDefinitionListItem item = new ConnectDefinitionListItem();
	                item.setValue(def.getId());
	                item.setLabel(def.getLabel());
	                connectDefinitionItems.add(item);
	            }
	        }
			return connectDefinitionItems;
        } catch (final Exception e) {
            getLogger().error(e);
            return null;
        }
	}

	@RequestMapping(value = "/objecteditconfirmation/checktableregvalid",method = RequestMethod.POST )
	 public @ResponseBody Map<String,String> doOnceInsertAddTable(@RequestBody SelectTablesRegister selectTablesRegister) {
		Map<String,String> resultMessage = new HashMap<String,String>();
		boolean isChecked = false;
		String connectDefinitionId = selectTablesRegister.getConnectDefinitionId();
		List<TrDTO> itemList=selectTablesRegister.getTable();
		String message = MessageUtils.getMessage("MI-F-0026");

	    /* リポジトリXML上に登録されているテーブル一覧を取得*/
	    final TableNameListIsAcquiredFromRepositoryLogic repository = new TableNameListIsAcquiredFromRepositoryLogic();
	    List<IdSelectable> repList = null;
		try {
			repList = repository.getTableNameList(connectDefinitionId);
		} catch (ApplicationDomainLogicException e) {
			new MessageInfo(e, MessageType.ERROR);
		}
		for (int i =0;i <itemList.size();i++) {
			TrDTO item = itemList.get(i);
			if (StringUtils.isEmpty(item.getTdTableName().getValue())) {
				// 値を入力してください(dbo.PassportDetails)(line : 1)
				resultMessage.put(item.getTdTableName().getId(), message);
				isChecked = true;
			}
		}
		if (isChecked) {
			//if message error same -- > show 1 error
			for(String id:resultMessage.keySet()) {
				String mess = resultMessage.get(id);
				if(checkMessageDupplicate(mess,resultMessage)){
					resultMessage.put(id, "");
				}
			}
			return resultMessage;
		}

		for (int i =0;i <itemList.size();i++) {
			TrDTO item = itemList.get(i);
			if (StringUtils.isEmpty(item.getTdTableName().getValue())) {
				// 値を入力してください(dbo.PassportDetails)(line : 1)
				resultMessage.put(item.getTdTableName().getId(), message);
				isChecked = true;
				new MessageInfo(message, MessageType.ERROR);
			}
			//check table name display same name screen
			if (checkTableNameSameNameScreen(itemList,item.getTdTableId().getValue(),item.getTdTableName().getValue())) {
				String args[] = { item.getTdTableName().getValue()};
				String mess = MessageUtils.getMessage("MI-F-0032", args);
				resultMessage.put(item.getTdTableName().getId(), mess);
				isChecked = true;
				new MessageInfo(mess, MessageType.ERROR);
			}
			//check table name display same name repository
			if (checkTableNameSameNameRepository(repList,item.getTdTableName().getValue())) {
				String args[] = { item.getTdTableName().getValue()};
				String mess = MessageUtils.getMessage("MI-F-0031", args);
				resultMessage.put(item.getTdTableName().getId(), mess);
				isChecked = true;
				new MessageInfo(mess, MessageType.ERROR);
			}
		}
		//if message error same -- > show 1 error
		for(String id:resultMessage.keySet()) {
			String mess = resultMessage.get(id);
			if(checkMessageDupplicate(mess,resultMessage)){
				resultMessage.put(id, "");
			}
		}
       if (!isChecked) {
			//テーブル登録
       	SelectOneMenuItem[] confirmTableItems = convertItemListToConfirmTableItems(itemList);
			String status = doOnceInsert(connectDefinitionId,confirmTableItems);
			String messageSuccess = messageService.getMessage("frm0300.add.success");
			if (!status.equals(messageSuccess)) {
				resultMessage.put("message", status);
				new MessageInfo(status, MessageType.ERROR);
				return resultMessage;
			}
			resultMessage.put("message", messageSuccess);
			new MessageInfo(messageSuccess, MessageType.SUCCESS);
       }       
		return resultMessage;
	 }

	/**
	 * @param mess
	 * @param resultMessage
	 * @return
	 */
	private boolean checkMessageDupplicate(String mess, Map<String, String> resultMessage) {
		int count = 0;
		for (String id1 : resultMessage.keySet()) {
			if (mess.equals(resultMessage.get(id1))) {
				count++;
			}
		}
		if (count >= 2) {
			return true;
		}
		return false;
	}

	/**
	 * @param tableNameList
	 * @param tableName
	 * @return
	 */
	private boolean checkTableNameSameNameRepository(List<IdSelectable> repList,String tableName) {
		for (IdSelectable item : repList) {
			if (tableName.equals(item.getLabel())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param repList
	 * @param tableName
	 * @return
	 */
	private List<ChangeColumnItem> checkColumnNameSyncSameNameScreen(List<ChangeColumnItem> changeColumnItemList) {
		for (ChangeColumnItem item : changeColumnItemList) {
			int count = 0;
			List<ChangeColumnItem> changeColumnItemTemp = new ArrayList<ChangeColumnItem>();
			changeColumnItemTemp.add(item);
			for (ChangeColumnItem item1 : changeColumnItemList) {
				if (StringUtils.isNotEmpty(item.getColumnLabel()) && StringUtils.isNotEmpty(item1.getColumnLabel()) && item.getColumnLabel().equals(item1.getColumnLabel())) {
					count++;
					changeColumnItemTemp.add(item1);
				}
			}
			if (count >= 2) {
				return changeColumnItemTemp;
			}
		}
		return null;
	}

	/**
	 * @param repList
	 * @param tableName
	 * @return
	 */
	private boolean checkTableNameSyncSameNameRepository(List<IdSelectable> repList,String tableId,String tableName) {
		for (IdSelectable item : repList) {
			if (tableName.equals(item.getLabel()) && !tableId.equals(item.getId())) {
				return true;
			}
		}
		return false;
	}
	/**
	 * @param tableNameList
	 * @param tableName
	 * @return
	 */
	private boolean checkTableNameSameNameScreen(List<TrDTO> tableNameList,String tableId,String tableName) {
		for (TrDTO item : tableNameList) {
			if (tableName.equals(item.getTdTableName().getValue()) && !tableId.equals(item.getTdTableId().getValue())) {
				return true;
			}
		}
		return false;
	}

	public String doOnceInsert(String connectDefinitionId,SelectOneMenuItem[] confirmTableItems) {
   	//ADD ライセンス認証 機能追加　↓
   	//ライセンス認証機能(ライセンス数)の処理追加
   	//①＝システムプロパティにライセンス数を取得
   	//②＝リポジトリXMLに登録されているテーブル数[重複は除く])
   	//③＝選択されたテーブルの一覧の画面上で今回登録するテーブル数をカウント
   	final AcquisitionOfEnvironmentSetting logicEnv = new AcquisitionOfEnvironmentSetting();
   	final EnvironmentSettingDTO dto	= logicEnv.getAllProperties();
   	//①のライセンス数が「Unlimited」文字じゃないの場合、ライセンス違反をチェック：
		if (!LicenseKeyUtils.UNLIMITED.equalsIgnoreCase(dto.getLicenseCnt())) {
			//①＝システムプロパティにライセンス数を取得
			int numberTableRegisteredInRepository = logicEnv.countNumberOfTableHasRegisted();
			//③＝選択されたテーブルの一覧の画面上で今回登録するテーブル数をカウント
			int countTableNew = logicEnv.countNumberOfTableIsAddNew(connectDefinitionId,confirmTableItems);
			//②のリポジトリXMLに登録されているテーブル数[重複は除く] ＋ ③の（今回登録するテーブル数 -
			//今回登録するテーブル数のうち、既にリポジトリDBにあるテーブル） ＞ ①のライセンス数 の場合 （※）
			int licenseCnt = 0;
			try {
				licenseCnt = Integer.parseInt(dto.getLicenseCnt());
			} catch(NumberFormatException nEx) {
				licenseCnt = 0;
			}
			if (countTableNew + numberTableRegisteredInRepository > licenseCnt) {
				//MI-F-0020=ライセンス数の上限を超える登録操作です。{0}個のテーブル登録が可能です。
				Integer numberTableAdd = licenseCnt - numberTableRegisteredInRepository;
				final String args[] = { numberTableAdd.toString() };
				String message = MessageUtils.getMessage("MI-F-0020", args);
				return message;
			}
		}
   	//ADD ライセンス認証 機能追加　↑
       final TableRegistrationToRepositoryLogic logic = new TableRegistrationToRepositoryLogic();
       UserInfo userInfo = getUserInfo();
       String userId = userInfo.getId();
       String label = "";
       try {
           for (SelectOneMenuItem item : confirmTableItems) {
               try {
            	   label = item.getLabel();
                   logic.addTable(
                   		connectDefinitionId,
                   		item.getValue(),
                   		item.getLabel(),
                   		userId);

                   OutputAuditLog.writeGuiSettingLog(
                   		AuditEventKind.INSERT,
                   		userInfo,
                   		connectDefinitionId,
                   		label,
                   		AuditStatus.success,
                   		String.valueOf(1));
               } catch (final ApplicationDomainLogicException e) {
                   OutputAuditLog.writeGuiSettingLog(
                   		AuditEventKind.INSERT,
                   		userInfo,
                   		connectDefinitionId,
                   		label,
                   		AuditStatus.failure,
                   		String.valueOf(0));
                   return e.getMessage().substring(e.getMessage().lastIndexOf(":")+1);
               }
           }
       } catch (final Exception e) {
           getLogger().fatal(e.getMessage(), e);
           OutputAuditLog.writeGuiSettingLog(
           		AuditEventKind.INSERT,
           		userInfo,
           		connectDefinitionId,
           		label,
           		AuditStatus.failure,
           		String.valueOf(0));
           return e.getMessage();
       }
       String messageSuccess = messageService.getMessage("frm0300.add.success");
       return messageSuccess;
   }

	@RequestMapping(value = "/objectdeleteconfirmation/isdeletetable",method = RequestMethod.POST )
	 public @ResponseBody DeleteResultModel doDeleteTable(@RequestBody SelectTablesRegister selectTablesRegister) throws Exception{
		DeleteResultModel resultModel = new DeleteResultModel();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		String connectDefinitionId = selectTablesRegister.getConnectDefinitionId();
		List<TrDTO> itemList = selectTablesRegister.getTable();
		if (itemList.size() == 0) {
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			MessageInfo error = new MessageInfo();
			error = new MessageInfo("", MessageType.ERROR, "frm0320.table.delete", messageService);
			messageInfoList.add(error);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		 //is Deleted Object
		if (!isDeletedObjectDel(selectTablesRegister)) {
			MessageInfo error = new MessageInfo();
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0116", messageService);
			messageInfoList.add(error);
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}

		//RelationScreenForDeleteDTO{connectDefinitionId,tableFormId,relationId,relationLabel,tableFormIdTypeMultiTable,tableFormLabelTypeMultiTable}
		 List<RelationScreenForDeleteDTO> relationScreens = getRelationScreenUseTableDTO(selectTablesRegister);
		//if(type == check):return deleteInfoDTO{relationScreens}
		//if(type == delete && relationScreens.size() > 0):return deleteInfoDTO{relationScreens}
		if (selectTablesRegister.getType().equals("delete") && relationScreens.size() > 0) {
			DeleteInfoDTO resultData = new DeleteInfoDTO();
			resultData.setSelectTablesRegister(selectTablesRegister);
			resultData.setRelationScreens(relationScreens);
			resultModel.setResultData(resultData);
			resultModel.setStatus(Constants.CONST_STATUS_OK);
			resultModel.setMessageInfo(messageInfoList);
			new MessageInfo("object.del.success", MessageType.SUCCESS, messageService);
			return resultModel;
		} else if (selectTablesRegister.getType().equals("delete") && relationScreens.size() == 0) {
			//削除 tableForm type="table"
			SelectOneMenuItem[] confirmTableItems = convertItemListToConfirmTableItems(itemList);
			String status = doOnceDelete(connectDefinitionId,confirmTableItems);
			if (status.equals(Constants.CONST_STATUS_OK)) {
				resultModel.setStatus(Constants.CONST_STATUS_OK);
				resultModel.setMessageInfo(messageInfoList);
				new MessageInfo("object.del.success", MessageType.SUCCESS, messageService);
				return resultModel;
			}
		} else if (selectTablesRegister.getType().equals("check") && relationScreens.size() >= 0) {//テーブル削除
			DeleteInfoDTO resultData = new DeleteInfoDTO();
			resultData.setSelectTablesRegister(selectTablesRegister);
			resultData.setRelationScreens(relationScreens);
			resultModel.setResultData(resultData);
			resultModel.setStatus(Constants.CONST_STATUS_OK);
			resultModel.setMessageInfo(messageInfoList);
			new MessageInfo("object.del.success", MessageType.SUCCESS, messageService);
			return resultModel;
		}
		return resultModel;
	 }

	@RequestMapping(value = "/objectdeleteconfirmation/deleteRelationMultiTable",method = RequestMethod.POST )
	 public @ResponseBody FRM0300ResultModel deleteRelationMultiTable(@RequestBody DeleteInfoDTO deleteInfoDTO) {
		FRM0300ResultModel resultModel  = new  FRM0300ResultModel();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		String connectDefinitionId = deleteInfoDTO.getSelectTablesRegister().getConnectDefinitionId();
		List<TrDTO> itemList = deleteInfoDTO.getSelectTablesRegister().getTable();
		SelectOneMenuItem[] confirmTableItems = convertItemListToConfirmTableItems(itemList);
		//削除 tableForm type="table"
		String status = doOnceDelete(connectDefinitionId,confirmTableItems);
		//削除 tableForm type="multi-table"
		deleteRelationAndMultiTable(deleteInfoDTO);
		if (status.equals(Constants.CONST_STATUS_OK)) {
			resultModel.setStatus(Constants.CONST_STATUS_OK);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}
		return resultModel;
	}

	/**
	 * @param deleteInfoDTO
	 */
	private void deleteRelationAndMultiTable(DeleteInfoDTO deleteInfoDTO) {
		try {
			final TableRegistrationToRepositoryLogic logic = new TableRegistrationToRepositoryLogic();
			logic.deleteRelationAndMultiTable(deleteInfoDTO);
		} catch (final ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
	}

	/**
	 * @param selectTablesRegister
	 * @return
	 */
	private List<RelationScreenForDeleteDTO> getRelationScreenUseTableDTO(SelectTablesRegister selectTablesRegister) {
		try {
			final TableRegistrationToRepositoryLogic logic = new TableRegistrationToRepositoryLogic();
			return logic.getRelationScreenUseTableDTO(selectTablesRegister);
		} catch (final ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
		return null;
	}

	/**
	 * @param itemList
	 */
	private SelectOneMenuItem[] convertItemListToConfirmTableItems(List<TrDTO> itemList) {
		final List<SelectOneMenuItem> buf = new ArrayList<SelectOneMenuItem>();
		for (TrDTO selectItem : itemList) {
               final SelectOneMenuItem confirmItem = new TableIdListItem();
               confirmItem.setValue(selectItem.getTdTableId().getValue());
               confirmItem.setLabel(selectItem.getTdTableName().getValue());
               buf.add(confirmItem);
       }
		SelectOneMenuItem[] confirmTableItems = buf.toArray(new SelectOneMenuItem[0]);
		return confirmTableItems;
	}

	/**
	 * @param connectDefinitionId
	 * @param confirmTableItems
	 * @return
	 */
	public String doOnceDelete(String connectDefinitionId,SelectOneMenuItem[] confirmTableItems) {
       final DeletionProcessingOfTableFromRepositoryLogic logic = new DeletionProcessingOfTableFromRepositoryLogic();
       UserInfo userInfo = getUserInfo();
       String label = "";
       try {
           for (SelectOneMenuItem item : confirmTableItems) {
               try {
            	   label = item.getLabel();
                   logic.delete(connectDefinitionId,item.getValue());
                   OutputAuditLog.writeGuiSettingLog(
                   		AuditEventKind.DELETE,
                   		userInfo,
                   		connectDefinitionId,
                   		label,
                   		AuditStatus.success,
                   		String.valueOf(1));
               } catch (final ApplicationDomainLogicException e) {
                   OutputAuditLog.writeGuiSettingLog(
                   		AuditEventKind.DELETE,
                   		userInfo,
                   		connectDefinitionId,
                   		label,
                   		AuditStatus.failure,
                   		String.valueOf(0));
                   return e.getMessage().substring(e.getMessage().lastIndexOf(":")+1);
               }
           }
       } catch (final Exception e) {
           getLogger().fatal(e.getMessage(), e);
           OutputAuditLog.writeGuiSettingLog(
           		AuditEventKind.DELETE,
           		userInfo,
           		connectDefinitionId,
           		label,
           		AuditStatus.failure,
           		String.valueOf(0));
           return e.getMessage();
       }
       return Constants.CONST_STATUS_OK;
   }

	@RequestMapping(value="/objectsyncronize",method = RequestMethod.POST)
	public @ResponseBody ObjectSyncronizeDTO index(@RequestBody SelectTablesDTO selectTablesDTO,Model model) throws Exception {
		ObjectSyncronizeDTO objectSyncronizeDTO = doInitialize(selectTablesDTO);
		return objectSyncronizeDTO;
	}

	 /**
     * Page クラスの初期化イベントハンドラ。
	 */
	public ObjectSyncronizeDTO doInitialize(SelectTablesDTO selectTablesDTO) {
		String connectDefinitionId= selectTablesDTO.getConnectDefinitionId();
		List<SelectTable>  selectTables= selectTablesDTO.getSelectTables();
		SelectTable tableSync = selectTables.get(0);
		String tableId= tableSync.getTableId();
		String tableLabel  = tableSync.getTableName();
		//table info
		ObjectSyncronizeDTO objectSyncronizeDTO = new ObjectSyncronizeDTO();
		objectSyncronizeDTO.setConnectDefinitionId(connectDefinitionId);
		TrDTO trDTO = new TrDTO();
		trDTO.setId("id_tr");
		TdTableId tdTableId = new TdTableId();
		tdTableId.setId("id_tr_td1");
		tdTableId.setValue(tableId);
		TdTableName  tdTableName = new TdTableName();
		tdTableName.setId("id_tr_td2");
		tdTableName.setValue(tableLabel);
		trDTO.setTdTableId(tdTableId);
		trDTO.setTdTableName(tdTableName);
		objectSyncronizeDTO.setTrDTO(trDTO);

		final RecordEditorInformationDTO dto;
		String userId = getUserInfo().getId();
        try {
            final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			dto = logic.getRecordEditorInformation(connectDefinitionId,tableId,userId);
        } catch (final ApplicationDomainLogicException e) {
            getLogger().error(e.getMessage());
            return null;
        }
        final Map<String, TableItemDTO> itemDefinitions = dto.getTableForm().getTableItemMap();
        final Map<String, DefinitionOfColumn> definitionOfColumns = dto.getTableDef().getDefinitionOfColumnMap();
        final SortedMap<Integer, ChangeColumnItem> map = new TreeMap<Integer, ChangeColumnItem>();
        int sortIndex = 0;
        int id=1;
        final CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic logic = new CheckDifferenceOfColumnOnRepositoryAndDatabaseLogic();
        for (final TableItemDTO itemDto : itemDefinitions.values()) {
        	final ChangeColumnItem item = new ChangeColumnItem();
        	item.setId("id_tr" + id );
        	String itemId = itemDto.getItemId();
        	item.setColumnId(itemId);
        	item.setColumnLabel(itemDto.getItemLabel());
        	item.setSortIndex(itemDto.getSortIndex());
			if (itemDefinitions.get(itemId) != null && definitionOfColumns.get(itemId) != null
					&& logic.isChangeColumnAttribute(itemDefinitions.get(itemId), definitionOfColumns.get(itemId))) {
        		String updateVal = messageService.getMessage(ColumnChangePresence.update.getLabel());
				item.setChangePresence(ColumnChangePresence.update);
				item.setChangePresenceLabel(updateVal);
			} else if (definitionOfColumns.containsKey(itemDto.getItemId())) {
            	item.setChangePresence(ColumnChangePresence.no_change);
            	item.setChangePresenceLabel(ColumnChangePresence.no_change.getLabel());
        	} else {
        		String deleteVal = messageService.getMessage(ColumnChangePresence.delete.getLabel());
            	item.setChangePresence(ColumnChangePresence.delete);
            	//item.setChangePresenceLabel(ColumnChangePresence.delete.getLabel());
            	item.setChangePresenceLabel(deleteVal);
        	}
        	if (sortIndex < itemDto.getSortIndex()) {
        		sortIndex = itemDto.getSortIndex();
        	}
        	map.put(itemDto.getSortIndex(), item);
        	id = id + 1;
        }
        List<SelectOneMenuItem> copyColumnIdItems = createCopyColumnIdItems(map);
        for (final DefinitionOfColumn defDto : definitionOfColumns.values()) {
        	if (!itemDefinitions.containsKey(defDto.getColumnId())) {
        		sortIndex++;
            	final ChangeColumnItem item = new ChangeColumnItem();
            	item.setId("id_tr" + id );
            	item.setColumnId(defDto.getColumnId());
            	item.setColumnLabel(defDto.getColumnId());
            	String addVal = messageService.getMessage(ColumnChangePresence.add.getLabel());
            	item.setChangePresence(ColumnChangePresence.add);
            	//item.setChangePresenceLabel(ColumnChangePresence.add.getLabel());
            	item.setChangePresenceLabel(addVal);
            	item.setCopyColumnIdItems(copyColumnIdItems);
            	item.setSortIndex(sortIndex);
            	map.put(sortIndex, item);
        	}
        }
        List<ChangeColumnItem> changeColumnItems = new ArrayList<ChangeColumnItem>();
        for (Integer index : map.keySet()) {
        	changeColumnItems.add(map.get(index));
        }
        objectSyncronizeDTO.setChangeColumnItems(changeColumnItems);
		return objectSyncronizeDTO;
	}

	/**
	 * 定義をコピーする、コピー元カラム名リストを生成して戻します。
	 * <p>
	 * リポジトリXMLファイルに登録されている、カラムの一覧をリスト化します。
	 * </p>
	 *
	 * @param map
	 * @return
	 */
	private List<SelectOneMenuItem> createCopyColumnIdItems(
			final SortedMap<Integer, ChangeColumnItem> map) {
        final List<SelectOneMenuItem> ret = new ArrayList<SelectOneMenuItem>();
		for (final Integer index : map.keySet()) {
        	final ChangeColumnItem changeColumnItem = map.get(index);
        	final SelectableItem item = new SelectableItem();
        	item.setValue(changeColumnItem.getColumnId());
        	item.setLabel(changeColumnItem.getColumnLabel());
        	ret.add(item);
        }

		return ret;
	}

	@RequestMapping(value = "/objectsyncronize/issavetablesynchr",method = RequestMethod.POST )
	 public @ResponseBody FRM0300ResultModel doOnceInsert(@RequestBody ObjectSyncronizeDTO objectSyncronizeDTO) {
		FRM0300ResultModel resultModel = new FRM0300ResultModel();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		MessageInfo error = new MessageInfo();

		String connectDefinitionId = objectSyncronizeDTO.getConnectDefinitionId();
		TrDTO trDto=objectSyncronizeDTO.getTrDTO();

		 //is Deleted Object
		TableFormDto check = creationService.getTableFormDtoByID(connectDefinitionId,trDto.getTdTableId().getValue(), getUserAuthority());
		// if check === null => check.getId() is error and
		// =>ApplicationDomainLogicException
		if (check == null) {//true : exist /false : not exist
			error = new MessageInfo("", MessageType.ERROR, "MI-E-0116", messageService);
			messageInfoList.add(error);
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}

		String tableLabel = trDto.getTdTableName().getValue();
		if(StringUtils.isEmpty(tableLabel)){
			//テーブル表示名は必須入力項目です。
			error = new MessageInfo("", MessageType.ERROR, "MI-F-0028", messageService);
			String idTableLabel = "#" + trDto.getTdTableName().getId();
			error.setIdError(idTableLabel);
			messageInfoList.add(error);
		}

		//check table name display same name repository
		/* リポジトリXML上に登録されているテーブル一覧を取得*/
	    final TableNameListIsAcquiredFromRepositoryLogic repository = new TableNameListIsAcquiredFromRepositoryLogic();
	    List<IdSelectable> repList = null;
		try {
			repList = repository.getTableNameList(connectDefinitionId);
		} catch (ApplicationDomainLogicException e) {
			getLogger().error(e);
		}
		String tableId = objectSyncronizeDTO.getTrDTO().getTdTableId().getValue();
		if (checkTableNameSyncSameNameRepository(repList,tableId,tableLabel)) {
			String args[] = { tableLabel};
			String mess = MessageUtils.getMessage("MI-F-0031", args);
			error = new MessageInfo(mess,MessageType.ERROR);
			String idTableLabel = "#" + trDto.getTdTableName().getId();
			error.setIdError(idTableLabel);
			messageInfoList.add(error);
		}

		List<ChangeColumnItem> changeColumnItemList = objectSyncronizeDTO.getChangeColumnItems();

		List<ChangeColumnItem> changeColumnItemTemp = checkColumnNameSyncSameNameScreen(changeColumnItemList);
		if (changeColumnItemTemp != null) {
			for (ChangeColumnItem column : changeColumnItemTemp) {
				String args[] = { column.getColumnLabel()};
				String mess = MessageUtils.getMessage("MI-F-0032", args);
				error = new MessageInfo(mess,MessageType.ERROR);
				String idColumnLabel = "#" + column.getId();
				error.setIdError(idColumnLabel);
				messageInfoList.add(error);
			}
		}

		for (ChangeColumnItem column : changeColumnItemList) {
			if (StringUtils.isEmpty(column.getColumnLabel())) {
				// カラム表示名は必須入力項目です。(line : 2)
				error = new MessageInfo("", MessageType.ERROR, "MI-F-0027", messageService);
				String idColumnLabel = "#" + column.getId();
				error.setIdError(idColumnLabel);
				messageInfoList.add(error);
			}
		}
		if (messageInfoList.size() > 0) {
			resultModel.setStatus(Constants.CONST_STATUS_NG);
			resultModel.setMessageInfo(messageInfoList);
			return resultModel;
		}

		String addVal = messageService.getMessage(ColumnChangePresence.add.getLabel());
		String delVal = messageService.getMessage(ColumnChangePresence.delete.getLabel());
		String updateVal = messageService.getMessage(ColumnChangePresence.update.getLabel());

		final RecordEditorInformationDTO dto;
//		 String tableId = objectSyncronizeDTO.getTrDTO().getTdTableId().getValue();
		 String userId = getUserInfo().getId();
        try {
            final RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			dto = logic.getRecordEditorInformation(
					connectDefinitionId,
					tableId,
					userId);
        } catch (final ApplicationDomainLogicException e) {
        	new MessageInfo(e.getMessage(), MessageType.ERROR);
            return null;
        }
        final Map<String, TableItemDTO> itemDefinitions = dto.getTableForm().getTableItemMap();

         int sortIndexMax = -1;
		 for (final ChangeColumnItem item : changeColumnItemList) {
			 	TableItemDTO tableItemDTO = getSortIndex(itemDefinitions,item);
			 	if(tableItemDTO!=null && tableItemDTO.getSortIndex()>sortIndexMax){
			 		sortIndexMax = tableItemDTO.getSortIndex();
			 	}
	        	if (addVal.equals(item.getChangePresenceLabel())) {
	        		item.setChangePresence(ColumnChangePresence.add);
	        		if (tableItemDTO != null) {
	        			item.setSortIndex(tableItemDTO.getSortIndex());
	        		} else {
	        			sortIndexMax = sortIndexMax+1;
	        			item.setSortIndex(sortIndexMax);
	        		}
	        	}else  if (updateVal.equals(item.getChangePresenceLabel())) {
	            	item.setChangePresence(ColumnChangePresence.update);
	        	} else  if (delVal.equals(item.getChangePresenceLabel())) {
	            	item.setChangePresence(ColumnChangePresence.delete);
	            	sortIndexMax = sortIndexMax-1;
	        	} else {
	        		item.setChangePresence(ColumnChangePresence.no_change);
	        		if (tableItemDTO != null) {
	        			item.setSortIndex(tableItemDTO.getSortIndex());
	        		} else {
	        			sortIndexMax = sortIndexMax+1;
	        			item.setSortIndex(sortIndexMax);
	        		}
	        	}
	        }

		 //1.チェック 列 戻ると一覧「データ操作画面で作成した画面」、一覧「リレーション」  : DBの項目削除,DBの項目の型変更,DBの項目にPK追加,DBの項目にPK削除
		 //入力：ChangeColumnInfoDTO{connectDefinitionId,tableFormId,List<ChangeColumnItem>}

		 //columnChangeUseCase:{DELETE_COLUMN_USE_RELATION_SCREEN,DELETE_COLUMN_USE_ITEM_COLS,
		 //COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM,COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM}
		 //RelationAndScreenInfoDTO{relationId,relationLabel,connectDefinisionId,tableFormIdTypeMultiTable,tableFormLabelTypeMultiTable}
		 //RelationScreenDTO{tableFormId,itemId,columnChangeUseCase,RelationAndScreenInfoDTO}

		 //ObjectSyncronizeDTO:type{check,synchr}
		 //出力:List<RelationScreenDTO> relationScreens
		 ChangeColumnInfoDTO changeColumnInfoDTO = new ChangeColumnInfoDTO(userId,connectDefinitionId,tableId,changeColumnItemList);
		 List<RelationScreenDTO> relationScreens = getRelationScreenDTO(changeColumnInfoDTO);
		 //if(type == check):return synchrInfoDTO{connectDefinitionId,tableId,tableLabel,relationScreens,changeColumnItemList}
		//if(type == synchr && relationScreens.size() > 0):return synchrInfoDTO{connectDefinitionId,tableId,tableLabel,relationScreens,changeColumnItemList}
		if (objectSyncronizeDTO.getType().equals("synchr") && relationScreens.size() > 0) {
			SynchrInfoDTO resultData = new SynchrInfoDTO();
			resultData.setObjectSyncronizeDTO(objectSyncronizeDTO);
			resultData.setRelationScreens(relationScreens);
			resultModel.setResultData(resultData);
			resultModel.setStatus(Constants.CONST_STATUS_OK);
			resultModel.setMessageInfo(messageInfoList);
			new MessageInfo("object.synchr.success", MessageType.SUCCESS, messageService);
			return resultModel;
		} else if (objectSyncronizeDTO.getType().equals("synchr") && relationScreens.size() == 0) {
			//同期 tableForm type="table"
			doOnceSave(connectDefinitionId,tableLabel,changeColumnItemList,tableId);
			resultModel.setStatus(Constants.CONST_STATUS_OK);
			resultModel.setMessageInfo(messageInfoList);
			new MessageInfo("object.synchr.success", MessageType.SUCCESS, messageService);
			return resultModel;
		} else if (objectSyncronizeDTO.getType().equals("check") && relationScreens.size() >= 0) {//同期 tableForm type="table"
			SynchrInfoDTO resultData = new SynchrInfoDTO();
			resultData.setObjectSyncronizeDTO(objectSyncronizeDTO);
			resultData.setRelationScreens(relationScreens);
			resultModel.setResultData(resultData);
			resultModel.setStatus(Constants.CONST_STATUS_OK);
			resultModel.setMessageInfo(messageInfoList);
			new MessageInfo("object.synchr.success", MessageType.SUCCESS, messageService);
			return resultModel;
		}
		resultModel.setStatus(Constants.CONST_STATUS_OK);
		resultModel.setMessageInfo(messageInfoList);
		new MessageInfo("object.synchr.success", MessageType.SUCCESS, messageService);
		return resultModel;
	 }

	@RequestMapping(value = "/objectsyncronize/synchronizeMultiTable",method = RequestMethod.POST )
	 public @ResponseBody FRM0300ResultModel synchronizeMultiTable(@RequestBody SynchrInfoDTO synchrInfoDTO) {
		FRM0300ResultModel resultModel  = new  FRM0300ResultModel();
		List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();
		//同期 tableForm type="table"
		ObjectSyncronizeDTO objectSyncronizeDTO = synchrInfoDTO.getObjectSyncronizeDTO();
		String connectDefinitionId = objectSyncronizeDTO.getConnectDefinitionId();
		String tableId = objectSyncronizeDTO.getTrDTO().getTdTableId().getValue();
		String tableLabel = objectSyncronizeDTO.getTrDTO().getTdTableName().getValue();
		List<ChangeColumnItem> changeColumnItemList= objectSyncronizeDTO.getChangeColumnItems();

		doOnceSave(connectDefinitionId,tableLabel,changeColumnItemList,tableId);
		//同期 tableForm type="multi-table"
		synchrMultiTable(synchrInfoDTO);
		resultModel.setStatus(Constants.CONST_STATUS_OK);
		resultModel.setMessageInfo(messageInfoList);
		return resultModel;
	}

	/**
	 * @param synchrInfoDTO
	 */
	private void synchrMultiTable(SynchrInfoDTO synchrInfoDTO) {
		try {
			final TableRegistrationToRepositoryLogic logic = new TableRegistrationToRepositoryLogic();
			logic.synchrMultiTable(synchrInfoDTO);
		} catch (final ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
	}

	/**
	 * @param changeColumnInfoDTO
	 * @return
	 */
	private List<RelationScreenDTO> getRelationScreenDTO(ChangeColumnInfoDTO changeColumnInfoDTO) {
		try {
			final TableRegistrationToRepositoryLogic logic = new TableRegistrationToRepositoryLogic();
			return logic.getRelationScreenDTO(changeColumnInfoDTO);
		} catch (final ApplicationDomainLogicException e) {
			getLogger().error(e.getMessage());
		}
		return null;
	}

	/**
	 * @param itemDefinitions
	 * @param item
	 * @return TableItemDTO
	 */
	private TableItemDTO getSortIndex(Map<String, TableItemDTO> itemDefinitions, ChangeColumnItem item) {
        for (final TableItemDTO itemDto : itemDefinitions.values()) {
        	if (item.getColumnId().equals(itemDto.getItemId())) {
        		return itemDto;
        	}
        }
        return null;
	}

	/**
	 * 保存ボタン押下時のイベントハンドラ
     * <p>
     * 選択されたテーブル ID <s>と入力された情報を元に、アプリケーション
     * リポジトリのテーブル情報を更新します。
     * </p><p>
     * 更新後はテーブル選択画面へ遷移します。
     * </p>
	 *
	 * @return
	 */
	public String doOnceSave(String connectDefinitionId,String tableLabel,List<ChangeColumnItem> changeColumnItems,String tableId) {
		for (final ChangeColumnItem item : changeColumnItems) {
			getLogger().debug("------- change column information");
			getLogger().debug(" " + item.getColumnId());
			getLogger().debug(" " + item.getColumnLabel());
			getLogger().debug(" " + item.getChangePresence());
			getLogger().debug(" " + item.getSortIndex());
			getLogger().debug(" " + item.getCopyColumnId());
		}

		UserInfo userInfo = getUserInfo();
		try {
			final TableRegistrationToRepositoryLogic logic = new TableRegistrationToRepositoryLogic();
			String userId = userInfo.getId();
			logic.syncrozieTable(
					connectDefinitionId,
					tableId,
					tableLabel,
					changeColumnItems,
					userId);

            OutputAuditLog.writeGuiSettingLog(
            		AuditEventKind.UPDATE,
            		userInfo,
            		connectDefinitionId,
            		tableLabel,
            		AuditStatus.success,
               		String.valueOf(1));
		} catch (final ApplicationDomainLogicException e) {
            OutputAuditLog.writeGuiSettingLog(
            		AuditEventKind.UPDATE,
            		userInfo,
            		connectDefinitionId,
            		tableLabel,
            		AuditStatus.failure,
               		String.valueOf(0));
            return e.getMessage();
		}
		 return Constants.CONST_STATUS_OK;
	}

}
