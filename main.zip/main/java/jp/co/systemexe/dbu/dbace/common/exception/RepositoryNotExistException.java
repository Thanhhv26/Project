/**
 * @Copyright - 2015 SystemEXE-VN
 */
package jp.co.systemexe.dbu.dbace.common.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;

/**
 * @author tu-lenh
 *
 */
public class RepositoryNotExistException extends AuthenticationException implements IUtilException {
	private final Logger logger = LoggerFactory.getLogger(RepositoryNotExistException.class);
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor.
	 */
	public RepositoryNotExistException(String message) {
		super(message);
		logger.error(message);
	}

	/**
	 * Constructor.
	 */
	public RepositoryNotExistException(String message, Throwable cause) {
		super(message, cause);
		logger.error(message, cause);
	}

}
