/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import jp.co.systemexe.dbu.dbace.presentation.AdLdapServerType;
import jp.co.systemexe.dbu.dbace.presentation.LdapUserServerIdentify;

/**
 * 環境設定情報を保持するDTO
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class EnvironmentSettingDTO {
	/*
	 * login : not Encrypt password
	 */
	private boolean notEncryptAuthConnectPwd;
	/**
	 * リポジトリXMLファイルパス
	 */
	private String repositoryFilePath;

	/**
	 * 選択されたレコード表示件数
	 */
	private String recordDisplayCount;

	/**
	 * カラム表示件数(検索時)
	 */
	private String columnDisplayCount;

	/**
	 * 検索条件保存パス
	 */
	private String retrievalConditionPreservationPath;

	/**
	 * プルダウン表示最大件数
	 */
	private String pulldownDisplayMaximumCount;

	/**
	 * プルダウン表示時のフェッチサイズ
	 */
	private String pulldownDisplayFetchSize;

	/**
	 * ファイルダウンロード時のフェッチサイズ
	 */
	private String fileDownloadFetchSize;

	/**
	 * 監査ログ情報設定XMLファイルパス
	 */
	private String auditLogFilePath;

	/**
	 * インポートファイルの一時格納フォルダパス
	 */
	private String importTempFilePath;

	/**
	 * ダウンロードファイル最大バイト(EXCEL)
	 */
	private String downloadMaximumByteForExcel;

	/**
	 * ダウンロードファイル最大バイト(CSV)
	 */
	private String downloadMaximumByteForCsv;

	/**
	 * インポートファイル最大バイト(EXCEL)
	 */
	private String importMaximumByteForExcel;

	/**
	 * インポートファイル最大バイト(CSV)
	 */
	private String importMaximumByteForCsv;

	/**
	 * インポートファイル最大バイト(TSV)
	 */
	private String importMaximumByteForTsv;

	/**
	 * レコードの最大検索件数
	 */
	private String searchMaxRecordCount;

	/**
	 *
	 */
	private String searchComparisonOperatorOrder;

	/**
	 * authServerUserIdentify を戻します。
	 *
	 * @return LdapUserServerIdentify
	 */
	public LdapUserServerIdentify getAuthServerUserIdentify() {
		return authServerUserIdentify;
	}

	/**
	 * authServerUserIdentify を設定します。
	 *
	 * @param LdapUserServerIdentify authServerUserIdentify
	 */
	public void setAuthServerUserIdentify(LdapUserServerIdentify authServerUserIdentify) {
		this.authServerUserIdentify = authServerUserIdentify;
	}

	/**
	 * authServerType を戻します。
	 *
	 * @return AdLdapServerType
	 */
	public AdLdapServerType getAuthServerType() {
		return authServerType;
	}

	/**
	 * authServerType を設定します。
	 *
	 * @param AdLdapServerType authServerType
	 */
	public void setAuthServerType(AdLdapServerType authServerType) {
		this.authServerType = authServerType;
	}

	/**
	 * repositoryFilePath を戻します。
	 *
	 * @return String
	 */
	public String getRepositoryFilePath() {
		return repositoryFilePath;
	}

	/**
	 * repositoryFilePath を設定します。
	 *
	 * @param String repositoryFilePath
	 */
	public void setRepositoryFilePath(String repositoryFilePath) {
		this.repositoryFilePath = repositoryFilePath;
	}

	/**
	 * recordDisplayCount を戻します。
	 *
	 * @return String
	 */
	public String getRecordDisplayCount() {
		return recordDisplayCount;
	}

	/**
	 * recordDisplayCount を設定します。
	 *
	 * @param String recordDisplayCount
	 */
	public void setRecordDisplayCount(String recordDisplayCount) {
		this.recordDisplayCount = recordDisplayCount;
	}

	/**
	 * columnDisplayCount を戻します。
	 *
	 * @return String
	 */
	public String getColumnDisplayCount() {
		return columnDisplayCount;
	}

	/**
	 * columnDisplayCount を設定します。
	 *
	 * @param String columnDisplayCount
	 */
	public void setColumnDisplayCount(String columnDisplayCount) {
		this.columnDisplayCount = columnDisplayCount;
	}

	/**
	 * retrievalConditionPreservationPath を戻します。
	 *
	 * @return String
	 */
	public String getRetrievalConditionPreservationPath() {
		return retrievalConditionPreservationPath;
	}

	/**
	 * retrievalConditionPreservationPath を設定します。
	 *
	 * @param String retrievalConditionPreservationPath
	 */
	public void setRetrievalConditionPreservationPath(
			String retrievalConditionPreservationPath) {
		this.retrievalConditionPreservationPath = retrievalConditionPreservationPath;
	}

	/**
	 * pulldownDisplayMaximumCount を戻します。
	 *
	 * @return String
	 */
	public String getPulldownDisplayMaximumCount() {
		return pulldownDisplayMaximumCount;
	}

	/**
	 * pulldownDisplayMaximumCount を設定します。
	 *
	 * @param String pulldownDisplayMaximumCount
	 */
	public void setPulldownDisplayMaximumCount(String pulldownDisplayMaximumCount) {
		this.pulldownDisplayMaximumCount = pulldownDisplayMaximumCount;
	}

	/**
	 * pulldownDisplayFetchSize を戻します。
	 *
	 * @return String
	 */
	public String getPulldownDisplayFetchSize() {
		return pulldownDisplayFetchSize;
	}

	/**
	 * pulldownDisplayFetchSize を設定します。
	 *
	 * @param String pulldownDisplayFetchSize
	 */
	public void setPulldownDisplayFetchSize(String pulldownDisplayFetchSize) {
		this.pulldownDisplayFetchSize = pulldownDisplayFetchSize;
	}

	/**
	 * fileDownloadFetchSize を戻します。
	 *
	 * @return String
	 */
	public String getFileDownloadFetchSize() {
		return fileDownloadFetchSize;
	}

	/**
	 * fileDownloadFetchSize を設定します。
	 *
	 * @param String fileDownloadFetchSize
	 */
	public void setFileDownloadFetchSize(String fileDownloadFetchSize) {
		this.fileDownloadFetchSize = fileDownloadFetchSize;
	}

	/**
	 * auditLogFilePath を戻します。
	 *
	 * @return String
	 */
	public String getAuditLogFilePath() {
		return auditLogFilePath;
	}

	/**
	 * auditLogFilePath を設定します。
	 *
	 * @param String auditLogFilePath
	 */
	public void setAuditLogFilePath(String auditLogFilePath) {
		this.auditLogFilePath = auditLogFilePath;
	}

	/**
	 * downloadMaximumByteForExcel を戻します。
	 *
	 * @return String
	 */
	public String getDownloadMaximumByteForExcel() {
		return downloadMaximumByteForExcel;
	}

	/**
	 * downloadMaximumByteForExcel を設定します。
	 *
	 * @param String downloadMaximumByteForExcel
	 */
	public void setDownloadMaximumByteForExcel(String downloadMaximumByteForExcel) {
		this.downloadMaximumByteForExcel = downloadMaximumByteForExcel;
	}

	/**
	 * downloadMaximumByteForCsv を戻します。
	 *
	 * @return String
	 */
	public String getDownloadMaximumByteForCsv() {
		return downloadMaximumByteForCsv;
	}

	/**
	 * downloadMaximumByteForCsv を設定します。
	 *
	 * @param String downloadMaximumByteForCsv
	 */
	public void setDownloadMaximumByteForCsv(String downloadMaximumByteForCsv) {
		this.downloadMaximumByteForCsv = downloadMaximumByteForCsv;
	}

	/**
	 * importMaximumByteForExcel を戻します。
	 *
	 * @return String
	 */
	public String getImportMaximumByteForExcel() {
		return importMaximumByteForExcel;
	}

	/**
	 * importMaximumByteForExcel を設定します。
	 *
	 * @param String importMaximumByteForExcel
	 */
	public void setImportMaximumByteForExcel(String importMaximumByteForExcel) {
		this.importMaximumByteForExcel = importMaximumByteForExcel;
	}

	/**
	 * importMaximumByteForCsv を戻します。
	 *
	 * @return String
	 */
	public String getImportMaximumByteForCsv() {
		return importMaximumByteForCsv;
	}

	/**
	 * importMaximumByteForCsv を設定します。
	 *
	 * @param String importMaximumByteForCsv
	 */
	public void setImportMaximumByteForCsv(String importMaximumByteForCsv) {
		this.importMaximumByteForCsv = importMaximumByteForCsv;
	}

	/**
	 * importMaximumByteForTsv を戻します。
	 *
	 * @return String
	 */
	public String getImportMaximumByteForTsv() {
		return importMaximumByteForTsv;
	}

	/**
	 * importMaximumByteForTsv を設定します。
	 *
	 * @param String importMaximumByteForTsv
	 */
	public void setImportMaximumByteForTsv(String importMaximumByteForTsv) {
		this.importMaximumByteForTsv = importMaximumByteForTsv;
	}

	/**
	 * importTempFilePath を戻します。
	 *
	 * @return String
	 */
	public String getImportTempFilePath() {
		return importTempFilePath;
	}

	/**
	 * importTempFilePath を設定します。
	 *
	 * @param String importTempFilePath
	 */
	public void setImportTempFilePath(String importTempFilePath) {
		this.importTempFilePath = importTempFilePath;
	}

	/**
	 * searchMaxRecordCount を戻します。
	 *
	 * @return String
	 */
	public String getSearchMaxRecordCount() {
		return searchMaxRecordCount;
	}

	/**
	 * searchMaxRecordCount を設定します。
	 *
	 * @param String searchMaxRecordCount
	 */
	public void setSearchMaxRecordCount(String searchMaxRecordCount) {
		this.searchMaxRecordCount = searchMaxRecordCount;
	}

	/**
	 * searchComparisonOperatorOrder を戻します。
	 *
	 * @return String
	 */
	public String getSearchComparisonOperatorOrder() {
		return searchComparisonOperatorOrder;
	}

	/**
	 * searchComparisonOperatorOrder を設定します。
	 *
	 * @param String searchComparisonOperatorOrder
	 */
	public void setSearchComparisonOperatorOrder(String searchComparisonOperatorOrder) {
		this.searchComparisonOperatorOrder = searchComparisonOperatorOrder;
	}

	// ADD ライセンス認証と外部認証連携の機能追加　↓
	/**
	 * ライセンスキー
	 */
	private String licenseKey;
	/**
	 * ライセンス数
	 */
	private String licenseCnt;
	/**
	 * 外部認証
	 */
	private String extAuth;
	/**
	 * サーバー種類
	 */
	private AdLdapServerType authServerType;
	/**
	 * サーバーID
	 */
	private String authServerId;
	/**
	 * ポート番号
	 */
	private String authServerPort;
	/**
	 * ベースDN／ドメイン名
	 */
	private String authServerBaseDomain;
	/**
	 * サーバープロトコル
	 */
	private String authServerProtocol;
	/**
	 * サーバーセキュリティ
	 */
	private String authServerSecurity;
	/**
	 * サーバータイムアウト
	 */
	private String authServerTimeout;
	/**
	 * 接続ユーザーの識別子
	 */
	private LdapUserServerIdentify authServerUserIdentify;
	/**
	 * 接続ユーザー
	 */
	private String authConnectUsername;
	/**
	 * 接続パスワード
	 */
	private String authConnectPwd;

	/**
	 * licenseKey を戻します。
	 *
	 * @return String
	 */
	public String getLicenseKey() {
		return licenseKey;
	}

	/**
	 * licenseKey を設定します。
	 *
	 * @param String licenseKey
	 */
	public void setLicenseKey(String licenseKey) {
		this.licenseKey = licenseKey;
	}

	/**
	 * licenseCnt を戻します。
	 *
	 * @return String
	 */
	public String getLicenseCnt() {
		return licenseCnt;
	}

	/**
	 * licenseCnt を設定します。
	 *
	 * @param String licenseCnt
	 */
	public void setLicenseCnt(String licenseCnt) {
		this.licenseCnt = licenseCnt;
	}

	/**
	 * extAuth を戻します。
	 *
	 * @return String
	 */
	public String getExtAuth() {
		return extAuth;
	}

	/**
	 * extAuth を設定します。
	 *
	 * @param String extAuth
	 */
	public void setExtAuth(String extAuth) {
		this.extAuth = extAuth;
	}

	/**
	 * authServerId を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerId() {
		return authServerId;
	}

	/**
	 * authServerId を設定します。
	 *
	 * @param String authServerId
	 */
	public void setAuthServerId(String authServerId) {
		this.authServerId = authServerId;
	}

	/**
	 * authServerPort を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerPort() {
		return authServerPort;
	}

	/**
	 * authServerPort を設定します。
	 *
	 * @param String authServerPort
	 */
	public void setAuthServerPort(String authServerPort) {
		this.authServerPort = authServerPort;
	}

	/**
	 * authServerBaseDomain を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerBaseDomain() {
		return authServerBaseDomain;
	}

	/**
	 * authServerBaseDomain を設定します。
	 *
	 * @param String authServerBaseDomain
	 */
	public void setAuthServerBaseDomain(String authServerBaseDomain) {
		this.authServerBaseDomain = authServerBaseDomain;
	}

	/**
	 * authServerProtocol を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerProtocol() {
		return authServerProtocol;
	}

	/**
	 * authServerProtocol を設定します。
	 *
	 * @param String authServerProtocol
	 */
	public void setAuthServerProtocol(String authServerProtocol) {
		this.authServerProtocol = authServerProtocol;
	}

	/**
	 * authServerSecurity を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerSecurity() {
		return authServerSecurity;
	}

	/**
	 * authServerSecurity を設定します。
	 *
	 * @param String authServerSecurity
	 */
	public void setAuthServerSecurity(String authServerSecurity) {
		this.authServerSecurity = authServerSecurity;
	}

	/**
	 * authServerTimeout を戻します。
	 *
	 * @return String
	 */
	public String getAuthServerTimeout() {
		return authServerTimeout;
	}

	/**
	 * authServerTimeout を設定します。
	 *
	 * @param String authServerTimeout
	 */
	public void setAuthServerTimeout(String authServerTimeout) {
		this.authServerTimeout = authServerTimeout;
	}

	/**
	 * authConnectUsername を戻します。
	 *
	 * @return String
	 */
	public String getAuthConnectUsername() {
		return authConnectUsername;
	}

	/**
	 * authConnectUsername を設定します。
	 *
	 * @param String authConnectUsername
	 */
	public void setAuthConnectUsername(String authConnectUsername) {
		this.authConnectUsername = authConnectUsername;
	}

	/**
	 * authConnectPwd を戻します。
	 *
	 * @return String
	 */
	public String getAuthConnectPwd() {
		return authConnectPwd;
	}

	/**
	 * authConnectPwd を設定します。
	 *
	 * @param String authConnectPwd
	 */
	public void setAuthConnectPwd(String authConnectPwd) {
		this.authConnectPwd = authConnectPwd;
	}
	// ADD ライセンス認証と外部認証連携の機能追加　↑

	/**
	 * @return the notEncryptAuthConnectPwd
	 */
	public boolean isNotEncryptAuthConnectPwd() {
		return notEncryptAuthConnectPwd;
	}

	/**
	 * @param notEncryptAuthConnectPwd the notEncryptAuthConnectPwd to set
	 */
	public void setNotEncryptAuthConnectPwd(boolean notEncryptAuthConnectPwd) {
		this.notEncryptAuthConnectPwd = notEncryptAuthConnectPwd;
	}

}
