/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSaveConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchResultDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;

/**
 * データベースのテーブルデータ DAO。
 * <p>
 * 実際にデータベース内のテーブルデータにアクセスする DAO です。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public interface DatabaseTableDAO {

    /**
     * データベースとの接続を確立します。
     * <p>
     * 既に接続されている場合は例外をスローします。</p>
     *
     * @param dto DbConnectInfomationDTO
     * @exception DAOException
     */
    public void connect(final DbConnectInfomationDTO dto) throws DAOException;

    /**
     * データベースとの接続を閉じます。
     *
     * @throws DAOException
     */
    public void close() throws DAOException;

    /**
     * id と label ペアの選択候補マップを戻します。
     * <p>
     * SQL 文を直接指定してレコードを取得し、結果をコレクションに設定して戻し
     * ます。<br />
     * 得られた結果セットのカラム数が２よりも少ない場合は例外をスローします。
     * </p><p>
     * なお、本メソッドはプルダウンリストへの表示データの取得を意図したメソッド
     * なので、戻すレコード件数は 1,000 件上限に制限されています。
     * </p>
     *
     * @param sql SQL 文
     * @return SelectOneMenuItem[]
     * @throws DAOException
     */
    public SelectableItem[] getSelectableMap(final String sql)
            throws DAOException;

    /**
     * select を発行し結果レコードをコレクションに設定して戻します。
     * <p>
     * 条件指定に従い、一致検索或いは曖昧検索を行い、取得したレコードを
     * コレクションに設定して戻します。
     * </p><p>
     * 検索されたレコードの内、戻す範囲の先頭と、一度に戻すレコード数も指定
     * 出来ます。<br />
     * 指定された先頭位置にレコードが発見できない場合は空のコレクションを戻し
     * ます。<br />
     * 指定された先頭位置から、指定されたレコード数が存在しない場合は、存在した
     * 分だけを戻します。また、レコード数が 0 以下で指定されていた場合は、検索
     * されたレコードを指定された先頭位置から全て戻します。
     * </p>
     *
     * @param dto レコード検索条件 DTO
     * @param form テーブルフォーム DTO
     * @param table テーブル DB 内定義 DTO
     * @return RecordSearchResultDTO レコード検索結果 DTO
     * @throws DAOException
     */
    public RecordSearchResultDTO doSelect(
            final RecordSearchConditionDTO dto,
            final TableFormDTO form,
            final TableDefinitionDTO table) throws DAOException;

    /**
     * select count(*) を発行しレコード件数を返します。
     * <p>
     * 条件指定に従い、一致検索或いは曖昧検索を行い、レコード件数を返します。
     * </p>
     *
     * @param dto レコード検索条件 DTO
     * @param form テーブルフォーム DTO
     * @param table テーブル DB 内定義 DTO
     * @return int レコード数
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseTableDAO#doSelect(jp.co.systemexe.dbu.dbace.persistance.dto.RecordSearchConditionDTO)
     */
    public int getRowCount(
            final RecordSearchConditionDTO dto,
            final TableFormDTO form) throws DAOException;

    public int getRowCountTab(
            final RecordSearchConditionDTO dto,
            final TableDto table) throws DAOException;

    /**
     * Count record in a table.
     * @param dto
     * @return
     * @throws DAOException
     */
    public int getRowCount(final RecordSearchConditionDTO dto) throws DAOException;

    /**
     * delete を発行しレコードを削除します。
     *
     * @param dto レコード削除条件 DTO
     * @param table テーブル DB 内定義 DTO
     * @throws DAOException
     */
    public int doDelete(
    		final RecordSearchConditionDTO dto,
            final TableDefinitionDTO table,
    		final String databaseId,
    		final UserInfo userInfo
    		)
    throws DAOException;

    /**
     * update を発行しレコードを更新します。
     *
     * @param records レコード保持マップ
     * @param dto 保存条件 DTO
     * @param table テーブル DB 内定義 DTO
     * @throws DAOException
     */
    public void doUpdate(
    		final Map<String, String> records,
            final RecordSaveConditionDTO dto,
            final TableDefinitionDTO table,
            final Map<String, TableItemDTO> tableItemMap,
    		final String databaseId,
    		final UserInfo userInfo
    		)
    throws DAOException;

    /**
     * insert を発行しレコードを追加します。
     *
     * @param records レコード保持マップ
     * @param dto 保存条件 DTO
     * @param table テーブル DB 内定義 DTO
     * @throws DAOException
     */
    public void doInsert(
    		final Map<String, String> records,
            final RecordSaveConditionDTO dto,
            final TableDefinitionDTO table,
            final Map<String, TableItemDTO> tableItemMap,
    		final String databaseId,
    		final UserInfo userInfo
    		)
    throws DAOException;

	public void setSearchCondition(String searchCondition);

    public void setPreparedStatement(PreparedStatement preparedStatement);

    public Connection getConnection() throws DAOException;

    public void connectWithTransaction(final DbConnectInfomationDTO dto) throws DAOException;

    public void commit() throws DAOException;

    public void rollback() throws DAOException;

}
