/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.record.dto;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class FRM0200DeleteParam {
	private String connectDefinisionId;
	private String tableId;

	private SearchConditionItem[] searchConditionItems;
	private Map<String, String> currentObject;

	private boolean exclusion1;
	private boolean exclusion2;
	private boolean exclusion3;
	private UserInfo userInfo;
}
