/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.item.dto;
import lombok.Data;
@Data
public class restrictionsDTO {
	String idRes;
	String valueRes;
}
