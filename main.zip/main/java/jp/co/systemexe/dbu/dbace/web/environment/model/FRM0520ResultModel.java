/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.environment.model;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.web.environment.dto.EnvironmentDto;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;

/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 jan 18, 2017
 */

@Data
public class FRM0520ResultModel {
	boolean status;
	private List<EnvironmentDto> resultData;

	private List<MessageInfo> messageInfo;

	public FRM0520ResultModel() {
		resultData = new ArrayList<EnvironmentDto>();
		messageInfo = new ArrayList<MessageInfo>();
	}
}
