/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.BaseDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;

/**
 * ファイル読み込み基底抽象クラス
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public abstract class BaseInputFileDAO extends BaseDAO {
    private TableFormDTO tableForm;

    /**
     * ファイル読込後の後始末を行います。
     * <p>
     * ファイルストリームのクローズなど
     * </p>
     */
    public abstract void close();

    /**
     * 次のレコードが存在するか否かを返します。
     *
     * @return
     * @throws DAOException
     */
    public abstract boolean hasNext() throws DAOException;

    /**
     * ヘッダレコード(カラムIDのリスト)を返します。
     *
     * @return
     * @throws DAOException
     */
    public abstract List<String> getColumnIdList() throws DAOException;

    public abstract Map<String,Integer> getMultiColumnIdList(Map<String, TableItemDTO> tableItemMap,List<String> columnIdList,TableDto tableDto) throws DAOException;

    /**
     * カラムのデータを返します。
     *
     * @param columnIdList
     * @return
     */
    public abstract Map<String,String> read(final List<String> columnIdList);

    /**
     * @param columnIdMap
     * @return
     */
    public abstract Map<String,String> readMulti(final Map<String,Integer> columnIdMap) throws ApplicationDomainLogicException;
    /**
     * 引数のデータが、リポジトリに登録されている、カラムID、カラムの表示名に
     * 一致した場合は、カラムIDを返します。
     * 一致しない場合は""を返します。
     *
     * @param data
     * @return
     */
    protected String getColumnId(final String data) {
        String columnId = "";
        if (tableForm.getTableItemMap().containsKey(data)) {
            columnId = data;
        } else {
            for (final TableItemDTO item
                    : tableForm.getTableItemMap().values()) {
                if (item.getItemLabel().equals(data)) {
                    columnId = item.getItemId();
                    break;
                }
            }
        }

        return columnId;
    }

    /**
     * tableForm を戻します。
     *
     * @return TableFormDTO
     */
    public TableFormDTO getTableForm() {
        return tableForm;
    }

    /**
     *
     * @param tableForm
     */
    public BaseInputFileDAO(final TableFormDTO tableForm) {
        this.tableForm = tableForm;
    }

}
