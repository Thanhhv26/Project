/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.dto;

import lombok.Data;

/**
 * 環境設定情報を保持するDTO
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
@Data
public class EnvironmentSettingLicenseKeyDTO {
	EnvironmentSettingDTO environmentSettingDTO;
	int numberTableRegisteredInRepository;
}
