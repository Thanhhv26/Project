/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;

/**
 * サーブレットを実装する際の基底抽象クラス。
 * <p>
 * HttpServlet のサブクラスを実装する際に使用する基底抽象クラスです。</p>
 * <p>
 * このクラスは本プロジェクトにおける実装フレームワークであり、サーブレットを
 * 実装する際には原則本クラスを継承しなければなりません。</p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public abstract class BaseHttpServlet extends HttpServlet {

    /**
     * ロガーインスタンス参照。
     */
    private final Logger logger;

    /**
     * logger を戻します。
     * <p>
     * サーブレットのサブクラス実装に対し専用のロガーを提供します。</p>
     * 
     * @return Logger
     */
    protected Logger getLogger() {
        return this.logger;
    }

    /**
     * response オブジェクト。
     */
    protected final HttpServletResponse response;

    /**
     * response を戻します。
     * 
     * @return
     */
    protected HttpServletResponse getHttpServletResponse() {
        return this.response;
    }

    protected final HttpServletRequest request;

    protected final HttpServletRequest getHttpServletRequest() {
        return request;
    }

    /**
     * BaseHttpServlet の生成。
     * <p>
     * コンストラクタ。</p>
     */
    public BaseHttpServlet() {
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
        this.response = this.getHttpServletResponse();
        this.request = this.getHttpServletRequest();
    }
}
