package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.ItemRestriction;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.RetrievalProcessingOfRecordFromDatabaseLogic;


/**
 * リスト系アイテム入力制限
 * <p>
 * リスト系アイテム以外の入力を禁じる項目用のチェックコマンドです。</p>
 *
 * @author  EXE 島田 雄一郎
 * @author  EXE 相田 一英
 * @version 0.0.0
 */
public class ListItemOtherThanCannotBeInputCheckCommand extends BaseLogicalCheckCommand {

	@Override
	public void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
 		final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap) {
		// TODO 自動生成されたメソッド・スタブ
        final String value = messages.getCorrectedValue(columnId);//現在値の取得
        if (value == null || value.equals("")) {
	    	//MI-E-0150={0}にリストに存在しない値は入力できません。
        	String columnLabel = tableItemMap.get(columnId).getItemLabel();
        	final String args[] = {columnLabel};
	    	messages.getMessages(columnId).add(MessageUtils.getMessage("MI-E-0150",args));
            return;
        }
        TableItemDTO tableitem = getDisplayDef().getItemDefinitions().get(columnId);
        if (DefinedHtmlElement.INPUT_RADIO == tableitem.getHtmlElement() || DefinedHtmlElement.SELECT == tableitem.getHtmlElement()) {
	        RetrievalProcessingOfRecordFromDatabaseLogic logic = new RetrievalProcessingOfRecordFromDatabaseLogic();
			SelectOneMenuItem[] items = null;
			try {
				items = logic.getSelectableMap(columnId, columnIdAndValue, dbConnectInfomationDTO, tableitem);
				if (null != items ){
					for (SelectOneMenuItem oneitem: items ){
						if (value.equals(oneitem.getValue())) return;
					}
				} else {
					for (SelectOneMenuItem oneitem: tableitem.getSelectableItems()){
						if (value.equals(oneitem.getValue())) return;
					}
				}
			} catch (ApplicationDomainLogicException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
	    	//MI-E-0150={0}にリストに存在しない値は入力できません。
			String columnLabel = tableItemMap.get(columnId).getItemLabel();
			final String args[] = {columnLabel};
	    	messages.getMessages(columnId).add(MessageUtils.getMessage("MI-E-0150",args));
        }
	}

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * このクラスが検査対象とする条件は、
     * <ol>
     *  <li>リポジトリの入力値制約に NOT_CONTAIN_LISTITEM_FOR_DATAIMPORT 制約が存在する場合。</li>
     * </ol>
     * </p>
     *
     * @param columnId
     * @return true : 検査担当 / false : 担当ではない
     * @see jp.co.systemexe.dbu.dbace.presentation.check.command.BaseLogicalCheckCommand#isMyTask(java.lang.String)
     */
	@Override
	protected boolean isMyTask(String columnId) {
        final TableItemDTO item = getDisplayDef().getItemDefinitions().get(
                columnId);
        if (item.getItemRestrictions().containsKey(
            ItemRestriction.NOT_CONTAIN_LISTITEM)) {
            return true;
        } else {
            return false;
        }
	}

}
