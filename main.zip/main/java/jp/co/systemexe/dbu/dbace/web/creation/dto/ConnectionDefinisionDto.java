/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import lombok.Data;

/**
 * @author van-thanh
 *
 */
@Data
public class ConnectionDefinisionDto {
    private String id;
    private String label;
    private DbConnectDto dbConnectDto;
    private TableFormsDto tableFormsDto;
}
