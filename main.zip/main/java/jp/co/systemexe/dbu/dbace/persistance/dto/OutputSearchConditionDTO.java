/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;

/**
 * （JavaDoc）。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class OutputSearchConditionDTO {
    private String connectDefinitionId;
    private String tableId;
    private String userId;
    private String fileName;
    private boolean isUpdate;
    private boolean isCommon;
    private String updateFilePath;
    private List<SelectConditionItem> list;
    
    /**
     * connectDefinitionId を戻します。
     * 
     * @return String
     */
    public String getConnectDefinitionId() {
        return connectDefinitionId;
    }
    
    /**
     * connectDefinitionId を設定します。
     *
     * @param String connectDefinitionId 
     */
    public void setConnectDefinitionId(String connectDefinitionId) {
        this.connectDefinitionId = connectDefinitionId;
    }
    
    /**
     * isCommon を戻します。
     * 
     * @return boolean
     */
    public boolean isCommon() {
        return isCommon;
    }
    
    /**
     * isCommon を設定します。
     *
     * @param boolean isCommon 
     */
    public void setCommon(boolean isCommon) {
        this.isCommon = isCommon;
    }
    
    /**
     * isUpdate を戻します。
     * 
     * @return boolean
     */
    public boolean isUpdate() {
        return isUpdate;
    }
    
    /**
     * isUpdate を設定します。
     *
     * @param boolean isUpdate 
     */
    public void setUpdate(boolean isUpdate) {
        this.isUpdate = isUpdate;
    }
    
    /**
     * list を戻します。
     * 
     * @return List<SelectConditionItem>
     */
    public List<SelectConditionItem> getList() {
        return list;
    }
    
    /**
     * list を設定します。
     *
     * @param List<SelectConditionItem> list 
     */
    public void setList(List<SelectConditionItem> list) {
        this.list = list;
    }
    
    /**
     * tableId を戻します。
     * 
     * @return String
     */
    public String getTableId() {
        return tableId;
    }
    
    /**
     * tableId を設定します。
     *
     * @param String tableId 
     */
    public void setTableId(String tableId) {
        this.tableId = tableId;
    }
    
    /**
     * userId を戻します。
     * 
     * @return String
     */
    public String getUserId() {
        return userId;
    }
    
    /**
     * userId を設定します。
     *
     * @param String userId 
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * fileName を戻します。
     * 
     * @return String
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * fileName を設定します。
     *
     * @param String fileName 
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * updateFilePath を戻します。
     * 
     * @return String
     */
    public String getUpdateFilePath() {
        return updateFilePath;
    }

    /**
     * updateFilePath を設定します。
     *
     * @param String updateFilePath 
     */
    public void setUpdateFilePath(String updateFilePath) {
        this.updateFilePath = updateFilePath;
    }
}
