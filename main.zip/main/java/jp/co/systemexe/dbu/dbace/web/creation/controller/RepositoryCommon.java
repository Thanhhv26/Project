/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.controller;

import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.persistance.dao.xml.AppRepository;

/**
 * @author van-thanh
 *
 */
public class RepositoryCommon {
	
	/**
	 * check file repository exist
	 * @return boolean
	 */
	public static boolean checkFileRepositoryExist() {
		final AppRepository appRepository = AppRepository.getInstance();
		if(!appRepository.getFile().exists()){
			return false;
		}
		return true;
	}
	
	/**
	 * check format file repository
	 * @return boolean
	 */
	public static boolean checkFormatFileRepositoryXml() {
		boolean flag = true;
		try {
			final AcquisitionOfConnectDefinitionListLogic connectDefinitionListLogic = new AcquisitionOfConnectDefinitionListLogic();		
			flag = connectDefinitionListLogic.checkFormatFileRepositoryXml();
		} catch (ApplicationDomainLogicException e) {
			return false;
		}
		return flag;
	}

}
