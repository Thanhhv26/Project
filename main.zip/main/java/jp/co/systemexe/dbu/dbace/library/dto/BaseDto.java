/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.dto;

import java.io.Serializable;

import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import jp.co.systemexe.dbu.dbace.library.util.SpringContextHelper;

/**
* @author systemexe
* @version 1.0 Dec 01, 2016
*
*/
public abstract class BaseDto implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @see MessageService
	 */
	protected final MessageService getMessageService() {
		return SpringContextHelper.findBean(MessageService.class);
	};
}
