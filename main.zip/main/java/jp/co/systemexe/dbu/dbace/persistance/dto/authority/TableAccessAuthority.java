/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto.authority;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;

/**
 * テーブルアクセス権限定義 enum。
 * <p>
 * ユーザーの、テーブルに対するアクセス権限を定義した列挙体です。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public enum TableAccessAuthority implements IdSelectable {
    /**
     * 参照権限。
     * <p>テーブル内のデータに対する参照権限です。</p>
     */
    REFER("refer", "参照権限"),
    /**
     * 編集権限。
     * <p>
     * テーブル内のデータに対する編集権限です。追加、削除、更新全てが可能です。<br />
     * </p>
     */
    EDIT("edit", "編集権限");

    private static Map<String, TableAccessAuthority> map;
    static {
        map = new HashMap<String, TableAccessAuthority>();
        for (final TableAccessAuthority buff : values()) {
            map.put(buff.getId(), buff);
        }
    }

    public static TableAccessAuthority idOf(final int id) {
        if (map.containsKey(id)) {
            return map.get(id);
        } else {
            return null;
        }
    }

    private final String id;
    private final String label;

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable#getId()
     */
    public String getId() {
        return id;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable#getLabel()
     */
    public String getLabel() {
        return label;
    }

    /**
     * TableAccessAuthority の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param id 権限 ID
     * @param label 表示用ラベル
     */
    private TableAccessAuthority(final String id, final String label) {
        this.id = id;
        this.label = label;
    }
}
