/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import static com.google.common.base.Preconditions.checkState;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;

import jp.co.systemexe.dbu.dbace.domain.service.BigExcelWriter;
import jp.co.systemexe.dbu.dbace.domain.service.SpreadsheetWriter;

public class BigExcelWriterImpl implements BigExcelWriter {

	private static final String XML_ENCODING = "UTF-8";

	private final File outputFile;

	private final File tempFileOutputDir;

	private File templateFile = null;

	private XSSFWorkbook workbook = null;

	private LinkedHashMap<String, XSSFSheet> addedSheets = new LinkedHashMap<String, XSSFSheet>();

	private Map<XSSFSheet, File> sheetTempFiles = new HashMap<XSSFSheet, File>();

	/* XMLファイルを処理中 */
	private String curFileXmlPro = "";

	private List<String> tempFileList = new ArrayList<>();

	public BigExcelWriterImpl(File outputFile) {
		this.outputFile = outputFile;
		this.tempFileOutputDir = outputFile.getParentFile();
	}

	/**
	 * XMLファイルを処理中
	 *
	 * @return
	 */
	public String getCurFileXmlPro() {
		return curFileXmlPro;
	}

	@Override
	public BigExcelWriter createWorkbook() {
		workbook = new XSSFWorkbook();
		return this;
	}

	@Override
	public BigExcelWriter addSheets(String... sheetNames) {
		checkState(workbook != null, "workbook must be created before adding sheets");

		for (String sheetName : sheetNames) {
			XSSFSheet sheet = workbook.createSheet(sheetName);
			addedSheets.put(sheetName, sheet);
		}

		return this;
	}

	@Override
	public BigExcelWriter writeWorkbookTemplate() throws IOException {
		checkState(workbook != null, "workbook must be created before writing template");
		// checkState(templateFile == null, "template file already written");

		templateFile = File.createTempFile(FilenameUtils.removeExtension(outputFile.getName()) + "_template",
				"." + FilenameUtils.getExtension(outputFile.getName()), tempFileOutputDir);

		if (!tempFileList.contains(templateFile.getAbsolutePath())) {
			tempFileList.add(templateFile.getAbsolutePath());
		}

		System.out.println(templateFile);
		FileOutputStream os = new FileOutputStream(templateFile);
		workbook.write(os);
		os.close();

		return this;
	}

	@Override
	public BigExcelWriter writeWorkbookTemplate(String sheetName) throws IOException {
		checkState(workbook != null, "workbook must be created before writing template");
		// checkState(templateFile == null, "template file already written");

		templateFile = File.createTempFile("_temp_" + addedSheets.size(),
				"." + FilenameUtils.getExtension(outputFile.getName()), tempFileOutputDir);

		if (!tempFileList.contains(templateFile.getAbsolutePath())) {
			tempFileList.add(templateFile.getAbsolutePath());
		}
		System.out.println(templateFile);
		FileOutputStream os = new FileOutputStream(templateFile);
		workbook.write(os);
		os.close();

		return this;
	}

	@Override
	public SpreadsheetWriter createSpreadsheetWriter(String sheetName) throws IOException {
		if (!addedSheets.containsKey(sheetName)) {
			addSheets(sheetName);
		}

		return createSpreadsheetWriter(addedSheets.get(sheetName));
	}

	@Override
	public SpreadsheetWriter createSpreadsheetWriter(XSSFSheet sheet) throws IOException {
		checkState(!sheetTempFiles.containsKey(sheet), "writer already created for this sheet");

		File tempSheetFile = File.createTempFile("_temp_" + addedSheets.size(), ".xml", tempFileOutputDir);

		if (!tempFileList.contains(tempSheetFile.getAbsolutePath())) {
			tempFileList.add(tempSheetFile.getAbsolutePath());
		}

		curFileXmlPro = tempSheetFile.getAbsolutePath();
		Writer out = null;
		try {
			out = new OutputStreamWriter(new FileOutputStream(tempSheetFile), XML_ENCODING);
			SpreadsheetWriter sw = new SpreadsheetWriterImpl(out);

			sheetTempFiles.put(sheet, tempSheetFile);
			return sw;
		} catch (RuntimeException e) {
			if (out != null) {
				out.close();
			}
			throw e;
		}
	}

	private static Function<XSSFSheet, String> getSheetName = new Function<XSSFSheet, String>() {

		@Override
		public String apply(XSSFSheet sheet) {
			return sheet.getPackagePart().getPartName().getName().substring(1);
		}
	};

	@Override
	public File completeWorkbook() throws IOException {
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(outputFile);
			ZipOutputStream zos = new ZipOutputStream(out);

			Iterable<String> sheetEntries = Iterables.transform(sheetTempFiles.keySet(), getSheetName);
			System.out.println("Sheet Entries: " + sheetEntries);
			copyTemplateMinusEntries(templateFile, zos, sheetEntries);

			for (Map.Entry<XSSFSheet, File> entry : sheetTempFiles.entrySet()) {
				XSSFSheet sheet = entry.getKey();
				substituteSheet(entry.getValue(), getSheetName.apply(sheet), zos);
			}
			zos.close();
			out.close();

			return outputFile;
		} finally {
			if (out != null) {
				out.close();
			}
			workbook.close();
		}
	}

	public void createTempFileExcelForCheckSize() throws IOException {
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(outputFile);
			ZipOutputStream zos = new ZipOutputStream(out);

			Iterable<String> sheetEntries = Iterables.transform(sheetTempFiles.keySet(), getSheetName);
			System.out.println("Sheet Entries: " + sheetEntries);
			copyTemplateMinusEntries(templateFile, zos, sheetEntries);

			for (Map.Entry<XSSFSheet, File> entry : sheetTempFiles.entrySet()) {
				XSSFSheet sheet = entry.getKey();
				substituteSheet(entry.getValue(), getSheetName.apply(sheet), zos);
			}
			zos.close();
			out.close();

		} finally {
			if (out != null) {
				out.close();
			}
		}
	}

	@Override
	public void deleteTempFiles() throws IOException {
//		String file = FilenameUtils.removeExtension(FilenameUtils.getName(outputFile.getName()));
//		String path = outputFile.getParent();
//		File folder = new File(path);
//		File[] listOfFiles = folder.listFiles();
//		for (int i = 0; i < listOfFiles.length; i++) {
//			if (listOfFiles[i].isFile()
//					&& (listOfFiles[i].getName().startsWith(file) || listOfFiles[i].getName().startsWith("_temp_"))) {
//				// System.out.println("File " + listOfFiles[i].getName());
//				listOfFiles[i].delete();
//			}
//		}
		for (String path : tempFileList) {
			File f = new File(path);
			if(f.exists()) {
				f.delete();
			}

		}

	}

	private static void copyTemplateMinusEntries(File templateFile, ZipOutputStream zos, Iterable<String> entries)
			throws IOException {

		ZipFile templateZip = new ZipFile(templateFile);

		@SuppressWarnings("unchecked")
		Enumeration<ZipEntry> en = (Enumeration<ZipEntry>) templateZip.entries();
		while (en.hasMoreElements()) {
			ZipEntry ze = en.nextElement();
			if (!Iterables.contains(entries, ze.getName())) {
				// System.out.println("Adding template entry: " + ze.getName());
				zos.putNextEntry(new ZipEntry(ze.getName()));
				InputStream is = templateZip.getInputStream(ze);
				copyStream(is, zos);
				is.close();
			}
		}
		templateZip.close();
	}

	private static void substituteSheet(File tmpfile, String entry, ZipOutputStream zos) throws IOException {
		// System.out.println("Adding sheet entry: " + entry);
		zos.putNextEntry(new ZipEntry(entry));
		InputStream is = new FileInputStream(tmpfile);
		copyStream(is, zos);
		is.close();
	}

	private static void copyStream(InputStream in, OutputStream out) throws IOException {
		byte[] chunk = new byte[1024];
		int count;
		while ((count = in.read(chunk)) >= 0) {
			out.write(chunk, 0, count);
		}
	}

	@Override
	public Workbook getWorkbook() {
		return workbook;
	}

	@Override
	public ImmutableList<XSSFSheet> getSheets() {
		return ImmutableList.copyOf(addedSheets.values());
	}

	public void close() throws IOException {
		workbook.close();
	}

}
