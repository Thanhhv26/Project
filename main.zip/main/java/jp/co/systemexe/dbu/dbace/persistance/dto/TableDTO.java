/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Getter
@Setter
public class TableDTO {
	//inner join,left join,outer join
    private String type;
    //connection id
    private String connectid;
    //schema.table
    private String tableid;
    private String tablelabel;
    private String databaseTypeConnectionDestination;
}
