/**
 * Copyright(C) 2008 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import jp.co.systemexe.dbu.dbace.persistance.dao.file.OutputsToCsvWithTableDataDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.OutputsToExcelWithTableDataDAO;

/**
 * テーブルデータ出力ファイル形式 enum
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum FileOutputTableData {
    EXCEL("Excel 形式", OutputsToExcelWithTableDataDAO.class.getSimpleName(), "xlsx", true),
    CSV("CSV 形式", OutputsToCsvWithTableDataDAO.class.getSimpleName(), "csv", true);
//    XML("XML(DB Secure Utility)形式", OutputsToXmlWithTableDataDAO.class.getSimpleName(), "xml", false);

	/**
	 * エクセル列の最大値
	 */
	public static int EXCEL_MAX_COL_COUNT = 256;
    private String label;
    private String className;
    private String extension;
    private boolean visible;

    /**
     * className を戻します。
     *
     * @return String
     */
    public String getClassName() {
        return className;
    }
    /**
     * label を戻します。
     *
     * @return String
     */
    public String getLabel() {
        return label;
    }

    /**
     * visible を戻します。
     *
     * @return boolean
     */
    public boolean isVisible() {
        return visible;
    }

    /**
     * extension を戻します。
     *
     * @return String
     */
    public String getExtension() {
        return extension;
    }

    private FileOutputTableData(
            final String label,
            final String className,
            final String extension,
            final boolean visible) {
        this.label = label;
        this.className = className;
        this.extension = extension;
        this.visible = visible;
    }
}
