/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.common.audit;

/**
 * ファイルローテーションサイズ単位を保持する 列挙体
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum AuditFileUnit {
    M("メガ"),
    K("キロ");
    
    private String unitName;
    public String getUnitName() {
        return unitName;
    }
    
    private AuditFileUnit(final String unitName) {
        this.unitName = unitName;
    }
}
