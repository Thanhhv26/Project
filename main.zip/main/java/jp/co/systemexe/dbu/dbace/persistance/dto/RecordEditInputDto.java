package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.web.common.dto.RecordEditorInformationDTO;
import jp.co.systemexe.dbu.dbace.web.record.dto.ColumnAttributeItemDTO;
import jp.co.systemexe.dbu.dbace.web.record.dto.FRM0200TableFormDTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecordEditInputDto extends CommonInputDto {
	private String connectDefinitionId;
	private String tableId;
	private UserInfo userInfo;
	private List<ColumnAttributeItemDTO> attributeItems;
	private RecordEditorInformationDTO recordEditorInformationDTO;
	private Map<String, String> columnMap;
	private Map<String, FRM0200TableFormDTO> listTableFormDTO;
	private TableFormDTO tableFormDto;
}
