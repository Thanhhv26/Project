/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.relation.dto;

import java.util.List;

import lombok.Data;

/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationDeleteDTO {
	String relationId;
	String relationName;
	String connectid;
	List<RelationScreenDTO> names;
	public RelationDeleteDTO(){

	}
}
