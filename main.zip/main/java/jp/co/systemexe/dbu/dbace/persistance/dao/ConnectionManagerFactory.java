/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAONotFoundException;
import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;

/**
 * ConnectionManagerファクトリ。
 * <p>
 * ConnectionManager を一括保持するファクトリクラスです。
 * </p>
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class ConnectionManagerFactory {
    /**
     * DAO の一覧マップMap&lt;インターフェース名,名前空間&gt;を保持します。
     * <p>
     * static initializer にてDAOをマップに登録していきます。</p>
     */
    private static Map<DatabaseTypeConnectionDestination, String> map;
    static {
        map = new HashMap<DatabaseTypeConnectionDestination, String>();
        map
            .put(DatabaseTypeConnectionDestination.Oracle,
                "jp.co.systemexe.dbu.dbace.persistance.dao.db.OracleConnectionManager");
        map
            .put(DatabaseTypeConnectionDestination.SqlServer,
                "jp.co.systemexe.dbu.dbace.persistance.dao.db.SQLServerConnectionManager");
        map
        	.put(DatabaseTypeConnectionDestination.PostgreSQL,
        		"jp.co.systemexe.dbu.dbace.persistance.dao.db.PostgreSQLConnectionManager");
        map
        	.put(DatabaseTypeConnectionDestination.MySQL,
        		"jp.co.systemexe.dbu.dbace.persistance.dao.db.MySQLConnectionManager");
/*        map
            .put(DatabaseTypeConnectionDestination.DB2,
                "jp.co.systemexe.dbu.dbace.persistance.dao.db.DB2ConnectionManager");
*/    }

    /**
     * ConnectionManager を生成して戻します。
     *
     * @param type DatabaseTypeConnectionDestination
     * @return BaseConnectionManager
     */
    public static BaseConnectionManager createConnectionManager(DatabaseTypeConnectionDestination type)
            throws DAONotFoundException, DAOException {
        try {
            return (BaseConnectionManager)Class.forName(
                        map.get(type)).newInstance();
        } catch (final ClassNotFoundException e) {
        	// MI-F-0001={0} クラスが存在しません。
        	final String args[] = {map.get(type)};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            throw new DAONotFoundException(message, e);
        } catch (final IllegalAccessException e) {
        	final String args[] = {map.get(type)};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            throw new DAONotFoundException(message, e);
        } catch (final InstantiationException e) {
        	final String args[] = {map.get(type)};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            throw new DAONotFoundException(message, e);
        } catch (final Exception e) {
        	final String args[] = {type.toString()};
            final String message = MessageUtils.getMessage("MI-F-0001", args);
            throw new DAOException(message);
        }
    }
}
