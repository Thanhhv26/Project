/**
 * Copyright(C) 2008 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dao.BaseDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dto.OutputSearchConditionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * 検索条件ファイル入出力の基底抽象クラス。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public abstract class BaseSearchConditionDAO extends BaseDAO {

    /**
     * 共通検索条件ファイル一覧を取得します。
     *
     * @param connectDefinitionId
     * @param tableId
     * @param userId
     * @return SortedMap<String, String> ファイル名、ファイルパス
     * @throws DAOException
     */
    public abstract Map<String, String> getCommonFileNameMap(
            final String connectDefinitionId,
            final String tableId,
            final String userId)
            throws DAOException;

    /**
     * ユーザー検索条件ファイル一覧を取得します。
     *
     * @param connectDefinitionId
     * @param tableId
     * @param userId
     * @return SortedMap<String, String> ファイル名、ファイルパス
     * @throws DAOException
     */
    public abstract Map<String, String> getUserFileNameMap(
            final String connectDefinitionId,
            final String tableId,
            final String userId)
            throws DAOException;

    /**
     * ファイル一覧を取得します。
     *
     * @param connectDefinitionId
     * @param tableId
     * @param userId
     * @return SortedMap<String, String> ファイル名、ファイルパス
     * @throws DAOException
     */
    public abstract Map<String, String> getFileNameMap(
            final String connectDefinitionId,
            final String tableId,
            final String userId)
            throws DAOException;

    /**
     * ファイル出力を行います。
     *
     * @param tableId テーブル名
     * @param def 項目表示定義 DTO
     * @param dto レコード検索結果 DTO
     * @param outputStream
     */
    public abstract void outputFile(
            final OutputSearchConditionDTO outputSearchConditionDTO)
            throws DAOException;

    /**
     * ファイルを読み込みます。
     *
     * @param filePath
     * @param outputStream
     */
    public abstract List<SelectConditionItem> inputFile(
            final String filePath)
            throws DAOException;

}
