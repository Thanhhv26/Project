/**
 * Copyright(C) 2016 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import java.util.HashMap;
import java.util.Map;

/**
 * 接続先データベースベンダー定義 enmu。
 * <p>
 * 接続定義がどのデータベースを対象としているか指示
 * するための定義値です。
 * </p>
 *
 * @author  NguyenDongTruc
 * @version 0.0.0
 */
public enum AdLdapServerType {
    /**
     * Active Directory
     */
    AD("AD", "Active Directory"),
    /**
     * LDAP/OpenLDAP
     */
    LDAP("LDAP","LDAP/OpenLDAP");

    private final String key;
    private final String serverName;

    private static Map<String, AdLdapServerType> map;
    static {
        map = new HashMap<String, AdLdapServerType>();
        for (final AdLdapServerType buff : values()) {
            map.put(buff.getKey(), buff);
        }
    }

    public static AdLdapServerType keyOf(final String key) {
        if (map.containsKey(key)) {
            return map.get(key);
        } else {
            return null;
        }
    }

    /**
     * テーブル中に実際に保存されるキー文字列を戻します。
     *
     * @return
     */
    public String getKey() {
        return this.key;
    }

    /**
     * serverName を戻します。
     *
     * @return String
     */
    public String getServerName() {
        return this.serverName;
    }

    private AdLdapServerType(final String key, final String serverName) {
        this.key = key;
        this.serverName = serverName;
    }
}
