/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto.authority;

import java.util.HashMap;
import java.util.Map;

/**
 * システム接続定義情報 enum。
 * <p>
 * 接続定義情報「システム」を定義する列挙体です</p>
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public enum SystemConnectDefinision {

    SYSTEM("system", "SYSTEM");

    /**
     * 接続定義情報「システム」列挙体をMap&lt;ID, SystemAdministrator&gtにて保持
     * します。
     * <p>
     * スタティックイニシャライザーにて初期化されております。</p>
     */
    private static Map<String, SystemConnectDefinision> map;
    static {
        map = new HashMap<String, SystemConnectDefinision>();
        for (final SystemConnectDefinision buff : values()) {
            map.put(buff.getId(), buff);
        }
    }

    /**
     * 接続定義情報「システム」列挙体における IDより、列挙体を取得します。
     * 
     * @param id
     * @return SystemAdministrator
     */
    public static SystemConnectDefinision idOf(final String id) {
        if (map.containsKey(id)) {
            return map.get(id);
        } else {
            return null;
        }
    }

    /**
     * 接続定義情報「システム」列挙体における ID を返します。
     * 
     * @return
     */
    public String getId() {
        return id;
    }

    /**
     * 接続定義情報「システム」列挙体における Label を返します。
     * 
     * @return
     */
    public String getLabel() {
        return label;
    }

    /**
     * 接続定義情報「システム」列挙体における ID を保持します。
     */
    private final String id;

    /**
     * 接続定義情報「システム」列挙体における Label を保持します。
     */
    private final String label;

    /**
     * SystemConnectDefinision の生成。
     * <p>コンストラクタ。</p>
     * 
     * @param id
     * @param label
     */
    private SystemConnectDefinision(final String id, final String label) {
        this.id = id;
        this.label = label;
    }

}
