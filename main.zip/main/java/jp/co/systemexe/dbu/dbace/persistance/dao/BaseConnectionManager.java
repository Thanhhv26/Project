/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.MessageFormat;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;

/**
 * データベース接続マネージャ。
 * <p>
 * データベース接続のコネクションを保持するクラスです。データベース向けの DAO に
 * 対してコネクションを提供します。
 * </p><p>
 * 本アプリケーションは DAO内で自動トランザクションを実装するため、本マネージャが
 * トランザクションも保持します。</p>
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public abstract class BaseConnectionManager {
    /**
     * データベースコネクションを戻します。
     * <p>
     * Thin Driver を用いてデータベースコネクションを取得し、戻します。
     * 既にコネクションが保持されている場合はそれを戻します。<br />
     * また、初期設定として自動コミットを ON に設定しています。</p>
     *
     * @param dto 接続定義情報
     * @param connectionUserLabel 接続ユーザー（ログインユーザー表示名）
     * @return Connection
     * @exception SQLException
     */
    public abstract Connection getConnection(
            final DbConnectInfomationDTO dtol)
            throws SQLException;

    /**
     * コネクションを終了し、オブジェクト参照を初期化します。
     */
    public void close() {
        if (this.connection != null) {
            try {
                this.connection.close();
            } catch (final SQLException e) {
                this.logger.warn(e);
            }
            this.connection = null;
        }
    }

    /**
     * データベースコネクションを戻します。
     *
     * @return Connection
     */
    public Connection getConnection() {
        return connection;
    }

    /**
     * データベースコネクションを設定します。
     *
     * @return Connection
     */
    protected void setConnection(Connection connection) {
        this.connection = connection;
    }

    /**
     * ロガーインスタンスを保持します。
     */
    private final Logger logger;

    /**
     * DB Connection を保持します。
     */
    private Connection connection = null;

    /**
     * ロガーへの参照を戻します。
     *
     * @return Logger
     */
    protected Logger getLogger() {
        return logger;
    }

    /**
     * ConnectionManager の生成。
     */
    public BaseConnectionManager() {
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
    }

    /**
     * データベース接続ＵＲＬを戻します。
     *
     * <p>
     * DB 接続情報 DTO に設定された情報より、
     * 各ベンダーのデータベース接続ＵＲＬの形式で、
     * 生成したＵＲＬを戻します。<br />
     * また、ユーザがデータベース接続ＵＲＬを直に指定している
     * 場合は、そのＵＲＬを戻します。
     * </p>
     * <p>
     * 例：Oracle 、ＤＢサーバＩＰ：192.168.0.0、ポート：1521、データベース名：SAMPLEの場合<br />
     * jdbc:oracl:thin@192.168.0.0:1521:SAMPLE
     * </p>
     *
     * @param dto
     * @return
     */
    public String createDatabaseUrl(
            final DbConnectInfomationDTO dto) {
        if (dto.isUseDatabaseUrl()) {
            return dto.getDatabaseUrl();
        } else {
            final MessageFormat formatter = new MessageFormat(
                dto.getDatabaseTypeConnectionDestination().getUrl());
            return formatter.format(
                new Object[]{
                        dto.getServerId(),
                        dto.getPortId(),
                        dto.getDatabaseId()});
        }
    }

    /**
     * @param dto
     * @throws SQLException
     */
	public void connectWithTransaction(final DbConnectInfomationDTO dto) throws SQLException {
		getConnection(dto);
		this.connection.setAutoCommit(false);
	}

	/**
	 * @throws SQLException
	 */
	public void commit() throws SQLException {
		this.connection.commit();
	}

	/**
	 * @throws SQLException
	 */
	public void rollback() throws SQLException {
		this.connection.rollback();
	}
	
	/**
	 * @return
	 * MySQL = `
	 * PostgreSQL/Oracle/SQLServer = " 
	 */
	public String getQuoteId() {
		try {
			return this.connection.getMetaData().getIdentifierQuoteString();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "\"";
	}
}
