/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.db;

/**
 * テーブル ID の定義 VO。
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class TableIdDefinition {

    private String tableId;

    private String schem;

    private String table;

    /**
     * tableId を戻します。
     *
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * schem を戻します。
     *
     * @return String
     */
    public String getSchem() {
        return schem;
    }

    /**
     * table を戻します。
     *
     * @return String
     */
    public String getTable() {
        return table;
    }

    /**
     * TableIdDefinition の生成。
     * <p>テーブル ID を受け取り、スキーマ名とテーブル名に分割します。</p>
     *
     * @param tableId テーブル ID（スキーマ名.テーブル名）
     */
    public TableIdDefinition(final String tableId) {
        this.tableId = tableId;
        final String[] data = tableId.split("\\.");
        if (data.length == 2) {
            this.schem = data[0];
            this.table = data[1];
        } else {
            this.schem = null;
            this.table = tableId;
        }
    }

}
