/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForms;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

@Data
public class TableFormsDto {
	private List<TableFormDto> tableFormDtoList;

	public TableFormsDto() {

	}

	public TableFormsDto(TableForms tableForms) {
		if (tableForms != null) {
			List<TableFormDto> tableFormDtoList = new ArrayList<TableFormDto>();
			for(TableForm item : tableForms.getTableForm()){
				TableFormDto dto = new TableFormDto(item);
				tableFormDtoList.add(dto);
			}
			this.setTableFormDtoList(tableFormDtoList);
		}
	}	
	
	/**
	 * 1. new ArrayList<TableFormDto>()
	 * 2. sort by label
	 * @return tableFormDtoList
	 */
	public List<TableFormDto> getTableFormDtoList(){
		if(tableFormDtoList == null){
			tableFormDtoList = new ArrayList<TableFormDto>();
		}else{
			Collections.sort(tableFormDtoList, new Comparator<TableFormDto>() {
			  @Override public int compare(final TableFormDto o1, final TableFormDto o2) {
			    return o1.getLabel().compareTo(o2.getLabel());
			  }
			});
		}		
		return tableFormDtoList;
	}
}
