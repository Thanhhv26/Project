package jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.CellStyle;

import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;

/**
 * @author van-thanh
 *
 */
public class LogicFormatCellCommand {
	
	/**
	 * 
	 */
	private SXSSFWorkbookCus workbook;
	
	/**
	 * 
	 */
	private DatabaseTypeConnectionDestination type;
	
	private Map<String, CellStyle> map = null;
	
	/**
	 * 
	 */
	public LogicFormatCellCommand(){
		
	}
	
	/**
	 * @param workbook
	 * @param type
	 */
	public LogicFormatCellCommand(
			final SXSSFWorkbookCus workbook,			
			final String type) {
		this.workbook = workbook;
		this.type = DatabaseTypeConnectionDestination.keyOf(type);
		this.initCellFormatCommand();
	}
	
	private static List<BaseFormatCell> list;
	static {
		list = new ArrayList<BaseFormatCell>();
		list.add(new MySQLFormatCellCommand());
		list.add(new PostgreSQLFormatCellCommand());
		list.add(new OracleFormatCellCommand());
		list.add(new SQLServerFormatCellCommand());
	}
	
	/**
	 * 
	 */
	private void initCellFormatCommand(){
		for(BaseFormatCell item : list){
			item.setWorkbook(workbook);
			item.setType(type);
		}
	}
	
	/**
	 * @return
	 */
	public Map<String, CellStyle> getMapCellStyles(){
		if(map != null){
			return map;
		}
		for(BaseFormatCell item : list){
			if(item.checkDatabaseType()){
				map = item.getMapFormatCell();
				return map;
			}
		}
		return null;
	}
	
	/**
	 * @return
	 */
	public BaseFormatCell getClassFormatCell(){
		for(BaseFormatCell item : list){
			if(item.checkDatabaseType()){				
				return item;
			}
		}
		return null;
	}

}
