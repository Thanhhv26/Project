/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * リポジトリ内の登録情報の有無を確認するロジック。
 * <p>
 * リポジトリ内情報のエクスポート＆インポートを行う際に、エクスポート元及び
 * インポート先の接続定義内に、対象情報（ユーザー情報或いはテーブルフォーム情報）
 * の既存登録があるかどうかを確認します。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class ExistenceOfInformationInRepositoryIsConfirmedLogic
        extends BaseApplicationDomainLogic {
    /**
     * テーブルフォーム情報の登録有無を確認する。
     * <p>
     * リポジトリ内の指定された接続定義に対し、にテーブルフォーム情報の登録が
     * あるか否かを確認します。
     * </p><p>
     * tableForms 要素が存在しない、或いは子要素である tableForm 要素が存在
     * しない場合に登録無しを示す false を戻し、tableForm 要素が一つでも存在
     * すれば true を戻します。
     * </p>
     *
     * @param connectDefinition 接続定義 ID
     * @return true : 登録あり / false : 登録なし
     * @throws ApplicationDomainLogicException
     */
    public boolean hasTableForms(final String connectDefinition)
            throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        try {
            return dao.hasTableForms(connectDefinition);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * ExistenceOfInformationInRepositoryIsConfirmedLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public ExistenceOfInformationInRepositoryIsConfirmedLogic() {
        return;
    }

    /**
     * テーブルフォーム DAO を生成して戻す。
     *
     * @return TableFormDAO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDAO createTableFormDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
