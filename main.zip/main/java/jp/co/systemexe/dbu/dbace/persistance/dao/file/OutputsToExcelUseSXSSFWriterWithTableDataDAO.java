package jp.co.systemexe.dbu.dbace.persistance.dao.file;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.SortedMap;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.BaseFormatCell;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.LogicFormatCellCommand;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.SXSSFCellCus;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.SXSSFRowCus;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.SXSSFSheetCus;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.SXSSFWorkbookCus;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * ＳXSSFでテーブルデータをExcelに出力します。
 * <p>
 * 出力されるExcelのファイル名は テーブル名 + 日付(yyyy/MM/dd hh:mm:ss.SSS).xlsx になります。<br />
 * また、出力されるExcelのシート名は テーブル名 となります。
 * </p>
 *
 * @author EXE Phung-Tien
 * @version 0.0.0
 */
public class OutputsToExcelUseSXSSFWriterWithTableDataDAO extends BaseOutputsToFileWithTableDataDAO {

	/**
	 * Excel Max行数
	 */
	private final int MAX_ROW_COUNT = 1048576;
	/**
	 * 最大出力ファイルサイズ
	 */
	private long MAX_OUTPUT_BYTES = ((long) SystemProperties.getDownloadMaximumByteForExcel()) * 1024L * 1024L;

	/**
	 * 現在のExcel行数
	 */
	private int rowCount = 1;
	private int sheetIndex = 1;
	/**
	 * データ出力件数
	 */
	private int recordCount = 0;

	/**
	 * ファイルサイズをチェックする、レコード件数
	 * <p>
	 * 初期値は1000
	 * </p>
	 */
	private int checkRecordCount = 1000;

	private SXSSFWorkbookCus workbook;
	private SXSSFSheetCus sSheet = null;
	private LogicFormatCellCommand command = null;

	/**
	 * OutputsToExcelUseSXSSFWriterWithTableDataDAO.java の生成。
	 *
	 */
	public OutputsToExcelUseSXSSFWriterWithTableDataDAO() {

		super();
	}
	
	/**
	 * @param columnId
	 * @param dbType
	 */
	private void setColumnStyle(
			final int index,
			final String dataType,
			final String dbType){
		if(command == null){
			command = new LogicFormatCellCommand(workbook, dbType);
		}
		final BaseFormatCell baseFormatCell = command.getClassFormatCell();
		final Map<String, CellStyle> mapFormatCell = command.getMapCellStyles();
		final String typeFormatsCell = baseFormatCell.getTypeFormatsCellByDataType(dataType);
		final CellStyle cellStyle = mapFormatCell.get(typeFormatsCell);
		if(cellStyle != null){
			sSheet.setDefaultColumnStyle(index, cellStyle);
		}
	}

	@Override
	public void outputFile(
			final String tableId, 
			final SortedMap<Integer, TableItemDTO> columnId,
			final Map<String, String> columnData,
			final String dbType) throws DAOException {
		if (workbook == null) {
			getLogger().debug("download_mode: 0");
			workbook = new SXSSFWorkbookCus(100);
			workbook.setCompressTempFiles(false);
		}

		if (rowCount == 1 || rowCount >= MAX_ROW_COUNT) {
			rowCount = 1;
			final String tableName;
			if (tableId.indexOf(".") == -1) {
				tableName = tableId;
			} else {
				tableName = tableId.substring(tableId.indexOf(".") + 1);
			}

			String sheetName = tableName.length() > 10 ? tableName.substring(0, 10) : tableName;
			sheetName += "_" + sheetIndex;			
			sSheet = workbook.createSheet(sheetName);			
			sSheet.setRandomAccessWindowSize(100);// keep 100 rows in memory,
													// exceeding rows will be
													// flushed to disk
			sheetIndex++;			
			// ヘッダ部作成
			createHeader(columnId, sSheet, dbType);
		}

		// 名細部作成
		createRow(columnId, columnData, sSheet, dbType);
		//getLogger().debug(recordCount + "件目出力中");
		if (!checkFileSize()) {
			// MI-E-0147=ダウンロード件数が多すぎます。データ件数を絞り込んでください。
			final String message = MessageUtils.getMessage("MI-E-0147");
			getLogger().error(message);
			throw new DAOException(message);
		}

	}

	/**
	 * Create header use SXSSF</br>
	 * JP mode(use SXSSF)
	 *
	 * @param columnId
	 * @param sheet
	 */
	private void createHeader(
			final SortedMap<Integer, TableItemDTO> columnId, 
			final SXSSFSheetCus sheet,
			final String dbType) {
		final SXSSFRowCus headerRow = sheet.createRow(0);
		short headerCellIndex = 0;
		for (final Integer index : columnId.keySet()) {
			final TableItemDTO item = columnId.get(index);
			final SXSSFCellCus cell = headerRow.createCell(headerCellIndex);
			final XSSFRichTextString richTextString = new XSSFRichTextString(item.getItemLabel());
			cell.setCellValue(richTextString);
			//set column style by data type --BEGIN
			this.setColumnStyle(index, item.getDataType(), dbType);
			//set column style by data type --END
			headerCellIndex++;
		}
	}

	/**
	 * Create row use SXSSF</br>
	 * JP mode(use SXSSF)
	 *
	 * @param columnId
	 * @param columnData
	 * @param sheet
	 */
	private void createRow(
			final SortedMap<Integer, TableItemDTO> columnId, 
			final Map<String, String> columnData,
			final SXSSFSheetCus sheet,
			final String dbType) {
		// 行の作成
		final SXSSFRowCus detailRow = sheet.createRow(rowCount);
		short detailCellIndex = 0;
		
		for (final Integer index : columnId.keySet()) {
			final TableItemDTO tableItemDTO = columnId.get(index);
			String data = columnData.get(tableItemDTO.getItemId());
			if(data == null){
				data = "";
			}
			final SXSSFCellCus cell = detailRow.createCell(detailCellIndex);
			cell.setCellStyle(sheet.getColumnStyle(detailCellIndex));
			final XSSFRichTextString richTextString = new XSSFRichTextString(data.trim());
			//RichTextString, String => xml: t="inlineStr"
			//Boolean  => xml: t="b"
			//Double  => xml: t="n"
			cell.setCellValue(richTextString);
			detailCellIndex++;
		}
		recordCount++;
		rowCount++;
	}

	@Override
	public void write() throws DAOException {
		try {
			workbook.write(getOutputStream());
			workbook.dispose();
		} catch (final IOException e) {
			final String message = "Excelファイルの出力に失敗しました。(" + e.getMessage() + ")";
			getLogger().fatal(message, e);
			throw new DAOException(message, e);
		} catch (final OutOfMemoryError e) {
			final String message = MessageUtils.getMessage("MI-E-0147");
			getLogger().fatal(message, e);
			throw new DAOException(message, e);
		}
	}

	@Override
	public int getOutputRecordCount() {
		return recordCount;
	}

	@Override
	public boolean checkFileSize() throws DAOException {
		if (recordCount >= checkRecordCount) {

			// ファイル出力するファイルパス
			String pathTempFile = "";
			pathTempFile = this.getFilePath();

			// Excelファイルの出力
			writeExcelToTempFile(pathTempFile);

			// ファイルサイズチェック
			File file = new File(pathTempFile);
			final long bytes = file.length();

			if (bytes > MAX_OUTPUT_BYTES) {
				getLogger().debug("excel file size:" + bytes + "," + MAX_OUTPUT_BYTES);
				workbook.dispose();
				this.close();
				file.delete();
				return false;
			} else {
				checkRecordCount = (int) (MAX_OUTPUT_BYTES / (bytes / recordCount));
				getLogger().debug("checkRecordCount:" + checkRecordCount);

				// Excelファイル出力し続きます。
				try {
					sSheet.reOpenFile();
				} catch (IOException e) {
					final String message = "Excelファイルの出力に失敗しました。(" + e.getMessage() + ")";
					getLogger().fatal(message, e);
					throw new DAOException(message, e);
				}
				return true;
			}
		}
		return true;

	}

	/**
	 * Excelファイルの出力
	 *
	 * @param path
	 * @throws DAOException
	 */
	private void writeExcelToTempFile(String path) throws DAOException {
		try {
			// ファイル出力するファイルパスを設定します。
			OutputStream bos = new FileOutputStream(path);
			// Excelファイルの出力
			workbook.write(bos);
			bos.flush();
			bos.close();
		} catch (final IOException e) {
			final String message = "Excelファイルの出力に失敗しました。(" + e.getMessage() + ")";
			getLogger().fatal(message, e);
			throw new DAOException(message, e);
		} catch (final OutOfMemoryError e) {
			final String message = MessageUtils.getMessage("MI-E-0147");
			getLogger().fatal(message, e);
			throw new DAOException(message, e);
		}
	}

}
