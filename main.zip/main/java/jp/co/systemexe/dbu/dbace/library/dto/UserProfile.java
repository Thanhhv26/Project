/**
 *
 */
package jp.co.systemexe.dbu.dbace.library.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.Getter;
import lombok.Setter;

/**
 * @author vdlson
 *
 */
public class UserProfile extends BaseDto implements UserDetails, Serializable {
	private static final long serialVersionUID = 1632835826723103685L;

	@Getter
	@Setter
	private String username;
	@Getter
	@Setter
	private String email;
	@Getter
	@Setter
	private String password;
	@Getter
	@Setter
	private Integer employeeId;
	@Getter
	@Setter
	private String firstName;
	@Getter
	@Setter
	private String lastName;
	@Getter
	@Setter
	private String phone;
	@Getter
	@Setter
	private Timestamp logindate;
	@Getter
	@Setter
	private boolean accountNonExpired;
	@Getter
	@Setter
	private boolean accountNonLocked;
	@Getter
	@Setter
	private boolean credentialsNonExpired;
	@Getter
	@Setter
	private boolean enabled;
	@Getter
	@Setter
	private boolean sysadmin;
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return null;
	}
}

