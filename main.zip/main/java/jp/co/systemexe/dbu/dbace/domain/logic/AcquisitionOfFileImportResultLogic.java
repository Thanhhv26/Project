/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.file.BaseFileImportResultDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.file.FileImportResultDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.FileImportResultDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * データ一括インポートにおける、エラーメッセージ情報の取得。
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class AcquisitionOfFileImportResultLogic
        extends BaseApplicationDomainLogic {

    /**
	 * データ一括インポートにおける、エラーメッセージ情報を取得します。
	 * <p>
	 * 取得後、ファイルを削除します。
	 * </p>
     * 
     * @param fileName
     * @return
     * @throws ApplicationDomainLogicException
     */
    public FileImportResultDTO getFileImportResultDAO(
            final String fileName)
            throws ApplicationDomainLogicException {
        final BaseFileImportResultDAO fileImportResultDAO
	    	= new FileImportResultDAO();
	    try {
	    	final FileImportResultDTO ret
	    		= fileImportResultDAO.inputFile(fileName);
	        fileImportResultDAO.deleteFile(fileName);
	        return ret;
	    } catch (final DAOException e) {
	        throw new ApplicationDomainLogicException(e);
	    }
    }
    
    /**
     * AcquisitionOfSearchConditionControlLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public AcquisitionOfFileImportResultLogic() {
        return;
    }
}
