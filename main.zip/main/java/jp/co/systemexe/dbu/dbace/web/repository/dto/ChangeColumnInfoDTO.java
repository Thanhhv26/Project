/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import java.util.List;

import jp.co.systemexe.dbu.dbace.web.repository.model.ChangeColumnItem;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class ChangeColumnInfoDTO {
	private String userId;
	private String connectDefinitionId;
	private String tableFormId;
	private List<ChangeColumnItem> changeColumnItems;
	
	/**
	 * @param userId
	 * @param connectDefinitionId
	 * @param tableFormId
	 * @param changeColumnItems
	 */
	public ChangeColumnInfoDTO(String userId, String connectDefinitionId, String tableFormId,List<ChangeColumnItem> changeColumnItems) {
		this.userId = userId;
		this.connectDefinitionId = connectDefinitionId;
		this.tableFormId = tableFormId;
		this.changeColumnItems = changeColumnItems;
	}
	
}
