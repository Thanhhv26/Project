/**
 * Copyright(C) 2009 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.persistance.dao.AuditSettingDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.AuditSettingDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * 監査ログ設定情報の変更ロジック。
 * <p>
 * 現在使用されている、監査ログ設定情報を新しい監査ログ設定情報に更新するための処理です。</p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */
public class ChangeAuditLogLogic
        extends BaseApplicationDomainLogic {

    /**
     * 現在使用されている、監査ログ設定情報を引数で指定された新しい監査ログ設定情報に更新します。
     * 
     * @param dto AuditSettingDTO
     * @throws ApplicationDomainLogicException
     */
    public void changeAuditLog(final AuditSettingDTO dto)
            throws ApplicationDomainLogicException {
        try {
            OutputAuditLog.changeAuditLogSetting(dto);
        } catch (final Exception e) {
            
        }
    }

    /**
     * 現在使用されている、監査ログ設定情報を監査ログ設定情報XMLより取得した、情報に更新します。
     * 
     * @throws ApplicationDomainLogicException
     */
    public void newAuditLog()
            throws ApplicationDomainLogicException {
        final AuditSettingDAO dao = createAuditSettingDAO();
        final AuditSettingDTO dto;
        try {
            dto = dao.getAuditSettingDTO();
        } catch (final DAOException e) {
           throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        OutputAuditLog.createAuditLogSetting(dto);
    }

    /**
     * PreservationOfConnectDefinitionLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public ChangeAuditLogLogic() {
        return;
    }

    /**
     * 監査ログ設定情報 DAO を生成して戻す。
     * 
     * @return AuditSettingDAO
     * @throws ApplicationDomainLogicException
     */
    private AuditSettingDAO createAuditSettingDAO()
            throws ApplicationDomainLogicException {
        try {
            return (AuditSettingDAO)createDAO("AuditSettingDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
