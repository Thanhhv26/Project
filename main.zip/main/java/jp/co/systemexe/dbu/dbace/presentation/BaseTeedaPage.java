/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import jp.co.systemexe.dbu.dbace.presentation.dto.ApplicationMessageDTO;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;

/**
 * Teeda フレームワーク Page クラス作成用抽象基底クラス。
 * <p>
 * Page クラスを作成するためのスーパークラスです。Teeda フレームワーク利用上の
 * ノウハウ、及びアプリケーションが共通に使用するオブジェクト（ロガー、ユーザー
 * 情報）を定義しています。<br />
 * Page クラスの実装にかかる前に、必ず本クラスのコメント、メソッド定義をご確認
 * 下さい。
 * </p><p>
 * サブアプリケーション単位で共通処理を拡張定義したい場合、本クラスを継承した
 * サブクラスとして、新たに抽象クラスを定義して下さい。<br />
 * ただしその場合、スーパークラスを三層以上定義したり、或いは本クラスを修正する
 * ような事の無いようにして下さい。
 * </p>
 *
 * @author EXE 鈴木 伸祐
 * @author EXE 相田 一英
 * @version 0.0.0
 * @see http://www.seasar.org/wiki/index.php?Teeda%2FgettingStarted
 */
public abstract class BaseTeedaPage {

    /**
     * ロガー。
     */
    private final Logger logger;

    private MessageInfo messageInfo;

    private List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();

    /**
     * ユーザー情報。
     * <p>
     * セッション中に保持されるユーザー情報です。実際に設定されるインスタンスは、
     * Serializable インターフェースを実装した上で、session.dicon 内でセッション
     * 内で保持するように定義したオブジェクトです。
     * </p>
     * @see jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo
     * @see /src/main/resources/session.dicon
     */
//    private UserInfo userInfo;

    /**
     * サブアプリケーション間メッセージ通知 DTO。
     * <p>
     * セッション中に保持されるメッセージ通知用 DTO です。実際に設定される
     * インスタンスは、Serializable インターフェースを実装した上で、session.dicon
     * 内でセッション内で保持するように定義したオブジェクトです。
     * </p><p>
     * 本 DTO の利用が許可されるのはサブアプリケーション間でのメッセージのやり
     * とりを行う場合に限ります。サブアプリケーション内でのメッセージ通知は、
     * Teeda 標準の共通名称プロパティに対する DI 機構を利用して下さい。
     * </p>
     *
     * @see jp.co.systemexe.dbu.dbace.presentation.dto.ApplicationMessageDTO
     * @see /src/main/resources/session.dicon
     */
    private ApplicationMessageDTO applicationMessageDTO;

    /**
     * 前画面要素の名称。
     */
    private String previousViewId;

    /**
     * ポストバック判定。
     */
    private boolean postback;

    /**
     * Page クラスの初期化イベントハンドラ。
     * <p>
     * Page クラスが初期化されるときに一回だけ実行されます。<br />
     * このメソッドが無くても Teeda は動作しますが、本プロジェクトでは必ず実装
     * するものとします。特に何もしない（遷移を行わない）場合は、
     * <code>
     * public String initialize() {
     *  return null;
     * }
     * </code>
     * とし、メソッドコメントに何も行わない旨明記して下さい。
     * </p>
     *
     * @return null
     */
    public abstract String initialize();

    /**
     * 画面要素の描画処理イベントハンドラ。
     * <p>
     * Page クラスとマッピングされた画面要素が、ブラウザ上で再描画される度に実行
     * されます。<br />
     * このメソッドが無くても Teeda は動作しますが、本プロジェクトでは必ず実装
     * するものとします。特に何もしない（遷移を行わない）場合は、
     * <code>
     * public String prerender() {
     *  return null;
     * }
     * </code>
     * とし、メソッドコメントに何も行わない旨明記して下さい。
     * </p>
     *
     * @return
     */
    public abstract String prerender();

    /**
     * userInfo を戻します。
     * <p>
     * ユーザー情報オブジェクトを戻します。インスタンスはセッション内から自動的
     * に DI されます。</p>
     *
     * @return User2
     */
//    public UserInfo getUserInfo() {
//        return userInfo;
//    }

    /**
     * userInfo を設定します。
     * <p>
     * ユーザー情報オブジェクトの実体は、Serializable インターフェースを実装した
     * 上で、session.dicon 内でセッション内で保持するように定義したオブジェクト
     * です。<br />
     * 本メソッドを使用してユーザー情報がセッションに設定されるのは、ログオン
     * 処理の初回一回のみです。
     * </p>
     *
     * @param User2 userInfo
     * @see jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo
     * @see /src/main/resources/session.dicon
     */
//    public void setUserInfo(final UserInfo userInfo) {
//        this.userInfo = userInfo;
//    }

    /**
     * applicationMessageDTO を戻します。
     * <p>
     * セッション中に保持されるメッセージ通知用 DTO です。実際に設定される
     * インスタンスは、Serializable インターフェースを実装した上で、session.dicon
     * 内でセッション内で保持するように定義したオブジェクトです。
     * </p><p>
     * 本 DTO の利用が許可されるのはサブアプリケーション間でのメッセージのやり
     * とりを行う場合に限ります。サブアプリケーション内でのメッセージ通知は、
     * Teeda 標準の共通名称プロパティに対する DI 機構を利用して下さい。
     * </p>
     *
     * @return ApplicationMessageDTO
     * @see jp.co.systemexe.dbu.dbace.presentation.dto.ApplicationMessageDTO
     * @see /src/main/resources/session.dicon
     */
    public ApplicationMessageDTO getApplicationMessageDTO() {
        return applicationMessageDTO;
    }

    /**
     * applicationMessageDTO を設定します。
     * <p>
     * 本メソッドによって DTO のインスタンスが設定されるのは、スタートページの
     * 初期化イベント一回のみです。
     * </p><p>
     * セッション中に保持されるメッセージ通知用 DTO です。実際に設定される
     * インスタンスは、Serializable インターフェースを実装した上で、session.dicon
     * 内でセッション内で保持するように定義したオブジェクトです。
     * </p><p>
     * 本 DTO の利用が許可されるのはサブアプリケーション間でのメッセージのやり
     * とりを行う場合に限ります。サブアプリケーション内でのメッセージ通知は、
     * Teeda 標準の共通名称プロパティに対する DI 機構を利用して下さい。
     * </p>
     *
     * @param ApplicationMessageDTO applicationMessageDTO
     * @see jp.co.systemexe.dbu.dbace.presentation.dto.ApplicationMessageDTO
     * @see /src/main/resources/session.dicon
     */
    public void setApplicationMessageDTO(
            final ApplicationMessageDTO applicationMessageDTO) {
        this.applicationMessageDTO = applicationMessageDTO;
    }

    /**
     * 前の画面要素名を戻します。
     * <p>
     * Teeda が自動的にインジェクションした、前の画面要素名を戻します。</p>
     *
     * @return String
     */
    public String getPreviousViewId() {
        return previousViewId;
    }

    /**
     * 前の画面要素名を設定します。
     * <p>
     * 前の画面要素名を Teeda が自動的にインジェクションするための setter です。
     * プログラマが明示的に設定してはいけません。</p>
     *
     * @param String previousViewId
     * @deprecated 本メソッドは Teeda フレームワークが使用するメソッドです。
     */
    public void setPreviousViewId(final String previousViewId) {
        this.previousViewId = previousViewId;
    }

    /**
     * ポストバック判定を戻します。
     * <p>
     * Page クラスの初期化が発生した際に、それが通常の遷移なのかポストバック
     * なのかを示すフラグです。</p>
     *
     * @return boolean true : ポストバック / false : 通常遷移
     */
    public boolean isPostback() {
        return postback;
    }

    /**
     * ポストバック判定を設定します。
     * <p>
     * ポストバック判定を Teeda が自動的にインジェクションするための setter です。
     * プログラマが明示的に設定してはいけません。</p>
     *
     * @param boolean postback
     * @deprecated 本メソッドは Teeda フレームワークが使用するメソッドです。
     */
    public void setPostback(final boolean postback) {
        this.postback = postback;
    }

    /**
     * 画面表示の標準メッセージに文言を追加します。
     * <p>
     * 画面表示上の汎用メッセージ Message/AllMessages/Message に文言を追加します。
     * バリデーションではなく、メソッドレベルでメッセージ表示を利用したい場合、
     * このメソッドを利用した上で null を戻します。</p>
     * <p>
     * ログ出力も自動で行います。</p>
     *
     * @param e 例外オブジェクト
     */
    protected void addPageMessage(final ApplicationException e) {
        getLogger().error(e.getLocalizedMessage(), e);
        /*FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage("message.UidNotFound", e.getLocalizedMessage()));*/
        /*this.errorMessage.setErrorCode("message.UidNotFound");
        this.errorMessage.setErrorString(e.getLocalizedMessage());*/
    }

    protected void addPageMessage(final Exception e) {
        getLogger().error(e.getLocalizedMessage(), e);
        /*FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage("message.UidNotFound", e.getLocalizedMessage()));*/
        /*this.errorMessage.setErrorCode("message.UidNotFound");
        this.errorMessage.setErrorString(e.getLocalizedMessage());*/
    }

    /**
     * 画面表示の標準メッセージに文言を追加します。
     * <p>
     * 画面表示上の汎用メッセージ Message/AllMessages/Message に文言を追加します。
     * バリデーションではなく、メソッドレベルでメッセージ表示を利用したい場合、
     * このメソッドを利用した上で null を戻します。</p>
     * <p>
     * ログ出力も自動で行います。</p>
     *
     * @param message 例外メッセージ
     */
    public void addPageMessage(final String message) {
        getLogger().error(message);
        /*FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage("message.UidNotFound", message));*/
        /*MessageInfo error = new MessageInfo(message, messageService);
        this.errorMessage.setErrorCode(error.getErrorCode());
        this.errorMessage.setErrorString(error.getErrorString());*/
    }

    public void addPageMessage(final String message, MessageService messageService) {
        getLogger().error(message);
        /*FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage("message.UidNotFound", message));*/
        /*MessageInfo error = new MessageInfo(message, messageService);
        this.errorMessage.setErrorCode(error.getErrorCode());
        this.errorMessage.setErrorString(error.getErrorString());*/
    }

    /**
     * 画面表示の標準メッセージをメッセージIDを元にappMessages_ja.propertiesより
     * 追加します。
     * <p>
     * 画面表示上の汎用メッセージ Message/AllMessages/Message に文言を追加します。
     * バリデーションではなく、メソッドレベルでメッセージ表示を利用したい場合、
     * このメソッドを利用した上で null を戻します。</p>
     * <p>
     * メッセージの本文はappMessages_ja.propertiesに登録してください。
     * </p>
     * <p>
     * ログ出力も自動で行います。</p>
     *
     * @param messageId 例外メッセージID
     * @param args パラメータ
     */
    protected void addPageMessageId(final String messageId, String args[]) {
//        final FacesMessage message
//            = FacesMessageUtil.getMessage(FacesContext.getCurrentInstance(), messageId, args);
//        getLogger().error(message.getDetail());
//        FacesContext.getCurrentInstance().addMessage(null, message);
    }

    /**
     * 画面表示の標準メッセージをメッセージIDを元にappMessages_ja.propertiesより
     * 追加します。
     * <p>
     * 画面表示上の汎用メッセージ Message/AllMessages/Message に文言を追加します。
     * バリデーションではなく、メソッドレベルでメッセージ表示を利用したい場合、
     * このメソッドを利用した上で null を戻します。</p>
     * <p>
     * メッセージの本文はappMessages_ja.propertiesに登録してください。
     * </p>
     * <p>
     * ログ出力も自動で行います。</p>
     *
     * @param messageId 例外メッセージID
     */
    protected void addPageMessageId(final String messageId) {
        addPageMessageId(messageId, null);
    }

    /**
     * logger を戻します。
     * <p>
     * Teeda Page サブクラスに対しロガー参照を提供します。</p>
     *
     * @return Logger
     */
    protected Logger getLogger() {
        return logger;
    }

    /**
     * BaseTeedaPage の生成。
     * <p>
     * コンストラクタ。ロガーの初期化を行っています。</p>
     */
    public BaseTeedaPage() {
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
    }


    /**
     * HTMLレイアウトを返します。
     *
     * @return
     */
    public String getLayout() {
        return "/layout/mainLayout.html";
    }

    /**
     * version を戻します。
     *
     * @return String
     */
    public String getVersion() {
        return "Version," + SystemProperties.getApplicationVersion();
    }

	public MessageInfo getMessageInfo() {
		return messageInfo;
	}

	public void setMessageInfo(MessageInfo messageInfo) {
		this.messageInfo = messageInfo;
	}

	public List<MessageInfo> getMessageInfoList() {
		return messageInfoList;
	}

}
