/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationUserDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.GeneralUserOperationAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * ユーザー情報操作ロジック。
 * <p>
 * アプリケーションリポジトリに保持されたユーザー情報を操作するためのビジネス
 * ロジックです。<br />
 * 既にアプリケーションが認証した権限者によって操作されます。</p>
 *
 * @author EXE 島田 雄一郎
 * @author EXE 鈴木 伸祐
 * @author EXE 相田 一英
 * @author EXE 六本木 圭
 * @version 0.0.0
 */
public class OperationOfUserInformationLogic extends BaseApplicationDomainLogic {

    /**
     * ユーザー情報を取得して戻す。
     * <p>
     * 接続定義情報、ユーザーID より、ユーザー情報 DTO を取得します。
     * </p><p>
     * なお、返される DTO にはパスワード情報は含みません。
     * </p>
     * 
     * @param userId
     * @return UserInfoDTO
     * @exception ApplicationDomainLogicException アプリケーションドメインロジック例外
     * @see getApplicationPassword()
     */
    public UserInfoDTO getUserInfoDTO(final String userId)
    		throws ApplicationDomainLogicException {
        final UserInfoDTO ret = new UserInfoDTO();
        final ApplicationUserDAO dao = createApplicationUserDAO();
        final ApplicationUserDTO dto;
        try {
            dto = dao.getApplicationUserDTO(userId);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        ret.setId(dto.getUserId());
        ret.setName(dto.getUserLabel());
        ret.setUserAuthority(dto.getAuthority());
        
        boolean isApplicationAdministrator = false;
        final Map<String, Boolean> applicationAdministratorMap
        	= new HashMap<String, Boolean>();
        for (final ConnectDefinisionAuthority def
        		: dto.getAuthority().getConnectDefinisionAuthoritys()) {
        	boolean isConnectDefinisionOfApplicationAdministrator = false;
        	for (final GeneralUserOperationAuthority auth
        			: def.getOperationAuthority()) {
        		if (auth == GeneralUserOperationAuthority.CUSTOMIZE) {
        			isApplicationAdministrator = true;
        			isConnectDefinisionOfApplicationAdministrator = true;
        			break;
        		}
        	}
			applicationAdministratorMap.put(
					def.getConnectDefinisionId(),
					isConnectDefinisionOfApplicationAdministrator);
        }
        
        ret.setApplicationAdministrator(isApplicationAdministrator);
        ret.setApplicationAdministratorMap(applicationAdministratorMap);
        
        return ret;
    }

    /**
     * ユーザーのパスワードを取得して戻す。
     * <p>
     * 接続定義情報、ユーザーID より、リポジトリ内に設定されているユーザーの
     * パスワードだけを取得して戻します。
     * </p><p>
     * 通常のユーザー情報取得処理ではパスワード情報が取得できません。これは、
     * 機密性の高いパスワード情報を無意味に提供しないように取り決められた実装
     * 上のセキュリティポリシーに拠ります。
     * </p><p>
     * 原則、本メソッドを使用してパスワードを取得する処理は、ユーザー情報の
     * （画面上パスワード入力が無い、特殊な場合の）更新処理以外では在り得ません。
     * </p>
     * 
     * @param userId
     * @return String Password
     * @exception ApplicationDomainLogicException アプリケーションドメインロジック例外
     * @see getUserInfoDTO()
     */
    public String getApplicationPassword(final String userId)
    		throws ApplicationDomainLogicException {
        final ApplicationUserDAO dao = createApplicationUserDAO();
        final ApplicationUserDTO dto;
        try {
            dto = dao.getApplicationUserDTO(userId);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return dto.getPassword();
    }

    /**
     * ユーザー名の一覧を戻します。
     * <p>
     * ユーザー ID、ユーザー名の一覧を設定した Map を戻します。</p>
     * 
     * @return Map&lt;ユーザー ID, ユーザー名&gt;
     * @throws ApplicationDomainLogicException
     */
    public Map<String, String> getUserNameMap()
            throws ApplicationDomainLogicException {
        final ApplicationUserDAO dao = createApplicationUserDAO();
        final Map<String, String> map;
        try {
            map = dao.getUserNameMap();
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
        return map;
    }

    /**
     * OperationOfUserInformationLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public OperationOfUserInformationLogic() {
        return;
    }

    /**
     * アプリケーションユーザー DAO を生成して戻す。
     * 
     * @return ApplicationUserDAO
     * @throws ApplicationDomainLogicException
     */
    private ApplicationUserDAO createApplicationUserDAO()
            throws ApplicationDomainLogicException {
        try {
            return (ApplicationUserDAO)createDAO("ApplicationUserDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
