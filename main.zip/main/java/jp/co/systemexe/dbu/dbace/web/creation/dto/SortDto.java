/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

@Data
public class SortDto {
	private List<RowDto> rowDto;
	
	public SortDto(){
		
	}
	
	public SortDto(TableForm.Sort sort){
		if (sort != null) {
			List<RowDto> rowDtoTemp = new ArrayList<RowDto>();
			for (TableForm.Sort.Row item : sort.getRow()) {
				SortDto.RowDto rowDto = new SortDto.RowDto(item);
				rowDtoTemp.add(rowDto);
			}
			this.setRowDto(rowDtoTemp);
		}
	}
	
	public List<RowDto> getRowDto() {
        if (this.rowDto == null) {
        	this.rowDto = new ArrayList<RowDto>();
        }
        return this.rowDto;
    }
	
	@Data
	public static class RowDto {
		private String id;
		private String value;
		
		public RowDto(){
			
		}
		
		public RowDto(TableForm.Sort.Row row){
			if(row!=null){
				this.setId(row.getId());
				this.setValue(row.getValue());
			}
		}
	}
}
