/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.check.command;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.logger.Logger;
import jp.co.systemexe.dbu.dbace.common.logger.LoggerFactory;
import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.presentation.check.CheckMessageDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.ColumnDisplayDefinitionDTO;

/**
 * 論理チェックコマンドの基底抽象クラス。
 * <p>
 * 実際の論理チェックを行うコマンドクラスの基底抽象クラスです。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public abstract class BaseLogicalCheckCommand {
    /**
     * ロガーへの参照を保持します。
     */
    private final Logger logger;

    private ColumnDisplayDefinitionDTO displayDef;

    /**
     * 項目表示定義 DTO を受け取りコマンドを初期化します。
     * <p>
     * 項目表示定義 DTO への参照を受け取ります。この DTO の保持値を元に動作を
     * 決定します。
     * </p><p>
     * 本メソッドは、このクラスに定義された他の全てのメソッドよりも先に実行され
     * なければいけません。
     * </p>
     *
     * @param ColumnDisplayDefinitionDTO displayDef
     */
    public void init(final ColumnDisplayDefinitionDTO displayDef) {
        this.displayDef = displayDef;
    }

    /**
     * 項目表示定義 DTO を戻します。
     *
     * @return ColumnDisplayDefinitionDTO
     */
    protected final ColumnDisplayDefinitionDTO getDisplayDef() {
        return displayDef;
    }

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。
     * </p><p>
     * 実行される基本検査は、
     * <ol>
     *  <li>リポジトリで「編集可能な項目」となっていない場合は検査対象外。</li>
     * </ol>
     * </p>
     *
     * @param columnId
     * @return
     */
    public final boolean isCharge(final String columnId) {
        final TableItemDTO item = getDisplayDef().getItemDefinitions().get(
            columnId);
        if (item == null || item.canEditing() == false) {
            return false;
        }
        return isMyTask(columnId);
    }

    /**
     * 検査を実行します。
     * <p>
     * 論理チェックを実行し、チェックの結果問題があれば結果メッセージ DTO に
     * メッセージを追加します。
     * </p><p>
     * チェックは CheckMessageDTO 内の値補正値に対して実行します。原則、問題の
     * ある文字列の除去、書式の補正を行い値を再設定します。<br />
     * この補正が連鎖的に実行される事で、補正処理の重複実行が回避されます。
     * </p><p>
     * このメソッドは全てのサブクラスで実装されなければいけません。
     * </p>
     *
     * @param columnId カラム名
     * @param messages 論理チェック結果メッセージ保持 DTO
     */
    public abstract void check(
    		final DbConnectInfomationDTO dbConnectInfomationDTO,
    		final String columnId,
    		final Map<String, String> columnIdAndValue,
            final CheckMessageDTO messages,final Map<String, TableItemDTO>  tableItemMap);

    /**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。</p>
     * <p>
     * このメソッドは全てのサブクラスで実装されなければいけません。設定された
     * カラム名を元に ColumnDisplayDefinitionDTO の参照からリポジトリの定義情報、
     * DB スキーマ情報を取得し、自身に定義された検査が実行されるべきか否かを
     * 判断します。
     * </p><p>
     * 「編集禁止」が定義されているような項目は対象から除外する、等の基本的な
     * チェックは呼び出しもとの isCharge メソッド側で判断されます。
     * </p><p>
     * また、特に検査の実行条件が存在しない場合は、
     * <code>   return true;</code>
     * だけを定義します。</p>
     *
     * @param columnId
     * @return true : 検査担当 / false : 担当ではない
     */
    protected abstract boolean isMyTask(final String columnId);

 /*   *//**
     * 検査の担当か否かを戻す。
     * <p>
     * コマンドがそのカラムの検査を担当するか否かを戻します。担当だった場合、
     * 対象カラムへの検査を実行します。</p>
     * <p>
     * このメソッドは全てのサブクラスで実装されなければいけません。設定された
     * カラム名を元に ColumnDisplayDefinitionDTO の参照からリポジトリの定義情報、
     * DB スキーマ情報を取得し、自身に定義された検査が実行されるべきか否かを
     * 判断します。
     * </p><p>
     * 「編集禁止」が定義されているような項目は対象から除外する、等の基本的な
     * チェックは呼び出しもとの isCharge メソッド側で判断されます。
     * </p><p>
     * また、特に検査の実行条件が存在しない場合は、
     * <code>   return true;</code>
     * だけを定義します。</p>
     *
     * @param columnId
     * @return true : 検査担当 / false : 担当ではない
     *//*
    protected abstract boolean isDataImportMyTask(final String columnId);
*/
    /**
     * カラムIDより、カラムの表示名を取得します。
     *
     * @param columnId
     * @return
     */
    protected String getColumnLabel(final String columnId) {
    	return displayDef.getItemDefinitions().get(columnId).getItemLabel();
    }

    /**
     * BaseLogicalCheckCommand の生成。
     * <p>コンストラクタ。</p>
     */
    public BaseLogicalCheckCommand() {
        this.logger = LoggerFactory.getLogger(this.getClass().getName());
    }

	/**
	 * logger を戻します。
	 *
	 * @return Logger
	 */
	public Logger getLogger() {
		return logger;
	}
}
