/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.relation.dto;
import java.util.List;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import lombok.Data;
/**
 * @author  tu-lenh
 * @version 0.0.0
 */
@Data
public class RelationMessageInfo {
	//OK , NG
	private String status;
	//id of html element, message error
	Map<String,String> errorMap;
	//id of html element, message success
	Map<String,String> successMap;
	private List<MessageInfo> messageInfo;
	List<RelationScreenDTO> relationScreenDTOList;
	/**
	 * constructor
	 */
	public RelationMessageInfo(){

	}
}
