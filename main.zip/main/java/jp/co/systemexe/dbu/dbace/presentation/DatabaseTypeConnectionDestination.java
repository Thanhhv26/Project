/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import java.util.HashMap;
import java.util.Map;

/**
 * 接続先データベースベンダー定義 enmu。
 * <p>
 * 接続定義がどのデータベースを対象としているか指示
 * するための定義値です。
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public enum DatabaseTypeConnectionDestination {
    /**
     * Oracle 10g
     */
    Oracle("Oracle", "Oracle Database", "jdbc:oracle:thin:@{0}:{1}:{2}", true),
    /**
     * SQL Sever 2005
     */
    SqlServer("SQLServer","SQL Server", "jdbc:sqlserver://{0}:{1};databaseName={2};{3}", true),
    /**
     * PostgreSQL V9
     */
    PostgreSQL("PostgreSQL","PostgreSQL", "jdbc:postgresql://{0}:{1}/{2}", true),
    /**
     * MySQL
     */
    //MySQL("MySQL","MySQL", "jdbc:mysql://{0}:{1}/{2}", true);
    MySQL("MySQL","MySQL", "jdbc:mysql://{0}:{1}/{2}?useUnicode=true&characterEncoding=UTF-8", true);
    /**
     * DB2 V9
     */
//    DB2("DB2","DB2 V9", "jdbc:db2://{0}:{1}:{2}", true);

    private final String key;
    private final String databaseName;
    private final String url;
    private final boolean visible;

    private static Map<String, DatabaseTypeConnectionDestination> map;
    static {
        map = new HashMap<String, DatabaseTypeConnectionDestination>();
        for (final DatabaseTypeConnectionDestination buff : values()) {
            map.put(buff.getKey(), buff);
        }
    }

    public static DatabaseTypeConnectionDestination keyOf(final String key) {
        if (map.containsKey(key)) {
            return map.get(key);
        } else {
            return null;
        }
    }

    /**
     * テーブル中に実際に保存されるキー文字列を戻します。
     *
     * @return
     */
    public String getKey() {
        return this.key;
    }

    /**
     * visible を戻します。
     *
     * @return boolean
     */
    public boolean isVisible() {
        return visible;
    }

    /**
     * databaseName を戻します。
     *
     * @return String
     */
    public String getDatabaseName() {
        return this.databaseName;
    }

    /**
     * url を戻します。
     *
     * @return String
     */
    public String getUrl() {
        return url;
    }

    private DatabaseTypeConnectionDestination(
            final String key,
            final String databaseName,
            final String url,
            final boolean visible) {
        this.key = key;
        this.databaseName = databaseName;
        this.url = url;
        this.visible = visible;
    }
}
