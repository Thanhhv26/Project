/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

import java.util.HashMap;
import java.util.Map;

/**
 * レコード削除条件 DTO。
 * <p>
 * レコードの削除操作はレコード一件単位でしか発生しません。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class RecordDeleteConditionDTO {

    /**
     * 接続定義 ID。
     */
    private String connectDefinitionId;

    /**
     * テーブル ID。
     */
    private String tableId;

    /**
     * 削除条件マップ。
     * <p>Map&l;プライマリキーカラム名, 一致条件&gt;</p>
     */
    private Map<String, String> conditions = new HashMap<String, String>();

    /**
     * connectDefinitionId を戻します。
     * 
     * @return String
     */
    public String getConnectDefinitionId() {
        return connectDefinitionId;
    }

    /**
     * connectDefinitionId を設定します。
     *
     * @param String connectDefinitionId 
     */
    public void setConnectDefinitionId(String connectDefinitionId) {
        this.connectDefinitionId = connectDefinitionId;
    }

    /**
     * tableId を戻します。
     * 
     * @return String
     */
    public String getTableId() {
        return tableId;
    }

    /**
     * tableId を設定します。
     *
     * @param String tableId 
     */
    public void setTableId(String tableId) {
        this.tableId = tableId;
    }

    /**
     * 削除条件マップを戻します。
     * 
     * @return Map&l;プライマリキーカラム名, 一致条件&gt;
     */
    public Map<String, String> getConditions() {
        return conditions;
    }

    /**
     * RecordDeleteConditionDTO の生成。
     * <p>コンストラクタ。</p>
     */
    public RecordDeleteConditionDTO() {
        return;
    }
}
