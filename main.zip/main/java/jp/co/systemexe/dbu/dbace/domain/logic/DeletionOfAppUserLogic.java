/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import jp.co.systemexe.dbu.dbace.persistance.dao.ApplicationUserDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * アプリケーションユーザー情報の削除ロジック。
 * <p>
 * リポジトリからアプリケーションユーザー情報を削除します。</p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class DeletionOfAppUserLogic extends BaseApplicationDomainLogic {

    /**
     * リポジトリからユーザー情報を削除します。
     * <p>
     * システム管理者に対して実行した場合は例外をスローします。</p>
     * 
     * @param userId
     * @throws ApplicationDomainLogicException
     */
    public void remove(final String userId)
            throws ApplicationDomainLogicException {
        final ApplicationUserDAO dao = createApplicationUserDAO();
        try {
            dao.remove(userId);
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * DeletionOfAppUserLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public DeletionOfAppUserLogic() {
        return;
    }

    /**
     * アプリケーションユーザー DAO を生成して戻す。
     * 
     * @return ApplicationUserDAO
     * @throws ApplicationDomainLogicException
     */
    private ApplicationUserDAO createApplicationUserDAO()
            throws ApplicationDomainLogicException {
        try {
            return (ApplicationUserDAO)createDAO("ApplicationUserDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
}
