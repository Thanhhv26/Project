/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.web.user.dto.FRM0400DeleteDto;
import jp.co.systemexe.dbu.dbace.web.user.dto.FRM0400InsertDto;
import jp.co.systemexe.dbu.dbace.web.user.dto.FRM0400ResultDto;
import jp.co.systemexe.dbu.dbace.web.user.dto.FRM0600ResultDto;
import jp.co.systemexe.dbu.dbace.web.user.json.FRM0400Param;
import jp.co.systemexe.dbu.dbace.web.user.json.FRM0400ParamDelete;
import jp.co.systemexe.dbu.dbace.web.user.json.FRM0400ParamInsert;
import jp.co.systemexe.dbu.dbace.web.user.json.FRM0600Param;

/**
 * @author van-thanh
 *
 */

/**
 * contain method to processing for user screen
 *
 */
public interface UserInformationService {
	/**
	 * searchUserInformation
	 * param: searchParam
	 * return FRM0400SearchResultDto
	 */
	FRM0400ResultDto searchUserInformation(FRM0400Param searchParam) throws ApplicationRuntimeException;

	/**
	 * deleteUserInformation
	 * param: searchParam
	 * return FRM0400SearchResultDto
	 */
	/*FRM0400ResultDto deleteUserInformation(FRM0400Param searchParam) throws ApplicationRuntimeException;*/

	/**
	 * insertUpdateUserInformation
	 * param: searchParam
	 * return FRM0400SearchResultDto
	 */
	FRM0400ResultDto insertUpdateUserInformation(FRM0400Param param) throws ApplicationRuntimeException;

	/**
	 * getUserById
	 * param: searchParam
	 * return FRM0400SearchResultDto
	 */
	FRM0400ResultDto getUserById(FRM0400ParamInsert param) throws ApplicationRuntimeException;

	/**
	 * deleteUser
	 * param: searchParam
	 * return FRM0400SearchResultDto
	 */
	FRM0400DeleteDto deleteUser(FRM0400ParamDelete param);

	/**
	 * doOnceConfirmation
	 * param: param
	 * return FRM0400InsertDto
	 */
	FRM0400InsertDto doOnceConfirmation(FRM0400ParamInsert param);

	/**
	 * init for begin insert or update
	 * @param param
	 * @return
	 */
	FRM0400InsertDto initializeInsert(FRM0400ParamInsert param);
	/**
	 * 個人プロファイル
	 * @param param
	 * @return
	 */
	FRM0600ResultDto doSaveEditProfile (FRM0600Param param) throws ApplicationDomainLogicException;
	
	/**
	 * @return
	 */
	String getExtAuth();

}
