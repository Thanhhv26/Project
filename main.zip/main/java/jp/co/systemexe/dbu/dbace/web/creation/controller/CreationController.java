/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfAppRelationLogic;
import jp.co.systemexe.dbu.dbace.domain.service.CreationService;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.web.common.AppConst;
import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ConnectionDefinisionDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.RelationsDto.RelationDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.creation.json.FRM0330JsonInsert;
import jp.co.systemexe.dbu.dbace.web.creation.json.FRM0330JsonSearch;
import jp.co.systemexe.dbu.dbace.web.creation.model.FRM0330ModelInsert;
import jp.co.systemexe.dbu.dbace.web.creation.model.FRM0330ModelSearch;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;
import jp.co.systemexe.dbu.dbace.web.user.dto.PageInfo;

/**
 * @author van-thanh
 *
 */

@RestController
@RequestMapping(value = "/data")
public class CreationController extends AbstractController {
	private static final long serialVersionUID = 1L;

	@Autowired
	CreationService creationService;

	/**
	 * get info page
	 *
	 * @return PageInfo
	 */
	@RequestMapping(value = "/create/getInfoPage", method = { RequestMethod.POST })
	public PageInfo getInfoPage() throws Exception {
		return new PageInfo();
	}

	/**
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/create", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index(Model model) throws Exception {
		ModelAndView mv = new ModelAndView(PageConst.SCREEN_OBJECT_CREATION);
		return mv;
	}

	/**
	 * @param search
	 * @return
	 */
	@RequestMapping(value = "/create/search", method = RequestMethod.POST)
	public @ResponseBody FRM0330ModelSearch doOnceValueTableSearch(@RequestBody FRM0330JsonSearch search) {
		FRM0330ModelSearch result = new FRM0330ModelSearch();
		try{
			search.setUserAuthority(getUserAuthority());
			result.setTableMultiList(creationService.getAllTableMulti(search));
			OutputAuditLog.writeMakeViewLog(
					getUserInfo(), //userInfo
					AuditStatus.success,
					"",//databaseName
					"",
					AuditEventKind.SEARCH,
					String.valueOf(result.getTableMultiList().size()));
		}catch(Exception e){
			OutputAuditLog.writeMakeViewLog(
					getUserInfo(), //userInfo
					AuditStatus.failure,
					"",//databaseName
					"",
					AuditEventKind.SEARCH,
					"");
		}
		return result;
	}

	/**
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/create/initInsert", method = RequestMethod.POST)
	public @ResponseBody FRM0330ModelInsert initInsert(@RequestBody FRM0330JsonInsert param) {
		FRM0330ModelInsert result = new FRM0330ModelInsert();
		List<MessageInfo> messages = new ArrayList<MessageInfo>();
		boolean flagSF = true;
		try {
			//check file repository.xml exist
			if(!RepositoryCommon.checkFileRepositoryExist()){
				messages.add(new MessageInfo("frm0330.file.repository.not.exist", MessageType.ERROR, messageService));
				result.setMessages(messages);
				return result;
			}
			//check format file repository.xml
			if(!RepositoryCommon.checkFormatFileRepositoryXml()){
				messages.add(new MessageInfo("frm0330.file.repository.wrong.format", MessageType.ERROR, messageService));
				result.setMessages(messages);
				return result;
			}

			/*get all connection*/
			/*param.setUserAuthority(getUserAuthority());*/
			result.setConnectionList(creationService.getConnectionList(-1, getUserAuthority()));//not get table multi
			//sort ConnectionDefinisionDto list by label
			Collections.sort(result.getConnectionList(), new Comparator<ConnectionDefinisionDto>() {
			  @Override public int compare(final ConnectionDefinisionDto o1, final ConnectionDefinisionDto o2) {
			    return o1.getLabel().compareTo(o2.getLabel());
			  }
			});

			/*get all relation*/
			result.setRelationList(creationService.getAllRelationInformationList());

			if(param.getActionUIRD().equals(AppConst.ACTION_EDIT)
					|| param.getActionUIRD().equals(AppConst.ACTION_COPY)
					|| param.getActionUIRD().equals(AppConst.ACTION_VIEW)){
				result.setObjectInsert(
						creationService.getTableFormDtoByLabel(
								param.getConnectionIdUIRD(),
								param.getTableUIRD().getLabel(),
								getUserAuthority()));
			}
		} catch (Exception e) {
			flagSF = false;
		}

		if(param.getActionUIRD().equals(AppConst.ACTION_VIEW)){
			OutputAuditLog.writeMakeViewLog(
					getUserInfo(),
					flagSF ? AuditStatus.success : AuditStatus.failure,
							creationService.getConnectionById(param.getConnectionIdUIRD(), 0, getUserAuthority()).getLabel(),
					param.getTableUIRD().getLabel(),
					AuditEventKind.REFERENCE,
					flagSF ? String.valueOf(1) : String.valueOf(0));
		}

		result.setMessages(messages);
		return result;
	}

	/**
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/create/insert", method = RequestMethod.POST)
	public @ResponseBody FRM0330ModelInsert insert(@RequestBody FRM0330JsonInsert param) throws Exception{
		FRM0330ModelInsert result = new FRM0330ModelInsert();
		List<MessageInfo> messages = new ArrayList<MessageInfo>();

		if(param.getActionUIRD().equals(AppConst.ACTION_EDIT) || param.getActionUIRD().equals(AppConst.ACTION_COPY)) {
			param.setUserAuthority(getUserAuthority());
			//check table exits
			//if check === null => check.getId() is error and =>ApplicationDomainLogicException
			TableFormDto check = creationService.getTableFormDtoByID(param.getConnectionIdUIRD(), param.getTableUIRD().getId(), param.getUserAuthority());
			if (check == null) {
				String mgs = messageService.getMessage("frm0330.screen.main.delete.error");
				messages.add(new MessageInfo(mgs, MessageType.ERROR));
				result.setMessages(messages);
				return result;
			}
		}

		//note: check validate server
		try {
			if(param.getActionUIRD().equals(AppConst.ACTION_INSERT)){
				/*//check table exits
				for(TableDto tableDto:param.getTableUIRD().getTablesDto().getTableDtoList()){
					TableFormDto checkTable = creationService.getTableFormDtoByID(param.getConnectionIdUIRD(), tableDto.getId(), param.getUserAuthority());
					if (checkTable == null) {
						final String args[]={tableDto.getLabel()};
						messages.add(new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args));
						result.setMessages(messages);
						return result;
					}
				}
				// check relation exist
				final PreservationOfAppRelationLogic logicRel = new PreservationOfAppRelationLogic();
				for(RelationDto relationDto:param.getTableUIRD().getRelationsDto().getRelationDtoList()){
					if (!logicRel.checkRelationExist(relationDto.getId())) {
						final String args[]={relationDto.getLabel()};
						messages.add(new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args));
						result.setMessages(messages);
						return result;
					}
				}*/
				param.getTableUIRD().setId(this.generateRelationId());
				creationService.insertTableMulti(param);
				messages.add(new MessageInfo("frm0330.screen.g.save.success", MessageType.SUCCESS, messageService));
			}else if(param.getActionUIRD().equals(AppConst.ACTION_EDIT)){
				creationService.updateTableMulti(param);
				messages.add(new MessageInfo("frm0330.screen.g.update.success", MessageType.SUCCESS, messageService));
			}else if(param.getActionUIRD().equals(AppConst.ACTION_COPY)){
				param.getTableUIRD().setId(this.generateRelationId());
				creationService.insertTableMulti(param);
				messages.add(new MessageInfo("frm0330.screen.g.copy.success", MessageType.SUCCESS, messageService));
			}
		} catch (DAOException e) {
			messages.add(new MessageInfo(e, MessageType.ERROR));
			result.setMessages(messages);
			return result;
		}
		result.setMessages(messages);
		return result;
	}

	/**
	 * is Deleted Creation
	 * @return true : exist /false : not exist
	 */
	@RequestMapping(value = "/create/isDeletedCreation", method = { RequestMethod.POST })
	public boolean isDeletedCreation(@RequestBody FRM0330JsonInsert param) throws Exception {
		param.setUserAuthority(getUserAuthority());
		// check creation exist
		TableFormDto check = creationService.getTableFormDtoByID(param.getD_connectionID(), param.getD_tableID(),param.getUserAuthority());
		// if check === null => check.getId() is error and
		// =>ApplicationDomainLogicException
		return check == null ? false : true;
	}

	/**
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/create/delete", method = RequestMethod.POST)
	public @ResponseBody FRM0330ModelInsert delete(@RequestBody FRM0330JsonInsert param) {
		FRM0330ModelInsert result = new FRM0330ModelInsert();
		List<MessageInfo> messages = new ArrayList<MessageInfo>();
		String databaseName = "";
		//remove
		try {
			//check table exits
			//if check === null => check.getId() is error and =>ApplicationDomainLogicException
			TableFormDto check = creationService.getTableFormDtoByID(param.getD_connectionID(), param.getD_tableID(), param.getUserAuthority());
			check.getId();

			creationService.removeTableMulti(param);
			messages.add(new MessageInfo("frm0330.screen.main.delete.success", MessageType.SUCCESS, messageService));

			databaseName = creationService.getConnectionById(param.getD_connectionID(), 0, param.getUserAuthority()).getLabel();//databaseName
			OutputAuditLog.writeMakeViewLog(
					param.getUserInfo(), //userInfo
					AuditStatus.success,
					databaseName,//databaseName
					param.getD_tableLabel(),
					AuditEventKind.DELETE,
					String.valueOf(1));
		} catch (DAOException e) {
			OutputAuditLog.writeMakeViewLog(
					param.getUserInfo(), //userInfo
					AuditStatus.failure,
					databaseName,//databaseName
					param.getD_tableLabel(),
					AuditEventKind.DELETE,
					String.valueOf(1));
			String mgs = messageService.getMessage("frm0330.screen.main.delete.error");
			messages.add(new MessageInfo(mgs, MessageType.ERROR));
		}catch (Exception ex) {
			OutputAuditLog.writeMakeViewLog(
					param.getUserInfo(), //userInfo
					AuditStatus.failure,
					databaseName,//databaseName
					param.getD_tableLabel(),
					AuditEventKind.DELETE,
					String.valueOf(1));
			String mgs = messageService.getMessage("frm0330.screen.main.delete.error");
			messages.add(new MessageInfo(mgs, MessageType.ERROR));
		}
		result.setMessages(messages);
		return result;
	}

	@RequestMapping(value = "/create/getTableMultiById", method = RequestMethod.POST)
	public @ResponseBody FRM0330ModelInsert getTableMultiById(@RequestBody FRM0330JsonInsert param) {
		FRM0330ModelInsert result = new FRM0330ModelInsert();
		List<MessageInfo> messages = new ArrayList<MessageInfo>();

		param.getTableUIRD().setId(this.generateRelationId());
		try {
			creationService.insertTableMulti(param);
		} catch (DAOException e) {
			messages.add(new MessageInfo(e, MessageType.ERROR));
		}
		result.setMessages(messages);
		return result;
	}

	/**
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/create/check_update_key", method = RequestMethod.POST)
	public @ResponseBody FRM0330ModelInsert checkUpdateKey(@RequestBody FRM0330JsonInsert param) throws Exception {
		FRM0330ModelInsert result = new FRM0330ModelInsert();
		List<MessageInfo> messages = new ArrayList<MessageInfo>();
		//check table exits
		for(TableDto tableDto:param.getTableUIRD().getTablesDto().getTableDtoList()){
			TableFormDto checkTable = creationService.getTableFormDtoByID(param.getConnectionId(), tableDto.getId(), param.getUserAuthority());
			if (checkTable == null) {
				final String args[]={tableDto.getLabel()};
				messages.add(new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args));
				result.setMessages(messages);
				return result;
			}
		}
		// check relation exist
		final PreservationOfAppRelationLogic logicRel = new PreservationOfAppRelationLogic();
		for(RelationDto relationDto:param.getTableUIRD().getRelationsDto().getRelationDtoList()){
			if (!logicRel.checkRelationExist(relationDto.getId())) {
				final String args[]={relationDto.getLabel()};
				messages.add(new MessageInfo("","MI-E-0113", MessageType.ERROR, messageService,args));
				result.setMessages(messages);
				return result;
			}
		}
		//param -1 is not get table multi
		ConnectionDefinisionDto selectedConnection = creationService.getConnectionById(param.getConnectionId(), -1,getUserAuthority());
		result.setTableFormDtoList(selectedConnection.getTableFormsDto().getTableFormDtoList());
		return result;
	}

	/**
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/create/check-table-label-exist", method = RequestMethod.POST)
	public @ResponseBody FRM0330ModelInsert checkTableLabelExist(@RequestBody FRM0330JsonInsert param) {
		FRM0330ModelInsert result = new FRM0330ModelInsert();
		List<MessageInfo> messages = new ArrayList<MessageInfo>();

		//check table label exist
		String connectionID = param.getConnectionIdUIRD();
		String tableID = param.getActionUIRD().equals(AppConst.ACTION_EDIT) ? param.getTableUIRD().getId() : null;
		String tableLabel = param.getTableUIRD().getLabel();
		if(creationService.checkTableLabelExist(connectionID, tableID, tableLabel)){
			messages.add(new MessageInfo("frm0330.table.label.exist", MessageType.ERROR, messageService));
			result.setMessages(messages);
			return result;
		}
		result.setMessages(messages);
		return result;
	}

	/**
    * 譁ｰ縺励＞creation ID 繧堤函謌舌＠縺ｦ謌ｻ縺励∪縺吶��
    *
    * @return creation ID
    */
   public String generateRelationId() {
       final SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmssZ");
       return sdf.format(new Date());
   }
}
