/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao;

import jp.co.systemexe.dbu.dbace.persistance.dto.DbConnectInfomationDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

/**
 * データベースへの接続情報 DAO。
 * <p>
 * リポジトリに対するデータベース接続情報入出力 DAO です。</p>
 * <p>
 * パスワードの暗号化・復号化は DAO の内部で自動的に実行されます。</p>
 *
 * @author EXE 鈴木 伸祐
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public interface DbConnectInfomationDAO {

    /**
     * DB 接続情報 DTO を戻します。
     * <p>
     * 接続定義 ID を指定し、リポジトリから DB 接続情報 DTO を取得して戻します。
     * </p>
     *
     * @param connectDefinisionId 接続定義 ID
     * @return DbConnectInfomationDTO DB 接続情報 DTO
     * @throws DAOException 独自定義例外
     */
    public DbConnectInfomationDTO getDbConnectInfomationDTO(
            final String connectDefinitionId) throws DAOException;
    /**
     * DB 接続情報 DTO を戻します。
     * <p>
     * 接続定義 ID を指定し、リポジトリから DB 接続情報 DTO を取得して戻します。
     * </p>
     *
     * @param connectDefinisionId 接続定義名
     * @return DbConnectInfomationDTO DB 接続情報 DTO
     * @throws DAOException 独自定義例外
     */
    public DbConnectInfomationDTO getDbConnectInfomationLableDTO(
            final String connectDefinitionId) throws DAOException;
    /**
     * DB 接続情報を保存します。
     * <p>
     * リポジトリに DB 接続情報を保存します。リポジトリ内に対象要素が存在しない
     * 場合には、明示的に要素を作成します。</p>
     *
     * @param connectDefinisionId 接続定義 ID
     * @param dto DbConnectInfomationDTO DB 接続情報 DTO
     * @throws DAOException 独自定義例外
     */
    public void save(final String connectDefinitionId,
            final DbConnectInfomationDTO dto) throws DAOException;

    public String openSesame();

}
