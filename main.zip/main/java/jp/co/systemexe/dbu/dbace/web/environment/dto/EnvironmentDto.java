/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.environment.dto;

import jp.co.systemexe.dbu.dbace.library.dto.BaseDto;
import jp.co.systemexe.dbu.dbace.presentation.AdLdapServerType;
import jp.co.systemexe.dbu.dbace.presentation.LdapUserServerIdentify;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * @author LUONG THI THANH TRUC
 * @version 6.0 jan 18, 2017
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
public class EnvironmentDto extends BaseDto {

	private static final long serialVersionUID = 1L;
	/**
	 * リポジトリXMLファイルパス
	 */
	private String repositoryFilePath;

	/**
	 * 選択されたレコード表示件数
	 */
	private String recordDisplayCount;

	/**
	 * カラム表示件数(検索時)
	 */
	private String columnDisplayCount;

	/**
	 * 検索条件保存パス
	 */
	private String retrievalConditionPreservationPath;

	/**
	 * プルダウン表示最大件数
	 */
	private String pulldownDisplayMaximumCount;

	/**
	 * プルダウン表示時のフェッチサイズ
	 */
	private String pulldownDisplayFetchSize;

	/**
	 * ファイルダウンロード時のフェッチサイズ
	 */
	private String fileDownloadFetchSize;

	/**
	 * 監査ログ情報設定XMLファイルパス
	 */
	private String auditLogFilePath;

	/**
	 * インポートファイルの一時格納フォルダパス
	 */
	private String importTempFilePath;

	/**
	 * ダウンロードファイル最大バイト(EXCEL)
	 */
	private String downloadMaximumByteForExcel;

	/**
	 * ダウンロードファイル最大バイト(CSV)
	 */
	private String downloadMaximumByteForCsv;

	/**
	 * インポートファイル最大バイト(EXCEL)
	 */
	private String importMaximumByteForExcel;

	/**
	 * インポートファイル最大バイト(CSV)
	 */
	private String importMaximumByteForCsv;

	/**
	 * インポートファイル最大バイト(TSV)
	 */
	private String importMaximumByteForTsv;

	/**
	 * レコードの最大検索件数
	 */
	private String searchMaxRecordCount;

	/**
	 *
	 */
	private String searchComparisonOperatorOrder;

	/**
	 * ライセンスキー
	 */
	private String licenseKey;
	/**
	 * ライセンス数
	 */
	private String licenseCnt;
	/**
	 * 外部認証
	 */
	private String extAuth;
	/**
	 * サーバー種類
	 */
	private String adLdapServerType;
	private AdLdapServerType authServerType;
	/**
	 * サーバーID
	 */
	private String authServerId;
	/**
	 * ポート番号
	 */
	private String authServerPort;
	/**
	 * ベースDN／ドメイン名
	 */
	private String authServerBaseDomain;
	/**
	 * サーバープロトコル
	 */
	private String authServerProtocol;
	/**
	 * サーバーセキュリティ
	 */
	private String authServerSecurity;
	/**
	 * サーバータイムアウト
	 */
	private String authServerTimeout;
	/**
	 * 接続ユーザーの識別子
	 */
	private String ldapUserServerIdentify;
	private LdapUserServerIdentify authServerUserIdentify;
	/**
	 * 接続ユーザー
	 */
	private String authConnectUsername;
	/**
	 * 接続パスワード
	 */
	private String authConnectPwd;
}
