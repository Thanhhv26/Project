/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemMultiDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.OptionalMultiDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

/*<table id="dbo.Customer" label="dbo.Customer" ListNO=1 CommitNO=1>
	<item id="CustomerID" label="CustomerID">
	  <isUpdateKey>false</isUpdateKey>
	  <PrimaryKey>true</PrimaryKey>
	  <Unique>true</Unique>
	  <ForeignKey>true</ForeignKey>
	  <DataType>varchar</DataType>
	  <DataLength>50</DataLength>
	  <DataUnit>byte</DataUnit>
	</item>
	<optional>
	  <insert OverWrite="false" NotAddNew="false" />
	  <update NotOverWrite="false" Delete="false" />
	  <copy OverWrite="false" NotAddNew="false" />
	  <delete Exclusion1="false" Exclusion2="false" Exclusion3="false" />
	</optional>
</table>*/

/**
 * @author van-thanh
 *
 */
/**
 * @author van-thanh
 *
 */
/**
 * @author van-thanh
 *
 */
/**
 * @author van-thanh
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "item",
    "optional"
})
@XmlRootElement(name = "table")
@Data
public class Table {
	@XmlAttribute(required = true)
    protected String id;
   /* @XmlAttribute(required = true)
    protected String label;*/
    @XmlAttribute(required = true)
    protected String listNO;
    @XmlAttribute(required = true)
    protected String commitNO;    
    
    protected List<ItemMulti> item;
    protected List<Table.OptionalMulti> optional;
    
    /**
     * contructor default
     */
    public Table(){
    	
    }
    
    /**
     * contructor with param TableDto
     * 
     * @param tableDto
     */
    public Table(TableDto tableDto){
    	if(tableDto != null){
    		this.setId(tableDto.getId());
    		/*this.setLabel(tableDto.getLabel());*/
    		this.setListNO(tableDto.getListNO());
    		this.setCommitNO(tableDto.getCommitNO());
    		this.setItem(tableDto.getItemMultiDto());
    		this.setOptional(tableDto.getOptionalMultiDto());
    	}
    }
    
    /**
     * get List<Item> default
     * 
     * @return
     */
    public List<ItemMulti> getItem(){
		if(item == null){
			item = new ArrayList<ItemMulti>();
		}
		return item;
	}
    
    /**
     * get List<ItemDto> default
     * 
     * @param ItemDtoList
     */
    public void setItem(List<ItemMultiDto> itemMultDtoList){
		if(itemMultDtoList != null){
			for(ItemMultiDto itemMultiDto : itemMultDtoList){
				ItemMulti item = new ItemMulti(itemMultiDto);
				this.getItem().add(item);
			}
		}
	}
    
    /**
     * @return
     */
    public List<OptionalMulti> getOptional(){
		if(optional == null){
			optional = new ArrayList<OptionalMulti>();
		}
		return optional;
	}
	
	/**
	 * @param optionalMultiDto
	 */
	public void setOptional(List<OptionalMultiDto> optionalMultiDto){
		if(optionalMultiDto != null){
			for(OptionalMultiDto item : optionalMultiDto){
				OptionalMulti optionalTemp = new OptionalMulti(item);
				this.getOptional().add(optionalTemp);
			}
		}
	}
    
    /*<optional>		
		<insert OverWrite="false" NotAddNew="false" />		
		<update NotOverWrite="false" Delete="false" />		
		<copy OverWrite="false" NotAddNew="false" />		
		<delete Exclusion1="false" Exclusion2="false" Exclusion3="false" />		
	</optional>*/
	
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(name = "", propOrder = {
			"insert",
			"update",
			"copy",
			"delete"
	})
	@XmlRootElement(name = "optional")
	@Data
	public static class OptionalMulti {
		@XmlElement
		protected OptionalMulti.Insert insert;
		@XmlElement
		protected OptionalMulti.Update update;
		@XmlElement
		protected OptionalMulti.Copy copy;
		@XmlElement
		protected OptionalMulti.Delete delete;
		
		public OptionalMulti() {

		}
		
		public OptionalMulti(OptionalMultiDto optionalMultiDto) {
			if (optionalMultiDto != null) {
				if (optionalMultiDto.getInsert() != null) {
					this.setInsert(new OptionalMulti.Insert(
							optionalMultiDto.getInsert().isOverWrite(), 
							optionalMultiDto.getInsert().isNotAddNew()));
				}
			}
			if (optionalMultiDto.getUpdate() != null) {
				this.setUpdate(new OptionalMulti.Update(
						optionalMultiDto.getUpdate().isNotOverWrite(), 
						optionalMultiDto.getUpdate().isDelete()));
			}
			if(optionalMultiDto.getCopy() != null){
				this.setCopy(new OptionalMulti.Copy(
						optionalMultiDto.getCopy().isOverWrite(), 
						optionalMultiDto.getCopy().isNotAddNew()));
			}
			if(optionalMultiDto.getDelete() != null){
				this.setDelete(new OptionalMulti.Delete(
						optionalMultiDto.getDelete().isExclusion1(), 
						optionalMultiDto.getDelete().isExclusion2(), 
						optionalMultiDto.getDelete().isExclusion3()));
			}
		}
		
		/*<insert OverWrite="false" NotAddNew="false" />*/
		@XmlAccessorType(XmlAccessType.FIELD)
	    @XmlType(name = "")
	    @Data
	    public static class Insert{
			@XmlAttribute
	    	private boolean overWrite;
			@XmlAttribute
	    	private boolean notAddNew;
			
			public Insert() {
				
			}
			
			public Insert(boolean overWrite, boolean notAddNew) {
				this.setOverWrite(overWrite);
				this.setNotAddNew(notAddNew);
			}
	    }
	    
		/*<update NotOverWrite="false" Delete="false" />*/
	    @XmlAccessorType(XmlAccessType.FIELD)
	    @XmlType(name = "")
	    @Data
	    public static class Update{
	    	@XmlAttribute
	    	private boolean notOverWrite;
	    	@XmlAttribute
	    	private boolean delete;
	    	
	    	public Update() {
				
			}
	    	
	    	public Update(boolean notOverWrite, boolean delete) {
				this.setNotOverWrite(notOverWrite);
				this.setDelete(delete);
			}
	    }
	    
	    /*<copy OverWrite="false" NotAddNew="false" />*/
	    @XmlAccessorType(XmlAccessType.FIELD)
	    @XmlType(name = "")
	    @Data
	    public static class Copy{
	    	@XmlAttribute
	    	private boolean overWrite;
	    	@XmlAttribute
	    	private boolean notAddNew;
	    	
	    	public Copy() {
				
			}
	    	
	    	public Copy(boolean overWrite, boolean notAddNew) {
				this.setOverWrite(overWrite);
				this.setNotAddNew(notAddNew);
			}
	    }
	
	    /*<delete Exclusion1="false" Exclusion2="false" Exclusion3="false" />*/
	    @XmlAccessorType(XmlAccessType.FIELD)
	    @XmlType(name = "")
	    @Data
		public static class Delete{
	    	@XmlAttribute
	    	private boolean exclusion1;
	    	@XmlAttribute
	    	private boolean exclusion2;
	    	@XmlAttribute
	    	private boolean exclusion3;
	    	
	    	public Delete() {
    			
			}
	    	
	    	public Delete(boolean exclusion1, boolean exclusion2, boolean exclusion3) {
				this.setExclusion1(exclusion1);
				this.setExclusion2(exclusion2);
				this.setExclusion3(exclusion3);
			}
		}
	}
}
