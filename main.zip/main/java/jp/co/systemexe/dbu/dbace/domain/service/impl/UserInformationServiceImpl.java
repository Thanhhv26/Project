/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.systemexe.dbu.dbace.common.audit.AuditEventKind;
import jp.co.systemexe.dbu.dbace.common.audit.AuditStatus;
import jp.co.systemexe.dbu.dbace.common.audit.OutputAuditLog;
import jp.co.systemexe.dbu.dbace.common.authenticator.ExtAuthValue;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationException;
import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.common.presentation.IdSelectable;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfConnectDefinitionListLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfEnvironmentSetting;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfUserAuthorityLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.AcquisitionOfUserListLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.DeletionOfAppUserLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.OperationOfUserInformationLogic;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfAppUserLogic;
import jp.co.systemexe.dbu.dbace.domain.service.UserInformationService;
import jp.co.systemexe.dbu.dbace.library.service.AbstractService;
import jp.co.systemexe.dbu.dbace.library.service.message.MessageService;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.GeneralUserOperationAuthority;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.UserAuthority;
import jp.co.systemexe.dbu.dbace.presentation.CharacterOfSystemFixation;
import jp.co.systemexe.dbu.dbace.presentation.UpdateDivision;
import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectManyCheckboxItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.OperationAuthoritysItem;
import jp.co.systemexe.dbu.dbace.web.user.dto.FRM0400DeleteDto;
import jp.co.systemexe.dbu.dbace.web.user.dto.FRM0400InsertDto;
import jp.co.systemexe.dbu.dbace.web.user.dto.FRM0400ResultDto;
import jp.co.systemexe.dbu.dbace.web.user.dto.FRM0600ResultDto;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo;
import jp.co.systemexe.dbu.dbace.web.user.dto.MessageInfo.MessageType;
import jp.co.systemexe.dbu.dbace.web.user.dto.UserInformationDto;
import jp.co.systemexe.dbu.dbace.web.user.json.FRM0400Param;
import jp.co.systemexe.dbu.dbace.web.user.json.FRM0400ParamDelete;
import jp.co.systemexe.dbu.dbace.web.user.json.FRM0400ParamInsert;
import jp.co.systemexe.dbu.dbace.web.user.json.FRM0600Param;
import jp.co.systemexe.dbu.dbace.web.user.model.UserAuthorityItem;
import jp.co.systemexe.dbu.dbace.web.user.model.UserInformation;

/**
 * @author van-thanh
 *
 */

/**
 * contain method to processing for user screen
 *
 */
@Service
public class UserInformationServiceImpl extends AbstractService implements UserInformationService {

	private static final long serialVersionUID = 1L;

	// @Autowired
	// private UserInfo userInfo;
	@Autowired
	MessageService messageService;

	private List<MessageInfo> messageInfoList = new ArrayList<MessageInfo>();

	private FRM0400InsertDto frm0400InsertDto = new FRM0400InsertDto();

	/*
	 * searchUserInformation param: searchParam return FRM0400SearchResultDto
	 *
	 * (non-Javadoc)
	 *
	 * @see jp.co.systemexe.dbu.dbace.domain.service.UserInformationService#
	 * searchUserInformation(jp.co.systemexe.dbu.dbace.web.user.json.
	 * FRM0400Param)
	 */
	@Override
	public FRM0400ResultDto searchUserInformation(FRM0400Param searchParam) throws ApplicationRuntimeException {
		FRM0400ResultDto searchResultDto = new FRM0400ResultDto();
		String searchUser = searchParam.getSearchUser();

		final AcquisitionOfUserListLogic logic = new AcquisitionOfUserListLogic();
		final Map<String, UserInformation> userInformationMap;
		try {
			userInformationMap = logic.getUserInformationMap();
		} catch (final ApplicationDomainLogicException e) {
			searchResultDto.setMessageInfo(new MessageInfo(e.getMessage(), MessageType.ERROR));
			return searchResultDto;
		}

		List<UserInformation> userInformationList = new ArrayList<UserInformation>();
		for (final String id : userInformationMap.keySet()) {
			final UserInformation info = userInformationMap.get(id);
			if (StringUtils.isEmpty(searchUser)
					// MOD 外部認証連携 機能追加 ↓
					|| info.getUserId().toLowerCase().contains(searchUser.toLowerCase())
					|| info.getUserLabel().toLowerCase().contains(searchUser.toLowerCase())) {
				// MOD 外部認証連携 機能追加 ↑
				userInformationList.add(info);
			}
		}

		if (userInformationList.size() == 0) {
			searchResultDto.setMessageInfo(new MessageInfo("MI-E-0053", MessageType.INFO, messageService));
			return searchResultDto;
		}
		searchResultDto.setUserInformationList(userInformationList);
		return searchResultDto;
	}

	/*
	 * @Override public FRM0400ResultDto deleteUserInformation(FRM0400Param
	 * param) throws ApplicationRuntimeException { FRM0400ResultDto resultDto =
	 * new FRM0400ResultDto(); UserDeletationConfirmationPage
	 * userDeletationConfirmationPage = new UserDeletationConfirmationPage();
	 * userDeletationConfirmationPage.setMessageService(messageService);
	 * userDeletationConfirmationPage.setSelectedUserId(param.getUserIdDelete())
	 * ;
	 * userDeletationConfirmationPage.setUpdateDivision(UpdateDivision.delete);
	 * userDeletationConfirmationPage.initialize();
	 * resultDto.setMessageInfo(userDeletationConfirmationPage.getMessageInfo())
	 * ; userDeletationConfirmationPage.doOnceDelete(); return resultDto; }
	 */

	@Override
	public FRM0400ResultDto insertUpdateUserInformation(FRM0400Param param) throws ApplicationRuntimeException {
		FRM0400ResultDto resultDto = new FRM0400ResultDto();
		/*
		 * UserInformationDto userInsert = param.getUserInsert();
		 *
		 * UserEditorPage userEditorPage = new UserEditorPage(); //set
		 * BaseUserEditingPage field if(param.isUpdateFlg() == true){
		 * userEditorPage.setUpdateDivision(UpdateDivision.update); }else{
		 * userEditorPage.setUpdateDivision(UpdateDivision.insert); }
		 * userEditorPage.setSystemAdministratorAuthority(Boolean.valueOf(
		 * userInsert.getUserAuthority()));
		 * userEditorPage.setSelectedUserId(userInsert.getUserId());
		 * userEditorPage.initialize(); //set userEditorPage field
		 * userEditorPage.setUserLabel(userInsert.getUserLabel());
		 * userEditorPage.setPassword(userInsert.getPassword());
		 * userEditorPage.setPasswordConfirmation(userInsert.
		 * getPasswordConfirmation());
		 * userEditorPage.setUserAuthorityItems(userInsert.getUserAuthorityItems
		 * ()); userEditorPage.setMessageService(messageService);
		 * userEditorPage.setSystemAdministratorAuthority(Boolean.valueOf(
		 * userInsert.getUserAuthority())); userEditorPage.doOnceConfirmation();
		 *
		 * resultDto.setMessageInfo(userEditorPage.getMessageInfo());
		 */
		return resultDto;
	}

	/*
	 * getUserById param: searchParam return FRM0400SearchResultDto
	 *
	 * (non-Javadoc)
	 *
	 * @see jp.co.systemexe.dbu.dbace.domain.service.UserInformationService#
	 * getUserById(jp.co.systemexe.dbu.dbace.web.user.json.FRM0400ParamInsert)
	 */
	@Override
	public FRM0400ResultDto getUserById(FRM0400ParamInsert param) throws ApplicationRuntimeException {
		FRM0400ResultDto resultDto = new FRM0400ResultDto();
		this.initializeInsert(param);
		if (frm0400InsertDto.getMessageInfoList() != null && frm0400InsertDto.getMessageInfoList().size() > 0) {
			resultDto.setMessageInfo(frm0400InsertDto.getMessageInfoList().get(0));
			return resultDto;
		}
		UserInformationDto userInformationDto = new UserInformationDto();
		List<UserAuthorityItem> userAuthorityItems = new ArrayList<UserAuthorityItem>();
		UserInfoDTO beforeUserInfoDto = frm0400InsertDto.getBeforeUserInfoDto();
		userInformationDto.setUserId(beforeUserInfoDto.getId());
		userInformationDto.setUserLabel(beforeUserInfoDto.getName());
		userInformationDto.setExistingPassword(frm0400InsertDto.getExistingPassword());
		UserAuthority userAuthority = null;
		List<ConnectDefinisionAuthority> connectDefinisionAuthoritys = null;
		if (beforeUserInfoDto != null) {
			userAuthority = beforeUserInfoDto.getUserAuthority();
		}
		if (userAuthority != null) {
			connectDefinisionAuthoritys = userAuthority.getConnectDefinisionAuthoritys();
			resultDto.setSystemAdministratorAuthority(String.valueOf(userAuthority.isSystemAdministrator()));
		}
		if (connectDefinisionAuthoritys != null) {
			for (ConnectDefinisionAuthority item : connectDefinisionAuthoritys) {
				UserAuthorityItem i = new UserAuthorityItem();
				i.setConnectDefinitionId(item.getConnectDefinisionId());
				List<GeneralUserOperationAuthority> temp = item.getOperationAuthority();
				String strTemp = "";
				if (temp != null && temp.size() > 0) {
					for (GeneralUserOperationAuthority item1 : temp) {
						if (strTemp.length() > 0) {
							strTemp += "," + item1.getId();
						} else {
							strTemp += item1.getId();
						}
					}
				}
				i.setUserOperationAuthority(strTemp.length() > 0 ? strTemp.split(",") : null);
				userAuthorityItems.add(i);
			}
		}
		if (userAuthorityItems.size() > 0) {
			userInformationDto.setUserAuthorityItems(userAuthorityItems);
		}
		resultDto.setUserInformationDto(userInformationDto);
		resultDto.setExtAuth(frm0400InsertDto.getExtAuth());
		return resultDto;
	}

	/*
	 * deleteUser param: searchParam return FRM0400SearchResultDto
	 *
	 * (non-Javadoc)
	 *
	 * @see jp.co.systemexe.dbu.dbace.domain.service.UserInformationService#
	 * deleteUser(jp.co.systemexe.dbu.dbace.web.user.json.FRM0400ParamDelete)
	 */
	@Override
	public FRM0400DeleteDto deleteUser(FRM0400ParamDelete param) {
		FRM0400DeleteDto result = new FRM0400DeleteDto();
		// ADD 外部認証連携 機能追加 ↓
		final UpdateDivision div = param.getUpdateDivision();
		if (UpdateDivision.delete.getKey().equals(div.getKey())) {
			if (!this.isDeleteValidate(param.getSelectedUserId())) {
				result.setMessageInfoList(this.messageInfoList);
				result = this.initializeDelete(param);
				return result;
			}
		}

		// ADD 外部認証連携 機能追加 ↑
		final DeletionOfAppUserLogic logic = new DeletionOfAppUserLogic();
		UserInfo userInfo = param.getUserInfo();
		try {
			logic.remove(param.getSelectedUserId());

			OutputAuditLog.writeUserOperationLog(AuditEventKind.DELETE, userInfo, param.getSelectedUserId(),
					AuditStatus.success, "1");
			return result;
		} catch (final ApplicationDomainLogicException e) {
			result.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
			OutputAuditLog.writeUserOperationLog(AuditEventKind.DELETE, userInfo, param.getSelectedUserId(),
					AuditStatus.failure, "1");
			return result;
		} catch (final Exception e) {
			result.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
			OutputAuditLog.writeUserOperationLog(AuditEventKind.DELETE, userInfo, param.getSelectedUserId(),
					AuditStatus.failure, "1");
			return result;
		}
	}

	/**
	 * @param param
	 * @return
	 */
	public FRM0400DeleteDto initializeDelete(FRM0400ParamDelete param) {
		FRM0400DeleteDto result = new FRM0400DeleteDto();
		try {
			final OperationOfUserInformationLogic logic = new OperationOfUserInformationLogic();
			final UserInfoDTO dto;
			try {
				dto = logic.getUserInfoDTO(param.getSelectedUserId());
			} catch (final ApplicationDomainLogicException e) {
				result.getMessageInfoList().add(new MessageInfo(MessageUtils.getMessage("MI-E-0119"), MessageType.ERROR));
				return result;
			}

			result.setUserLabel(dto.getName());
			result.setSystemAdministratorAuthority(dto.isSystemAdministrator());

			final AcquisitionOfConnectDefinitionListLogic connectDefinitionLogic = new AcquisitionOfConnectDefinitionListLogic();
			final List<IdSelectable> defList = connectDefinitionLogic.getIdSelectableList(param.getUserAuthority());

			result.setUserAuthorityItems(new ArrayList<UserAuthorityItem>());
			for (final IdSelectable def : defList) {
				if (def.getId().equals(CharacterOfSystemFixation.SYSTEM.getCode())) {
					continue;
				}

				ConnectDefinisionAuthority authority = null;
				for (final ConnectDefinisionAuthority auth : dto.getUserAuthority().getConnectDefinisionAuthoritys()) {
					if (auth.getConnectDefinisionId().equals(def.getId())) {
						authority = auth;
						break;
					}
				}

				if (authority == null) {
					continue;
				}

				final UserAuthorityItem item = new UserAuthorityItem();
				item.setConnectDefinitionId(def.getId());
				item.setConnectDefinitionLabel(def.getLabel());

				final StringBuilder build = new StringBuilder();
				for (GeneralUserOperationAuthority auth : GeneralUserOperationAuthority.values()) {
					if (build.length() != 0) {
						build.append("　");
					}

					if (authority.getOperationAuthority() == null || authority.getOperationAuthority().size() == 0) {
						build.append("□");
						build.append(auth.getLabel());
					} else {
						boolean isChecked = false;
						for (final GeneralUserOperationAuthority id : authority.getOperationAuthority()) {
							if (auth == id) {
								isChecked = true;
								break;
							}
						}
						if (isChecked) {
							build.append("■");
							build.append(auth.getLabel());
						} else {
							build.append("□");
							build.append(auth.getLabel());
						}
					}
				}
				item.setUserOperationAuthorityLabel(build.toString());

				result.getUserAuthorityItems().add(item);
			}

			return null;
		} catch (final Exception e) {
			result.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
			return result;
		}
	}

	/**
	 * @param userId
	 * @return
	 */
	private boolean isDeleteValidate(String userId) {
		final OperationOfUserInformationLogic logic = new OperationOfUserInformationLogic();
		final UserInfoDTO dto;
		try {
			dto = logic.getUserInfoDTO(userId);
			if (dto.getId().equals("admin")) {
				// MI-E-0050=ユーザー{0}は削除できません。
				MessageInfo msg = new MessageInfo("MI-E-0050", MessageType.ERROR, messageService);
				this.messageInfoList.add(msg);
				return false;
			}
		} catch (final ApplicationDomainLogicException e) {
			this.messageInfoList.add(new MessageInfo(MessageUtils.getMessage("MI-E-0119"), MessageType.ERROR));
			return false;
		}
		return true;
	}
	/* end delete */

	/* begin insert update */
	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.systemexe.dbu.dbace.domain.service.UserInformationService#
	 * doOnceConfirmation(jp.co.systemexe.dbu.dbace.web.user.json.
	 * FRM0400ParamInsert)
	 */
	@Override
	public FRM0400InsertDto doOnceConfirmation(FRM0400ParamInsert param) {
		try {
			final UpdateDivision div = param.getUpdateDivision();
			if (div == UpdateDivision.insert) {
				if (!isInsertValidate(param)) {
					return frm0400InsertDto;
				}
			} else if (div == UpdateDivision.update) {
				if (!isUpdateValidate(param)) {
					return frm0400InsertDto;
				}
			} else {
				// MI-F-0016=設定されている、更新区分が不正です。({0})。
				final String args[] = { div.toString() };
				MessageInfo msg = new MessageInfo("MI-F-0016", MessageType.ERROR, args, messageService);
				frm0400InsertDto.getMessageInfoList().add(msg);
				/*
				 * final String message = MessageUtils.getMessage("MI-F-0016",
				 * args); throw new WebAppRuntimeException(message);
				 */
			}
			frm0400InsertDto.setUserAuthorityItems(param.getUserAuthorityItems());
			// ユーザー権限の補完
			for (final UserAuthorityItem item : frm0400InsertDto.getUserAuthorityItems()) {
				if (item.getUserOperationAuthority() == null || item.getUserOperationAuthority().length == 0) {
					continue;
				} else {
					final List<String> userOperationAuthorityList = new ArrayList<String>();
					boolean checkedReference = false;
					boolean isAddCheckReference = false;
					/* getLogger().debug("" + item.getConnectDefinitionId()); */
					for (final String id : item.getUserOperationAuthority()) {
						/* getLogger().debug("  " + id); */
						final GeneralUserOperationAuthority auth = GeneralUserOperationAuthority.idOf(id);

						if (auth == GeneralUserOperationAuthority.REFERENCE) {
							checkedReference = true;
						}

						if (auth == GeneralUserOperationAuthority.CUSTOMIZE
								|| auth == GeneralUserOperationAuthority.INSERT
								|| auth == GeneralUserOperationAuthority.UPDATE
								|| auth == GeneralUserOperationAuthority.DELETE
								|| auth == GeneralUserOperationAuthority.DOWNLOAD
								|| auth == GeneralUserOperationAuthority.IMPORT) {
							isAddCheckReference = true;
						}

						userOperationAuthorityList.add(id);
					}

					if (!checkedReference && isAddCheckReference) {
						userOperationAuthorityList.add(GeneralUserOperationAuthority.REFERENCE.getId());
						item.setUserOperationAuthority(userOperationAuthorityList.toArray(new String[0]));
					}
				}
			}

			for (final UserAuthorityItem item : frm0400InsertDto.getUserAuthorityItems()) {
				final StringBuilder build = new StringBuilder();
				for (GeneralUserOperationAuthority auth : GeneralUserOperationAuthority.values()) {
					if (build.length() != 0) {
						build.append("　");
					}

					if (item.getUserOperationAuthority() == null || item.getUserOperationAuthority().length == 0) {
						build.append("□");
						build.append(auth.getLabel());
					} else {
						boolean isChecked = false;
						for (final String id : item.getUserOperationAuthority()) {
							if (auth.getId().equals(id)) {
								isChecked = true;
								break;
							}
						}
						if (isChecked) {
							build.append("■");
							build.append(auth.getLabel());
						} else {
							build.append("□");
							build.append(auth.getLabel());
						}
					}
				}
				item.setUserOperationAuthorityLabel(build.toString());
			}
			this.doOnceSave(param);
			return frm0400InsertDto;
		} catch (final Exception e) {
			frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
			return frm0400InsertDto;
		}
	}

	/**
	 * @param param
	 * @return
	 */
	public FRM0400InsertDto doOnceSave(FRM0400ParamInsert param) {
		try {
			if (param.getUpdateDivision() == UpdateDivision.update) {
				final DeletionOfAppUserLogic logic = new DeletionOfAppUserLogic();
				try {
					logic.remove(param.getSelectedUserId());
				} catch (final ApplicationDomainLogicException e) {
					frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
					return frm0400InsertDto;
				}
			}

			final UserInfoDTO dto = new UserInfoDTO();
			dto.setId(param.getSelectedUserId());
			dto.setName(param.getUserLabel());

			final UserAuthority userAuthority = new UserAuthority();
			/*
			 * userAuthority.setSystemAdministrator(frm0400InsertDto.
			 * isSystemAdministratorAuthority());
			 */
			userAuthority.setSystemAdministrator(param.isSystemAdministratorAuthority());
			userAuthority.setConnectDefinisionAuthoritys(getConnectDefinisionAuthorityList());
			dto.setUserAuthority(userAuthority);

			final PreservationOfAppUserLogic logic = new PreservationOfAppUserLogic();
			try {
				logic.save(dto, frm0400InsertDto.getBeforeUserInfoDto(), param.getPassword(),
						frm0400InsertDto.getExistingPassword(), param.getUpdateDivision(), param.getUserInfo());
			} catch (final ApplicationDomainLogicException e) {
				frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
				return frm0400InsertDto;
			}
			return frm0400InsertDto;
		} catch (final Exception e) {
			frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
			return frm0400InsertDto;
		}
	}

	/**
	 * @param param
	 * @return
	 */
	private boolean isInsertValidate(FRM0400ParamInsert param) {
		final AcquisitionOfUserAuthorityLogic logic = new AcquisitionOfUserAuthorityLogic();
		try {
			if (logic.isUserIDRepetition(param.getSelectedUserId())) {
				// MI-E-0101=入力されたユーザー ID は、既に使用されています。
				MessageInfo msg = new MessageInfo("MI-E-0101", MessageType.ERROR, messageService);
				frm0400InsertDto.getMessageInfoList().add(msg);
				return false;
			}
		} catch (final ApplicationDomainLogicException e) {
			frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
			return false;
		}

		// MOD 外部認証連携 機能追加 ↓
		if (ExtAuthValue.OFF.getValue().equals(frm0400InsertDto.getExtAuth())) {
			if (StringUtils.isBlank(param.getPassword())) {
				// MI-E-0040=パスワードを入力してください。
				MessageInfo msg = new MessageInfo("MI-E-0040", MessageType.ERROR, messageService);
				frm0400InsertDto.getMessageInfoList().add(msg);
				return false;
			} else if (!param.getPassword().equals(param.getPasswordConfirmation())) {
				// MI-E-0036=パスワードとパスワード(確認用)が一致しません。
				MessageInfo msg = new MessageInfo("MI-E-0036", MessageType.ERROR, messageService);
				frm0400InsertDto.getMessageInfoList().add(msg);
				return false;
			}
			try {
				frm0400InsertDto.setDummyPassword(param.getPassword().replaceAll(".", "*"));
				param.setPassword(logic.passwordEncryption(param.getPassword()));
				return true;
			} catch (ApplicationDomainLogicException e) {
				frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
				return false;
			}
		}
		return true;
		// MOD 外部認証連携 機能追加 ↑
	}

	/**
	 * @param param
	 * @return
	 */
	private boolean isUpdateValidate(FRM0400ParamInsert param) {
		if (ExtAuthValue.OFF.getValue().equals(frm0400InsertDto.getExtAuth())
				|| StringUtils.isBlank(frm0400InsertDto.getExtAuth())) {
			final String currentPassword = (param.getPassword() == null ? StringUtils.EMPTY : param.getPassword());
			final String confirmPassword = (param.getPasswordConfirmation() == null ? StringUtils.EMPTY
					: param.getPasswordConfirmation());
			if (StringUtils.EMPTY.equals(currentPassword) || StringUtils.EMPTY.equals(confirmPassword)) {
				// ADD 外部認証連携 機能追加 ↓
				final AcquisitionOfUserAuthorityLogic userLogic = new AcquisitionOfUserAuthorityLogic();
				String noPwdXml = StringUtils.EMPTY;
				try {
					noPwdXml = userLogic.passwordEncryption(StringUtils.EMPTY);
				} catch (ApplicationException e) {
					messageInfoList.add(new MessageInfo(e, MessageType.ERROR));
					return false;
				}
				// 外部認証OFF時、かつ、該当ユーザーのパスワードがリポジトリXMLで0バイト「""」の場合
				// 「パスワード、パスワード(確認用)」の入力チェックをして
				if (frm0400InsertDto.getExistingPassword()!= null && frm0400InsertDto.getExistingPassword().equals(noPwdXml)) {
					if (StringUtils.isBlank(param.getPassword())) {
						// MI-E-0040=パスワードを入力してください。
						frm0400InsertDto.getMessageInfoList()
								.add(new MessageInfo("MI-E-0040", MessageType.ERROR, messageService));
						return false;
					} else if (!param.getPassword().equals(param.getPasswordConfirmation())) {
						// MI-E-0036=パスワードとパスワード(確認用)が一致しません。
						frm0400InsertDto.getMessageInfoList()
								.add(new MessageInfo("MI-E-0036", MessageType.ERROR, messageService));
						return false;
					}
				} else if (!currentPassword.equals(confirmPassword)) {
					// MI-E-0036=パスワードとパスワード(確認用)が一致しません。
					frm0400InsertDto.getMessageInfoList()
							.add(new MessageInfo("MI-E-0036", MessageType.ERROR, messageService));
					return false;
				} else {
					param.setPassword(frm0400InsertDto.getExistingPassword());
				}
				// ADD 外部認証連携 機能追加 ↑
				final OperationOfUserInformationLogic logic = new OperationOfUserInformationLogic();
				try {
					frm0400InsertDto.setDummyPassword(
							logic.getApplicationPassword(param.getSelectedUserId()).replaceAll(".", "*"));
					return true;
				} catch (ApplicationException e) {
					frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
					return false;
				}
			} else {
				if (!currentPassword.equals(confirmPassword)) {
					// MI-E-0036=パスワードとパスワード(確認用)が一致しません。
					frm0400InsertDto.getMessageInfoList()
							.add(new MessageInfo("MI-E-0036", MessageType.ERROR, messageService));
					return false;
				}
				/* setDummyPassword(this.password.replaceAll(".", "*")); */
				final AcquisitionOfUserAuthorityLogic userLogic = new AcquisitionOfUserAuthorityLogic();
				try {
					param.setPassword(userLogic.passwordEncryption(param.getPassword()));
					return true;
				} catch (ApplicationException e) {
					frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
					return false;
				}
			}
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.systemexe.dbu.dbace.domain.service.UserInformationService#
	 * initializeInsert(jp.co.systemexe.dbu.dbace.web.user.json.
	 * FRM0400ParamInsert)
	 */
	@Override
	public FRM0400InsertDto initializeInsert(FRM0400ParamInsert param) {
		frm0400InsertDto = new FRM0400InsertDto();
		// ADD 外部認証連携 機能追加 ↓
		// 外部認証情報を取得 system.properties の ext-auth
		final AcquisitionOfEnvironmentSetting logi = new AcquisitionOfEnvironmentSetting();
		final EnvironmentSettingDTO dto = logi.getAllProperties();
		// ADD 外部認証連携 機能追加 ↑
		try {
			/*
			 * if (getPreviousViewId().indexOf("userEditorConfirmation") != -1)
			 * { return null; }
			 */

			final List<SelectManyCheckboxItem> opeList = new ArrayList<SelectManyCheckboxItem>();
			for (final GeneralUserOperationAuthority ope : GeneralUserOperationAuthority.getValuesList()) {
				final SelectManyCheckboxItem checkboxItem = new OperationAuthoritysItem();
				checkboxItem.setValue(ope.getId());
				checkboxItem.setLabel(ope.getLabel());
				opeList.add(checkboxItem);
			}

			final AcquisitionOfConnectDefinitionListLogic connectDefinitionLogic = new AcquisitionOfConnectDefinitionListLogic();
			final List<IdSelectable> defList = connectDefinitionLogic.getIdSelectableList(param.getUserAuthority());

			// 更新時
			if (param.getUpdateDivision() == UpdateDivision.update) {
				final OperationOfUserInformationLogic logic = new OperationOfUserInformationLogic();
				try {
					final AcquisitionOfUserAuthorityLogic userLogic = new AcquisitionOfUserAuthorityLogic();
					frm0400InsertDto.setExistingPassword(
							userLogic.passwordEncryption(logic.getApplicationPassword(param.getSelectedUserId())));

					final UserInfoDTO userInfo = logic.getUserInfoDTO(param.getSelectedUserId());
					// ADD 外部認証連携 機能追加 ↓
					if (userInfo.getId().equals("admin")) {
						frm0400InsertDto.setExtAuth("");
					} else {
						frm0400InsertDto.setExtAuth(dto.getExtAuth());
					}
					// ADD 外部認証連携 機能追加 ↑
					frm0400InsertDto.setUserLabel(userInfo.getName());
					frm0400InsertDto.setSystemAdministratorAuthority(userInfo.isSystemAdministrator());

					List<UserAuthorityItem> userAuthorityItems = new ArrayList<UserAuthorityItem>();
					for (final IdSelectable def : defList) {
						if (def.getId().equals(CharacterOfSystemFixation.SYSTEM.getCode())) {
							continue;
						}
						final UserAuthorityItem item = new UserAuthorityItem();
						item.setConnectDefinitionId(def.getId());
						item.setConnectDefinitionLabel(def.getLabel());
						item.setUserOperationAuthorityItems(opeList);

						for (final ConnectDefinisionAuthority defAuth : userInfo.getUserAuthority()
								.getConnectDefinisionAuthoritys()) {
							if (def.getId().equals(defAuth.getConnectDefinisionId())) {
								final List<String> list = new ArrayList<String>();
								for (final GeneralUserOperationAuthority ope : defAuth.getOperationAuthority()) {
									list.add(ope.getId());
								}
								item.setUserOperationAuthority(list.toArray(new String[0]));
								break;
							}
						}

						userAuthorityItems.add(item);
					}
					frm0400InsertDto.setUserAuthorityItems(userAuthorityItems);

					UserInfoDTO beforeUserInfoDto = new UserInfoDTO();
					beforeUserInfoDto.setApplicationAdministrator(userInfo.isApplicationAdministrator());
					beforeUserInfoDto.setId(userInfo.getId());
					beforeUserInfoDto.setName(userInfo.getName());
					beforeUserInfoDto.setUserAuthority(userInfo.getUserAuthority());
					frm0400InsertDto.setBeforeUserInfoDto(beforeUserInfoDto);

				} catch (ApplicationDomainLogicException e) {
					frm0400InsertDto.getMessageInfoList().add(new MessageInfo(MessageUtils.getMessage("MI-E-0119"), MessageType.ERROR));
					return frm0400InsertDto;
				}

				// 登録時
			} else if (param.getUpdateDivision() == UpdateDivision.insert) {
				// ADD 外部認証連携 機能追加 ↓
				frm0400InsertDto.setExtAuth(dto.getExtAuth());
				// ADD 外部認証連携 機能追加 ↑
				List<UserAuthorityItem> userAuthorityItems = new ArrayList<UserAuthorityItem>();
				for (final IdSelectable def : defList) {
					if (def.getId().equals(CharacterOfSystemFixation.SYSTEM.getCode())) {
						continue;
					}
					final UserAuthorityItem item = new UserAuthorityItem();
					item.setConnectDefinitionId(def.getId());
					item.setConnectDefinitionLabel(def.getLabel());
					item.setUserOperationAuthorityItems(opeList);
					userAuthorityItems.add(item);
				}
				frm0400InsertDto.setUserAuthorityItems(userAuthorityItems);
			}
			return frm0400InsertDto;
		} catch (ApplicationDomainLogicException e) {
			frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
			return null;
		} catch (final Exception e) {
			frm0400InsertDto.getMessageInfoList().add(new MessageInfo(e, MessageType.ERROR));
			return null;
		}
	}
	/* end insert update */

	/**
	 * @return
	 */
	private List<ConnectDefinisionAuthority> getConnectDefinisionAuthorityList() {
		if (frm0400InsertDto.isSystemAdministratorAuthority()) {
			return new ArrayList<ConnectDefinisionAuthority>();
		}

		final List<ConnectDefinisionAuthority> connectDefinisionAuthorityList = new ArrayList<ConnectDefinisionAuthority>();
		for (final UserAuthorityItem authItem : frm0400InsertDto.getUserAuthorityItems()) {
			final ConnectDefinisionAuthority connectDefinisionAuthority = new ConnectDefinisionAuthority();
			connectDefinisionAuthority.setConnectDefinisionId(authItem.getConnectDefinitionId());

			final List<GeneralUserOperationAuthority> authList = new ArrayList<GeneralUserOperationAuthority>();
			if (authItem.getUserOperationAuthority() != null) {
				for (final String auth : authItem.getUserOperationAuthority()) {
					authList.add(GeneralUserOperationAuthority.idOf(auth));
				}
			}
			connectDefinisionAuthority.setOperationAuthority(authList);

			connectDefinisionAuthorityList.add(connectDefinisionAuthority);
		}
		return connectDefinisionAuthorityList;
	}

	@Override
	public FRM0600ResultDto doSaveEditProfile(FRM0600Param search) throws ApplicationDomainLogicException {
		FRM0600ResultDto resultModel = new FRM0600ResultDto();
		resultModel.setStatus(true);
		MessageInfo error = new MessageInfo();
		final OperationOfUserInformationLogic logic = new OperationOfUserInformationLogic();
		final AcquisitionOfUserAuthorityLogic logicOfUserAuthorityLogic = new AcquisitionOfUserAuthorityLogic();
		final PreservationOfAppUserLogic logicOfAppUserLogic = new PreservationOfAppUserLogic();
//		MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication()
//				.getPrincipal();
		UserInfoDTO dto;
		dto = logic.getUserInfoDTO(search.getUserID());
		UserInfo userInfo = search.getUserInfo();
		final String existingPassword = logic.getApplicationPassword(dto.getId());
		if (StringUtils.isEmpty(search.getUsername()) || StringUtils.isBlank(search.getUsername())) {
			// MI-F-0024=値を入力してください
			resultModel.setStatus(false);
			error = new MessageInfo("FRM0600.S1-002", MessageType.ERROR, /*"frm0600.profile.username", */messageService);
			resultModel.getMessageInfo().add(error);
			error.setId("frm0600.profile.username");
			return resultModel;
		} else {
			if ((StringUtils.isEmpty(search.getOldPassword()) || StringUtils.isBlank(search.getOldPassword()))
					&& (StringUtils.isEmpty(search.getNewPassword()) || StringUtils.isBlank(search.getNewPassword()))
					&& (StringUtils.isEmpty(search.getPasswordConfirmation())
							|| StringUtils.isBlank(search.getPasswordConfirmation()))) {
				try {
					final String passwordEncrypiton = logicOfUserAuthorityLogic.passwordEncryption(existingPassword);
					logicOfAppUserLogic.saveUsernamePassword(dto, search.getUsername(), passwordEncrypiton);
					// update username in principal
//					myUserDetails.setUserName(search.getUsername());
					error = new MessageInfo("FRM0600.S1-001", MessageType.SUCCESS, /*search.getUsername()*/messageService);
					resultModel.getMessageInfo().add(error);
					resultModel.setUsername(search.getUsername());
					OutputAuditLog.writeUserOperationLog(AuditEventKind.CHANGE_USERNAME, userInfo, userInfo.getId(),
							AuditStatus.success, "1");

				} catch (final ApplicationDomainLogicException e) {
					error = new MessageInfo(e.getLocalizedMessage(), MessageType.ERROR, messageService);
					resultModel.getMessageInfo().add(error);
					OutputAuditLog.writeUserOperationLog(AuditEventKind.CHANGE_USERNAME, userInfo, userInfo.getId(),
							AuditStatus.failure, "1");
				}
			} else {
				if (!StringUtils.isEmpty(search.getOldPassword()) || !StringUtils.isBlank(search.getOldPassword())) {
					//旧パスワードが入力されているか？
					//はい
					if (!StringUtils.isEmpty(existingPassword) || !StringUtils.isBlank(existingPassword)) {
						//旧パスワードが正しいか？
						//いいえ
						if (!existingPassword.equals(search.getOldPassword())) {
							// MI-E-0068=旧パスワードが一致しません
							resultModel.setStatus(false);
							error = new MessageInfo("MI-E-0068", MessageType.ERROR, messageService);
							resultModel.getMessageInfo().add(error);
							error.setId("frm0600.profile.oldPassword");
						}
					}
				}
				else
				{
					//いいえ
					// MI-F-0025=値を入力してください
					resultModel.setStatus(false);
					error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0600.profile.oldPassword", messageService);
					resultModel.getMessageInfo().add(error);
					error.setId("frm0600.profile.oldPassword");
				}

				//新パスワードが入力されているか？
				if (StringUtils.isEmpty(search.getNewPassword())
						|| StringUtils.isBlank(search.getNewPassword())) {
					//旧パスワード、または、新パスワード(確認)が入力されているか？
					// MI-F-0025=値を入力してください
					resultModel.setStatus(false);
					error = new MessageInfo("MI-F-0025", MessageType.ERROR, "frm0600.profile.newPassword",
							messageService);
					resultModel.getMessageInfo().add(error);
					error.setId("frm0600.profile.newPassword");
				}
				//新パスワード(確認)が入力されているか？
				if (StringUtils.isEmpty(search.getPasswordConfirmation())
						|| StringUtils.isBlank(search.getPasswordConfirmation())) {
					//旧パスワード、または、新パスワードが入力されているか？
					// MI-F-0025=値を入力してください
					resultModel.setStatus(false);
					error = new MessageInfo("MI-F-0025", MessageType.ERROR,
							"frm0600.profile.confirmPassword", messageService);
					resultModel.getMessageInfo().add(error);
					error.setId("frm0600.profile.confirmPassword");
				}
				//新パスワードと新パスワード(確認)の値が一致しているか？
				if (!StringUtils.isEmpty(search.getNewPassword()) && !StringUtils.isEmpty(search.getPasswordConfirmation()))
				{
					if (!search.getNewPassword().equals(search.getPasswordConfirmation())) {
						// MI-E-0036=パスワードとパスワード(確認用)が一致しません。
						resultModel.setStatus(false);
						error = new MessageInfo("MI-E-0036", MessageType.ERROR, messageService);
						resultModel.getMessageInfo().add(error);
						error.setId("frm0600.profile.password");
					}
				}

				if (resultModel.isStatus() == true) {
					try {
						String passwordEncrypiton = logicOfUserAuthorityLogic
								.passwordEncryption(search.getNewPassword());
						logicOfAppUserLogic.saveUsernamePassword(dto, search.getUsername(), passwordEncrypiton);
						// update username in principal
//						myUserDetails.setUserName(search.getUsername());
						error = new MessageInfo("FRM0600.S1-001", MessageType.SUCCESS, search.getUsername(),
								messageService);
						resultModel.setUsername(search.getUsername());
						resultModel.getMessageInfo().add(error);
						OutputAuditLog.writeUserOperationLog(AuditEventKind.CHANGE_USERNAME_PASSWORD, userInfo,
								userInfo.getId(), AuditStatus.success, "1");
					} catch (ApplicationDomainLogicException e) {
						error = new MessageInfo(e.getLocalizedMessage(), MessageType.ERROR, messageService);
						resultModel.getMessageInfo().add(error);
						OutputAuditLog.writeUserOperationLog(AuditEventKind.CHANGE_USERNAME_PASSWORD, userInfo,
								userInfo.getId(), AuditStatus.failure, "1");
					}
				}

			}
			return resultModel;
		}
	}

	@Override
	public String getExtAuth() {
		final AcquisitionOfEnvironmentSetting logi = new AcquisitionOfEnvironmentSetting();
		final EnvironmentSettingDTO dto = logi.getAllProperties();
		return dto.getExtAuth();
	}
}
