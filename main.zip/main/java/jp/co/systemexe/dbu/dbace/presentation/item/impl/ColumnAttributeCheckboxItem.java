/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation.item.impl;

import java.util.ArrayList;
import java.util.List;

import jp.co.systemexe.dbu.dbace.presentation.item.SelectManyCheckboxItem;

/**
 * 編集対象レコードのカラム属性がチェックボックスの場合の表示用アイテム。
 * <p>
 * </p>
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class ColumnAttributeCheckboxItem implements SelectManyCheckboxItem {

    /**
     * 編集対象レコードのカラム属性がプルダウンリスト名称。
     * <p>ユーザーが定義する接続定義に付けた表示用名称です。</p>
     */
    private String label;
    /**
     * 編集対象レコードのカラム属性がプルダウンリスト ID。
     * <p>システム内部で扱われる ID です。</p>
     */
    private String value;

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneCheckboxItem#getLabel()
     */
    public String getLabel() {
        return this.label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneCheckboxItem#getValue()
     */
    public String getValue() {
        return this.value;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneCheckboxItem#setLabel()
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /* (非 Javadoc)
     * @see jp.co.systemexe.dbu.dbace.presentation.item.SelectOneCheckboxItem#setValue()
     */
    public void setValue(String value) {
        this.value = value;
    }
    
    public List<SelectManyCheckboxItem> crateItem() {
        List<SelectManyCheckboxItem> items = new ArrayList<SelectManyCheckboxItem>();
        final ColumnAttributeCheckboxItem item = new ColumnAttributeCheckboxItem();
        
        item.setLabel("チェックボックスラベル");
        item.setValue("true");
        
        items.add(item);
        
        return items;
    }

}
