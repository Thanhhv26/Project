/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.creation.dto;

import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.web.creation.dto.OptionalDto.Delete.First;
import jp.co.systemexe.dbu.dbace.web.creation.dto.OptionalDto.Delete.Second;
import jp.co.systemexe.dbu.dbace.web.creation.dto.OptionalDto.Delete.Third;
import lombok.Data;

/**
 * @author van-thanh
 *
 */

@Data
public class OptionalDto {
	protected OptionalDto.Reference reference;
	protected OptionalDto.Insert insert;
	protected OptionalDto.Update update;
	protected OptionalDto.Copy copy;
	protected OptionalDto.Delete delete;
	protected OptionalDto.Upload upload;
	protected OptionalDto.Download download;

	public OptionalDto() {

	}

	public OptionalDto(TableForm.Optional optional) {
		if (optional != null) {
			if (optional.getReference() != null) {
				this.setReference(new OptionalDto.Reference(optional.getReference().isEnable()));
			}
			if (optional.getInsert() != null) {
				this.setInsert(new OptionalDto.Insert(optional.getInsert().isEnable()));
			}
			if (optional.getUpdate() != null) {
				this.setUpdate(new OptionalDto.Update(optional.getUpdate().isEnable()));
			}
			if (optional.getCopy() != null) {
				this.setCopy(new OptionalDto.Copy(optional.getCopy().isEnable()));
			}
			if (optional.getDelete() != null) {
				OptionalDto.Delete deleteTemp = new OptionalDto.Delete();
				deleteTemp.setEnable(optional.getDelete().isEnable());

				if (optional.getDelete().getFirst() != null) {
					boolean enable = optional.getDelete().getFirst().isEnable();
					String label = optional.getDelete().getFirst().getLabel();
					deleteTemp.setFirst(new First(enable, label));
				}

				if (optional.getDelete().getSecond() != null) {
					boolean enable = optional.getDelete().getSecond().isEnable();
					String label = optional.getDelete().getSecond().getLabel();
					deleteTemp.setSecond(new Second(enable, label));
				}

				if (optional.getDelete().getThird() != null) {
					boolean enable = optional.getDelete().getThird().isEnable();
					String label = optional.getDelete().getThird().getLabel();
					deleteTemp.setThird(new Third(enable, label));
				}

				this.setDelete(deleteTemp);
			}

			if (optional.getUpload() != null) {
				this.setUpload(new OptionalDto.Upload(optional.getUpload().isEnable()));
			}

			if (optional.getDownload() != null) {
				this.setDownload(new OptionalDto.Download(optional.getDownload().isEnable()));
			}
		}
	}



	/* public static class Reference */
	@Data
	public static class Reference {
		private boolean enable;

		public Reference() {

		}

		public Reference(boolean enable) {
			this.setEnable(enable);
		}
	}

	/* public static class Insert */
	@Data
	public static class Insert {
		private boolean enable;

		public Insert() {

		}

		public Insert(boolean enable) {
			this.setEnable(enable);
		}
	}

	/* public static class Update */
	@Data
	public static class Update {
		private boolean enable;

		public Update() {

		}

		public Update(boolean enable) {
			this.setEnable(enable);
		}
	}

	/* public static class Copy */
	@Data
	public static class Copy {
		private boolean enable;

		public Copy() {

		}

		public Copy(boolean enable) {
			this.setEnable(enable);
		}
	}

	/* public static class Delete */
	@Data
	public static class Delete {
		private boolean enable;
		private Delete.First first;
		private Delete.Second second;
		private Delete.Third third;

		/* public static class First */
		@Data
		public static class First {
			private boolean enable;
			private String label;

			public First() {

			}

			public First(boolean enable, String label) {
				this.setEnable(enable);
				this.setLabel(label);
			}
		}

		/* public static class Second */
		@Data
		public static class Second {
			private boolean enable;
			private String label;

			public Second() {

			}

			public Second(boolean enable, String label) {
				this.setEnable(enable);
				this.setLabel(label);
			}
		}

		/* public static class Third */
		@Data
		public static class Third {
			private boolean enable;
			private String label;

			public Third() {

			}

			public Third(boolean enable, String label) {
				this.setEnable(enable);
				this.setLabel(label);
			}
		}
	}

	/* public static class Upload */
	@Data
	public static class Upload {
		private boolean enable;

		public Upload() {

		}

		public Upload(boolean enable) {
			this.setEnable(enable);
		}
	}

	/* public static class Download */
	@Data
	public static class Download {
		private boolean enable;

		public Download() {

		}

		public Download(boolean enable) {
			this.setEnable(enable);
		}
	}
}
