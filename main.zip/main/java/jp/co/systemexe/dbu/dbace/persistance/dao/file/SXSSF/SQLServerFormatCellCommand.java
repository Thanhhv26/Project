package jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;

import jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination;

/**
 * @author van-thanh
 *
 */
@SuppressWarnings("serial")
public class SQLServerFormatCellCommand extends BaseFormatCell {
	
	private static Map<String, List<String>> dataTypesMap;
	static {
		dataTypesMap = new HashMap<String, List<String>>();
		dataTypesMap.put(FormatCellConstant.CHARACTER, new ArrayList<String>(){{
			add("varchar".toLowerCase());
			add("decimal".toLowerCase());			
			add("money".toLowerCase());
			add("datetime".toLowerCase());
			add("smalldatetime".toLowerCase());
			add("char".toLowerCase());
			add("text".toLowerCase());
			add("numeric".toLowerCase());
			add("real".toLowerCase());
			add("smallmoney".toLowerCase());
			add("datetime2".toLowerCase());
			add("nchar".toLowerCase());
			add("nvarchar".toLowerCase());
		}});
		dataTypesMap.put(FormatCellConstant.NUMERIC, new ArrayList<String>(){{
			
		}});
		dataTypesMap.put(FormatCellConstant.DATE, new ArrayList<String>(){{
			
		}});
		dataTypesMap.put(FormatCellConstant.DATE_TIME, new ArrayList<String>(){{
			
		}});
	}
	
	/**
	 * 
	 */
	public SQLServerFormatCellCommand(){
		
	}
	
	/**
	 * @param workbook
	 * @param type
	 */
	public SQLServerFormatCellCommand(
			final SXSSFWorkbookCus workbook,
			final DatabaseTypeConnectionDestination type){
		this.workbook = workbook;
		this.type = type;
	}	

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.BaseFormatCell#createFormatCellCharacter()
	 */
	@Override
	public CellStyle createFormatCellCharacter(){
		final CellStyle cellStyle = this.workbook.createCellStyle();
		final CreationHelper creationHelper = this.workbook.getCreationHelper();
		final Short format = creationHelper.createDataFormat().getFormat("@");
		cellStyle.setDataFormat(format);
		return cellStyle;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.BaseFormatCell#createCellStyleNumeric()
	 */
	@Override
	public CellStyle createCellStyleNumeric() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.BaseFormatCell#createCellStyleDate()
	 */
	@Override
	public CellStyle createCellStyleDate() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.BaseFormatCell#createCellStyleDateTime()
	 */
	@Override
	public CellStyle createCellStyleDateTime() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.BaseFormatCell#checkDatabaseType()
	 */
	@Override
	public boolean checkDatabaseType() {
		return (DatabaseTypeConnectionDestination.SqlServer == type);
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.BaseFormatCell#getMapFormatCell()
	 */
	@Override
	public Map<String, CellStyle> getMapFormatCell() {
		Map<String, CellStyle> map;
		map = new HashMap<String, CellStyle>();
		map.put(FormatCellConstant.CHARACTER, this.createFormatCellCharacter());
		map.put(FormatCellConstant.NUMERIC, this.createCellStyleNumeric());
		map.put(FormatCellConstant.DATE, this.createCellStyleDate());
		map.put(FormatCellConstant.DATE_TIME, this.createCellStyleDateTime());
		return map;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.BaseFormatCell#init(jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.SXSSFWorkbookCus, jp.co.systemexe.dbu.dbace.presentation.DatabaseTypeConnectionDestination)
	 */
	@Override
	public void init(
			final SXSSFWorkbookCus workbook, 
			final DatabaseTypeConnectionDestination type) {
		// TODO Auto-generated method stub
		this.workbook = workbook;
		this.type = type;
	}

	/* (non-Javadoc)
	 * @see jp.co.systemexe.dbu.dbace.persistance.dao.file.SXSSF.BaseFormatCell#getTypeFormatsCellByDataType(java.lang.String)
	 */
	@Override
	public String getTypeFormatsCellByDataType(final String dataType) {
		for(Map.Entry<String, List<String>> item : dataTypesMap.entrySet()){
			if(item.getValue().indexOf(dataType.toLowerCase()) != -1){
				return item.getKey();
			}
		}
		return null;
	}

}
