/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.dto.TableLabeDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.TableLabeExtendConnectDTO;
import jp.co.systemexe.dbu.dbace.domain.dto.UserInfoDTO;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.domain.logic.PreservationOfAppRelationLogic;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.ApplicationRelationDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.authority.ConnectDefinisionAuthority;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.DefinedHtmlElement;
import jp.co.systemexe.dbu.dbace.persistance.xml.constant.ItemRestriction;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item.Restrictions.Restriction;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item.SelectableList;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Item.SelectableList.Li;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Repository.ConnectDefinision;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm.Relations;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm.Sort.Row;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForms;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.Tables;
import jp.co.systemexe.dbu.dbace.presentation.item.SelectOneMenuItem;
import jp.co.systemexe.dbu.dbace.presentation.item.impl.SelectableItem;
import jp.co.systemexe.dbu.dbace.web.common.AppConst;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.ColsDto.ColDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto.OperationDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.OptionalDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TablesDto;

/**
 * テーブルフォーム DAO。
 * <p>
 * リポジトリ内の、各テーブルに対応した画面設定（テーブルフォーム）情報への
 * DAO です。</p>
 *
 * @author  EXE 島田 雄一郎
 * @author  EXE 鈴木 伸祐
 * @author  EXE 相田 一英
 * @author van-thanh
 * @version 0.0.0
 */

public class TableFormDAOImpl extends BaseRepositoryXmlDAO implements TableFormDAO {

	/**
     * テーブルフォーム情報の登録があるか否かを戻します。
     * <p>
     * テーブルフォーム情報が一件以上登録されていれば true を、一件も無ければ
     * false を戻します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @return true : 登録あり / false : 登録なし
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO#hasTableForms()
     */
    public boolean hasTableForms(final String connectDefinitionId)
            throws DAOException {
        final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final TableForms forms = def.getTableForms();
        if (forms == null) {
            return false;
        }
        final List<TableForm> list = forms.getTableForm();
        if (list == null || list.size() <= 0) {
            return false;
        }
        final TableForm form = list.get(0);
        if (form == null || form.getId() == null || form.getId().equals("")) {
            return false;
        }
        return true;
    }

    /**
     * テーブルフォーム情報の登録があるか否かを戻します。
     * <p>
     * テーブルフォーム情報が一件以上登録されていれば true を、一件も無ければ
     * false を戻します。</p>
     *
     * @param connectDefinitionId 接続定義名
     * @return true : 登録あり / false : 登録なし
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO#hasTableForms()
     */
    public boolean hasTableFormsByConnectName(final String connectDefinitionId)
            throws DAOException {
        final ConnectDefinision def = searchConnectDefinisionName(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final TableForms forms = def.getTableForms();
        if (forms == null) {
            return false;
        }
        final List<TableForm> list = forms.getTableForm();
        if (list == null || list.size() <= 0) {
            return false;
        }
        final TableForm form = list.get(0);
        if (form == null || form.getId() == null || form.getId().equals("")) {
            return false;
        }
        return true;
    }

    public TableItemDTO getTableItemDTO(final String connectDefinitionId,
            final String tableFormId, final String tableItemId) throws DAOException {
    	TableFormDTO tableFormDTO = getTableFormDTO(connectDefinitionId, tableFormId);
    	if(tableFormDTO != null){
    		for (Iterator<TableItemDTO> iterator = tableFormDTO.getTableItemMap().values().iterator(); iterator.hasNext();) {
				TableItemDTO tableItemDTO = (TableItemDTO) iterator.next();
				if( tableItemDTO.getTableId().equals(tableFormId) && tableItemDTO.getItemId().equals(tableItemId)){
					return tableItemDTO;
				}
			}
    	}
        return null;
    }

    /**
     * テーブルフォーム DTO を戻す。
     * <p>
     * リポジトリから、各テーブルに対応した、画面上での制御情報を保持した
     * テーブルフォーム DTO を取得して戻します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブルフォーム ID
     * @return TableFormDTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO#getTableFormDTO(java.lang.String, java.lang.String)
     */
    public TableFormDTO getTableFormDTO(final String connectDefinitionId,
            final String tableFormId) throws DAOException {
        final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }

        for (final TableForm table : def.getTableForms().getTableForm()) {
            if (table.getId().equals(tableFormId)) {
                final TableFormDTO ret = new TableFormDTO();
                ret.setTableFormId(table.getId());
                ret.setTableFormLabel(table.getLabel());
                ret.setOrderDesc((null != table.isOrderdesc() ? table.isOrderdesc() : false));

                if(table.getType() != null && AppConst.MULTI_TABLE.equals(table.getType())){
                	ret.setType(table.getType());
                	ret.setDescription(table.getDiscription());
                	ret.setEnable(table.getEnable());

                	TablesDto tablesDto = new TablesDto(table.getTables());
                    for (Iterator<TableDto> iterator = tablesDto.getTableDtoList().iterator(); iterator.hasNext();) {
    					TableDto tableDto = (TableDto) iterator.next();
    					ret.getTableMap().put(tableDto.getId(), tableDto);
                    }

                	// Get relation
                	if(table.getRelations() != null && table.getRelations().getRelation() != null){
	                	for (final Iterator<Relations.Relation> resIte = table
	                            .getRelations().getRelation().iterator(); resIte
	                            .hasNext();) {
	                            final Relations.Relation res = resIte.next();
	                            ApplicationRelationDTO relation = getRelationInfoById(res.getId());
	                            if(relation != null){
	                            	ret.getRelationMap().put(res.getId(), relation);
	                            }
	                    }
                	}

                	// Get optional
                	if(table.getOptional() != null){
                		OptionalDto optionalDto = new OptionalDto(table.getOptional());
                		ret.setOptional(optionalDto);
                	}
                }


                for (final Iterator<Row> rowIte = table.getSort().getRow()
                    .iterator(); rowIte.hasNext();) {
                    final Row row = rowIte.next();
                    ret.getSortConditionMap().put(Integer.valueOf(row.getId()),
                        row.getValue());
                }
                for (final Iterator<Item> itemIte = table.getItem().iterator(); itemIte
                    .hasNext();) {
                    final Item item = itemIte.next();
                    final TableItemDTO buff = new TableItemDTO();
                    buff.setTableId(tableFormId);
                    buff.setItemId(item.getId());
                    buff.setItemLabel(item.getLabel());
                    buff.setSortIndex(item.getSortIndex());
                    buff.setDefaultValue(item.getDefault());
                    buff.setEditing("true".equals(item.getCanEditing()));
                    buff.setExplanation(item.getExplanation());
                    buff.setHtmlElement(DefinedHtmlElement.keyOf(item
                        .getHtmlElement()));
                    if (item.getSelectableSql() != null) {
                        buff.setSqlString(item.getSelectableSql());
                    }
                    if (item.getSelectableList() != null) {
                        final List<SelectOneMenuItem> selectItems = new ArrayList<SelectOneMenuItem>();
                        for (final Iterator<Li> liIte
                                = item.getSelectableList().getLi().iterator(); liIte.hasNext();) {
                            final Li li = liIte.next();
                            final SelectOneMenuItem selectItem = new SelectableItem();
                            selectItem.setValue(li.getId());
                            selectItem.setLabel(li.getLabel());
                            selectItems.add(selectItem);
                        }
                        buff.setSelectableItems(selectItems.toArray(new SelectableItem[0]));
                    }
                    buff.setPreview(null != item.getCanPreview() ? item.getCanPreview().equals("true") : true);
                    buff.setDisplayRecordEdit(null != item.getCanDisplayRecordEdit() ? item.getCanDisplayRecordEdit().equals("true") : true);
                    buff.setDisplayNamePreview(null != item.getCanDisplayNamePreview() ? item.getCanDisplayNamePreview().equals("true") : false);
                    buff.setSelectKey(null != item.getIsSelectKey() ? item.getIsSelectKey().equals("true") : true);
                    buff.setUpdateKey(null != item.getIsUpdateKey() ? item.getIsUpdateKey().equals("true") : true);

                    buff.setPrimaryKey(null != item.getPrimaryKey() ? item.getPrimaryKey().equals("true") : true);
                    buff.setUnique(null!=item.getUnique()?item.getUnique().equals("true"):true);
                    buff.setForeignKey(null != item.getForeignKey()?item.getForeignKey().equals("true"):true);
                    buff.setDataType(item.getDataType());
                    buff.setDataLength(item.getDataLength());
                    buff.setDataUnit(item.getDataUnit());
                    buff.setParametersSql(item.getParametersSql());

                    for (final Iterator<Restriction> resIte = item
                        .getRestrictions().getRestriction().iterator(); resIte
                        .hasNext();) {
                        final Restriction res = resIte.next();
                        buff.getItemRestrictions().put(
                            ItemRestriction.idOf(res.getId()),
                            res.getValue().equals("true"));
                    }

                    buff.setRelatedSelectItems(
                        isRelatedSelectItems(
                            item.getLabel(),
                            table.getItem()));


                    if (table.getType() != null && AppConst.MULTI_TABLE.equals(table.getType()) && item.getCols() != null) {
                    	// Get columns
						for (final Iterator<Item.Cols.Col> itemCol = item.getCols().getCol().iterator(); itemCol
								.hasNext();) {
							final Item.Cols.Col xmlCol = itemCol.next();
							ColDto col = new ColDto();
							col.setListNO(xmlCol.getListNO());
							col.setTableID(xmlCol.getTableID());
							col.setItemID(xmlCol.getItemID());
							buff.getCols().put(col.getListNO(), col);
						}

						buff.setOperations(new OperationDto(item.getOperation()));
					}
                    ret.getTableItemMap().put(buff.getItemId(), buff);

                }
                return ret;
            }
        }
        return null;
    }

    private ApplicationRelationDTO getRelationInfoById(String relationId) {
		final PreservationOfAppRelationLogic logic = new PreservationOfAppRelationLogic();
		try {
			return logic.getApplicationRelationDTO(relationId);
		} catch (final ApplicationDomainLogicException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
     * テーブルフォーム DTO を戻す。
     * <p>
     * リポジトリから、各テーブルに対応した、画面上での制御情報を保持した
     * テーブルフォーム DTO を取得して戻します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブルフォーム ID
     * @return TableFormDTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO#getTableFormDTO(java.lang.String, java.lang.String)
     */
    public TableFormDTO getTableFormDTOByConnectName(final String connectDefinitionId,
            final String tableFormId) throws DAOException {
        final ConnectDefinision def = searchConnectDefinisionName(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }

        for (final TableForm table : def.getTableForms().getTableForm()) {
            if (table.getId().equals(tableFormId)) {
                final TableFormDTO ret = new TableFormDTO();
                ret.setTableFormId(table.getId());
                ret.setTableFormLabel(table.getLabel());
                ret.setOrderDesc((null != table.isOrderdesc() ? table.isOrderdesc() : false));

                if(table.getType() != null && AppConst.MULTI_TABLE.equals(table.getType())){
                	ret.setType(table.getType());
                	ret.setDescription(table.getDiscription());
                	ret.setEnable(table.getEnable());

                	TablesDto tablesDto = new TablesDto(table.getTables());
                    for (Iterator<TableDto> iterator = tablesDto.getTableDtoList().iterator(); iterator.hasNext();) {
    					TableDto tableDto = (TableDto) iterator.next();
    					ret.getTableMap().put(tableDto.getId(), tableDto);
                    }

                	// Get relation
                	if(table.getRelations() != null && table.getRelations().getRelation() != null){
	                	for (final Iterator<Relations.Relation> resIte = table
	                            .getRelations().getRelation().iterator(); resIte
	                            .hasNext();) {
	                            final Relations.Relation res = resIte.next();
	                            ApplicationRelationDTO relation = getRelationInfoById(res.getId());
	                            if(relation != null){
	                            	ret.getRelationMap().put(res.getId(), relation);
	                            }
	                    }
                	}

                	// Get optional
                	if(table.getOptional() != null){
                		OptionalDto optionalDto = new OptionalDto(table.getOptional());
                		ret.setOptional(optionalDto);
                	}
                }


                for (final Iterator<Row> rowIte = table.getSort().getRow()
                    .iterator(); rowIte.hasNext();) {
                    final Row row = rowIte.next();
                    ret.getSortConditionMap().put(Integer.valueOf(row.getId()),
                        row.getValue());
                }
                for (final Iterator<Item> itemIte = table.getItem().iterator(); itemIte
                    .hasNext();) {
                    final Item item = itemIte.next();
                    final TableItemDTO buff = new TableItemDTO();
                    buff.setTableId(tableFormId);
                    buff.setItemId(item.getId());
                    buff.setItemLabel(item.getLabel());
                    buff.setSortIndex(item.getSortIndex());
                    buff.setDefaultValue(item.getDefault());
                    buff.setEditing("true".equals(item.getCanEditing()));
                    buff.setExplanation(item.getExplanation());
                    buff.setHtmlElement(DefinedHtmlElement.keyOf(item
                        .getHtmlElement()));
                    if (item.getSelectableSql() != null) {
                        buff.setSqlString(item.getSelectableSql());
                    }
                    if (item.getSelectableList() != null) {
                        final List<SelectOneMenuItem> selectItems = new ArrayList<SelectOneMenuItem>();
                        for (final Iterator<Li> liIte
                                = item.getSelectableList().getLi().iterator(); liIte.hasNext();) {
                            final Li li = liIte.next();
                            final SelectOneMenuItem selectItem = new SelectableItem();
                            selectItem.setValue(li.getId());
                            selectItem.setLabel(li.getLabel());
                            selectItems.add(selectItem);
                        }
                        buff.setSelectableItems(selectItems.toArray(new SelectableItem[0]));
                    }
                    buff.setPreview(null != item.getCanPreview() ? item.getCanPreview().equals("true") : true);
                    buff.setDisplayRecordEdit(null != item.getCanDisplayRecordEdit() ? item.getCanDisplayRecordEdit().equals("true") : true);
                    buff.setDisplayNamePreview(null != item.getCanDisplayNamePreview() ? item.getCanDisplayNamePreview().equals("true") : false);
                    buff.setSelectKey(null != item.getIsSelectKey() ? item.getIsSelectKey().equals("true") : true);
                    buff.setUpdateKey(null != item.getIsUpdateKey() ? item.getIsUpdateKey().equals("true") : true);

                    buff.setPrimaryKey(null != item.getPrimaryKey() ? item.getPrimaryKey().equals("true") : true);
                    buff.setUnique(null!=item.getUnique()?item.getUnique().equals("true"):true);
                    buff.setForeignKey(null != item.getForeignKey()?item.getForeignKey().equals("true"):true);
                    buff.setDataType(item.getDataType());
                    buff.setDataLength(item.getDataLength());
                    buff.setDataUnit(item.getDataUnit());
                    buff.setParametersSql(item.getParametersSql());

                    for (final Iterator<Restriction> resIte = item
                        .getRestrictions().getRestriction().iterator(); resIte
                        .hasNext();) {
                        final Restriction res = resIte.next();
                        buff.getItemRestrictions().put(
                            ItemRestriction.idOf(res.getId()),
                            res.getValue().equals("true"));
                    }

                    buff.setRelatedSelectItems(
                        isRelatedSelectItems(
                            item.getLabel(),
                            table.getItem()));


                    if (table.getType() != null && AppConst.MULTI_TABLE.equals(table.getType()) && item.getCols() != null) {
                    	// Get columns
						for (final Iterator<Item.Cols.Col> itemCol = item.getCols().getCol().iterator(); itemCol
								.hasNext();) {
							final Item.Cols.Col xmlCol = itemCol.next();
							ColDto col = new ColDto();
							col.setListNO(xmlCol.getListNO());
							col.setTableID(xmlCol.getTableID());
							col.setItemID(xmlCol.getItemID());
							buff.getCols().put(col.getListNO(), col);
						}

						buff.setOperations(new OperationDto(item.getOperation()));
					}
                    ret.getTableItemMap().put(buff.getItemId(), buff);

                }
                return ret;
            }
        }
        return null;
    }

    /**
     * 引数で指定されたカラムに関連する、プルダウンリストがあるか否かを返します。
     *
     * @param columnLabel
     * @param items
     * @return
     */
    private boolean isRelatedSelectItems(
            final String columnLabel,
            final List<Item> items) {
        for (final Item item : items) {
            if (DefinedHtmlElement.keyOf(item.getHtmlElement())
                    == DefinedHtmlElement.SELECT) {
                final String sql = item.getSelectableSql();
                if (StringUtils.isNotEmpty(sql)) {
                    if (sql.indexOf("'@".concat(columnLabel).concat("'")) != -1) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * テーブル名の一覧を戻す。
     * <p>
     * リポジトリに設定済みのテーブル名一覧を戻します。
     * </p>
     * <p>
     * ソート順は テーブル表示名 ＋ テーブルIDの昇順となります。
     * </p>
     *
     * @param connectDefinisionId 接続定義 ID
     * @return Map&lt;テーブルフォーム ID, テーブル仮名&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO#getTableNameMap(java.lang.String)
     */
    public SortedMap<String, TableLabeDTO> getTableNameMap(final String connectDefinitionId)
            throws DAOException {
        final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final SortedMap<String, TableLabeDTO> ret = new TreeMap<String, TableLabeDTO>();
        for (final Iterator<TableForm> ite = def.getTableForms().getTableForm()
            .iterator(); ite.hasNext();) {
            final TableForm table = ite.next();
			if (null == table.getType()) {
				final TableLabeDTO dto = new TableLabeDTO();
				dto.setId(table.getId());
				dto.setLabel(table.getLabel());
				ret.put(table.getLabel() + table.getId(), dto);
			}
        }
        return ret;
    }

    /**
     * @param connectDefinitionId
     * @return
     * @throws DAOException
     */
    public SortedMap<String, TableLabeDTO> getAllTableNameMap(final String connectDefinitionId)
            throws DAOException {
        final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final SortedMap<String, TableLabeDTO> ret = new TreeMap<String, TableLabeDTO>();
        for (final Iterator<TableForm> ite = def.getTableForms().getTableForm().iterator(); ite.hasNext();) {
            final TableForm table = ite.next();
			final TableLabeDTO dto = new TableLabeDTO();
			dto.setId(table.getId());
			dto.setLabel(table.getLabel());
			ret.put(table.getLabel() + table.getId(), dto);
        }
        return ret;
    }
    /**
     * テーブル名の一覧を戻す。
     * <p>
     * リポジトリに設定済みのテーブル名一覧を戻します。
     * </p>
     * <p>
     * ソート順は テーブル表示名 ＋ テーブルIDの昇順となります。
     * </p>
     *
     * @param connectDefinisionId 接続定義名
     * @return Map&lt;テーブルフォーム ID, テーブル仮名&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO#getTableNameMap(java.lang.String)
     */
    public SortedMap<String, TableLabeDTO> getTableNameMapByConnectName(final String connectDefinitionId)
            throws DAOException {
        final ConnectDefinision def = searchConnectDefinisionName(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final SortedMap<String, TableLabeDTO> ret = new TreeMap<String, TableLabeDTO>();
        if(def.getTableForms() == null){
        	return null;
        }
        for (final Iterator<TableForm> ite = def.getTableForms().getTableForm()
            .iterator(); ite.hasNext();) {
            final TableForm table = ite.next();
            if (AppConst.MULTI_TABLE.equals(table.getType()) && false == table.getEnable()) {
            	continue;
            }
            final TableLabeDTO dto = new TableLabeDTO();
            dto.setId(table.getId());
            dto.setLabel(table.getLabel());
            dto.setType(table.getType());
            ret.put(table.getLabel() + table.getId(), dto);
        }
        return ret;
    }

    public SortedMap<String, TableForm> getTableFormsMapByConnectName(final String connectDefinitionId)
            throws DAOException {
        final ConnectDefinision def = searchConnectDefinisionName(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final SortedMap<String, TableForm> ret = new TreeMap<String, TableForm>();
        if(def.getTableForms() == null){
        	return null;
        }
        for (final Iterator<TableForm> ite = def.getTableForms().getTableForm()
            .iterator(); ite.hasNext();) {
            final TableForm table = ite.next();
            ret.put(table.getLabel() + table.getId(), table);
        }
        return ret;
    }

    /**
     * @return テブールの一覧
     * @throws DAOException
     */
    public SortedMap<String, TableLabeExtendConnectDTO> getAllTableNameMap(UserInfoDTO userInfoDTO) throws DAOException {
//    	MyUserDetails myUserDetails = (MyUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    	List<ConnectDefinision> connectDefinisionList= getConnectDefinisionList();
    	final SortedMap<String, TableLabeExtendConnectDTO> ret = new TreeMap<String, TableLabeExtendConnectDTO>();
    	//ログインユーザーがシステム管理者の場合
    	if(userInfoDTO != null && userInfoDTO.isSystemAdministrator()){
    		for (final Iterator<ConnectDefinision> condef = connectDefinisionList.iterator(); condef.hasNext();) {
    			final ConnectDefinision def = condef.next();
    			if (def.getTableForms() != null && def.getTableForms().getTableForm() != null) {
    				for (final Iterator<TableForm> ite = def.getTableForms().getTableForm().iterator(); ite.hasNext();) {
    					final TableForm table = ite.next();
	    				if(null == table.getType() || (null != table.getType() && AppConst.MULTI_TABLE.equals(table.getType()) && table.getEnable())){
	    					final TableLabeExtendConnectDTO dto = new TableLabeExtendConnectDTO();
	    					dto.setId(table.getId());
	    					dto.setLabel(table.getLabel());
	    					dto.setType(table.getType());
	    					String connectDefinisionId = def.getId();
	    					String connectDefinisionLabel = def.getLabel();
	    					dto.setConnectDefinisionId(connectDefinisionId);
	    					dto.setConnectDefinisionLabel(connectDefinisionLabel);
	    					dto.setDatabaseTypeConnectionDestination(def.getDbConnect().getDatabaseTypeConnectionDestination());
	    					if(null == ret.get(table.getLabel())) {
	    						ret.put(table.getLabel(), dto);
	    					} else {
	    						//previous
	    						TableLabeExtendConnectDTO dtoPre =ret.get(table.getLabel());
	    						ret.put(table.getLabel()+"("+dtoPre.getConnectDefinisionLabel()+")", dtoPre);
	    						//remove old
	    						ret.remove(table.getLabel());
	    						//last
	    						ret.put(table.getLabel()+"("+connectDefinisionLabel+")", dto);
	    					}
    					}
    				}
    			}
    		}
    	} else {//ログインユーザーが一般ユーザーの場合
    		List<ConnectDefinisionAuthority> connectDefinisionAuthoritys = userInfoDTO.getUserAuthority().getConnectDefinisionAuthoritys();
    		for (final ConnectDefinisionAuthority connectDefinisionAuthority : connectDefinisionAuthoritys) {
    			String connectDefinisionIdAuth = connectDefinisionAuthority.getConnectDefinisionId();
    			for (final Iterator<ConnectDefinision> condef = connectDefinisionList.iterator(); condef.hasNext();) {
    				final ConnectDefinision def = condef.next();
    				String connectDefinisionId = def.getId();
    				if(connectDefinisionIdAuth.equals(connectDefinisionId)) {
	    				if (def.getTableForms() != null && def.getTableForms().getTableForm() != null) {
	    					for (final Iterator<TableForm> ite = def.getTableForms().getTableForm().iterator(); ite.hasNext();) {
	    						final TableForm table = ite.next();
	    						if(null == table.getType() || (null != table.getType() && AppConst.MULTI_TABLE.equals(table.getType()) && table.getEnable())){
		    						final TableLabeExtendConnectDTO dto = new TableLabeExtendConnectDTO();
		    						dto.setId(table.getId());
		    						dto.setLabel(table.getLabel());
		    						dto.setType(table.getType());

		    						String connectDefinisionLabel = def.getLabel();
		    						dto.setConnectDefinisionId(connectDefinisionId);
		    						dto.setConnectDefinisionLabel(connectDefinisionLabel);
		    						dto.setDatabaseTypeConnectionDestination(def.getDbConnect().getDatabaseTypeConnectionDestination());
		    						if(null == ret.get(table.getLabel())) {
		    							ret.put(table.getLabel(), dto);
		    						} else {
		    							//previous
		    							TableLabeExtendConnectDTO dtoPre =ret.get(table.getLabel());
		    							ret.put(table.getLabel()+"("+dtoPre.getConnectDefinisionLabel()+")", dtoPre);
		    							//remove old
		    							ret.remove(table.getLabel());
		    							//last
		    							ret.put(table.getLabel()+"("+connectDefinisionLabel+")", dto);
		    						}
	    						}
	    					}
	    				}
    				}
    			}
    		}
    	}
        return ret;
    }

    /**
     * @return テブールの一覧
     * @throws DAOException
     */
    public SortedMap<String, TableLabeExtendConnectDTO> getAllTableNameConnectTypeMap(final String connectDefinitionId) throws DAOException {
    	final SortedMap<String, TableLabeExtendConnectDTO> ret = new TreeMap<String, TableLabeExtendConnectDTO>();
    	final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        for (final Iterator<TableForm> ite = def.getTableForms().getTableForm().iterator(); ite.hasNext();) {
            final TableForm table = ite.next();
            final TableLabeExtendConnectDTO dto = new TableLabeExtendConnectDTO();
            dto.setId(table.getId());
            dto.setLabel(table.getLabel());
            dto.setType(table.getType());

            String connectDefinisionId = def.getId();
            String connectDefinisionLabel = def.getLabel();
            dto.setConnectDefinisionId(connectDefinisionId);
            dto.setConnectDefinisionLabel(connectDefinisionLabel);
            if(null == ret.get(table.getLabel())) {
            	ret.put(table.getLabel(), dto);
            } else {
            	//previous
            	TableLabeExtendConnectDTO dtoPre =ret.get(table.getLabel());
            	ret.put(table.getLabel()+"("+dtoPre.getConnectDefinisionLabel()+")", dtoPre);
            	//remove old
            	ret.remove(table.getLabel());
            	//last
            	ret.put(table.getLabel()+"("+connectDefinisionLabel+")", dto);
            }
        }
        return ret;
    }

    /**
     * ドメインにて生成されたテーブルフォーム DTO を保存する。
     * <p>
     * ドメインにて生成された（各テーブルに対応する、画面上での制御情報を保持し
     * た）テーブルフォーム DTO のパラメータを、JAXBにてリポジトリにマッピングさ
     * れいる、永続化用のテーブルフォーム DTO オブジェクトに詰め替え、リポジトリ
     * に保存処理を行います。</p>
     * <p>
     * 既登録の情報であれば上書きを、未登録情報であれば新規に追加します。</p>
     *
     * @param connectDefinitionId 接続定義ID
     * @param dto <p>ドメインにて生成された保存すべきデータを保持するテーブルフ
     * ォーム DTO</p>
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO#save(java.lang.String, jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO)
     */
    public void save(final String connectDefinitionId, final TableFormDTO dto)
            throws DAOException {
        final TableForm tableForm = getTargetTableForm(connectDefinitionId, dto);
        tableForm.setId(dto.getTableFormId());
        tableForm.setLabel(dto.getTableFormLabel());
        tableForm.setOrderdesc(dto.getOrderDesc());
        setSortMapToTableForm(tableForm, dto.getSortConditionMap());
        tableForm.getItem().clear();
        for (final Iterator<TableItemDTO> ite = dto.getTableItemMap().values()
            .iterator(); ite.hasNext();) {
            final TableItemDTO itemDto = ite.next();

            final Item item;
            final Item buff = searchTableItem(tableForm, itemDto.getItemId());
            if (buff == null) {
                item = getObjectFactory().createItem();
                tableForm.getItem().add(item);
            } else {
                item = buff;
            }

            item.setId(itemDto.getItemId());
            item.setLabel(itemDto.getItemLabel());

            item.setSortIndex(itemDto.getSortIndex());
            item.setCanEditing(String.valueOf(itemDto.canEditing()));
            item.setCanPreview(String.valueOf(itemDto.canPreview()));
            item.setCanDisplayRecordEdit(String.valueOf(itemDto.canDisplayRecordEdit()));
            item.setCanDisplayNamePreview(String.valueOf(itemDto.canDisplayNamePreview()));
            item.setDefault(itemDto.getDefaultValue());
            item.setExplanation(itemDto.getExplanation());
            item.setHtmlElement(itemDto.getHtmlElement().getKey());
            if (itemDto.getSqlString() == null
                    || itemDto.getSqlString().equals("")) {
                item.setSelectableSql("");
            } else {
                item.setSelectableSql(itemDto.getSqlString());
            }
            item.setParametersSql(itemDto.getParametersSql());

            item.setSelectableList(getObjectFactory()
                .createItemSelectableList());
            if (itemDto.getSelectableItems() != null) {
                for (final SelectOneMenuItem selectItems : itemDto.getSelectableItems()) {
                    final String id = selectItems.getValue();
                    final SelectableList selectableList = item.getSelectableList();
                    final Li li;
                    final Li buffLi = searchLi(selectableList, id);
                    if (buffLi == null) {
                        li = getObjectFactory().createItemSelectableListLi();
                        item.getSelectableList().getLi().add(li);
                    } else {
                        li = buffLi;
                    }
                    li.setId(id);
                    li.setLabel(selectItems.getLabel());
                }
            }

            item.setIsSelectKey(String.valueOf(itemDto.isSelectKey()));
            item.setIsUpdateKey(String.valueOf(itemDto.isUpdateKey()));

            item.setPrimaryKey(String.valueOf(itemDto.getPrimaryKey()));
            item.setUnique(String.valueOf(itemDto.getUnique()));
            item.setForeignKey(String.valueOf(itemDto.getForeignKey()));
            item.setDataType(itemDto.getDataType());
            item.setDataLength(itemDto.getDataLength());
            item.setDataUnit(itemDto.getDataUnit());

            if (item.getRestrictions() == null) {
                item.setRestrictions(getObjectFactory()
                    .createItemRestrictions());
            }
            final Map<ItemRestriction, Boolean> map = itemDto
                .getItemRestrictions();
            item.getRestrictions().getRestriction().clear();
            for (final Iterator<ItemRestriction> irIte = map.keySet()
                .iterator(); irIte.hasNext();) {
                final ItemRestriction ir = irIte.next();
                final Restriction r = getObjectFactory()
                    .createItemRestrictionsRestriction();
                item.getRestrictions().getRestriction().add(r);
                r.setId(ir.getId());
                r.setValue(String.valueOf(map.get(ir)));
            }
            //relation table
//            item.setRelationName("");
//            item.setJoinType("");
//            item.setROwnerDefinition("");
//            item.setRTableNameDefinition("");
//            item.setRColumnNameDefinition("");
        }
        update();
    }

    /**
     * テーブルフォームを削除します。
     * <p>
     * リポジトリ内のテーブルフォーム要素を削除します。</p>
     *
     * @param connectDefinitionId 接続定義 ID
     * @param tableFormId テーブルフォーム ID（＝スキーマ名.テーブル名）
     * @throws DAOException DAO 例外
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO#remove(java.lang.String, java.lang.String)
     */
    public void remove(final String connectDefinitionId,
            final String tableFormId) throws DAOException {
        final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final List<TableForm> list = def.getTableForms().getTableForm();
        for (final Iterator<TableForm> ite = list.iterator(); ite.hasNext();) {
            final TableForm table = ite.next();
            if (table.getId().equals(tableFormId)) {
                ite.remove();
            }
        }
        update();
    }

    /**
     * 永続化用のテーブルフォーム DTO オブジェクトを戻します。
     * <p>
     * 接続定義情報及び、ドメインにて生成された、保存すべきフォームデータを保持す
     * るテーブルフォーム DTO より、永続化層に対しデータの存在確認を行う。まず、
     * テーブルフォームのリストを保持するトップノードであるフォームズオブジェクト
     * の存在確認を行います。存在しない場合には、フォームズオブジェクトを生成、存
     * 在する場合には、そのフォームズオブジェクトを取得し、フォームズオブジェクト
     * を保持する接続定義情報 DTO にセットします。</p>
     * <p>次に、フォームズオブジェクト中にドメインにて生成された、保存すべきフォ
     * ームデータを保持するテーブルフォーム DTO より、該当するテーブルフォーム要
     * 素の存在確認を行います。存在しない場合は、新たなテーブルフォーム DTO オブ
     * ジェクト作成、存在した場合にはそのテーブルフォーム DTO オブジェクトを取得
     * し返します。</p>
     * <p>ようは、テーブルフォームズオブジェクトの生成をクライアントから隠蔽し、
     * テーブルフォームオブジェクトの取得のみを主としています。</p>
     *
     * @param connectDefinitionId
     * @param dto <p>ドメインロジックにて生成されたテーブルフォーム情報を保持す
     * る DTO</p>
     * @return TableForm <p>JAXBにてリポジトリにマッピングされている、永続化用のテ
     * ーブルフォーム DTO オブジェクト</p>
     */
    private TableForm getTargetTableForm(final String connectDefinitionId,
            final TableFormDTO dto) throws DAOException {
        final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final TableForms tableForms;
        if (def.getTableForms() == null) {
            tableForms = getObjectFactory().createTableForms();
            def.setTableForms(tableForms);
        } else {
            tableForms = def.getTableForms();
        }
        final TableForm ret;
        final TableForm buff = searchTableForm(tableForms, dto.getTableFormId());
        if (buff == null) {
            ret = getObjectFactory().createTableForm();
            tableForms.getTableForm().add(ret);
        } else {
            ret = buff;
        }
        return ret;
    }

    /**
     * ドメインにて生成されたソート情報マップを、JAXB DTO の、テーブルフォームの
     * ソート情報リストに設定します。<p>
     * ドメインにて生成されたテーブルフォーム DTO が SortedMap にて保持する、ソ
     * ート情報要素を、JAXBにてリポジトリにマッピングされている、永続化用のテー
     * ブルフォーム DTO オブジェクトの List 形のソート情報要素に保存します。 ソ
     * ート情報要素が存在しない場合はソート情報要素オブジェクトを生成、存在する
     * 場合にはそのオブジェクトに対して保存処理を行います。</p>
     *
     * @param tableForm
     * @param map
     */
    private void setSortMapToTableForm(final TableForm tableForm,
            final SortedMap<Integer, String> map) {
        tableForm.setSort(getObjectFactory().createTableFormSort());
        for (final Iterator<Integer> ite = map.keySet().iterator(); ite
            .hasNext();) {
            final int key = ite.next();
            final Row row = getObjectFactory().createTableFormSortRow();
            row.setId(String.valueOf(key));
            row.setValue(map.get(key));
            tableForm.getSort().getRow().add(row);
        }
    }

    /**
     * 選択リストアイテム ID に対応した選択リストアイテム要素を検索して戻す。
     * <p>
     * List 要素内から、選択リストアイテム ID に対応した選択リストアイテム
     * 要素を検索し参照を戻します。発見出来なかった場合は null を戻します。</p>
     *
     * @param selectableList
     * @param id
     * @return
     */
    private Li searchLi(final SelectableList selectableList, final String id) {
        final List<Li> liList = selectableList.getLi();
        for (Iterator<Li> ite = liList.iterator(); ite.hasNext();) {
            final Li li = ite.next();
            if (li.getId().equals(id)) {
                return li;
            }
        }
        return null;
    }

    /**
     * テーブルフォーム ID に対応したテーブルフォーム要素を検索して戻す。
     * <p>
     * TableForms 要素内から、テーブルフォーム ID に対応したテーブルフォーム
     * 要素を検索し参照を戻します。発見出来なかった場合は null を戻します。</p>
     *
     * @param tableForms
     * @param tableFormId
     * @return
     */
    private TableForm searchTableForm(final TableForms tableForms,
            final String tableFormId) {
        for (final Iterator<TableForm> ite = tableForms.getTableForm()
            .iterator(); ite.hasNext();) {
            final TableForm buff = ite.next();
            if (buff.getId() != null && buff.getId().equals(tableFormId)) {
                return buff;
            }
        }
        return null;
    }

    /**
     * テーブルアイテム ID に対応したテーブルアイテム要素を検索して戻す。
     * <p>
     * TableForm 要素内から、テーブルアイテム ID に対応したテーブルアイテム
     * 要素を検索し参照を戻します。発見出来なかった場合は null を戻します。</p>
     *
     * @param tableForm
     * @param itemId
     * @return
     */
    private Item searchTableItem(final TableForm tableForm, final String itemId) {
        for (Iterator<Item> ite = tableForm.getItem().iterator(); ite.hasNext();) {
            final Item item = ite.next();
            if (item.getId().equals(itemId)) {
                return item;
            }
        }
        return null;
    }

    /**
     * insert or update table multi in a connection
     *
     * @param connectDefinitionId
     * @param dto
     * @throws DAOException
     */
    public void saveTableMulti(final String connectDefinitionId, final TableFormDto dto)
            throws DAOException {
        final TableForm tableForm = this.getTargetTableFormMulti(connectDefinitionId, dto);
        /*set attributes*/
        tableForm.setId(dto.getId());
        tableForm.setLabel(dto.getLabel());
        tableForm.setOrderdesc(dto.isOrderdesc());
        tableForm.setType(dto.getType());
        tableForm.setDiscription(dto.getDiscription());
        tableForm.setEnable(dto.isEnable());
        /*set elements*/
        tableForm.setSort(new TableForm.Sort(dto.getSortDto()));
        /*this.setItemDtoToItem(tableForm, dto.getItemDtoList());*/
        tableForm.setItem(dto.getItemDtoList());
        tableForm.setRelations(new TableForm.Relations(dto.getRelationsDto()));
        tableForm.setOptional(new TableForm.Optional(dto.getOptionalDto()));
        tableForm.setTables(new Tables(dto.getTablesDto()));

        update();
    }

    /**
     * 1.find connection by id (if it is null => error)
     * 2.find tableform by id in connection (if it is null => new Tableform)
     * 3.check tableform multi and return
     * @param connectDefinitionId
     * @param dto
     * @return ret
     * @throws DAOException
     */
    public TableForm getTargetTableFormMulti(final String connectDefinitionId,
            final TableFormDto dto) throws DAOException {
        final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final TableForms tableForms;
        if (def.getTableForms() == null) {
            tableForms = getObjectFactory().createTableForms();
            def.setTableForms(tableForms);
        } else {
            tableForms = def.getTableForms();
        }
        final TableForm ret;
        final TableForm buff = searchTableForm(tableForms, dto.getId());
        if (buff == null
        		|| StringUtils.isBlank(buff.getType())
        		|| !AppConst.MULTI_TABLE.equals(buff.getType())) {
            ret = getObjectFactory().createTableForm();
            tableForms.getTableForm().add(ret);
        } else {
            ret = buff;
        }
        return ret;
    }

    /**
     * TableFormDAOImpl の生成。
     * <p>コンストラクタ。</p>
     *
     * @throws DAOException
     */
    public TableFormDAOImpl() throws DAOException {
        super();
    }

	/**
	 *
	 */
	@Override
	public boolean isMultiTable(String connectDefinitionId, String tableFormId) throws DAOException {
		final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
		if (def == null) {
			// MI-E-0087=接続定義情報が存在しません。
			throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
		}
		for (final Iterator<TableForm> ite = def.getTableForms().getTableForm().iterator(); ite.hasNext();) {
			final TableForm table = ite.next();
			if (table.getId().equals(tableFormId) && AppConst.MULTI_TABLE.equals(table.getType())) {
				return true;
			}
		}
		return false;
	}

    /**
     * @param tableForms
     * @return
     */
    private Map<String,TableForm> searchTableFormMulti(final TableForms tableForms) {
    	Map<String,TableForm> tableMultiFormsMap = new HashMap<String,TableForm>();
        for (final Iterator<TableForm> ite = tableForms.getTableForm().iterator(); ite.hasNext();) {
            final TableForm buff = ite.next();
            if (buff.getType()!=null && AppConst.MULTI_TABLE.equals(buff.getType())) {
            	tableMultiFormsMap.put(buff.getId(), buff);
            }
        }
        return tableMultiFormsMap;
    }

    /**
     * @param connectDefinitionId
     * @return
     * @throws DAOException
     */
    public Map<String,TableForm> getAllTableFormMulti(final String connectDefinitionId) throws DAOException {
        final ConnectDefinision def = searchConnectDefinision(connectDefinitionId);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        final TableForms tableForms;
        if (def.getTableForms() == null) {
            tableForms = getObjectFactory().createTableForms();
            def.setTableForms(tableForms);
        } else {
            tableForms = def.getTableForms();
        }
        return searchTableFormMulti(tableForms);
    }

    /**
     * @param connectDefinitionName
     * @return
     * @throws DAOException
     */
    public String getConnectDefinitionIdByConnectName(final String connectDefinitionName) throws DAOException {
        final ConnectDefinision def = searchConnectDefinisionName(connectDefinitionName);
        if (def == null) {
        	// MI-E-0087=接続定義情報が存在しません。
            throw new DAOException(MessageUtils.getMessage("MI-E-0087"));
        }
        return  def.getId();
    }

}
