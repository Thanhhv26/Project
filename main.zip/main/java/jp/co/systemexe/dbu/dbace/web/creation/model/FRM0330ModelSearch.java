package jp.co.systemexe.dbu.dbace.web.creation.model;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import lombok.Data;

@Data
public class FRM0330ModelSearch {
	Map<String, TableFormDto> tableMultiList;
}
