/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.persistance.dto;

/**
 * 接続定義情報 DTO。
 * <p>
 * 接続定義情報を保持する DTO です。詳細な値は下位に属する詳細要素が保持するため、
 * この要素が保持するのは ID と名称のみです。
 * </p><p>
 * 本アイテムはリポジトリの定義に従って定義されています。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class ConnectDefinisionDTO {

    private String connectDefinisionId;
    private String connectDefinisionLabel;

    /**
     * connectDefinisionId を戻します。
     * 
     * @return String
     */
    public String getConnectDefinisionId() {
        return connectDefinisionId;
    }

    /**
     * connectDefinisionId を設定します。
     *
     * @param String connectDefinisionId 
     */
    public void setConnectDefinisionId(String connectDefinisionId) {
        this.connectDefinisionId = connectDefinisionId;
    }

    /**
     * connectDefinisionLabel を戻します。
     * 
     * @return String
     */
    public String getConnectDefinisionLabel() {
        return connectDefinisionLabel;
    }

    /**
     * connectDefinisionLabel を設定します。
     *
     * @param String connectDefinisionLabel 
     */
    public void setConnectDefinisionLabel(String connectDefinisionLabel) {
        this.connectDefinisionLabel = connectDefinisionLabel;
    }

}
