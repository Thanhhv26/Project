/**
 * Copyright(C) 2009 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.config.SystemProperties;
import jp.co.systemexe.dbu.dbace.common.config.SystemPropertyKeys;
import jp.co.systemexe.dbu.dbace.presentation.AdLdapServerType;
import jp.co.systemexe.dbu.dbace.presentation.LdapUserServerIdentify;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.dto.EnvironmentSettingDTO;

/**
 * system.properties から、設定情報をすべて取得します。
 *
 * @author  EXE 島田 雄一郎
 * @version 0.0.0
 */
public class AcquisitionOfEnvironmentSetting extends BaseApplicationDomainLogic {
	/**
	 * system.properties から、設定情報をすべて取得します。
	 *
	 * @return
	 */
	public EnvironmentSettingDTO getAllProperties() {
		final Map<SystemPropertyKeys, String> prop = SystemProperties.getAllPropertiesMap();

		final EnvironmentSettingDTO ret = new EnvironmentSettingDTO();
		ret.setRepositoryFilePath(prop.get(SystemPropertyKeys.APP_REPOSITORY));
		ret.setRecordDisplayCount(prop.get(SystemPropertyKeys.DISPLAYED_NUMBER_OF_RECORDS));
		ret.setColumnDisplayCount(prop.get(SystemPropertyKeys.PREVIEW_COLUMN_COUNT));
		ret.setRetrievalConditionPreservationPath(prop.get(SystemPropertyKeys.SEARCH_CONDITION_FILEPATH));
		ret.setImportTempFilePath(prop.get(SystemPropertyKeys.IMPORT_TEMP_FILE_PATH));
		ret.setPulldownDisplayMaximumCount(prop.get(SystemPropertyKeys.PULLDOWN_MAX_COUNT));
		ret.setPulldownDisplayFetchSize(prop.get(SystemPropertyKeys.PREFETCH_SIZE));
		ret.setFileDownloadFetchSize(prop.get(SystemPropertyKeys.DOWNLOAD_FETCH_SIZE));
		ret.setAuditLogFilePath(prop.get(SystemPropertyKeys.AUDIT_SETTING));
		ret.setDownloadMaximumByteForExcel(prop.get(SystemPropertyKeys.DOWNLOAD_MAXIMUM_BYTE_FOR_EXCEL));
		ret.setDownloadMaximumByteForCsv(prop.get(SystemPropertyKeys.DOWNLOAD_MAXIMUM_BYTE_FOR_CSV));
		ret.setImportMaximumByteForExcel(prop.get(SystemPropertyKeys.IMPORT_MAXIMUM_BYTE_FOR_EXCEL));
		ret.setImportMaximumByteForCsv(prop.get(SystemPropertyKeys.IMPORT_MAXIMUM_BYTE_FOR_CSV));
		ret.setImportMaximumByteForTsv(prop.get(SystemPropertyKeys.IMPORT_MAXIMUM_BYTE_FOR_TSV));
		ret.setSearchMaxRecordCount(prop.get(SystemPropertyKeys.SEARCH_MAX_RECORD_COUNT));
		ret.setSearchComparisonOperatorOrder(prop.get(SystemPropertyKeys.SEARCH_COMPARISON_OPERATOR_ORDER));

		// ADD ライセンス認証と外部認証連携の機能追加　↓
		ret.setLicenseKey(prop.get(SystemPropertyKeys.LICENSE_KEY));
		ret.setLicenseCnt(prop.get(SystemPropertyKeys.LICENSE_CNT));
		ret.setExtAuth(prop.get(SystemPropertyKeys.EXT_AUTH));
		ret.setAuthServerType(AdLdapServerType.keyOf(prop.get(SystemPropertyKeys.AUTH_SERVER_TYPE)));
		ret.setAuthServerId(prop.get(SystemPropertyKeys.AUTH_SERVER_ID));
		ret.setAuthServerPort(prop.get(SystemPropertyKeys.AUTH_SERVER_PORT));
		ret.setAuthServerBaseDomain(prop.get(SystemPropertyKeys.AUTH_SERVER_BASE_DOMAIN));
		ret.setAuthServerProtocol(prop.get(SystemPropertyKeys.AUTH_SERVER_PROTOCOL));
		ret.setAuthServerSecurity(prop.get(SystemPropertyKeys.AUTH_SERVER_SECURITY));
		ret.setAuthServerTimeout(prop.get(SystemPropertyKeys.AUTH_SERVER_TIMEOUT));
		ret.setAuthServerUserIdentify(LdapUserServerIdentify.keyOf(prop.get(SystemPropertyKeys.AUTH_SERVER_USER_IDENTIFY)));
		ret.setAuthConnectUsername(prop.get(SystemPropertyKeys.AUTH_CONNECT_USERNAME));
		ret.setAuthConnectPwd(prop.get(SystemPropertyKeys.AUTH_CONNECT_PWD));
		// ADD ライセンス認証と外部認証連携の機能追加　↑

		return ret;
	}
}
