/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.interceptor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import jp.co.systemexe.dbu.dbace.common.exception.ApplicationRuntimeException;
import jp.co.systemexe.dbu.dbace.library.util.BeanUtils;

/**
 * MethodInterceptorのクラス。
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
@Aspect
@Component
public abstract class WebInterceptor extends AbstractInterceptor {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * jp.co.systemexe.dbu.dbace.web methods pointcut
	 *
	 * @param joinPoint
	 * @return
	 * @throws Throwable
	 */
	@Around("execution(public * jp.co.systemexe.dbu.dbace.web..*(..))")
	public final Object inWebLayer(ProceedingJoinPoint joinPoint) throws Throwable {
		final String methodName = joinPoint.getSignature().getName();
		final String method = joinPoint.getTarget().getClass().getName() + "." + methodName;
		logger.debug("[START] {}", method);
		final StopWatch sw = new StopWatch();
		sw.start();

		Object value = null;
		Class<?> targetClass = null;
		Object[] medArgs = null;
		try {
			// checks before invoking
			targetClass = joinPoint.getTarget().getClass();
			boolean supported = BeanUtils.isInstanceOf(targetClass, this.supportFor());
			boolean allowed = !supported;
			if (supported) {
				medArgs = joinPoint.getArgs();
				allowed = this.checkInvoke(targetClass, methodName, medArgs);
			}

			// if allowing to invoke method
			if (allowed) {
				value = joinPoint.proceed();
			}
			else if (supported) {
				logger.warn("[ERRPERM] Not enough permission to invoking {}", method);
				throw new AccessDeniedException("[ERRPERM] Not enough permission to invoking " + method);
			}

			// if supporting for this target class;
			// then should execute after invoking
			if (supported && allowed) {
				this.afterInvoke(targetClass, methodName, medArgs, value);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			if (BeanUtils.isInstanceOf(e, AccessDeniedException.class)) {
				throw new ApplicationRuntimeException(403, e);
			}
			throw e;
		} finally {
			sw.stop();
			logger.debug(sw.prettyPrint());
			logger.debug("[ END ] {} [time] {} ms", method, sw.getTotalTimeMillis());
		}
		return value;

	}

	/**
	 * Get the target class that should be intercepted
	 *
	 * @return the target class
	 */
	protected abstract Class<?> supportFor();
	/**
	 * Check conditions to allow invoking method
	 * TODO Override for checking or default is true
	 *
	 * @param targetClass the target class invocation
	 * @param method the method name
	 * @param medArgs the method arguments
	 *
	 * @return true for allowing
	 */
	protected boolean checkInvoke(Class<?> targetClass, String method, Object[] medArgs) {
		return true;
	}
	/**
	 * Do something after invoking method
	 * TODO Override for doing something
	 *
	 * @param targetClass the target class invocation
	 * @param method the method name
	 * @param medArgs the method arguments
	 * @param value the result of method invoking
	 */
	protected void afterInvoke(Class<?> targetClass, String method, Object[] medArgs, Object value) {
		;
	}
}
