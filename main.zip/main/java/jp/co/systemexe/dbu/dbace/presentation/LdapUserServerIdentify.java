/**
 * Copyright(C) 2016 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.presentation;

import java.util.HashMap;
import java.util.Map;

/**
 * 接続先データベースベンダー定義 enmu。
 * <p>
 * 接続定義がどのデータベースを対象としているか指示
 * するための定義値です。
 * </p>
 *
 * @author  NguyenDongTruc
 * @version 0.0.0
 */
public enum LdapUserServerIdentify {
    /**
     * cn
     */
    cn("cn", "cn"),
    /**
     * uid
     */
    uid("uid", "uid");

    private final String key;
    private final String name;

    private static Map<String, LdapUserServerIdentify> map;
    static {
        map = new HashMap<String, LdapUserServerIdentify>();
        for (final LdapUserServerIdentify buff : values()) {
            map.put(buff.getKey(), buff);
        }
    }

    public static LdapUserServerIdentify keyOf(final String key) {
        if (map.containsKey(key)) {
            return map.get(key);
        } else {
            return null;
        }
    }

    /**
     * テーブル中に実際に保存されるキー文字列を戻します。
     *
     * @return
     */
    public String getKey() {
        return this.key;
    }

    /**
     * name を戻します。
     *
     * @return String
     */
    public String getName() {
        return this.name;
    }

    private LdapUserServerIdentify(final String key, final String name) {
        this.key = key;
        this.name = name;
    }
}
