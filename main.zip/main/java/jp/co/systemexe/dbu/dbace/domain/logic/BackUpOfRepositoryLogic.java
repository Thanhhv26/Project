/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.RepositoryBackUpDAO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * jp.co.systemexe.dbu.dbace.persistance.xml.common。
 * <p>
 * リポジトリのバックアップを行うロジックです。</p>
 *
 * @author  EXE 鈴木 伸祐
 * @version 0.0.0
 */
public class BackUpOfRepositoryLogic
        extends BaseApplicationDomainLogic {
    
    /**
     * リポジトリのバックアップを行います。
     * 
     * @return
     * @throws ApplicationDomainLogicException
     */
    public void buckUpReposiotry() throws ApplicationDomainLogicException {
        RepositoryBackUpDAO dao = createRepositoryBackUpDAO();
        
        try {
        	if (dao.isPossibleBackUp()) {
	            dao.backUp();
	            final List<String> repositoyBackUpFileNameList = dao.getRepositoyBackUpFileNameList();
	            final List<String> fileForDeletion = new ArrayList<String>();
	            
	            for (final String repositoyBackUpFileName : repositoyBackUpFileNameList) {
	                if (isFileForDeletion(repositoyBackUpFileName)) {
	                    fileForDeletion.add(repositoyBackUpFileName);
	                }
	            }
	            
	            dao.delete(fileForDeletion);
        	}
        }catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * BackUpOfRepositoryLogic.java の生成。
     * <p>コンストラクタ。</p>
     */
    public BackUpOfRepositoryLogic() {
        super();
    }

    /**
     * リポジトリファイル DAO を生成して戻す。
     * 
     * @return ConnectDefinisionDAO
     * @throws ApplicationDomainLogicException
     */
    private RepositoryBackUpDAO createRepositoryBackUpDAO()
            throws ApplicationDomainLogicException {
        try {
            return (RepositoryBackUpDAO)createDAO("RepositoryBackUpDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }
    
    /**
     * 削除対象ファイルかどうかを返します。
     * <p>
     * 当日日付より、１ヶ月以上前の場合はtrue、それ以外はfalse
     * </p>
     * 
     * @param file
     */
    private boolean isFileForDeletion(final String file)
            throws ApplicationDomainLogicException {
        final Calendar fileDate = Calendar.getInstance();
        if (file.indexOf("repository") == -1) {
            return false;
        } else {
            try {
                fileDate.setTime(new SimpleDateFormat("yyyyMMddHHmmssSSS").parse(file.replace("repository.xml", "")));
            } catch (final ParseException e) {
            	// MI-F-0011=リポジトリXMLファイルのバックアップ処理に失敗しました。
                final String message = MessageUtils.getMessage("MI-F-0011");
                getLogger().fatal(message, e);
                throw new ApplicationDomainLogicException(message, e);
            }
            final Calendar nowDate = Calendar.getInstance();
            nowDate.add(Calendar.MONTH, -1);
            return nowDate.after(fileDate);
        }
        
    }

}
