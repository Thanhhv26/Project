package jp.co.systemexe.dbu.dbace.persistance.dao.impl;

import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import jp.co.systemexe.dbu.dbace.common.jdbc.JDBCMetaDataType;
import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.DefinitionOfColumn;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.SelectConditionItem;
import jp.co.systemexe.dbu.dbace.persistance.dao.db.TableIdDefinition;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableDefinitionDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;

public class MySQLDatabaseSchemaDAOImpl extends BaseDatabaseDAO implements
		DatabaseSchemaDAO {

    /**
     * テーブルの定義情報を取得します。
     * <p>
     * テーブルのカラム詳細情報 DTO を取得して戻します。</p>
     *
     * @param tableId テーブル ID（スキーマ名.テーブル名）
     * @return TableDefinitionDTO
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO#getTableDefinition(java.lang.String)
     */
	public TableDefinitionDTO getTableDefinition(String tableId)
			throws DAOException {
		final DatabaseMetaData meta;
		try{
			meta = getDatabaseMetaData();
		} catch(final SQLException e){
			// MI-E-0031=データベースのメタデータ取得に失敗しました。
			final String message = MessageUtils.getMessage("MI-E-0031");
			getLogger().error(message, e);
			throw new DAOException(message, e);
		}
        final TableIdDefinition id = new TableIdDefinition(tableId);
        final SortedMap<Integer, String> columns = getComumnNames(id, meta);
        final TableDefinitionDTO ret = createDefaultTableDefinitionDTO(id,
            columns);
        ret.setView(isView(meta, id));
               setPrimaryKeysToTableDefinitionDTO(meta, id, ret);
        setFkKeysToTableDefinitionDTO(meta, id, ret);
        setUniqueColumnToTableDefinitionDTO(meta, id, ret);
        ret.getColumnNames().putAll(columns);
        setColumnTypeNames(meta, id, ret);
        setResultSetMetaDataToTableDefinitionDTO(id, ret);
        setRemarks(meta, id, ret);

        ret.outputDebugLog();
		return ret;
	}
	   /**
     * カラムのコメント(REMARKS)を設定します。
     * <p>SQL ServerはJDBC経由でコメントが取得できない。<br />
     * また、コメントが格納されているデータ型がsql_variant型（JDBC未対応）のため、
     * SQLでも取得不可能なため、nullを返します。
     * </p>
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setRemarks(
            final DatabaseMetaData meta,
            final TableIdDefinition id,
            final TableDefinitionDTO dto)
            throws DAOException {
        try {
            final ResultSet rs = meta.getColumns(id.getSchem(), null, id.getTable(), "%");
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                    .get(name);
                def.setRemarks(rs.getString("REMARKS"));
            }
        } catch (final SQLException e) {
        	// MI-E-0022=カラムのコメント(REMARKS)取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0022");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }

    /**
     * データベース固有のデータ型を返します。
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setColumnTypeNames(
            final DatabaseMetaData meta,
            final TableIdDefinition id,
            final TableDefinitionDTO dto)
            throws DAOException {
        try {
            final ResultSet rs = meta.getColumns(id.getSchem(), null, id.getTable(), "%");
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                final String type = rs.getString("TYPE_NAME");
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap().get(name);
                if(def != null){
                	//「decimal() identity」 => 「decimal」
                	final String custom = customIdentityColumnTypeName(type);
                	def.setColumnTypeName(custom);
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0123=カラムのデータ型の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0123");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
    }
    /**
     * 結果セットメタデータからカラムの精度等の情報を DTO に設定。
     * <p></p>
     *
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setResultSetMetaDataToTableDefinitionDTO(
            final TableIdDefinition id, final TableDefinitionDTO dto)
            throws DAOException {
        final StringBuffer columnSql = new StringBuffer();
        for (final Iterator<Integer> ite = dto.getColumnNames().keySet()
            .iterator(); ite.hasNext();) {
            final int index = ite.next();
            columnSql.append(String.format("`%s`", dto.getColumnNames().get(index)));
            columnSql.append(",");
        }
        columnSql.deleteCharAt(columnSql.length() - 1);
        final String sql = "select " + columnSql.toString() + " from "
                           + "`" + id.getSchem() + "`.`" + id.getTable() + "`";
        final PreparedStatement statement = getPreparedStatement(sql);
        final ResultSet rs;
        try {
            rs = statement.executeQuery();
        } catch (final SQLException e) {
        	// MI-E-0071=結果セットの取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0071");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }

        try {
        	final DatabaseMetaData metaDatabase = getDatabaseMetaData();
        	final int databaseMajorVersion = metaDatabase.getDatabaseMajorVersion();
            final ResultSetMetaData meta = rs.getMetaData();
            for (int i = 1; i <= meta.getColumnCount(); i++) {
                final String name = meta.getColumnName(i);
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                    .get(name);
                def.getDefinitionOfNumericalValue().setPrecision(
                    meta.getPrecision(i));
                def.getDefinitionOfNumericalValue().setScale(meta.getScale(i));
                def.setAutoIncrement(meta.isAutoIncrement(i));
                def.setColumnDisplayMaxSize(meta.getColumnDisplaySize(i));
                getJDBCMetaDataType(databaseMajorVersion, meta, i, def);
                if (meta.isNullable(i) == ResultSetMetaData.columnNullable) {
                    def.setNotNull(false);
                } else {
                    def.setNotNull(true);
                }
            }
        } catch (final SQLException e) {
        	// MI-E-0024=カラム情報の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0024");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                statement.close();
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }
    /**
     * MySQLに対応しては、YEAR型をTINYINTに置き換えます。
     * カラム型情報を戻します。
     * 単テーブル対応 
     * @param databaseMajorVersion
     * @param meta
     * @param i
     * @param def
     * @throws SQLException
     */
    private void getJDBCMetaDataType(
			final int databaseMajorVersion,
			final ResultSetMetaData meta,
			int i,
			final DefinitionOfColumn def)
			throws SQLException {
			if(def.getColumnTypeName().equalsIgnoreCase("year")){
		    	def.setJDBCMetaDataType(JDBCMetaDataType.TINYINT);
			} else {
		    	def.setJDBCMetaDataType(JDBCMetaDataType.dataTypeOf(meta.getColumnType(i)));
			}
	}
    
    /**
     * MySQLに対応しては、YEAR型をTINYINTに置き換えます。
     * カラム型情報を戻します。
     * マルチテーブル対応
     * @param databaseMajorVersion
     * @param meta
     * @param i
     * @param def
     * @throws SQLException
     */
    protected void getJDBCMetaDataType(
			final ResultSetMetaData meta,
			int i,
			final DefinitionOfColumn def)
			throws SQLException {
			if(def.getColumnTypeName().equalsIgnoreCase("year")){
		    	def.setJDBCMetaDataType(JDBCMetaDataType.TINYINT);
			} else {
		    	def.setJDBCMetaDataType(JDBCMetaDataType.dataTypeOf(meta.getColumnType(i)));
			}
	}
    
    /**
     * DB メタデータからユニーク制約の情報を読み込み DTO に設定する。
     * <p>
     * ユニークインデックスが定義されている場合は、そのカラムが主キーであると
     * 副次的に判定します。<br />
     * プライマリキー制約によって主キーを定義している場合は、この制約が存在
     * しない場合が（多々）あります。
     * </p>
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setUniqueColumnToTableDefinitionDTO(
            final DatabaseMetaData meta, final TableIdDefinition id,
            final TableDefinitionDTO dto) throws DAOException {
        if (dto.isView()) {
            return;
        }

        final StringBuilder sql = new StringBuilder();
        sql.append("SELECT");
        sql.append("  b.column_name AS COLUMN_NAME");
        sql.append(" FROM");
        sql.append("  information_schema.table_constraints a,");
        sql.append("  information_schema.columns b");
        sql.append(" WHERE");
        sql.append(" a.table_schema = '" + id.getSchem() + "'");
        sql.append(" AND a.table_name = '" + id.getTable() + "'");
        sql.append(" AND a.constraint_type = 'UNIQUE'");
//        sql.append(" AND a.table_catalog = b.table_catalog");
        sql.append(" AND a.table_schema = b.table_schema");
        sql.append(" AND a.table_name = b.table_name");
//        sql.append(" AND a.constraint_name = b.constraint_name");

        getLogger().debug(sql.toString());

        final PreparedStatement st = getPreparedStatement(sql.toString());
        ResultSet rs = null;
        try {
            rs = st.executeQuery();

            while (rs.next()) {
            	final String name = rs.getString("COLUMN_NAME");
            	if (name != null && name.equals("") == false) {
            		final DefinitionOfColumn def = dto
            		.getDefinitionOfColumnMap().get(name);
            		def.setUnique(true);
            	}
            }
        } catch (SQLException e) {
        	// MI-E-0018=ユニークキー（Unique Key)の取得に失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0018");
        	getLogger().error(message, e);
        	throw new DAOException(message, e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                }
            }
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException e) {
                }
            }
        }

    }
    /**
     * DB メタデータから外部キーの情報を読み込み DTO に設定する。
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setFkKeysToTableDefinitionDTO(final DatabaseMetaData meta,
            final TableIdDefinition id, final TableDefinitionDTO dto)
            throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getImportedKeys(id.getSchem(),null, id.getTable());
            while (rs.next()) {
                dto.getDefinitionOfColumnMap().get(
                    rs.getString("FKCOLUMN_NAME")).setForeignKey(true);
            }
        } catch (final SQLException e) {
        	// MI-E-0006=外部キー(Foreign Key)の取得に失敗しました。
        	final String message = MessageUtils.getMessage("MI-E-0006");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    /**
     * カラム名一覧からテーブル定義 DTO を生成して戻します。
     *
     * @param idDef
     * @param columnNames
     * @return
     */
    private TableDefinitionDTO createDefaultTableDefinitionDTO(
            final TableIdDefinition idDef,
            final Map<Integer, String> columnNames) {
        final TableDefinitionDTO ret = new TableDefinitionDTO(idDef.getTable());
        for (final Iterator<String> ite = columnNames.values().iterator(); ite
            .hasNext();) {
            final String name = ite.next();
            final DefinitionOfColumn columnDef = new DefinitionOfColumn(name);
            columnDef.setTableId(idDef.getTableId());
            ret.getDefinitionOfColumnMap().put(name, columnDef);
        }
        return ret;
    }

    /**
     * DB メタデータからプライマリキーの情報を読み込み DTO に設定する。
     * <p>
     * プライマリキーで主キーが定義されている場合は、同時にユニークフラグも ON
     * しておきます。</p>
     *
     * @param meta
     * @param id
     * @param dto
     * @throws DAOException
     */
    private void setPrimaryKeysToTableDefinitionDTO(
            final DatabaseMetaData meta, final TableIdDefinition id,
            final TableDefinitionDTO dto) throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getPrimaryKeys(id.getSchem(), null, id.getTable());
            while (rs.next()) {
                final DefinitionOfColumn def = dto.getDefinitionOfColumnMap()
                    .get(rs.getString("COLUMN_NAME"));
                def.setPrimaryKey(true);
                def.setUnique(true);
            }
        } catch (final SQLException e) {
        	// MI-E-0010=データベースに操作対象のオブジェクトが存在しません
            final String message = MessageUtils.getMessage("MI-E-0010");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

    /**
     * Viewか否か
     *
     * @param meta
     * @param id
     * @param dto
     * @return
     * @throws DAOException
     */
    private boolean isView(
            final DatabaseMetaData meta,
            final TableIdDefinition id)
            throws DAOException {
        ResultSet rs = null;
        try {
            rs = meta.getTables(id.getSchem(), null, id.getTable(), new String[]{"VIEW"});
            if (rs.next()) {
                return true;
            } else {
                return false;
            }
        } catch (final SQLException e) {
        	// MI-E-0019=VIEW情報の取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0019");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                getLogger().warn(e);
            }
        }
    }

	/**
     * カラム名の一覧を取得して Map に設定して戻します。
     *
     * @param id
     * @return
     * @throws DAOException
     */
    private SortedMap<Integer, String> getComumnNames(
    		final TableIdDefinition id,
            final DatabaseMetaData meta)
            throws DAOException {
        final SortedMap<Integer, String> ret = new TreeMap<Integer, String>();
        try {
            final ResultSet rs = meta.getColumns(id.getSchem(),null, id.getTable(), null);
            int index = 1;
            while (rs.next()) {
                final String name = rs.getString("COLUMN_NAME");
                ret.put(index, name);
                index++;
            }
            rs.close();
        } catch (final SQLException e) {
        	// MI-E-0025=カラム名の一覧取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0025");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
        return ret;
    }

	@Override
	protected String createSelectWheresClause(
			SortedMap<Integer, SelectConditionItem> wheresMap) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

    /**
     * テーブル名の一覧を取得して戻す。
     * <p>
     * 現在接続を確立しているデータベース内の、アクセス可能なテーブル名の一覧を
     * 取得して戻します。
     * </p><p>
     * テーブル名の前方はスキーマ名で修飾されています。
     * <code>(スキーマ名).(テーブル名)</code>
     * </p>
     *
     * @return List&lt;(スキーマ名).(テーブル名)&gt;
     * @throws DAOException
     * @see jp.co.systemexe.dbu.dbace.persistance.dao.DatabaseSchemaDAO#getTableNameList()
     */
	public List<String> getTableNameList(final String condition) throws DAOException {
        final List<String> ret = new ArrayList<String>();
        try {
            final DatabaseMetaData meta = getDatabaseMetaData();
            final String[] tps = {"TABLE", "VIEW"};
            final ResultSet rs = meta.getTables(null, null, null, tps);
            while (rs.next()) {
                final String schem = rs.getString("TABLE_CAT");
                final String table = rs.getString("TABLE_NAME");
                if (schem == null || schem.equals("")) {
                	if (StringUtils.isNotEmpty(condition)) {
                      if (table.matches(".*\\Q" + condition + "\\E.*")) {
                    	  ret.add(table);
                      }
                	} else {
                		ret.add(table);
                	}
                } else {
                	String schemTable = schem.concat(".").concat(table);
                	if (StringUtils.isNotEmpty(condition)) {
                		if (schemTable.matches(".*\\Q" + condition + "\\E.*")) {
                      	  ret.add(schemTable);
                        }
                	} else {
                		ret.add(schemTable);
                	}
                }
            }
            rs.close();
            return ret;
        } catch (final SQLException e) {
        	// MI-E-0035=テーブル名の一覧取得に失敗しました。
            final String message = MessageUtils.getMessage("MI-E-0035");
            getLogger().error(message, e);
            throw new DAOException(message, e);
        }
	}
	@Override
	protected String ignoreNullColumns(final List<String> columns, final String columnType) {
//		final StringBuffer columnsBuff = new StringBuffer();
//		final StringBuffer bracketsBuff = new StringBuffer();
//		String dbFunc = "IFNULL";
//		int index = 0;
//		for (String name : colList) {
//			if (columnsBuff.length() > 0) {
//				columnsBuff.append(", ");
//			}
//
//			columnsBuff.append(dbFunc);
//			columnsBuff.append("(");
//			columnsBuff.append(name);
//
//			if(index >= colList.size() - 1){
//				columnsBuff.append(", ");
//				columnsBuff.append("null");
//			}
//
//			bracketsBuff.append(")");
//			index++;
//		}
//		columnsBuff.append(bracketsBuff);
//		return columnsBuff.toString();
		return null;
	}
	@Override
	protected String createFuncCheckNullSelectWheresClause(SelectConditionItem item) {
		// TODO Auto-generated method stub
		return null;
	}

}
