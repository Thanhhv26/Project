/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.library.util;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.ConvertUtilsBean;
import org.apache.commons.beanutils.converters.BigDecimalConverter;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.beanutils.converters.SqlDateConverter;
import org.apache.commons.beanutils.converters.SqlTimeConverter;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Bean utilities
 *
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 */
@SuppressWarnings("unchecked")
public final class BeanUtils implements Serializable {

	/**
	 * default serial version id
	 */
	private static final long serialVersionUID = 1L;

	/** logger */
    protected static Logger logger = LoggerFactory.getLogger(BeanUtils.class);

	/** 新規BeanUtilsBeanインスタンス */
	private static BeanUtilsBean beanUtilsBean = new BeanUtilsBean(
			new ConvertUtilsBean(), BeanUtilsBean.getInstance()
					.getPropertyUtils());

	/** コンバータ登録済みフラグ */
	private static boolean isRegisteredConverter = false;

	/**
	 * The JAVA primitive types array
	 */
	private static final Class<?>[][] primitiveTypes = {
			{ Byte.TYPE, Short.TYPE, Integer.TYPE, Long.TYPE, Float.TYPE, Double.TYPE, Boolean.TYPE,
					Character.TYPE },
			{ java.lang.Byte.class, java.lang.Short.class, java.lang.Integer.class,
					java.lang.Long.class, java.lang.Float.class, java.lang.Double.class,
					java.lang.Boolean.class, java.lang.Character.class }, };

	/**
	 * Gets a boolean value indicating the specified {@link Type} whether is a
	 * primitive type
	 *
	 * @param type
	 *            the type to check
	 *
	 * @return true for primitive type; else otherwise
	 */
	public static boolean isPrimitive(Type type) {
		if (type != null) {
			for (int i = 0; i < primitiveTypes[0].length; i++) {
				if (primitiveTypes[0][i].equals(type)) {
					return true;
				}
			}
		}
		return false;
	}
	/**
	 * Gets java.lang type of the specified primitive type
	 *
	 * @param primitiveType
	 *            the primitive type
	 *
	 * @return the java.lang type
	 */
	public static Class<?> getPrimitiveType(Class<?> primitiveType) {
		if (primitiveType != null && primitiveType.isPrimitive()) {
			for (int i = 0; i < primitiveTypes[0].length; i++) {
				if (primitiveTypes[0][i].equals(primitiveType)) {
					return primitiveTypes[1][i];
				}
			}
			return String.class;
		}
		return primitiveType;
	}

	/**
	 * 配列にセットされたBeanを指定クラスに転記する
	 *
	 * @param srcList
	 * @param clazz K(変換先クラス)
	 * @return T
	 */
//	public static <T, K> List<T> copyBeansList(List<K> srcList, Class<T> clazz) throws Exception {
//		return copyBeansList(srcList, clazz, (String[]) null);
//	}
//	public static <T, K> List<T> copyBeansList(List<K> srcList, Class<T> clazz, String...ignorePoperties) throws Exception {
//		  List<T> destDtos = new LinkedList<T>();
//		  if (!CollectionUtils.isEmpty(srcList)) {
//			  for(K src : srcList) {
//				  destDtos.add(copyBean(src, clazz, ignorePoperties));
//			  }
//		  }
//		  return destDtos;
//	}

	/**
	 * Beanを指定クラスに転記する
	 *
	 * @param bean
	 * @param clazz T(変換先クラス)
	 * @return T
	 */
//	public static <T, K> T copyBean(K src, Class<T> clazz) throws ReflectiveOperationException {
//		return copyBean(src, clazz, (String[]) null);
//	}
//	public static <T, K> T copyBean(K src, Class<T> clazz, String...ignorePoperties) throws ReflectiveOperationException {
//		T dest = null;
//		if (src != null) {
//			try {
//				dest = clazz.newInstance();
//				org.springframework.beans.BeanUtils.copyProperties(src, dest, ignorePoperties);
//			}
//			catch (InstantiationException | IllegalAccessException e) {
//				e.printStackTrace();
//				logger.error(e.getMessage(), e);
//				throw e;
//			}
//		}
//		return dest;
//	}

	/**
	 * Gets a boolean value indicating that the specified value whether is
	 * assignable from the specified class or is an instance of this class
	 *
	 * @param <T>
	 *            the instance type
	 * @param value
	 *            the value to check
	 * @param checkedCls
	 *            the class to check
	 *
	 * @return true for being an instance of the specified class; else otherwise
	 */
	public static <T> boolean isInstanceOf(Object value, Class<? extends T> checkedCls) {
		Class<?> valueClass = null;
		if (value != null) {
//			if (isPrimitive(value.getClass()))
//				valueClass = getPrimitiveType(valueClass);
//			else
			valueClass = value.getClass();
		}
		return isInstanceOf(valueClass, checkedCls);
	}
	/**
	 * Gets a boolean value indicating that the specified value whether is
	 * assignable from the specified class or is an instance of this class
	 *
	 * @param <T>
	 *            the instance type
	 * @param value
	 *            the value to check
	 * @param checkedCls
	 *            the class to check
	 *
	 * @return true for being an instance of the specified class; else otherwise
	 */
	public static <T> boolean isInstanceOf(Object value, Class<? extends T>...checkedClss) {
		if (ArrayUtils.isEmpty(checkedClss)) return false;
		for(Class<? extends T> checkedCls : checkedClss) {
			if (isInstanceOf(value, checkedCls)) return true;
		}
		return false;
	}
	/**
	 * Gets a boolean value indicating that the specified value whether is
	 * assignable from the specified class or is an instance of this class
	 *
	 * @param <T>
	 *            the instance type
	 * @param value
	 *            the value to check
	 * @param checkedCls
	 *            the class to check
	 *
	 * @return true for being an instance of the specified class; else otherwise
	 */
//	public static <T> boolean isInstanceOf(Class<?> valueClass, Class<? extends T>...checkedClss) {
//		if (valueClass == null || ArrayUtils.isEmpty(checkedClss)) return false;
//		for(Class<? extends T> checkedCls : checkedClss) {
//			if (isInstanceOf(valueClass, checkedCls)) return true;
//		}
//		return false;
//	}
	/**
	 * Gets a class in the specified classes array that is super or instance of the specified value
	 *
	 * @param <T>
	 *            the instance type
	 * @param value
	 *            the value to check
	 * @param checkedCls
	 *            the class to check
	 *
	 * @return the class in the specified classes array that is super or instance of the specified value.
	 * NULL for not found
	 */
//	public static <T> Class<? extends T> findInstanceOf(Object value, Class<? extends T>...checkedClss) {
//		if (ArrayUtils.isEmpty(checkedClss)) return null;
//		for(Class<? extends T> checkedCls : checkedClss) {
//			if (isInstanceOf(value, checkedCls)) return checkedCls;
//		}
//		return null;
//	}
	/**
	 * Gets a class in the specified classes array that is super or instance of the specified value
	 *
	 * @param <T>
	 *            the instance type
	 * @param value
	 *            the value to check
	 * @param checkedCls
	 *            the class to check
	 *
	 * @return the class in the specified classes array that is super or instance of the specified value.
	 * NULL for not found
	 */
//	public static <T> Class<? extends T> findInstanceOf(Class<?> valueClass, Class<? extends T>...checkedClss) {
//		if (valueClass == null || ArrayUtils.isEmpty(checkedClss)) return null;
//		for(Class<? extends T> checkedCls : checkedClss) {
//			if (isInstanceOf(valueClass, checkedCls)) return checkedCls;
//		}
//		return null;
//	}
	/**
	 * Gets a boolean value indicating that the specified value whether is
	 * assignable from the specified class or is an instance of this class
	 *
	 * @param <T>
	 *            the instance type
	 * @param valueClass
	 *            the value to check
	 * @param checkedCls
	 *            the class to check
	 *
	 * @return true for being an instance of the specified class; else otherwise
	 */
	public static <T> boolean isInstanceOf(Class<?> valueClass, Class<? extends T> checkedCls) {
		// if valid
		if ((valueClass != null) && (checkedCls != null)) {
			// if checked class is not an interface
			if (!checkedCls.isInterface()) {
				// if object class is not an interface
				if (!valueClass.isInterface()) {
					return (checkedCls.isAssignableFrom(valueClass)
						|| checkedCls == valueClass
						|| checkedCls.equals(valueClass));
				}
				// if object class is an interface
				else {
					Class<?>[] arrIntClzz = valueClass.getInterfaces();
					Class<?>[] chkArrIntClzz = checkedCls.getInterfaces();
					if (!ArrayUtils.isEmpty(arrIntClzz) && !ArrayUtils.isEmpty(chkArrIntClzz)) {
						for(Class<?> intClzz : arrIntClzz) {
							boolean isIntanced = isInstanceOf(intClzz, chkArrIntClzz);
							if (isIntanced) return isIntanced;
						}
					}
				}
			}
			// if checked class is an interface
			else {
				return (checkedCls.isAssignableFrom(valueClass)
					|| checkedCls == valueClass
					|| checkedCls.equals(valueClass));
			}
		}
		return false;
	}

	public static <T> T safeType(Object value, Class<? extends T> clazz) {
		return (value == null || clazz == null || !isInstanceOf(value, clazz) ? null : (T) value);
	}

	public static <T, K> void copyBeans(List<T> dest, List<K> orig, Class<T> destClzz) throws InstantiationException, IllegalAccessException {

		if (dest == null || orig == null) {
			return;
		}

		for(K beanOrig : orig) {
			T beanDest = destClzz.newInstance();
			copyProperties(beanDest, beanOrig);
			dest.add(beanDest);
		}
	}

	/**
	 * コピー先、コピー元で同じプロパティ名に対して値をコピーします。
	 *
	 * @param dest
	 *            コピー先Bean
	 * @param orig
	 *            コピー元Bean
	 * @see org.apache.commons.beanutils.BeanUtilsBean.BeanUtils#copyProperties(Object
	 *      dest, Object orig)
	 */
	public static void copyProperties(Object dest, Object orig) {

		if (dest == null || orig == null) {
			return;
		}

		if (!isRegisteredConverter) {
			isRegisteredConverter = true;
			beanUtilsBean.getConvertUtils().register(new DateConverter(null),
					java.util.Date.class);
			beanUtilsBean.getConvertUtils().register(
					new SqlDateConverter(null), java.sql.Date.class);
			beanUtilsBean.getConvertUtils().register(
					new SqlTimeConverter(null), java.sql.Timestamp.class);
			beanUtilsBean.getConvertUtils().register(
					new BigDecimalConverter(null), BigDecimal.class);
		}

		try {
			beanUtilsBean.copyProperties(dest, orig);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		if (logger.isDebugEnabled()) {
			// TODO van-trung
			//writeLog(dest, orig);
		}
	}
/*
	private static void writeLog(Object dest, Object orig) {

		logger.debug("Bean copy DEST=" + dest.getClass().getName() + " SRC="
				+ orig.getClass().getName());

		StringBuffer sb = new StringBuffer();
		sb.append("\r\n");

		try {
			sb.append(testBeanCopy(dest.getClass(), orig.getClass()));
		} catch (Exception e) {
			logger.debug(e.getMessage(), e);
		}

		sb.append("\r\n");
		ObjectMapper mapper = new ObjectMapper();
		sb.append("DEST VALUE: " + dest.getClass().getName());
		sb.append("\r\n");
		try {
			sb.append(mapper.writeValueAsString(dest));
		} catch (IOException e) {
			// throw new RuntimeException("未実装です。");
		}
		sb.append("\r\n");

		sb.append("SRC VALUE: " + orig.getClass().getName());
		sb.append("\r\n");
		try {
			sb.append(mapper.writeValueAsString(orig));
		} catch (IOException e) {
			// throw new RuntimeException("未実装です。");
		}
		sb.append("\r\n");
		sb.append("********************************************");

		logger.debug(sb.toString());
	}

	private static String testBeanCopy(Class<? extends Object> desClass,
			Class<? extends Object> srcClass) {

		StringBuffer sb = new StringBuffer();

		try {
			StackTraceElement[] stackTraceElements = Thread.currentThread()
					.getStackTrace();
			if (stackTraceElements != null && stackTraceElements.length > 0) {

				for (int i = 3; i < 4 && i < stackTraceElements.length; i++) {

					StackTraceElement element = stackTraceElements[i];
					sb.append("Bean copy code : ");
					sb.append(element.toString());
					sb.append("\r\n");

				}

			}
		} catch (Exception e) {
			sb.append(e.getMessage());
			sb.append("\r\n");
		}

		try {
			sb.append("\r\n"
					+ "*********************************************************");
			sb.append("\r\n" + desClass.getName() + " <-- "
					+ srcClass.getName());

			Map<String, String> desMap = extractClass(desClass);
			Map<String, String> srcMap = extractClass(srcClass);

			boolean valid = true;

			Set<String> deskKeySet = desMap.keySet();
			if (deskKeySet != null && deskKeySet.size() > 0) {
				sb.append("\r\n"
						+ "----- DESTINATION & SOURCE (same name) -----");
				for (String key : deskKeySet) {
					if (srcMap.containsKey(key)) {
						String desType = desMap.get(key);
						String srcType = srcMap.get(key);
						sb.append("\r\n"
								+ " ( "
								+ String.valueOf(desType.equals(srcType))
										.toUpperCase() + " )   "
								+ padSpace(key) + " : " + desType + " <-- "
								+ srcType);

						if (!desType.equals(srcType)) {
							valid = false;
						}
					}
				}

				sb.append("\r\n" + "----- Only on DESTINATION -----");
				for (String key : deskKeySet) {
					if (!srcMap.containsKey(key)) {
						sb.append("\r\n" + " ( WARN )   " + padSpace(key)
								+ " : " + desMap.get(key) + " <-- NULL ");
					}
				}
			}

			Set<String> srcKeySet = srcMap.keySet();
			if (srcKeySet != null && srcKeySet.size() > 0) {
				sb.append("\r\n" + "----- Only on SOURCE -----");
				for (String key : srcKeySet) {
					if (!desMap.containsKey(key)) {
						sb.append("\r\n" + " ( WARN )   " + padSpace(key)
								+ " : " + " ??? <-- " + srcMap.get(key));
					}
				}
			}

			sb.append("\r\n" + "*** RESULT *** "
					+ String.valueOf(valid).toUpperCase());
			sb.append("\r\n" + desClass.getName() + " <-- "
					+ srcClass.getName());
		} catch (Exception e) {
			sb.append(e.getMessage());
			sb.append("\r\n");
		}

		return sb.toString();

	}

	private static Map<String, String> extractClass(
			Class<? extends Object> targetClass) {

		Map<String, String> map = new HashMap<String, String>();

		Field[] listField = targetClass.getDeclaredFields();

		if (listField != null && listField.length > 0) {
			for (Field field : listField) {
				map.put(field.getName(), field.getType().getName());
			}
		}

		return map;
	}

	private static String padSpace(String key) {

		final int len = 30;
		return StringUtils.rightPad(key, len);
	}
*/
	/**
	 * Gets the annotation of the specified entity class and annotation class
	 *
	 * @param targetClass
	 *            the instance class to check
	 * @param annotationClass
	 *            the annotation class to check
	 *
	 * @return the annotation of the specified entity class and annotation class
	 */
//	public static <T> T getClassAnnotation(Class<?> targetClass, Class<? extends T> annotationClass) {
//		T annotation = null;
//		if (targetClass != null) {
//			for (Class<?> clazz = targetClass; !Object.class.equals(clazz); clazz = clazz.getSuperclass()) {
//				for (Annotation anno : clazz.getAnnotations()) {
//					if (anno != null && isInstanceOf(anno.annotationType(), annotationClass)) {
//						annotation = (T) anno;
//						break;
//					}
//				}
//				if (annotation != null) break;
//			}
//		}
//		return annotation;
//	}
	/**
	 * Gets the annotations of the methods in the specified entity class and annotation class
	 *
	 * @param targetClass
	 *      the instance class to check
	 * @param methodName
	 *		the method name to parse. NULL for getting all
	 * @param annotationClasses
	 *		the annotation class to check
	 *
	 * @return the annotations list of the specified method
	 */
//	public static List<? extends Annotation> getMethodAnnotations(Class<?> targetClass, String methodName, Class<?>...annotationClasses) {
//		List<Annotation> annotations = new LinkedList<Annotation>();
//		if (targetClass != null) {
//			for(Method method : targetClass.getMethods()) {
//				if (org.springframework.util.StringUtils.hasText(methodName)
//						&& !methodName.equalsIgnoreCase(method.getName())) continue;
//				for (Annotation annotation : method.getAnnotations()) {
//					if (annotation != null && isInstanceOf(annotation.annotationType(), annotationClasses)) {
//						annotations.add(annotation);
//					}
//				}
//			}
//		}
//		return annotations;
//	}
	/**
	 * Gets the annotation of the methods in the specified entity class and annotation class
	 *
	 * @param targetClass
	 *      the instance class to check
	 * @param methodName
	 *		the method name to parse. NULL for getting all
	 * @param annotationClass
	 *		the annotation class to check
	 *
	 * @return the annotations list of the specified method
	 */
//	public static <T> T getMethodAnnotation(Class<?> targetClass, String methodName, Class<T> annotationClass) {
//		if (targetClass != null && org.springframework.util.StringUtils.hasText(methodName)) {
//			for(Method method : targetClass.getMethods()) {
//				if (!methodName.equalsIgnoreCase(method.getName())) continue;
//				for (Annotation anno : method.getAnnotations()) {
//					if (anno != null && isInstanceOf(anno.annotationType(), annotationClass)) {
//						return (T) anno;
//					}
//				}
//			}
//		}
//		return null;
//	}
	/**
	 * Gets a boolean value indicating that specified object whether is collection
	 * of the item class<br/>
	 * <b><i>(* NOTE: In empty collection, this function not accepts the empty collection)</i></b>
	 *
	 * @param collection
	 * 		the object to check
	 * @param itemClass
	 * 		the item class to check
	 *
	 * @return true for collection; else false
	 */
//	public static boolean isCollectionOf(Object collection, Class<?> itemClass) {
//		return (isInstanceOf(collection, Collection.class)
//				&& !CollectionUtils.isEmpty((Collection<?>) collection)
//				&& isInstanceOf(CollectionUtils.findCommonElementType((Collection<?>) collection), itemClass));
//	}
}
