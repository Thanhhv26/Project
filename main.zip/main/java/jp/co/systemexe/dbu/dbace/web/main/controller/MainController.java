/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.main.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jp.co.systemexe.dbu.dbace.web.common.PageConst;
import jp.co.systemexe.dbu.dbace.web.common.controller.AbstractController;

/**
 * @author systemexe
 * @version 1.0 Dec 01, 2016
 *
 */
@RestController
@RequestMapping(value = { "/web", "/main", "/web/main" })
public class MainController extends AbstractController {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Main - menu screen
	 *
	 * @return
	 */
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView index(
			HttpServletRequest request,
			@RequestParam(value = "h", required = false) boolean home) {
		// show view
		ModelAndView mav = new ModelAndView(PageConst.SCREEN_DASHBOARD);
		//Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		//HttpSession session = request.getSession(true); //create a new session
		// put the UserDetails object here.
		//session.setAttribute("myUserDetails", principal);
		return mav;
	}

}