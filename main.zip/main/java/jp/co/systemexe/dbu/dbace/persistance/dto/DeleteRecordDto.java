package jp.co.systemexe.dbu.dbace.persistance.dto;

import jp.co.systemexe.dbu.dbace.presentation.dto.UserInfo;

public class DeleteRecordDto implements InputDto{
	private DbConnectInfomationDTO dbConnectInfomationDTO;
	@Override
	public void setDbConnectInfomationDTO(DbConnectInfomationDTO dbConnectInfomationDTO) {
		this.dbConnectInfomationDTO = dbConnectInfomationDTO;
	}

	@Override
	public DbConnectInfomationDTO getDbConnectInfomationDTO() {
		return dbConnectInfomationDTO;
	}

	@Override
	public void setUserInfo(UserInfo userInfo) {
		// TODO Auto-generated method stub

	}

	@Override
	public UserInfo getUserInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setTableDefinitionDTO(TableDefinitionDTO tableDef) {
		// TODO Auto-generated method stub

	}

	@Override
	public TableDefinitionDTO getTableDefinitionDTO() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setTableFormDTO(TableFormDTO tableForm) {
		// TODO Auto-generated method stub

	}

	@Override
	public TableFormDTO getTableFormDTO() {
		// TODO Auto-generated method stub
		return null;
	}

}
