/**
 * Copyright(c) SystemEXE corp. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.web.repository.dto;
import lombok.Data;
/**
 * @author tu-lenh
 * @version 0.0.0
 */
@Data
public class ColumnChangeUseCase {
	private String DELETE_COLUMN_USE_RELATION_SCREEN;
	private String DELETE_COLUMN_USE_ITEM_COLS;
	private String COLUMN_TYPE_CHANGE_USE_ITEM_COLS_LISTNO1__TABLES_TABLE_ITEM;
	private String COLUMN_ADD_PK_USE_TABLES_TABLE_ITEM;
	private String COLUMN_DELETE_PK_USE_TABLES_TABLE_ITEM;
}