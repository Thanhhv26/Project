/**
 * @Copyright - 2015 SystemEXE-VN
 */
package jp.co.systemexe.dbu.dbace.library.enums;
import java.util.HashMap;
import java.util.Map;
/**
 * @author tu-lenh
 *
 */
public enum AuthenticationEnum {
	U_PRINCIPAL_REQUIRED("uPrincipalRequired"),
	P_PRINCIPAL_REQUIRED("pPrincipalRequired"),
	LK_PRINCIPAL_REQUIRED("lkPrincipalRequired"),
	VALIDLK_PRINCIPAL_REQUIRED("validlkPrincipalRequired"),
	NOTEXPIREDLK_PRINCIPAL_REQUIRED("notexpiredlkPrincipalRequired"),
	REPOSITORY_NOT_EXIST("repositoryNotExist"),
	CONTENT_REPOSITORY_INVALID("contentRepositoryInvalid"),
	VALID_BACKUP_REPOSITORY("validBackupRepository"),
	INCORRECTUP_PRINCIPAL_REQUIRED("incorrectupPrincipalRequired");

    boolean isValidFormatLK = false;
    boolean isNotExpiredLK = false;
    boolean isInCorrectUP = false;

	private String authCode;
	private static Map<String, AuthenticationEnum> authCodeMap;

	static {
		authCodeMap = new HashMap<String, AuthenticationEnum>();
		for (final AuthenticationEnum authEnum : values()) {
			authCodeMap.put(authEnum.getAuthCode(), authEnum);
		}
	}

	/**
	 * @param authCode
	 */
	private AuthenticationEnum(String authCode) {
		this.authCode = authCode;
	}

	/**
	 * authCodeと一致する、AuthenticationEnumを返す。
	 *
	 * @param authCode
	 * @return AuthenticationEnum
	 * @throws IllegalArgumentException
	 *             一致する値がない場合。
	 */
	public static AuthenticationEnum authCodeMapOf(final String authCode) {
		if (null == authCode || "".equals(authCode)) {
			return null;
		}
		if (authCodeMap.containsKey(authCode)) {
			return authCodeMap.get(authCode);
		}
		return null;
	}

	/**
	 * @return the authCode
	 */
	public String getAuthCode() {
		return authCode;
	}

	/**
	 * @param authCode the authCode to set
	 */
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

}
