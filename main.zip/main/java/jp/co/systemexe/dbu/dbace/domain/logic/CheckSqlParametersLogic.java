/**
 * Copyright(C) 2007 System-EXE,Inc. All Rights Reserved.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.HashMap;
import java.util.Map;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;

/**
 * プルダウンリスト用の SQL パラメータを検証するロジック。
 * <p>
 * プルダウンリストの表示値を SQL を発行して動的に取得するための SQL 定義の際に、
 * 画面上からテスト用のパラメータを入力します。<br />
 * このビジネスロジックはそのパラメータ指定文を検証、デコードし
 * プレゼンテーション層に戻すためのビジネスロジックです。
 * </p>
 *
 * @author	EXE 相田 一英
 * @version 0.0.0
 */
public class CheckSqlParametersLogic extends BaseApplicationDomainLogic {

    /**
     * SQL パラメータ指定文をデコードし、パラメータと置換値のマップを戻します。
     * <p>
     * 
     * </p><p>
     * パラメータ指定文の書式は、
     * <ol>
     *  <li>個々のパラメータ指定はセミコロン「;」で区切られている
     *      （終端への付加は問わない）。</li>
     *  <li>パラメータと指定値はイコール「=」で区切られている。</li>
     *  <li>パラメータ値はアットマーク「@」が先頭に付加された文字列。</li>
     *  <li>指定値は文字であってもシングルクォーテーション「'」を付加する必要
     *      は無い（あっても無視する）。</li>
     *  <li>パラメータの並び順や重複には意味が無い。</li>
     * </ol>
     * とします。
     * </p>
     * 
     * @param sqlParameters SQL パラメータ指定文
     * @return パラメータと指定値を設定したマップ
     * @throws ApplicationDomainLogicException
     */
    public Map<String, String> decode(final String sqlParameters)
            throws ApplicationDomainLogicException {
        final Map<String, String> ret = new HashMap<String, String>();
        try {
            final String[] clause = sqlParameters.split(";");
            for (int i = 0; i < clause.length; i++) {
                final String[] words = clause[i].split("=", 2);
                final String param = words[0].trim();
                if (param.substring(0, 1).equals("@") == false) {
                	// MI-E-0012=SQL パラメータ({0})の先頭に @ が付加されていません。
                	final String args[] = {param};
                    throw new ApplicationDomainLogicException(
                    		MessageUtils.getMessage("MI-E-0012", args));
                }
                if (ret.containsKey(param) == false) {
                    ret.put(param, words[1].trim());
                }
            }
            return ret;
        } catch (final ApplicationDomainLogicException e) {
            throw e;
        } catch (final Exception e) {
        	// MI-E-0013=SQL パラメータ指定文の書式が間違っています。
            throw new ApplicationDomainLogicException(
            		MessageUtils.getMessage("MI-E-0013"));
        }
    }

    /**
     * CheckSqlParametersLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public CheckSqlParametersLogic() {
        return;
    }
}
