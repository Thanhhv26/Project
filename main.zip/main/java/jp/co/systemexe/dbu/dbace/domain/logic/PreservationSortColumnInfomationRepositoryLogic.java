/**
 * Copyright(C) 2008 System-EXE,Inc.
 */
package jp.co.systemexe.dbu.dbace.domain.logic;

import java.util.ArrayList;
import java.util.SortedMap;

import jp.co.systemexe.dbu.dbace.common.message.MessageUtils;
import jp.co.systemexe.dbu.dbace.domain.BaseApplicationDomainLogic;
import jp.co.systemexe.dbu.dbace.domain.exception.ApplicationDomainLogicException;
import jp.co.systemexe.dbu.dbace.persistance.dao.TableFormDAO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableFormDTO;
import jp.co.systemexe.dbu.dbace.persistance.dto.TableItemDTO;
import jp.co.systemexe.dbu.dbace.persistance.exception.DAOException;
import jp.co.systemexe.dbu.dbace.persistance.xml.entity.repository.TableForm;
import jp.co.systemexe.dbu.dbace.web.common.AppConst;
import jp.co.systemexe.dbu.dbace.web.creation.dto.ItemDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.SortDto.RowDto;
import jp.co.systemexe.dbu.dbace.web.creation.dto.TableFormDto;
import jp.co.systemexe.dbu.dbace.web.item.dto.SelectItemDTOSave;

/**
 * カラムの表示順の保存処理。
 * <p>
 * カラムの表示順をリポジトリに対して更新します。</p>
 *
 * @author EXE 島田 雄一郎
 * @version 0.0.0
 */

public class PreservationSortColumnInfomationRepositoryLogic
        extends BaseApplicationDomainLogic {

    /**
     * カラムの表示順の保存処理。
     * <p>
     * カラムの表示順をリポジトリに対して更新します。</p>
     *
     * @param connectDefinitionId 接続定義ID
     * @param tableFormId テーブルフォームID
     * @param columnId カラムID
     * @param tableItemDto カラムの表示順Map
     * @throws ApplicationDomainLogicException
     */
    public void save(
            final String connectDefinitionId,
            final String tableFormId,
            final SortedMap<Integer, String> sortColumnMap)
            throws ApplicationDomainLogicException {

        final TableFormDAO dao = createTableFormDAO();
        final TableFormDTO tableFormDto;
        try {
            tableFormDto = dao
                .getTableFormDTO(connectDefinitionId, tableFormId);
            if (tableFormDto == null) {
            	// MI-E-0033=テーブル情報が存在しません。
                throw new ApplicationDomainLogicException(
                		MessageUtils.getMessage("MI-E-0033"));
            }
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

        setSortColumnInformationToTableForm(tableFormDto, sortColumnMap);

        try {
            dao.save(connectDefinitionId, tableFormDto);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

    }

    /**
     * カラムの表示順の保存処理。
     * <p>
     * カラムの表示順をリポジトリに対して更新します。</p>
     *
     * @param connectDefinitionId 接続定義ID
     * @param tableFormId テーブルフォームID
     * @param columnId カラムID
     * @param tableItemDto カラムの表示順Map
     * @throws ApplicationDomainLogicException
     */
    public void update(
            final String connectDefinitionId,
            TableFormDTO tableFormDto)
            throws ApplicationDomainLogicException {

		final TableFormDAO dao = createTableFormDAO();
		if (tableFormDto == null) {
			// MI-E-0033=テーブル情報が存在しません。
			throw new ApplicationDomainLogicException(MessageUtils.getMessage("MI-E-0033"));
		}
		TableFormDto tableFormDtoMulti = getTableMulti(connectDefinitionId, tableFormDto.getTableFormId());
		try {
			if (AppConst.MULTI_TABLE.equals(tableFormDtoMulti.getType())) {
				tableFormDtoMulti.setLabel(tableFormDto.getTableFormLabel());
				tableFormDtoMulti.setOrderdesc(tableFormDto.getOrderDesc());
				for (TableItemDTO tableItemDto : tableFormDto.getTableItemMap().values()) {
					for (ItemDto itemDto : tableFormDtoMulti.getItemDtoList()) {
						if (tableItemDto.getItemId().equals(itemDto.getId())) {
							itemDto.setSortIndex(tableItemDto.getSortIndex());
						}
					}
				}
				tableFormDtoMulti.getSortDto().setRowDto(new ArrayList());
				for(Integer id:tableFormDto.getSortConditionMap().keySet()){
					String value = tableFormDto.getSortConditionMap().get(id);
					RowDto rowDto = new RowDto();
					rowDto.setId(id.toString());
					rowDto.setValue(value);
					tableFormDtoMulti.getSortDto().getRowDto().add(rowDto);
				}

				dao.saveTableMulti(connectDefinitionId, tableFormDtoMulti);
			} else {
				dao.save(connectDefinitionId, tableFormDto);
			}
			// dao.saveTableMulti(connectDefinitionId, tableFormDto);
		} catch (final DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}
	}

/*	private void setItemChange(ItemDto retMulti,SelectItemDTOSave search) {
		//set info change
		retMulti.setSortIndex(search);
	}*/

    public void saveMulti(String connectDefinitionId, String tableFormId, SelectItemDTOSave search)
            throws ApplicationDomainLogicException {
        final TableFormDAO dao = createTableFormDAO();
        TableFormDto tableFormDto = getTableMulti(connectDefinitionId,tableFormId);
        if (tableFormDto.getId() == null) {
        	// MI-E-0033=テーブル情報が存在しません。
            throw new ApplicationDomainLogicException(MessageUtils.getMessage("MI-E-0033"));
        }
        try {
        	for(int i=0;i < tableFormDto.getItemDtoList().size();i++){
        		ItemDto itemDto = tableFormDto.getItemDtoList().get(i);
        		if(itemDto.getId().equals(search.getItemId())){
        			//setItemChange(itemDto,search);
        			break;
        		}
        	}
        	dao.saveTableMulti(connectDefinitionId, tableFormDto);
        } catch (DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }

    }

	public TableFormDto getTableMulti(String connectDefinitionId, String tableFormMultiTableId) throws ApplicationDomainLogicException {
		// TODO Auto-generated method stub
		AcquisitionOfTableLogic acquisitionOfTableLogic = new AcquisitionOfTableLogic();
		try {
			TableFormDAO tableFormDAO = acquisitionOfTableLogic.createTableFormDAO();
			TableFormDto dto = new TableFormDto();
			dto.setId(tableFormMultiTableId);
			TableForm tableForm = tableFormDAO.getTargetTableFormMulti(connectDefinitionId, dto);
			return new TableFormDto(tableForm);
		} catch (ApplicationDomainLogicException | DAOException e) {
			throw new ApplicationDomainLogicException(e.getMessage(), e);
		}
	}
    /**
     * PreservationFormComponentInfomationRepositoryLogic の生成。
     * <p>コンストラクタ。</p>
     */
    public PreservationSortColumnInfomationRepositoryLogic() {
        return;
    }

    /**
     * テーブルフォーム DAO を生成して戻す。
     *
     * @return TableFormDAO
     * @throws ApplicationDomainLogicException
     */
    private TableFormDAO createTableFormDAO()
            throws ApplicationDomainLogicException {
        try {
            return (TableFormDAO)createDAO("TableFormDAO");
        } catch (final DAOException e) {
            throw new ApplicationDomainLogicException(e.getMessage(), e);
        }
    }

    /**
     * テーブルフォーム DTOにカラム表示順を設定します。
     *
     * @param tableFormDto
     * @param sortColumnMap
     */
    private void setSortColumnInformationToTableForm(
            final TableFormDTO tableFormDto,
            final SortedMap<Integer, String> sortColumnMap) {
        for (final Integer index : sortColumnMap.keySet()) {
            final String columnId = sortColumnMap.get(index);
            final TableItemDTO tableItemDTO
                = tableFormDto.getTableItemMap().get(columnId);
            tableItemDTO.setSortIndex(index);
        }
        tableFormDto.setSortConditionMap(sortColumnMap);
    }
}
